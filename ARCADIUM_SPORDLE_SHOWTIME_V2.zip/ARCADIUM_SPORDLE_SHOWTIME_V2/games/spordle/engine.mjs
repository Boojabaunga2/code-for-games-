import {DICTIONARY,ANSWERS} from './words.mjs';
export const COLORS=['red','blue','green','yellow','pink','white'];
export const HEX=['#ff626f','#58acff','#64efaa','#ffe270','#ff8fe0','#e1edff'];
export const NAMES=['Dr. Rocket','Checkmate','Gizmo','Ada Numbers','Lexica','Prof. Scatter'];
export const ROWS=['QWERTYUIOP'.split(''),'ASDFGHJKL'.split(''),['ENTER',...'ZXCVBNM','BACK']];
export function grade(guess,answer){
 const result=Array(5).fill(0),left={};
 for(let i=0;i<5;i++)if(guess[i]===answer[i])result[i]=2;else left[answer[i]]=(left[answer[i]]||0)+1;
 for(let i=0;i<5;i++)if(!result[i]&&left[guess[i]]){result[i]=1;left[guess[i]]--;}
 return result;
}
export class Spordle {
 constructor({rng=Math.random,limit=120}={}){this.rng=rng;this.limit=limit;this.epoch=0;this.lobby();}
 lobby(){this.epoch++;this.phase='lobby';this.paused=false;this.round=0;this.elapsed=0;this.players=COLORS.map((color,i)=>({i,color,name:NAMES[i],human:false,alive:true,used:false,place:null,guesses:[],draft:'',keys:{},cursor:[0,0],solved:null,done:false,message:'',reaction:0}));this.history=[];this.challenge=null;this.winner=null;this.deck=[];this.revision=0;}
 join(i){if(this.phase==='lobby'){this.players[i].human=true;return true;}return false;}
 start(){if(this.phase!=='lobby')return false;this.deck=[...ANSWERS];for(let n=this.deck.length-1;n>0;n--){const k=Math.floor(this.rng()*(n+1));[this.deck[n],this.deck[k]]=[this.deck[k],this.deck[n]];}this.nextRound();return true;}
 nextRound(){this.round++;this.answer=this.deck.pop()||ANSWERS[0];this.elapsed=0;this.phase='countdown';this.countdown=3;this.challenge=null;this.order=[];this.revision++;
  for(const p of this.players){Object.assign(p,{guesses:[],draft:'',keys:{},cursor:[0,0],solved:null,done:!p.alive,message:'',reaction:0});p.cpuAt=9+this.rng()*18;}
 }
 get turnId(){return `${this.epoch}:${this.round}:${this.phase}:${this.revision}:${this.paused?1:0}`;}
 togglePause(){if(!['lobby','finished'].includes(this.phase)){this.paused=!this.paused;this.revision++;}}
 edit(i,key){const p=this.players[i];if(!p.human||!p.alive||p.done||this.phase!=='play'||this.paused)return false;
  p.message='';if(key==='BACK'){p.draft=p.draft.slice(0,-1);return true;}
  if(key==='ENTER')return this.submit(i);
  if(/^[A-Z]$/.test(key)&&p.draft.length<5){p.draft+=key;return true;}return false;
 }
 submit(i){const p=this.players[i];if(this.phase!=='play'||this.paused||p.done||!p.alive)return false;
  if(p.draft.length!==5){p.message='Five letters, genius!';p.reaction=1;return false;}
  if(!DICTIONARY.has(p.draft)){p.message='Not in the included word list';p.reaction=1;return false;}
  const marks=grade(p.draft,this.answer),word=p.draft;p.guesses.push({word,marks,at:this.elapsed});
  for(let n=0;n<5;n++)p.keys[word[n]]=Math.max(p.keys[word[n]]??-1,marks[n]);
  p.draft='';p.reaction=1.5;if(word===this.answer){p.solved=this.elapsed;p.done=true;p.message='EUREKA!';}else if(p.guesses.length===6){p.done=true;p.message='Six guesses used';}else p.message='Keep thinking…';
  if(this.players.filter(p=>p.alive).every(p=>p.done))this.endRound();return true;
 }
 move(i,dx,dy){const p=this.players[i];if(this.phase!=='play'||this.paused||!p.human||!p.alive||p.done)return;
  let [r,c]=p.cursor;if(dy){r=(r+dy+3)%3;c=Math.min(c,ROWS[r].length-1);}if(dx)c=(c+dx+ROWS[r].length)%ROWS[r].length;p.cursor=[r,c];
 }
 best(p){let best=[0,0,Infinity];for(const g of p.guesses){const a=g.marks.filter(m=>m===2).length,b=g.marks.filter(m=>m===1).length;if(a>best[0]||(a===best[0]&&b>best[1])||(a===best[0]&&b===best[1]&&g.at<best[2]))best=[a,b,g.at];}return best;}
 rank(a,b){if(a.solved!==null||b.solved!==null){if(a.solved===null)return 1;if(b.solved===null)return -1;if(a.solved!==b.solved)return a.solved-b.solved;}else{const x=this.best(a),y=this.best(b);if(x[0]!==y[0])return y[0]-x[0];if(x[1]!==y[1])return y[1]-x[1];if(x[2]!==y[2])return x[2]-y[2];}return ((a.i-this.round+6)%6)-((b.i-this.round+6)%6);}
 endRound(){if(this.phase!=='play')return;this.order=this.players.filter(p=>p.alive).sort((a,b)=>this.rank(a,b)).map(p=>p.i);const loser=this.order.at(-1),opponent=this.order.at(-2);this.players[loser].alive=false;this.players[loser].place=this.order.length;this.phase='results';this.revision++;this.challenge={challenger:loser,opponent,offer:!this.players[loser].used,attempt:1,submitted:{},reveal:null,outcome:null};this.history.push({round:this.round,answer:this.answer,order:[...this.order],elapsed:this.elapsed});}
 requestChallenge(i){const c=this.challenge;if(this.phase!=='results'||this.paused||!c?.offer||i!==c.challenger||this.players[i].used)return false;c.offer=false;this.players[i].used=true;this.phase='flip';this.revision++;return true;}
 pass(i){const c=this.challenge;if(this.phase!=='results'||this.paused||i!==c?.challenger)return false;c.offer=false;this.finishElimination();return true;}
 coin(i,value){const c=this.challenge;if(this.phase!=='flip'||this.paused||!['green','red'].includes(value)||![c.challenger,c.opponent].includes(i)||c.submitted[i])return false;c.submitted[i]=value;if(c.submitted[c.challenger]&&c.submitted[c.opponent]){c.reveal={...c.submitted};c.outcome=c.reveal[c.challenger]===c.reveal[c.opponent]?'tie':c.reveal[c.challenger]==='green'?'win':'lose';this.phase='reveal';this.revision++;}return true;}
 continue(){if(this.paused)return false;const c=this.challenge;if(this.phase==='reveal'){if(c.outcome==='tie'){c.attempt++;c.submitted={};c.reveal=null;c.outcome=null;this.phase='flip';this.revision++;return true;}if(c.outcome==='win'){const a=this.players[c.challenger],b=this.players[c.opponent];a.alive=true;a.place=null;b.alive=false;b.place=this.order.length;}this.finishElimination();return true;}if(this.phase==='results'&&!c.offer){this.finishElimination();return true;}return false;}
 finishElimination(){if(this.players.filter(p=>p.alive).length===1){this.winner=this.players.find(p=>p.alive).i;this.players[this.winner].place=1;this.phase='finished';this.revision++;}else this.nextRound();}
 update(dt){if(this.paused||!Number.isFinite(dt)||dt<0)return;
  for(const p of this.players)p.reaction=Math.max(0,p.reaction-dt);
  if(this.phase==='countdown'){this.countdown-=dt;if(this.countdown<=0){this.phase='play';this.revision++;}return;}
  if(this.phase!=='play')return;this.elapsed=Math.min(this.limit,this.elapsed+dt);
  for(const p of this.players){if(this.phase!=='play')break;if(p.alive&&!p.human&&!p.done&&this.elapsed>=p.cpuAt){const candidates=ANSWERS.filter(w=>p.guesses.every(g=>JSON.stringify(grade(g.word,w))===JSON.stringify(g.marks)));p.draft=candidates[Math.floor(this.rng()*candidates.length)]||this.answer;this.submit(p.i);p.cpuAt=this.elapsed+8+this.rng()*20;}}
  if(this.phase==='play'&&this.elapsed>=this.limit)this.endRound();
 }
 publicState(){const c=this.challenge;return {phase:this.phase,paused:this.paused,round:this.round,elapsed:this.elapsed,limit:this.limit,countdown:this.countdown,winner:this.winner,answer:['results','flip','reveal','finished'].includes(this.phase)?this.answer:null,order:this.order||[],challenge:c?{challenger:c.challenger,opponent:c.opponent,offer:c.offer,attempt:c.attempt,reported:Object.keys(c.submitted).map(Number),reveal:c.reveal,outcome:c.outcome}:null,players:this.players.map(p=>({i:p.i,color:p.color,name:p.name,human:p.human,alive:p.alive,used:p.used,place:p.place,attempts:p.guesses.length,solved:p.solved,done:p.done,reaction:p.reaction}))};}
 dashboard(i){const p=this.players[i],c=this.challenge;return {...this.publicState(),players:undefined,seat:i,name:p.name,color:p.color,human:p.human,alive:p.alive,used:p.used,place:p.place,guesses:p.guesses,draft:p.draft,keys:p.keys,cursor:p.cursor,solved:p.solved,done:p.done,message:p.message,ownCoin:c?.submitted[i]||null};}
}
