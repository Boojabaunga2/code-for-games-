// State masks are held input, never a movement latch. Same shared reader as Haunt.
export class CursorInput {
 constructor(){this.previous=Array(6).fill(0);this.direction=Array(6).fill(0);this.next=Array(6).fill(0);}
 clear(){this.previous.fill(0);this.direction.fill(0);this.next.fill(0);}
 step(i,mask,now,move,press){const old=this.previous[i],fresh=mask&~old;this.previous[i]=mask;
  const dirs=[1,2,4,8],newDirection=dirs.filter(b=>fresh&b).at(-1);let d=this.direction[i];if(newDirection)d=newDirection;else if(!(mask&d))d=dirs.filter(b=>mask&b).at(-1)||0;
  if(d!==this.direction[i]){this.direction[i]=d;this.next[i]=now;}
  if(d&&now>=this.next[i]){move(d===8?1:d===4?-1:0,d===2?1:d===1?-1:0);this.next[i]=now+(fresh&d?280:95);}
  for(const [bit,key] of [[16,'A'],[32,'B'],[64,'X'],[128,'Y'],[256,'START'],[512,'SELECT'],[1024,'L1'],[2048,'R1']])if(fresh&bit)press(key);
 }
}
