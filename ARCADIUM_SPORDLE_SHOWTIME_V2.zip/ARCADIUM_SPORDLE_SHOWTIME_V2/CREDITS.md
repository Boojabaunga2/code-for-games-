# SPORDLE Showtime V2 artwork and shared components

Original illustrated character atlas, laboratory stage and square SPORDLE cover were generated specifically for this Arcadium update. The cover uses the approved six-character cast. The sixteen additional game-specific covers were generated as four square 2×2 production atlases, then extracted without repainting or resizing by `tests/prepare-art.cjs`; the original atlases are retained. No external fonts or runtime CDN resources are required.

`art.mjs` draws six equal sprite cells from `assets/geniuses.png`; ghost variants use the same art and accessories with a spectral render effect. Every personal board uses its own dashboard and the same original character art.

`native-input.js` remains byte-for-byte identical to Haunt & Seek source commit `356b99db70abe831787dd1821c5cec90e99b9dd5`. The shared broker and launcher derive from that integration. Existing controller receiver and pairing are not replaced. `tests/universal_input_reference.py` is the unchanged shared native wrapper at that commit; the browser harness provides a minimal bridge fixture rather than the full installed OS.
