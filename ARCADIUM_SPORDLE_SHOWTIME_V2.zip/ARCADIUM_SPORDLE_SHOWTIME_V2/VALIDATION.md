# SPORDLE validation and practical limits

The source review folder contains machine-readable test evidence and actual gameplay captures. This document describes the checks and their scope; the CI run attached to the published source commit records the Windows result and exact archive hash.

- Engine/input: `node tests/engine.test.mjs` covers duplicate letters, valid-guess limits, six-player ranking/privacy, deadline/pause, physical coin sealing/retries/swaps, final comebacks, unique placements, CPU non-simulation, held movement/release/direction changes and native packet expiry.
- Browser: `node tests/browser.cjs` uses six actual personal pages and the unchanged universal native-input wrapper. It checks native packets through HTTP, private drafts/boards, real touch hit regions, reconnect, coin sealing, transitions and previous-game ownership handoff. The bridge itself is a minimal contract fixture, not a complete installed OS. Chromium/Playwright are test dependencies only, never runtime dependencies.
- Python: `python tests/test_host.py` tests catalogue-only registration, preservation/backups/idempotency, checksum refusal, exact extracted ZIP startup (including paths with spaces and ampersands), scoped dashboards/frames, session replays, owner handoff, traversal rejection and native authentication.
- Windows CI runs the Python checks with the exact ZIP on a Windows runner, and scans the Internet-marked archive, extracted directory and each script file using Microsoft Defender. It also records Windows attachment-policy/Save results. Read the recorded report before treating any scan as completed; an unavailable scan fails the check.
- The ZIP build uses fixed timestamps and checksums. It contains source, web assets and documentation; no APK, EXE, DLL, CMD, BAT or PowerShell installer.

Not physically verified: Mini Vibe hardware buttons, six-device venue Wi-Fi, the user's complete existing OS installation, display/touch behavior on the actual hardware or recipient antivirus acceptance. A Windows runner and its Defender verdict do not guarantee the recipient Windows PC will accept the download. No manual Microsoft review verdict is claimed. Keep protection enabled and leave any flagged file blocked.

Showtime V2 adds an artwork-only catalogue test: existing cover fields update for sixteen matching game IDs and the explicit screenshot title aliases, while launch URLs, controls, custom fields and unrelated games stay unchanged. The original V1 review records are historical; use the Showtime V2 run and V2 delivery record for the actual new archive.
