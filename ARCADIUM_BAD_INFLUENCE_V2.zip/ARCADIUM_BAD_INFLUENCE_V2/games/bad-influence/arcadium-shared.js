
/* =====================================================================
   ARCADIUM 10,000 - shared foundation (same PP core as Panic Pips so
   GoDiceManager.js / GoDiceSimulator.js drop in unchanged).
   ===================================================================== */
'use strict';

var PP = window.PP = {};

/* ---------- tiny utils ---------- */
PP.$ = function (id) { return document.getElementById(id); };
PP.h = function (tag, cls, txt) { var e = document.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = txt; return e; };
PP.rnd = function (a, b) { return a + Math.floor(Math.random() * (b - a + 1)); };
PP.pick = function (a) { return a[Math.floor(Math.random() * a.length)]; };
PP.clamp = function (v, a, b) { return Math.max(a, Math.min(b, v)); };
PP.wait = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
PP.waitFor = function (fn, ms) { var t0 = Date.now(); return new Promise(function (res) { (function loop() { if (fn()) return res(true); if (Date.now() - t0 > ms) return res(false); setTimeout(loop, 60); })(); }); };
PP.shortCode = function (id) { var h = 0; id = String(id || ''); for (var i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) | 0; h = Math.abs(h); var a = 'ABCDEFGHJKLMNPQRSTUVWXYZ'; return a.charAt(h % 24) + (h % 9 + 1) + a.charAt((h >> 5) % 24) + ((h >> 9) % 10); };
PP.fmtTime = function (s) { s = Math.max(0, Math.floor(s)); var m = Math.floor(s / 60), r = s % 60; return m + ':' + (r < 10 ? '0' : '') + r; };
PP.fmt = function (n) { return String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, ','); };
PP.setText = function (el, v) { v = String(v); if (el.textContent !== v) el.textContent = v; };
PP.setHTML = function (el, v) { if (el._h !== v) { el._h = v; el.innerHTML = v; } };
PP.tog = function (el, cls, on) { on = !!on; if (el.classList.contains(cls) !== on) el.classList.toggle(cls, on); };
PP.retrigger = function (el, cls) { el.classList.remove(cls); void el.offsetWidth; el.classList.add(cls); };

/* ---------- seats + dice (both follow the GoDice shell colours) ---------- */
PP.PLAYERS = [
  { id: 1, name: 'RED',    hex: '#ff2323', rgb: [255, 0, 0] },
  { id: 2, name: 'BLUE',   hex: '#2a7bff', rgb: [0, 100, 255] },
  { id: 3, name: 'GREEN',  hex: '#1dff63', rgb: [0, 255, 80] },
  { id: 4, name: 'YELLOW', hex: '#ffcc11', rgb: [255, 200, 0] },
  { id: 5, name: 'PINK',   hex: '#ff2d9a', rgb: [255, 40, 150] },
  { id: 6, name: 'WHITE',  hex: '#f4f6ff', rgb: [255, 255, 255] }
];
PP.DICE = PP.PLAYERS; // DIE 1 = red shell ... DIE 6 = white shell
PP.LED = { green: [0, 255, 0], red: [255, 0, 0], white: [255, 255, 255], off: [0, 0, 0], gold: [255, 170, 0] };
PP.DICE_COLOR_NAMES = ['black', 'red', 'green', 'blue', 'yellow', 'orange'];

/* ---------- event emitter ---------- */
PP.Emitter = class {
  constructor() { this._h = {}; }
  on(n, f) { (this._h[n] = this._h[n] || []).push(f); return this; }
  emit(n, p) {
    var lists = [this._h[n], this._h['*']];
    for (var k = 0; k < 2; k++) {
      var l = lists[k]; if (!l) continue;
      for (var i = 0; i < l.length; i++) { try { if (k === 0) l[i](p); else l[i](n, p); } catch (e) { console.error(e); } }
    }
  }
};

/* ---------- local settings (non-sensitive) ---------- */
PP.Store = {
  key: 'arcadium10000.v1',
  d: { volume: 0.7, players: 6, mode: 'CLASSIC', known: {}, autoReconnect: true },
  load: function () { try { var s = localStorage.getItem(this.key); if (s) { var o = JSON.parse(s); for (var k in o) this.d[k] = o[k]; } } catch (e) {} },
  save: function () { try { localStorage.setItem(this.key, JSON.stringify(this.d)); } catch (e) {} }
};

/* ---------- event log ---------- */
PP.Log = {
  lines: [], max: 300,
  add: function (txt, cls) {
    var t = new Date(); var ts = ('0' + t.getMinutes()).slice(-2) + ':' + ('0' + t.getSeconds()).slice(-2) + '.' + ('00' + t.getMilliseconds()).slice(-3);
    this.lines.push({ t: ts, txt: txt, cls: cls || '' });
    if (this.lines.length > this.max) this.lines.shift();
    this.dirty = true;
  }
};

