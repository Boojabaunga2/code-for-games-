export const COLORS=['red','blue','green','yellow','pink','white'];
export const HEX=['#ff4055','#3ba9ff','#5ce786','#ffd04b','#ff6aca','#edf4ff'];
export const CAST=[['jax','JAX'],['nova','NOVA'],['rico','RICO'],['luna','LUNA'],['blaze','BLAZE'],['zoe','ZOE']];
export const ROUNDS=[
 {name:'EVERYBODY’S A LIAR',sub:'Truth hurts. So does lying.',prompt:'A group of flamingos is called a flamboyance.',help:'Correct TRUE/FALSE scores your Survival Die. Wrong answers score zero.',choices:['TRUE','FALSE'],correct:'TRUE'},
 {name:'PASS THE DISASTER',sub:'Somebody is about to lose a friend.',prompt:'Secretly choose an opponent to attack.',help:'Your Trouble Die attacks their Survival Die. Take only the points they already have.',choices:null},
 {name:'TERRIBLE ADVICE',sub:'The worst decisions make the best stories.',prompt:'Would you show your browser history on TV for $10,000?',help:'Match the majority to score your Survival Die. An exact tie rewards everyone.',choices:['ABSOLUTELY','NO CHANCE']},
 {name:'FRIENDLY FIRE',sub:'Three players. Zero trustworthy friends.',prompt:'Secretly target an opponent. Team up… or don’t.',help:'Trouble attacks Survival. Two attackers on the same victim get +2 attack each. Transfers are capped.',choices:null},
 {name:'EVERYONE’S SCREWED',sub:'Two survivors. One very bad decision.',prompt:'Bank safe points or gamble for triple?',help:'SAFE scores Survival. CHAOS scores 3× Survival if Trouble ≥4; otherwise lose Survival.',choices:['SAFE','CHAOS']}
];
const clone=v=>JSON.parse(JSON.stringify(v));
export function createGame({now=Date.now}={}){
 const S={phase:'welcome',round:0,roundToken:0,serial:0,paused:false,openedAt:0,elapsed:0,players:CAST.map(([id,name],seat)=>({seat,id,name,color:COLORS[seat],hex:HEX[seat],alive:true,score:0,roundScore:0,dice:[null,null],fresh:[false,false],rolling:[false,false],connected:[false,false],role:1,answer:null,target:null,cursor:0,step:'dice',locked:false,review:null})),log:[],reveal:[],winner:null,lastEliminated:null,notice:'PAIR YOUR 12 REAL GODICE',reactions:Array(6).fill(null),reactionUntil:Array(6).fill(0)};
 const history=[],events=[],held=Array(6).fill(0),repeat=Array(6).fill(0);const live=()=>S.players.filter(p=>p.alive),pAt=i=>Number.isInteger(i)&&i>=0&&i<6?S.players[i]:null;
 const diceReady=p=>p.fresh.every(Boolean)&&p.dice.every(v=>Number.isInteger(v)&&v>=1&&v<=6)&&p.connected.every(Boolean);
 function checkpoint(){history.push(clone(S));if(history.length>32)history.shift();}
 function enter(phase,notice){S.phase=phase;S.notice=notice;S.serial++;held.fill(0);repeat.fill(0);}
 function roles(p){return{survival:p.dice[1-p.role],trouble:p.dice[p.role]};}
 function options(i){const p=pAt(i);if(!p||!p.alive)return[];if(p.step==='role')return['LEFT = TROUBLE','RIGHT = TROUBLE'];if(p.step==='decision'||p.step==='review')return ROUNDS[S.round].choices||live().filter(q=>q!==p).map(q=>q.id);return[];}
 function connect(slot,on){if(!Number.isInteger(slot)||slot<1||slot>12||typeof on!=='boolean')return false;const p=S.players[Math.floor((slot-1)/2)],face=(slot-1)%2;p.connected[face]=on;if(!on&&!p.locked){p.fresh[face]=false;p.rolling[face]=false;}return true;}
 function rollStart(slot,at=now()){if(S.phase!=='input'||S.paused||at<S.openedAt||!Number.isInteger(slot)||slot<1||slot>12)return false;const p=S.players[Math.floor((slot-1)/2)],face=(slot-1)%2;if(!p.alive||p.locked||!p.connected[face])return false;p.rolling[face]=true;p.fresh[face]=false;return true;}
 function stableRoll(slot,value,at=now()){if(S.phase!=='input'||S.paused||at<S.openedAt||!Number.isInteger(slot)||slot<1||slot>12||!Number.isInteger(value)||value<1||value>6)return false;const p=S.players[Math.floor((slot-1)/2)],face=(slot-1)%2;if(!p.alive||p.locked||!p.connected[face]||!p.rolling[face])return false;p.dice[face]=value;p.fresh[face]=true;p.rolling[face]=false;if(diceReady(p)&&p.step==='dice')p.step='role';events.push({type:'roll',seat:p.seat,face,value});return true;}
 function openInput(){checkpoint();S.roundToken++;S.openedAt=now();for(const p of live()){p.dice=[null,null];p.fresh=[false,false];p.rolling=[false,false];p.locked=false;p.role=1;p.answer=null;p.target=null;p.cursor=1;p.step='dice';p.review=null;}enter('input','ROLL BOTH REAL GODICE · PRIVATE DECISIONS ON MINI VIBES');}
 function move(i,d){const p=pAt(i);if(S.phase!=='input'||S.paused||!p?.alive||p.locked)return;const opts=options(i);if(!opts.length)return;p.cursor=opts.length===2?(d<0?0:1):(p.cursor+(d<0?-1:1)+opts.length)%opts.length;if(p.step==='role')p.role=p.cursor;else if(p.step==='decision'){if(ROUNDS[S.round].choices)p.answer=opts[p.cursor];else p.target=opts[p.cursor];}}
 function defaultDecision(p){p.cursor=0;const opts=options(p.seat);if(ROUNDS[S.round].choices)p.answer=opts[0];else p.target=opts[0];}
 function action(i,b){const p=pAt(i);if(!p)return false;
  if(b==='X'||b==='Y'){if(S.elapsed>=S.reactionUntil[i]){S.reactions[i]=p.alive?(b==='X'?'NO REGRETS!':'TRUST ME!'):(b==='X'?'BOOO!':'I’M WATCHING!');S.reactionUntil[i]=S.elapsed+3;events.push({type:'taunt',seat:i});}return true;}
  if(!p.alive)return false;if(b==='START'){if(S.phase==='input')return next();if(S.phase==='champion')return reset();return next();}if(S.paused)return false;
  if(b==='L1'||b==='R1')return move(i,b==='L1'?-1:1);
  if(/^CHOICE_[0-5]$/.test(b)&&S.phase==='input'&&!p.locked){const k=Number(b.slice(-1)),opts=options(i);if(k>=opts.length)return false;p.cursor=k;if(p.step==='role')p.role=k;else if(p.step==='decision'){if(ROUNDS[S.round].choices)p.answer=opts[k];else p.target=opts[k];}return true;}
  if(S.phase!=='input')return false;
  if(b==='B'){if(p.locked){p.locked=false;p.step='review';p.review=null;}else if(p.step==='review')p.step='decision';else if(p.step==='decision'){p.step='role';p.cursor=p.role;}return true;}
  if(b!=='A')return false;if(!diceReady(p)){S.notice='WAITING FOR BOTH FRESH, CONNECTED GODICE ROLLS';return false;}
  if(p.step==='dice'){p.step='role';p.cursor=p.role;return true;}
  if(p.step==='role'){p.step='decision';defaultDecision(p);return true;}
  if(p.step==='decision'){p.step='review';return true;}
  if(p.step==='review'){const opts=ROUNDS[S.round].choices||live().filter(q=>q!==p).map(q=>q.id);if(!opts.includes(ROUNDS[S.round].choices?p.answer:p.target))return false;p.review=clone({dice:p.dice,role:p.role,answer:p.answer,target:p.target});p.locked=true;p.step='locked';events.push({type:'lock',seat:i});return true;}return false;
 }
 function tally(){if(S.phase!=='input'||!live().every(p=>p.locked&&p.review))return false;checkpoint();const arr=live(),r=S.round;arr.forEach(p=>p.roundScore=0);S.reveal=[];
  if(r===0)for(const p of arr){p.roundScore=p.answer===ROUNDS[0].correct?roles(p).survival:0;}
  else if(r===1||r===3){
   // Simultaneous attacks draw only from each victim's opening bank. Proportional integer
   // allocation avoids minting points or privileging the first attacker in a loop.
   for(const victim of arr){const attackers=arr.filter(p=>p.target===victim.id),requests=attackers.map(p=>({p,want:Math.max(0,roles(p).trouble+(r===3&&attackers.length>1?2:0)-roles(victim).survival),take:0}));const wanted=requests.reduce((n,a)=>n+a.want,0),budget=Math.min(victim.score,wanted);if(!wanted)continue;let left=budget;
    for(const a of requests){a.take=Math.floor(budget*a.want/wanted);left-=a.take;a.frac=budget*a.want/wanted-a.take;}
    requests.sort((a,b)=>b.frac-a.frac||((a.p.seat+6-S.round)%6)-((b.p.seat+6-S.round)%6));for(const a of requests)if(left>0&&a.take<a.want){a.take++;left--;}
    for(const a of requests){victim.roundScore-=a.take;a.p.roundScore+=a.take;S.reveal.push({kind:'transfer',from:victim.seat,to:a.p.seat,points:a.take});}
   }
  }else if(r===2){const yes=arr.filter(p=>p.answer==='ABSOLUTELY').length;for(const p of arr){const match=yes===arr.length/2||p.answer===(yes>arr.length/2?'ABSOLUTELY':'NO CHANCE');p.roundScore=match?roles(p).survival:0;}}
  else for(const p of arr){const d=roles(p);p.roundScore=p.answer==='SAFE'?d.survival:d.trouble>=4?3*d.survival:-d.survival;}
  for(const p of arr){const before=p.score;p.score=Math.max(0,p.score+p.roundScore);S.reveal.push({kind:'result',seat:p.seat,answer:p.answer,target:p.target,...roles(p),roundScore:p.roundScore,total:p.score,before});}
  const top=[...arr].sort((a,b)=>b.roundScore-a.roundScore||b.score-a.score)[0];S.log.push(top.name+' LEADS THIS ROUND · '+(top.roundScore>=0?'+':'')+top.roundScore);enter('results','THE DECISIONS ARE REVEALED · CHECK THE SCOREBOARD');events.push({type:'reveal'});return true;
 }
 function next(){if(S.paused)return false;
  if(S.phase==='welcome'){checkpoint();enter('intro','REAL GODICE · '+ROUNDS[0].help);return true;}
  if(S.phase==='intro'){openInput();return true;}
  if(S.phase==='input'){if(!live().every(p=>p.locked)){S.notice=live().filter(p=>p.locked).length+' / '+live().length+' LOCKED · WAIT FOR EVERY PLAYER';return false;}return tally();}
  if(S.phase==='results'){checkpoint();if(S.round===4){const order=[...live()].sort((a,b)=>b.score-a.score||b.roundScore-a.roundScore||a.name.localeCompare(b.name));S.winner=order[0].seat;for(const p of order.slice(1))p.alive=false;enter('champion',order[0].name+' IS THE BAD INFLUENCE CHAMPION');events.push({type:'winner',seat:S.winner});}else{const order=[...live()].sort((a,b)=>a.roundScore-b.roundScore||a.score-b.score||a.name.localeCompare(b.name));const loser=order[0];loser.alive=false;S.lastEliminated=loser.seat;S.log.push(loser.name+' ELIMINATED · '+loser.roundScore+' ROUND / '+loser.score+' BANK');S.round++;enter('intro',loser.name+' IS OUT · '+live().length+' SURVIVORS');events.push({type:'out',seat:loser.seat});}return true;}return false;
 }
 function reset(){checkpoint();for(const p of S.players){const connected=p.connected.slice();Object.assign(p,{alive:true,score:0,roundScore:0,dice:[null,null],fresh:[false,false],rolling:[false,false],role:1,answer:null,target:null,cursor:1,step:'dice',locked:false,review:null,connected});}S.round=0;S.winner=null;S.lastEliminated=null;S.reveal=[];S.log=[];S.roundToken++;enter('welcome','NEW GAME · KEEP YOUR REAL GODICE PAIRING');return true;}
 function update(dt,masks=[]){if(S.paused)return;dt=Math.max(0,Math.min(.25,Number.isFinite(dt)?dt:0));S.elapsed+=dt;for(let i=0;i<6;i++){if(S.reactions[i]&&S.elapsed>S.reactionUntil[i]-.8)S.reactions[i]=null;const m=masks[i]||0,d=m&5?-1:m&10?1:0;if(d){repeat[i]-=dt;if(m!==held[i]||repeat[i]<=0){move(i,d);repeat[i]=m!==held[i]?.38:.18;}}else repeat[i]=0;held[i]=m;}}
 function undo(){if(!history.length)return false;const seq=S.serial+1,connected=S.players.map(p=>p.connected.slice());Object.assign(S,history.pop(),{serial:seq,paused:true});for(let i=0;i<6;i++)S.players[i].connected=connected[i];events.splice(0);return true;}
 return{S,live,roles,options,diceReady,connect,rollStart,stableRoll,action,move,next,tally,reset,update,undo,get canUndo(){return history.length>0;},drainEvents:()=>events.splice(0)};
}
