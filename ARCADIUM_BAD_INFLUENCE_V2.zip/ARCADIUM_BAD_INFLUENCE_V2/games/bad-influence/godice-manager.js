
'use strict';
/* =====================================================================
   GoDiceManager - the only code that touches godice.js.
   Normalized events (payload: {type, playerId(slot), diceId, value,
   xyz, simulated, timestamp}):
     dice-connected  dice-disconnected  reconnecting  reconnect-failed
     dice-unpaired   roll-start  stable-roll  tilt-stable  fake-stable
     move-stable     battery     dice-color
   playerId here is the SEAT the die was paired to. Games that move dice
   between players (SWAP) keep their own ownership map on top.
   ===================================================================== */
PP.MSG_NO_BT = 'Bluetooth unavailable. Open Panic Pips in Chrome or Edge on the Arcadium PC.';
PP.GoDiceManager = class extends PP.Emitter {
  constructor() {
    super();
    this.slots = {};
    this.autoReconnect = true;
    this.reconnectTries = 8;
    this.defaultDieType = 'D6';
  }
  static supported() { return !!(navigator.bluetooth && navigator.bluetooth.requestDevice); }
  static canRestore() { return !!(navigator.bluetooth && navigator.bluetooth.getDevices); }

  /* ---- internals ---- */
  _create(slot, simulated) {
    var die = simulated ? new PP.SimDie() : new GoDice();
    var rec = { slot: slot, die: die, diceId: null, name: '', simulated: !!simulated, connected: false, reconnecting: false, removed: false, manual: false,
      battery: null, color: null, dieType: this.defaultDieType, lastRoll: null, lastEvent: '', lastEventAt: 0, xyz: null, q: [], busy: false, ledView: null, pair: null, lastError: '' };
    this._patchQueue(rec);
    this._wire(rec);
    return rec;
  }
  _live(rec) { return this.slots[rec.slot] === rec && !rec.removed; }
  _norm(rec, type, extra) {
    var e = { type: type, playerId: rec.slot, diceId: rec.diceId, simulated: rec.simulated, timestamp: Date.now() };
    if (extra) for (var k in extra) e[k] = extra[k];
    rec.lastEvent = type + (extra && extra.value != null ? ' ' + extra.value : ''); rec.lastEventAt = e.timestamp;
    this.emit(type, e);
    return e;
  }
  _wire(rec) {
    var self = this, die = rec.die;
    die.onDiceConnected = function (id) { if (self._live(rec)) self._onConnected(rec, String(id)); };
    die.onDiceDisconnected = function () { if (self._live(rec)) self._onDisconnected(rec); };
    die.onRollStart = function () { if (self._live(rec) && rec.connected) self._norm(rec, 'roll-start'); };
    // NOTE: godice.js returns the D6 value as a STRING (object key). Normalise to Number here.
    die.onStable = function (id, value, xyz) { if (!self._live(rec) || !rec.connected) return; var v = Number(value); rec.lastRoll = v; rec.xyz = xyz; self._norm(rec, 'stable-roll', { value: v, xyz: xyz }); };
    // NOTE: official tilt callback order is (diceId, xyz, value) - different from the others.
    die.onTiltStable = function (id, xyz, value) { if (!self._live(rec) || !rec.connected) return; rec.xyz = xyz; self._norm(rec, 'tilt-stable', { value: Number(value), xyz: xyz }); };
    die.onFakeStable = function (id, value, xyz) { if (!self._live(rec) || !rec.connected) return; rec.xyz = xyz; self._norm(rec, 'fake-stable', { value: Number(value), xyz: xyz }); };
    die.onMoveStable = function (id, value, xyz) { if (!self._live(rec) || !rec.connected) return; rec.xyz = xyz; self._norm(rec, 'move-stable', { value: Number(value), xyz: xyz }); };
    die.onBatteryLevel = function (id, lvl) { if (!self._live(rec)) return; rec.battery = lvl; self._norm(rec, 'battery', { value: lvl }); };
    die.onDiceColor = function (id, c) { if (!self._live(rec)) return; rec.color = c; self._norm(rec, 'dice-color', { value: c, colorName: PP.DICE_COLOR_NAMES[c] || 'unknown' }); };
  }
  /* godice.js fires BLE writes without waiting; two writes at once throw
     "GATT operation already in progress". Serialise per die, and let a
     newer LED command replace an older one that has not been sent yet. */
  _patchQueue(rec) {
    var self = this, die = rec.die, base = die.sendMessage.bind(die);
    die.sendMessage = function (arr) {
      var isLed = (arr[0] === 8 || arr[0] === 16);
      if (isLed) {
        rec.ledView = arr[0] === 8 ? { mode: 'solid', c1: arr.slice(1, 4), c2: arr.slice(4, 7), at: Date.now() }
                                   : { mode: 'pulse', count: arr[1], on: arr[2], off: arr[3], c1: arr.slice(4, 7), at: Date.now() };
        for (var i = rec.q.length - 1; i >= 0; i--) if (rec.q[i].led) rec.q.splice(i, 1);
      }
      rec.q.push({ arr: arr, led: isLed });
      self._pump(rec, base);
      return Promise.resolve();
    };
  }
  _pump(rec, base) {
    var self = this;
    if (rec.busy || !rec.q.length) return;
    var it = rec.q.shift(); rec.busy = true;
    var done = function () { rec.busy = false; self._pump(rec, base); };
    var p; try { p = base(it.arr); } catch (e) { p = Promise.reject(e); }
    Promise.resolve(p).then(done, function (err) { rec.lastError = String((err && err.message) || err); done(); });
  }
  _onConnected(rec, id) {
    for (var s in this.slots) {
      var o = this.slots[s];
      if (o !== rec && o.diceId === id && !o.removed) {
        // Same physical die picked for a second seat: detach this instance, keep the original.
        this._drop(rec);
        try { if (rec.die.CubeCharacteristics) rec.die.CubeCharacteristics.removeEventListener('characteristicvaluechanged', rec.die.handleNotificationChanged); } catch (e) {}
        if (rec.pair) { var pr = rec.pair; rec.pair = null; pr.rej(new Error('That die is already assigned to P' + o.slot + '.')); }
        return;
      }
    }
    var again = !!rec.diceId;
    rec.diceId = id; rec.connected = true; rec.reconnecting = false; rec.manual = false; rec.lastError = '';
    rec.name = (rec.die.bluetoothDevice && rec.die.bluetoothDevice.name) || '';
    rec.die.setDieType(GoDice.diceTypes[rec.dieType]);
    this._norm(rec, 'dice-connected', { reconnected: again, name: rec.name });
    try { rec.die.getBatteryLevel(); } catch (e) {}
    try { rec.die.getDiceColor(); } catch (e) {}
    if (rec.pair) { var p = rec.pair; rec.pair = null; p.res(rec); }
  }
  _onDisconnected(rec) {
    if (!rec.connected && !rec.pair) return;
    rec.connected = false; rec.q.length = 0; rec.busy = false;
    this._norm(rec, 'dice-disconnected', { manual: rec.manual });
    if (!rec.manual && this.autoReconnect) this.reconnectDice(rec.slot).catch(function () {});
  }
  _drop(rec) { rec.removed = true; if (this.slots[rec.slot] === rec) delete this.slots[rec.slot]; }
  _rec(slot) { var r = this.slots[slot]; return (r && !r.removed) ? r : null; }
  _on(slot) { var r = this._rec(slot); return (r && r.connected) ? r : null; }

  /* ---- public API ---- */
  // Must be called directly from a click handler (Web Bluetooth user-gesture rule).
  pairDice(slot, opts) {
    opts = opts || {};
    var self = this, sim = !!opts.simulated;
    if (!sim && !PP.GoDiceManager.supported()) return Promise.reject(new Error(PP.MSG_NO_BT));
    var old = this._rec(slot);
    if (old) {
      if (old.connected || old.reconnecting) return Promise.reject(new Error('P' + slot + ' already has a die. Unpair it first.'));
      this._drop(old);
    }
    var rec = this._create(slot, sim);
    this.slots[slot] = rec;
    return new Promise(function (res, rej) {
      rec.pair = { res: res, rej: rej };
      var p; try { p = rec.die.requestDevice(); } catch (e) { p = Promise.reject(e); }
      p.then(function () {
        setTimeout(function () { if (rec.pair) { var pr = rec.pair; rec.pair = null; self._drop(rec); pr.rej(new Error('Die connected but did not answer. Try again.')); } }, 10000);
      }).catch(function (err) {
        if (!rec.pair) return;
        rec.pair = null; self._drop(rec);
        var msg = String((err && err.message) || err);
        if (/cancel/i.test(msg)) msg = 'Pairing cancelled.';
        rej(new Error(msg));
      });
    });
  }
  // Bounded reconnect. godice.js attemptReconnect() loops forever with no
  // way to stop it, so we drive the same official connect call ourselves.
  async reconnectDice(slot) {
    var rec = this._rec(slot);
    if (!rec) throw new Error('No die on P' + slot + '.');
    if (rec.connected) return true;
    if (rec.reconnecting) return false;
    if (!rec.die.bluetoothDevice) throw new Error('That die was unpaired. Pair it again.');
    rec.reconnecting = true; rec.manual = false;
    this._norm(rec, 'reconnecting');
    for (var i = 1; i <= this.reconnectTries && this._live(rec) && !rec.connected; i++) {
      try { await rec.die.connectDeviceAndCacheCharacteristics(); await PP.waitFor(function () { return rec.connected; }, 2500); }
      catch (e) { rec.lastError = String((e && e.message) || e); }
      if (!rec.connected) await PP.wait(1500);
    }
    rec.reconnecting = false;
    if (!this._live(rec)) return false;
    if (!rec.connected) { this._norm(rec, 'reconnect-failed'); return false; }
    return true;
  }
  // Drop the link but keep the seat binding (can RECONNECT later).
  disconnectDice(slot) {
    var rec = this._rec(slot); if (!rec) return;
    rec.manual = true;
    try { if (rec.die.bluetoothDevice && rec.die.bluetoothDevice.gatt.connected) rec.die.bluetoothDevice.gatt.disconnect(); } catch (e) {}
  }
  // Forget the die entirely for this seat.
  unassignDice(slot) {
    var rec = this._rec(slot); if (!rec) return;
    var die = rec.die, id = rec.diceId;
    try { if (rec.connected) die.setLed([0, 0, 0], [0, 0, 0]); } catch (e) {}
    rec.manual = true;
    this._norm(rec, 'dice-unpaired');
    this._drop(rec);
    setTimeout(function () { try { die.onDisconnectButtonClick(); } catch (e) {} }, 250);
    return id;
  }
  setPlayerColor(slot, rgb) { var r = this._on(slot); if (r) r.die.setLed(rgb, rgb); }
  setLeds(slot, rgb1, rgb2) { var r = this._on(slot); if (r) r.die.setLed(rgb1, rgb2); }
  ledsOff(slot) { var r = this._on(slot); if (r) r.die.setLed([0, 0, 0], [0, 0, 0]); }
  flashPlayer(slot, rgb) { var r = this._on(slot); if (r) r.die.pulseLed(2, 14, 10, rgb); }
  // onTime/offTime are in 10ms units (max 255) - that is the die firmware's unit.
  pulsePlayer(slot, count, onTime, offTime, rgb) { var r = this._on(slot); if (r) r.die.pulseLed(PP.clamp(count | 0, 1, 255), PP.clamp(onTime | 0, 1, 255), PP.clamp(offTime | 0, 1, 255), rgb); }
  getBattery(slot) { var r = this._on(slot); if (!r) return null; try { r.die.getBatteryLevel(); } catch (e) {} return r.battery; }
  identifyDice(slot, rgb) { this.pulsePlayer(slot, 6, 25, 20, rgb || PP.LED.white); }
  getPlayerForDice(diceId) { for (var s in this.slots) { var r = this.slots[s]; if (!r.removed && r.diceId === diceId) return r.slot; } return null; }
  getDiceForPlayer(slot) { var r = this._rec(slot); return r ? r.diceId : null; }
  getRecord(slot) { return this._rec(slot); }
  isConnected(slot) { return !!this._on(slot); }
  setDieType(slot, type) { var r = this._rec(slot); if (!r || GoDice.diceTypes[type] == null) return; r.dieType = type; r.die.setDieType(GoDice.diceTypes[type]); }
  // Re-attach dice this browser already has permission for (no chooser). Chrome-only, best effort.
  async restoreKnown(known) {
    if (!PP.GoDiceManager.canRestore()) throw new Error('This browser cannot restore dice automatically. Pair them again.');
    var devs = await navigator.bluetooth.getDevices(), n = 0;
    for (var i = 0; i < devs.length; i++) {
      var d = devs[i], slot = known[d.id];
      if (!slot || this._rec(slot)) continue;
      var rec = this._create(slot, false); this.slots[slot] = rec;
      var die = rec.die;
      // mirrors the body of GoDice.requestDevice() for an already-permitted device
      die.GlobalDeviceId = d.id.toString(); die.bluetoothDevice = d;
      (function (die) { d.addEventListener('gattserverdisconnected', function () { die.onDiceDisconnected(die.GlobalDeviceId, die); }); })(die);
      try {
        await Promise.race([die.connectDeviceAndCacheCharacteristics(), PP.wait(6000).then(function () { throw new Error('timeout'); })]);
        await PP.waitFor(function () { return rec.connected; }, 3000);
      } catch (e) { rec.lastError = String((e && e.message) || e); }
      if (rec.connected) n++; else this._drop(rec);
    }
    return n;
  }
};

