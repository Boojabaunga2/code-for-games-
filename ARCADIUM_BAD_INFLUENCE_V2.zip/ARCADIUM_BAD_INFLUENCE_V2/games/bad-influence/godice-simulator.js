
'use strict';
/* =====================================================================
   SimDie - a fake GoDice. It borrows the OFFICIAL GoDice methods
   (setLed, pulseLed, parseMessage, getDieValue...) and feeds them the
   same byte messages a real die sends, so simulator rolls travel the
   exact same code path as hardware rolls.
   ===================================================================== */
PP.simCount = 0;
PP.SimDie = class {
  constructor() {
    PP.simCount++;
    var self = this, id = 'SIM-' + Math.random().toString(36).slice(2, 7) + '-' + PP.simCount;
    this.messageIdentifiers = (new GoDice()).messageIdentifiers;
    this.GlobalDeviceId = id;
    this.bluetoothDevice = { id: id, name: 'SimDice_' + PP.simCount, gatt: { connected: false, disconnect: function () { self.drop(); } } };
    this.dieType = GoDice.diceTypes.D6;
    this.rolledValue = 0;
    this.simBattery = PP.rnd(35, 100);
    this.simColor = PP.rnd(0, 5);
    this.failReconnect = false;
    this.rolling = false;
  }
  requestDevice() {
    var self = this;
    return new Promise(function (res) {
      setTimeout(function () { self.bluetoothDevice.gatt.connected = true; res(); setTimeout(function () { self.onDiceConnected(self.GlobalDeviceId, self); }, 60); }, 300);
    });
  }
  connectDeviceAndCacheCharacteristics() {
    var self = this;
    if (this.failReconnect) return Promise.reject(new Error('Simulated die out of range'));
    return new Promise(function (res) {
      setTimeout(function () { self.bluetoothDevice.gatt.connected = true; res(); setTimeout(function () { self.onDiceConnected(self.GlobalDeviceId, self); }, 60); }, 250);
    });
  }
  sendMessage(arr) {
    if (!this.bluetoothDevice || !this.bluetoothDevice.gatt.connected) return Promise.reject(new Error('Simulated die not connected'));
    var self = this;
    if (arr[0] === 3) setTimeout(function () { self._rx([66, 97, 116, self.simBattery]); }, 40);
    if (arr[0] === 23) setTimeout(function () { self._rx([67, 111, 108, self.simColor]); }, 40);
    return new Promise(function (r) { setTimeout(r, 20); });
  }
  _rx(bytes) {
    var buf = new Int8Array(bytes.length);
    for (var i = 0; i < bytes.length; i++) buf[i] = bytes[i] > 127 ? bytes[i] - 256 : bytes[i];
    this.parseMessage(new DataView(buf.buffer), this.GlobalDeviceId);
  }
  _vectorFor(v) {
    var t = this.dieType === GoDice.diceTypes.D6 ? GoDice.d6Vectors : (this.dieType <= GoDice.diceTypes.D10X ? GoDice.d20Vectors : GoDice.d24Vectors);
    var keys = Object.keys(t);
    for (var i = 0; i < keys.length; i++) {
      var vec = t[keys[i]];
      var dv = new DataView(Int8Array.from([0, vec[0], vec[1], vec[2]]).buffer);
      if (Number(this.getDieValue(dv, 1)) === Number(v)) return vec;
    }
    return t[keys[0]];
  }
  roll(v) {
    if (!this.bluetoothDevice || !this.bluetoothDevice.gatt.connected || this.rolling) return;
    var self = this; this.rolling = true;
    this._rx([82]);
    var vec = this._vectorFor(v);
    setTimeout(function () {
      self.rolling = false;
      if (!self.bluetoothDevice || !self.bluetoothDevice.gatt.connected) return;
      self._rx([83, vec[0] + PP.rnd(-3, 3), vec[1] + PP.rnd(-3, 3), vec[2] + PP.rnd(-3, 3)]);
    }, PP.rnd(380, 700));
  }
  rollStartOnly() { if (this.bluetoothDevice && this.bluetoothDevice.gatt.connected) this._rx([82]); }
  badState(kind, v) {
    if (!this.bluetoothDevice || !this.bluetoothDevice.gatt.connected) return;
    var vec = this._vectorFor(v || PP.rnd(1, 6));
    var code = { tilt: 84, fake: 70, move: 77 }[kind];
    this._rx([code, 83, vec[0], vec[1], vec[2]]);
  }
  drop() {
    if (this.bluetoothDevice && this.bluetoothDevice.gatt.connected) {
      this.bluetoothDevice.gatt.connected = false;
      this.onDiceDisconnected(this.GlobalDeviceId, this);
    }
  }
  onDisconnectButtonClick() { this.drop(); this.bluetoothDevice = null; }
};
['setLed', 'pulseLed', 'getBatteryLevel', 'getDiceColor', 'setDieType', 'getClosestVector', 'getXyzFromBytes', 'getDieValue', 'parseMessage',
 'onRollStart', 'onBatteryLevel', 'onDiceColor', 'onStable', 'onFakeStable', 'onTiltStable', 'onMoveStable', 'onDiceConnected', 'onDiceDisconnected']
  .forEach(function (m) { PP.SimDie.prototype[m] = GoDice.prototype[m]; });

