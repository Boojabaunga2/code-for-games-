/* Real GoDice only. Keep the supplied SDK/manager intact and isolate this game's settings. */
(function(){'use strict';PP.Store.key='arcadium.bad-influence.godice.v1';const manager=new PP.GoDiceManager();let game=null,onChange=()=>{},notice='Pair each player’s left and right GoDice on this PC.';const labels=['JAX','NOVA','RICO','LUNA','BLAZE','ZOE'];
function record(slot){return manager.getRecord(slot);}function real(slot){const r=record(slot);return !!(r&&r.connected&&!r.simulated);}
function changed(){onChange();}
manager.on('dice-connected',e=>{const slot=Number(e.playerId);if(!e.simulated){game?.connect(slot,true);notice=labels[Math.floor((slot-1)/2)]+' '+(slot%2?'LEFT':'RIGHT')+' CONNECTED';}changed();});
manager.on('dice-disconnected',e=>{game?.connect(Number(e.playerId),false);notice='A die disconnected. Reconnect and roll before locking.';changed();});
manager.on('dice-unpaired',e=>{game?.connect(Number(e.playerId),false);changed();});
manager.on('roll-start',e=>{const slot=Number(e.playerId);if(!e.simulated&&real(slot))game?.rollStart(slot,e.timestamp);changed();});
manager.on('stable-roll',e=>{const slot=Number(e.playerId),value=Number(e.value);if(!e.simulated&&real(slot))game?.stableRoll(slot,value,e.timestamp);changed();});
window.BIHardware={manager,attach(g,change){game=g;onChange=change||(()=>{});for(let n=1;n<=12;n++)game.connect(n,real(n));},async pair(slot){if(!Number.isInteger(slot)||slot<1||slot>12)return;try{notice='Select '+labels[Math.floor((slot-1)/2)]+' '+(slot%2?'LEFT':'RIGHT')+' GoDice';changed();await manager.pairDice(slot);notice='Paired. Roll this real die when the round opens.';}catch(e){notice='PAIRING: '+String(e.message||e);}changed();},disconnect(slot){try{manager.disconnectDice(slot);}catch(e){notice=String(e.message||e);}changed();},get notice(){return notice;},record};
addEventListener('pagehide',()=>{for(let n=1;n<=12;n++)try{manager.disconnectDice(n);}catch{}});
})();
