"""Targeted Bad Influence installer; preserve Escape, Home, and every other game."""
import argparse
import ast
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import sys

SOURCE = Path(__file__).resolve().parent


def digest(data):
    return hashlib.sha256(data).hexdigest()


def atomic_write(path, data):
    temp = path.with_name(path.name + '.color-update.tmp')
    try:
        temp.write_bytes(data)
        os.replace(temp, path)
    finally:
        temp.unlink(missing_ok=True)


def patch_bridge(source):
    """Wrap the existing final Escape handler; never replace shared route code."""
    tree = ast.parse(source)
    functions = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'bridge']
    if len(functions) != 1:
        raise RuntimeError('Expected one existing bridge function; no files changed')
    returns = [n for n in functions[0].body if isinstance(n, ast.Return)]
    if len(returns) != 1:
        raise RuntimeError('Shared bridge return is not recognized; no files changed')
    node = returns[0]
    expression = ast.unparse(node.value)
    def known(n, names=None):
        names = set() if names is None else names
        if isinstance(n, ast.Name):
            return n.id == 'GameBridge' and 'wrap_e3mi_handler' in names
        if not isinstance(n, ast.Call) or not isinstance(n.func, ast.Name) or len(n.args)!=1 or n.keywords:
            return False
        name=n.func.id
        if name not in ('wrap_native_input_handler','wrap_e3mi_handler','wrap_tower_handler','wrap_reel_handler','wrap_agb_handler','wrap_agb_match_handler','wrap_ninja_handler','wrap_backyard_handler','wrap_cave_handler','wrap_pinball_handler','wrap_blob_handler','wrap_boop_handler','wrap_bad_influence_handler','wrap_riotball_handler','wrap_blocky_frogger_handler','wrap_color_rush_handler','wrap_final_cut_handler','wrap_sniper_kitty_handler','wrap_ghost_bubble_handler','wrap_racing_handler','wrap_party_handler','wrap_dogfight_handler','wrap_npcs_handler','wrap_wormaldeon_handler') or name in names:
            return False
        return known(n.args[0], names | {name})
    if not known(node.value):
        raise RuntimeError('Expected the known working Escape/Tower/Reel bridge; nothing changed')
    # An installed handler remains valid inside later game wrappers. Preserve order.
    already = any(isinstance(n, ast.Call) and isinstance(n.func, ast.Name)
        and n.func.id == 'wrap_bad_influence_handler' for n in ast.walk(node.value))
    # Require the real shared state used by the inspected current bridge.
    if not {'ACTIVE_WEB_GAME', 'ACTIVE_LOCK'} <= {
        n.id for n in ast.walk(tree) if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Store)}:
        raise RuntimeError('Existing shared game lease not found')
    lines = source.splitlines(keepends=True)
    newline = '\r\n' if '\r\n' in source else '\n'
    if not already:
        if node.lineno != node.end_lineno or lines[node.lineno-1].strip() != 'return '+expression:
            raise RuntimeError('Unexpected inline bridge return; no files changed')
        indent = lines[node.lineno-1][:node.col_offset]
        lines[node.lineno-1] = indent + 'return wrap_bad_influence_handler(' + expression + ')' + newline
    patched = ''.join(lines)
    imported = any(isinstance(n, ast.ImportFrom) and n.module == 'bad_influence_routes'
        and any(a.name == 'wrap_bad_influence_handler' and a.asname is None for a in n.names) for n in tree.body)
    if not imported:
        patched = 'from bad_influence_routes import wrap_bad_influence_handler' + newline + patched
    compile(patched, 'arcadium_game_bridge.py', 'exec')
    return patched


SLUGS=('bad-influence',)
CONTROLS='Real GoDice supply both rolls on the PC. D-pad/shoulders choose dice roles and secret decisions; A review/lock; B correct; START advance when ready. No manual dice or new APK.'

def registration(catalog):
 if not isinstance(catalog.get('games'),list):raise RuntimeError('Unknown catalog format')
 matches=[]
 for game in catalog['games']:
  labels=[re.sub('[^a-z0-9]','',str(game.get(k,'')).lower()) for k in ('id','name','title')]
  paths=[str(game.get(k,'')).lower().replace('\\','/') for k in ('launchUrl','launchTarget','url','path')]
  if any(v in ('badinfluence','arcadiumbadinfluence') for v in labels) or any('/bad-influence/' in v for v in paths):matches.append(game)
 if len(matches)>1:raise RuntimeError('Duplicate Bad Influence registrations; nothing changed')
 if matches:game=matches[0]
 else:
  game=json.loads((SOURCE/'games/bad-influence/arcadium-game.json').read_text());catalog['games'].append(game)
 if not game.get('id'):game['id']='bad-influence'
 if not game.get('image'):game['image']='/games/bad-influence/card.svg'
 game.update(name='Bad Influence',description='Six-player physical GoDice game show. Two real dice each, private Mini Vibe decisions, five elimination rounds and one champion.',launchUrl='/games/bad-influence/index.html?v=shared1',gameType='html',active=True,controls=CONTROLS,miniVibeUrl='/games/bad-influence/personal-v1/vibe.html',vibeUrl='/games/bad-influence/personal-v1/vibe.html',controllerUrl='/games/bad-influence/personal-v1/vibe.html')
 return catalog


def verify_payload():
    checks=SOURCE/'CHECKSUMS.json'
    if not checks.is_file():
        raise RuntimeError('Incomplete extraction: CHECKSUMS.json is missing')
    for name,expected in json.loads(checks.read_text()).items():
        file=(SOURCE/name).resolve()
        if not file.is_relative_to(SOURCE.resolve()) or not file.is_file() or digest(file.read_bytes())!=expected:
            raise RuntimeError('Package file missing or changed: '+name+'; extract the complete ZIP again')


def prepare(root):
    verify_payload()
    existing=root/'universal_input_routes.py'
    if not existing.is_file() or 'wrap_native_input_handler' not in (root/'arcadium_game_bridge.py').read_text(encoding='utf-8-sig'):
        raise RuntimeError('Install the Shared Mini Vibe Controls PC platform first. Bad Influence uses the existing universal v16 controller; no game-specific APK is needed.')
    server=(root/'arcadium_server.py').read_text(encoding='utf-8-sig')
    if 'arcadium_game_bridge' not in server:
        raise RuntimeError('Selected server does not load the existing shared game bridge')
    original=(root/'arcadium_game_bridge.py').read_bytes().decode('utf-8-sig')
    patched=patch_bridge(original)
    helpers={'e3mi_routes','tower_panic_routes','reel_mayhem_routes','agb_solo_routes','agb_match_routes','ninja_routes','backyard_routes','cave_routes','pinball_routes','blob_routes','dogfight_routes','npcs_routes','worm_tennis_routes','party_routes','rc_racing_routes','boop_routes','ghost_bubble_routes','universal_input_routes','sniper_kitty_routes','final_cut_routes','color_rush_routes','blocky_frogger_routes','riotball_routes'}
    for node in ast.parse(patched).body:
        if isinstance(node,ast.ImportFrom) and node.module in helpers:
            helper=root/(node.module+'.py')
            if not helper.is_file():raise RuntimeError('Current bridge requires missing '+helper.name)
            compile(helper.read_bytes(),str(helper),'exec')
    catalog=json.loads((root/'data/arcadium.json').read_text(encoding='utf-8-sig'))
    writes={Path('data/arcadium.json'):(json.dumps(registration(catalog),ensure_ascii=False,indent=2)+'\n').encode(),
        Path('arcadium_game_bridge.py'):patched.encode(),Path('bad_influence_routes.py'):(SOURCE/'bad_influence_routes.py').read_bytes()}
    compile(writes[Path('bad_influence_routes.py')],'bad_influence_routes.py','exec')
    for file in sorted((SOURCE/'games').rglob('*')):
        if file.is_file():
            relative=Path('games')/file.relative_to(SOURCE/'games')
            writes[relative]=file.read_bytes()
    return writes


def install(root):
    root = root.resolve()
    writes = prepare(root)
    for rel in writes:
        if not (root / rel).resolve().is_relative_to(root):
            raise RuntimeError('Destination escapes the installation')
    stamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    backup = root / 'arcadium_backups' / ('bad_influence_v1_' + stamp)
    backup.mkdir(parents=True)
    manifest = {'kind':'bad-influence-v1', 'root': str(root), 'files': {}, 'created_directories': []}
    after_catalog=json.loads(writes[Path('data/arcadium.json')])
    old_catalog=json.loads((root/'data/arcadium.json').read_text(encoding='utf-8-sig'))
    manifest['catalog_after_games']=[g for g in after_catalog['games'] if g.get('id') in SLUGS or g.get('launchUrl','').split('?')[0] in ['/games/'+s+'/index.html' for s in SLUGS]]
    manifest['catalog_before_games']={g['id']:next((old for old in old_catalog['games'] if old.get('id')==g['id']),None) for g in manifest['catalog_after_games']}
    for rel, data in writes.items():
        path = root / rel
        if path.exists():
            saved = backup / rel
            saved.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, saved)
        manifest['files'][rel.as_posix()] = {'existed': path.exists(), 'installed_sha256': digest(data), 'backup_sha256':digest((backup/rel).read_bytes()) if path.exists() else None}
    for slug in SLUGS:
        if not (root/'games'/slug).exists():manifest['created_directories'].append('games/'+slug)
    (backup / 'manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    changed = []
    try:
        for rel, data in writes.items():
            path = root / rel
            if path.exists() and path.read_bytes() == data:
                continue
            path.parent.mkdir(parents=True, exist_ok=True)
            atomic_write(path, data)
            changed.append(rel)
    except Exception:
        for rel in reversed(changed):
            if manifest['files'][rel.as_posix()]['existed']:
                atomic_write(root / rel, (backup / rel).read_bytes())
            else:
                (root / rel).unlink(missing_ok=True)
        for name in manifest['created_directories']:
            folder = root / name
            if folder.exists() and not any(folder.iterdir()):
                folder.rmdir()
        raise
    return backup


def rollback(backup):
    backup = backup.resolve()
    manifest = json.loads((backup / 'manifest.json').read_text(encoding='utf-8'))
    if manifest.get('kind') not in ('bad-influence-v1',):
        raise RuntimeError('Select a bad_influence_v1_* backup from this update, not an older OS/game backup')
    root = Path(manifest['root']).resolve()
    catalog_restore=None
    for name, info in manifest['files'].items():
        if Path(name).is_absolute() or '..' in Path(name).parts:
            raise RuntimeError('Invalid backup path')
        if info['existed'] and digest((backup/name).read_bytes()) != info['backup_sha256']:
            raise RuntimeError('Backup checksum failed; nothing restored')
        if name not in ('data/arcadium.json','arcadium_game_bridge.py','bad_influence_routes.py') and not any(name.startswith('games/'+slug+'/') for slug in SLUGS):
            raise RuntimeError('Not a Bad Influence backup; no files restored')
        path = (root / name).resolve()
        if not path.is_relative_to(root) or not path.is_file():
            raise RuntimeError('Invalid restore destination: '+name)
        if digest(path.read_bytes()) == info['installed_sha256']:
            continue
        if name=='data/arcadium.json':
            # Launch activity and unrelated game edits must survive game rollback.
            current=json.loads(path.read_text(encoding='utf-8-sig'))
            expected=manifest['catalog_after_games']
            updates=[]
            for game in expected:
                entries=[(i,g) for i,g in enumerate(current.get('games',[])) if g.get('id')==game['id']]
                if len(entries)!=1 or entries[0][1]!=game:break
                updates.append((entries[0][0],manifest['catalog_before_games'][game['id']]))
            if len(updates)==len(expected):
                for index,original in sorted(updates,reverse=True):
                    if original is None:current['games'].pop(index)
                    else:current['games'][index]=original
                catalog_restore=(json.dumps(current,ensure_ascii=False,indent=2)+'\n').encode()
                continue
        if digest(path.read_bytes()) != info['installed_sha256']:
            raise RuntimeError('Later changes detected in '+name+'. Refusing to overwrite later work.')
    for name, info in manifest['files'].items():
        path = root / name
        if name=='data/arcadium.json' and catalog_restore is not None:
            atomic_write(path,catalog_restore)
            continue
        if info['existed']:
            atomic_write(path, (backup / name).read_bytes())
        else:
            path.unlink()
    for name in manifest.get('created_directories', []):
        folder = (root / name).resolve()
        if folder.is_relative_to(root) and folder.is_dir() and not any(folder.iterdir()):
            folder.rmdir()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path)
    parser.add_argument('--rollback', type=Path)
    args = parser.parse_args()
    if args.rollback:
        rollback(args.rollback)
        print('Previous Bad Influence files restored. Restart Windows once before reopening Arcadium.')
        return
    root = args.root
    if root is None:
        import tkinter
        from tkinter import filedialog
        ui = tkinter.Tk(); ui.withdraw()
        chosen = filedialog.askdirectory(title='Select the existing Arcadium_OS_COMPACT installation')
        ui.destroy()
        if not chosen:
            raise RuntimeError('Cancelled; nothing changed')
        root = Path(chosen)
    backup = install(root)
    print('Bad Influence installed. Backup:', backup)
    print('RESTART WINDOWS ONCE to load the added game route, then open Arcadium normally on 8787.')
    print('Keep your existing pairing. Open Bad Influence from its existing carousel card.')
    print('Test with your Mini Vibes after restarting. Installation alone is not hardware verification.')


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        print('STOP:', error)
        sys.exit(1)
