from pathlib import Path
import json,tkinter as tk
from tkinter import filedialog
from update_bad_influence import install,rollback
ui=tk.Tk();ui.title('Arcadium / Bad Influence');ui.geometry('750x430');status=tk.StringVar(value='Bad Influence uses REAL GoDice: two per player, paired on the PC. Six Mini Vibes make private decisions. Select your existing Arcadium_OS_COMPACT folder. Keep the current universal Mini Vibe app and pairing. No new APK.')
tk.Label(ui,text='BAD INFLUENCE / REAL GODICE. PRIVATE DECISIONS.',font=('Segoe UI',15,'bold')).pack(pady=20);tk.Label(ui,textvariable=status,wraplength=700,justify='left',font=('Segoe UI',12)).pack(padx=20,pady=20)
def run():
 folder=filedialog.askdirectory(title='Select your existing Arcadium_OS_COMPACT folder')
 if not folder:return
 try:
  backup=install(Path(folder));Path(__file__).with_name('BAD_INFLUENCE_RECEIPT.json').write_text(json.dumps({'backup':str(backup)},indent=2));status.set('Installed. Backup: '+str(backup)+'\n\nRestart Windows once, then launch Bad Influence. Pair all 12 GoDice in the PC hardware panel. Open each round, then roll both real dice. Mini Vibes choose Trouble/Survival roles and secret decisions. A reviews/locks, B corrects. The host reveals once everyone is locked. No random/manual dice replacement. No new APK.\n\nPhysical Bluetooth and Mini Vibe acceptance are still needed.')
 except Exception as e:status.set('Stopped: '+str(e))
def undo():
 folder=filedialog.askdirectory(title='Select the bad_influence_v1_* backup')
 if not folder:return
 try:rollback(Path(folder));status.set('Previous Bad Influence restored. Restart Windows once.')
 except Exception as e:status.set('Rollback stopped: '+str(e))
tk.Button(ui,text='INSTALL BAD INFLUENCE',command=run,padx=20,pady=12).pack(pady=8);tk.Button(ui,text='Rollback this update',command=undo).pack();ui.mainloop()
