# Validation

Engine: `node integrations/bad-influence/tests/engine.test.mjs`.
Package: `python integrations/bad-influence/build_package.py`.
Python: `python -m unittest discover -s integrations/bad-influence/tests -p 'test_*.py'`.
Exact receiver harness: `python integrations/bad-influence/tests/harness.py --server-reference PATH_TO_ORIGINAL_arcadium_server.py`.
Browser: `NODE_PATH=/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules node integrations/bad-influence/tests/browser.cjs`.

Engine tests cover fresh connected real dice requirements, no generated rolls, stale/baseline rejection, held/released selection, locked roll freeze, early reveal guard, all five rounds, cap/conservation/proportional attacks, Friendly Fire bonus, majority tie, gamble, champion, undo and restart.

Python tests exercise six private routes, stale images/owner handoff, scoped touch tokens and epoch/sequence validation, extracted ZIP install/reinstall/rollback and prior-game/art preservation. Browser tests use the original native receiver, six private pages, and clearly labelled physical GoDice event fixtures. They do not pair actual Bluetooth devices.

Physical acceptance remains: twelve real GoDice through the PC Bluetooth stack, six Mini Vibes and real LAN, repeated round rolls, lock timing, disconnect/reconnect and return to previous games. No real-device/Bluetooth/antivirus scan results are claimed. Windows launcher and exact public download results are recorded in repository review/delivery.json.

Completed: engine suite, five Python installer/transport tests, and six-view browser suite passed. Browser checks completed all five rounds, reveal privacy, corrections, undo, spectator/champion views and five-game handoff without script errors. GoDice rolls in automation were event fixtures, not Bluetooth hardware. Original four libraries and six portraits are byte-for-byte preserved (review/preserved-assets.json).
