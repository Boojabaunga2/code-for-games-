# Credits

User-supplied bad-influence.zip provides the original five-round game, characters JAX/NOVA/RICO/LUNA/BLAZE/ZOE and their portrait artwork, and the existing GoDice SDK, manager, simulator and shared PP utility files. Those four library files and six portraits are copied unchanged.

Clean neon stage environment generated for this build using OpenAI image generation, based on the supplied stage style with all baked UI/labels/people removed. The fallback SVG card reuses this stage and the user's original character portraits.

New code adds real-only GoDice event validation, simultaneous private decisions, capped/conserved transfer scoring, Mini Vibe shared controls, live private views, guarded installation and test fixtures. No Android app files are modified.
