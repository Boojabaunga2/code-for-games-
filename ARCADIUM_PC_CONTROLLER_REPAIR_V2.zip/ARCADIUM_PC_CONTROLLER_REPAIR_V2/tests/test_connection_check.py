import importlib.util,unittest
from pathlib import Path
path=Path(__file__).resolve().parents[1]/'CHECK_BLOB_CONNECTION.py'
spec=importlib.util.spec_from_file_location('blob_check',path);check=importlib.util.module_from_spec(spec);spec.loader.exec_module(check)
class Diagnosis(unittest.TestCase):
 def test_missing_helper_is_not_claimed_fixed(self):
  self.assertIn('cannot distinguish',check.diagnosis({'/'+check.SLUG+'/status':{'http':404}}))
 def test_loaded_inactive_identifies_activation_failure(self):
  self.assertIn('lease is inactive',check.diagnosis({'/'+check.SLUG+'/status':{'http':200,'json':{'active':False}}}))
 def test_server_success_is_not_hardware_verification(self):
  checks={'/'+check.SLUG+'/status':{'http':200,'json':{'active':True}}}
  for c in check.COLORS:
   checks['/api/vibe/mode?color='+c]={'http':200,'json':{'mode':'web-game','game':check.SLUG}}
   checks['/'+check.SLUG+'/frame?color='+c]={'http':200}
  self.assertIn('does not verify the physical',check.diagnosis(checks))
  checks['/'+check.SLUG+'/frame?color=blue']={'http':503}
  self.assertIn('frame feeds are unavailable',check.diagnosis(checks))
 def test_unavailable_server_reports_errors(self):
  result=check.read_check('/test','http://127.0.0.1:1')
  self.assertIn('error',result)
