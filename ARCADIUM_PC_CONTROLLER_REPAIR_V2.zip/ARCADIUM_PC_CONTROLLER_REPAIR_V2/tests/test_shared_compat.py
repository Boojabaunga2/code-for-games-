import unittest,tempfile,shutil,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));import compat_patch
class Compat(unittest.TestCase):
 def test_targeted_patch_preserves_assets_and_second_install(self):
  with tempfile.TemporaryDirectory() as temp:
   root=Path(temp)
   for folder,slug,files in [('cave-money','cave-money-unga-boonga',['index.html','cave-runtime.js']),('npcs','npcs-non-playable-characters-of-real-life',['index.html','npcs-runtime.js']),('rc-trigger-racing','rc-trigger-racing',['index.html','input.mjs','native.mjs'])]:
    dest=root/'games'/slug;dest.mkdir(parents=True)
    for n in files:shutil.copyfile(ROOT.parent/folder/'games'/slug/n,dest/n)
    (dest/'approved-art.png').write_bytes(b'USER APPROVED GRAPHICS')
   (root/'arcadium_server.py').write_bytes(b'MAIN SERVER');(root/'universal_input_routes.py').write_bytes(b'WORKING SHARED PLATFORM');(root/'index.html').write_bytes(b'HOME')
   writes={**compat_patch.prepare(root,ROOT),**compat_patch.racing(root,ROOT)}
   self.assertEqual(len(writes),13)
   for p,data in writes.items():
    self.assertTrue(str(p).startswith('games/'));(root/p).write_bytes(data)
   self.assertEqual(compat_patch.prepare(root,ROOT),{});self.assertEqual(compat_patch.racing(root,ROOT),{})
   self.assertEqual((root/'index.html').read_bytes(),b'HOME');self.assertEqual((root/'universal_input_routes.py').read_bytes(),b'WORKING SHARED PLATFORM')
   for p in root.glob('games/*/approved-art.png'):self.assertEqual(p.read_bytes(),b'USER APPROVED GRAPHICS')
 def test_unknown_version_refused_without_replacement(self):
  with tempfile.TemporaryDirectory() as temp:
   root=Path(temp);d=root/'games/rc-trigger-racing';d.mkdir(parents=True)
   for n in ['index.html','input.mjs','native.mjs']:(d/n).write_text('UNRECOGNIZED USER VERSION')
   with self.assertRaises(RuntimeError):compat_patch.racing(root,ROOT)
   self.assertTrue(all(p.read_text()=='UNRECOGNIZED USER VERSION' for p in d.iterdir()))
class ProjectGhostCollection(unittest.TestCase):
 def test_only_game_sources_are_collected_locally(self):
  from collect_project_ghost import collect
  import zipfile
  with tempfile.TemporaryDirectory() as temp:
   root=Path(temp);folder=root/'games/project-ghost';folder.mkdir(parents=True)
   (folder/'index.html').write_text('<html>game</html>');(folder/'vibe.js').write_text('controller')
   (folder/'pair.json').write_text('PRIVATE');(root/'arcadium_server.py').write_text('PRIVATE');(folder/'.hidden.js').write_text('PRIVATE')
   output=root/'PROJECT_GHOST_SOURCE.zip';self.assertEqual(collect(root,output),str(output))
   with zipfile.ZipFile(output) as z:self.assertEqual(set(z.namelist()),{'project-ghost/index.html','project-ghost/vibe.js'})
if __name__=='__main__':unittest.main()

from test_blob import Install,chain
import update_blob
class FullRepair(unittest.TestCase):
 setUp=Install.setUp
 tearDown=Install.tearDown
 def test_full_repair_and_rollback_preserve_working_platform_and_art(self):
  root=self.root;(root/'pinball_routes.py').write_bytes((ROOT.parent/'pinball-pandemonium/pinball_routes.py').read_bytes());(root/'arcadium_game_bridge.py').write_text(chain())
  originals={}
  for folder,slug,files in [('cave-money','cave-money-unga-boonga',['index.html','cave-runtime.js']),('npcs','npcs-non-playable-characters-of-real-life',['index.html','npcs-runtime.js']),('rc-trigger-racing','rc-trigger-racing',['index.html','input.mjs','native.mjs'])]:
   dest=root/'games'/slug;dest.mkdir(parents=True,exist_ok=True)
   for n in files:
    data=(ROOT.parent/folder/'games'/slug/n).read_bytes();(dest/n).write_bytes(data);originals[(dest/n).relative_to(root)]=data
   (dest/'custom-art.png').write_bytes(b'APPROVED')
  for n in ['universal_input_routes.py','sniper_kitty_routes.py']:(root/n).write_text('WORKING PLATFORM '+n)
  protected={n:(root/n).read_bytes() for n in ['arcadium_server.py','index.html','universal_input_routes.py','sniper_kitty_routes.py']}
  backup=update_blob.install(root)
  for n,data in protected.items():self.assertEqual((root/n).read_bytes(),data)
  for p in root.glob('games/*/custom-art.png'):self.assertEqual(p.read_bytes(),b'APPROVED')
  update_blob.rollback(backup)
  for n,data in originals.items():self.assertEqual((root/n).read_bytes(),data)
  for slug in compat_patch.GAMES:self.assertFalse((root/'games'/slug/'pc-input-compat.js').exists())
