from pathlib import Path
import argparse,importlib.util,sys,json,time
from http.server import ThreadingHTTPServer
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'ghost-bubble/tests'))
spec=importlib.util.spec_from_file_location('shared_native_reference',ROOT/'ghost-bubble/tests/native_transport.py');ref=importlib.util.module_from_spec(spec);spec.loader.exec_module(ref)
sys.path.insert(0,str(ROOT/'boop'));import boop_routes
sys.path.insert(0,str(ROOT/'universal-mini-vibe-input'));import universal_input_routes
sys.path.insert(0,str(ROOT/'sniper-kitty'));import sniper_kitty_routes
sys.path.insert(0,str(ROOT/'blob-drop'));import blob_routes
import tempfile,shutil
sys.path.insert(0,str(ROOT/'cave-money'));import cave_routes
sys.path.insert(0,str(ROOT/'npcs'));import npcs_routes
sys.path.insert(0,str(ROOT/'rc-trigger-racing'));import rc_racing_routes
import compat_patch
TEST_ROOT=Path(tempfile.mkdtemp(prefix='arcadium-shared-compat-'))
for folder,slug in [('cave-money','cave-money-unga-boonga'),('npcs','npcs-non-playable-characters-of-real-life'),('rc-trigger-racing','rc-trigger-racing')]:
 shutil.copytree(ROOT/folder/'games'/slug,TEST_ROOT/'games'/slug)
for relative,data in {**compat_patch.prepare(TEST_ROOT,ROOT/'blob-drop'),**compat_patch.racing(TEST_ROOT,ROOT/'blob-drop')}.items():
 (TEST_ROOT/relative).write_bytes(data)
cave_routes.BASE=TEST_ROOT;npcs_routes.BASE=TEST_ROOT;rc_racing_routes.BASE=TEST_ROOT
from types import SimpleNamespace
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--server-reference',type=Path,required=True);a=ap.parse_args();native=ref.receiver(a.server_reference);Real=native['ExactReceiver'];bridge,Base=ref.harness.modules();Parent=blob_routes.wrap_blob_handler(sniper_kitty_routes.wrap_sniper_kitty_handler(universal_input_routes.wrap_native_input_handler(boop_routes.wrap_boop_handler(Base))))
 Parent=cave_routes.wrap_cave_handler(npcs_routes.wrap_npcs_handler(rc_racing_routes.wrap_racing_handler(Parent)))
 class Handler(Parent):
  def log_message(self,*args):pass
  json_out=Real.json_out;body_json=Real.body_json
  def do_POST(self):
   if self.path=='/api/vibe/input':
    Real.do_POST(self)
    with native['VIBE_LOCK']:self.server.events={'latest':native['VIBE_SEQUENCE'],'events':[dict(e) for e in native['VIBE_EVENTS']],'slots':[dict(s,connected=time.time()-s['lastSeen']<8) for s in native['VIBE_SLOTS'].values()]}
    return
   if self.path=='/__test/reset':
    self.rfile.read(int(self.headers.get('Content-Length',0)))
    with native['VIBE_LOCK']:native['VIBE_SEQUENCE']=0;native['VIBE_EVENTS'].clear();universal_input_routes.EVENTS.clear();universal_input_routes.SEQUENCE=0;universal_input_routes.SLOTS.clear()
    self.server.events={'latest':0,'events':[],'slots':[]};self.send_response(204);self.send_header('Content-Length','0');self.end_headers();return
   if self.path=='/__test/events':
    self.server.events=json.loads(self.rfile.read(int(self.headers['Content-Length'])));self.send_response(204);self.send_header('Content-Length','0');self.end_headers();return
   return super().do_POST()
 server=ThreadingHTTPServer(('127.0.0.1',8787),Handler);server.events={'latest':0,'events':[],'slots':[]};server.native_app=SimpleNamespace(VIBE_PAIR_TOKEN=native['VIBE_PAIR_TOKEN'],PINK_DEVICE_IP=None);print('Blob + Kitty exact native receiver and prior games on8787',flush=True);server.serve_forever()
