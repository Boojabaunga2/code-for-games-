import base64,importlib.util,json,sys,tempfile,threading,time,unittest,urllib.request,urllib.error
from pathlib import Path
from http.server import ThreadingHTTPServer
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT));import update_blob as updater;import blob_routes as routes
spec=importlib.util.spec_from_file_location('pin_reference',ROOT.parent/'pinball-pandemonium/tests/test_pinball.py');ref=importlib.util.module_from_spec(spec);spec.loader.exec_module(ref)
def chain():return ref.updater.patch_bridge(ref.chain())
def modern_chain(existing_blob=False):
    source=chain()
    if existing_blob:source=updater.patch_bridge(source)
    for folder,name in [('dogfight-riot','update_dogfight'),('npcs','update_npcs')]:
        sys.path.insert(0,str(ROOT.parent/folder))
        spec=importlib.util.spec_from_file_location(name+'_modern',ROOT.parent/folder/(name+'.py'))
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        source=module.patch_bridge(source)
    return source

def modules():
 bridge,worm=ref.reference.modules();source=updater.patch_bridge(modern_chain());exec(compile(source,'arcadium_game_bridge.py','exec'),bridge.__dict__);return bridge,worm
class Routes(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.bridge,worm=modules();cls.server=ThreadingHTTPServer(('127.0.0.1',0),worm.wrap(cls.bridge.bridge(ref.reference.Base)));cls.server.events={'latest':0,'events':[],'slots':[]}
  cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True);cls.thread.start();cls.base='http://127.0.0.1:'+str(cls.server.server_port)
 @classmethod
 def tearDownClass(cls):cls.server.shutdown();cls.server.server_close();cls.thread.join()
 def setUp(self):self.bridge.ACTIVE_WEB_GAME.update(game=None,until=0);routes.FRAMES.clear()
 def request(self,path,data=None):
  req=urllib.request.Request(self.base+path,data=None if data is None else json.dumps(data).encode(),headers={'Content-Type':'application/json'})
  try:
   with urllib.request.urlopen(req) as response:return response.status,response.read()
  except urllib.error.HTTPError as e:return e.code,e.read()
 def test_six_seats_and_stale_frames(self):
  self.assertEqual(self.request(routes.ACTIVATE,{})[0],200)
  for i,color in enumerate(routes.COLORS):
   frame=b'\xff\xd8'+color.encode()
   self.assertEqual(self.request('/blob-drop-arcadium-ghost-race/frame',dict(seat=i+1,image=base64.b64encode(frame).decode()))[0],200)
   self.assertEqual(self.request('/blob-drop-arcadium-ghost-race/frame?color='+color),(200,frame))
   for endpoint in ['mode','launch']:
    self.assertEqual(json.loads(self.request('/api/vibe/'+endpoint+'?color='+color)[1])['page'],'/games/blob-drop-arcadium-ghost-race/personal/vibe.html')
  routes.FRAMES[1]=(time.monotonic()-4,b'\xff\xd8old');self.assertEqual(self.request('/blob-drop-arcadium-ghost-race/frame?color=red')[0],503)
  self.assertEqual(self.request('/blob-drop-arcadium-ghost-race/frame?color=purple')[0],400)
  self.assertEqual(self.request('/blob-drop-arcadium-ghost-race/frame',dict(seat=9,image='bad'))[0],400)
 def test_passthrough_switch_exit_and_assets(self):
  self.request(routes.ACTIVATE,{})
  for path in ['/games/blob-drop-arcadium-ghost-race/personal/vibe.html','/games/blob-drop-arcadium-ghost-race/carousel-v1.png','/games/blob-drop-arcadium-ghost-race/assets/base.jpg','/api/vibe/events?after=0','/unrelated']:
   self.assertEqual(self.request(path)[0],200,path)
  self.assertEqual(self.request('/games/blob-drop-arcadium-ghost-race/%2e%2e/%2e%2e/blob_routes.py')[0],404)
  self.assertEqual(json.loads(self.request('/blob-drop-arcadium-ghost-race/status')[1])['build'],'blob-v3')
  self.request('/arcadium-vibe/activate/pinball-pandemonium',{})
  self.request(routes.ACTIVATE,{'active':False})
  self.assertEqual(json.loads(self.request('/api/vibe/mode?color=blue')[1])['game'],'pinball-pandemonium')
class Install(ref.Install):
 def test_blob_targeted_install_rollback(self):
  root=self.root
  (root/'pinball_routes.py').write_bytes((ROOT.parent/'pinball-pandemonium/pinball_routes.py').read_bytes())
  (root/'arcadium_game_bridge.py').write_text(chain())
  oldbridge=(root/'arcadium_game_bridge.py').read_bytes();server=(root/'arcadium_server.py').read_bytes()
  original=json.loads((root/'data/arcadium.json').read_text());backup=updater.install(root)
  self.assertEqual((root/'arcadium_server.py').read_bytes(),server);self.assertEqual((root/'index.html').read_text(),'ORIGINAL HOME')
  catalog=json.loads((root/'data/arcadium.json').read_text());self.assertEqual(catalog['games'][:2],original['games'])
  entry=catalog['games'][-1];self.assertEqual(entry['image'],'/games/blob-drop-arcadium-ghost-race/carousel-v1.png')
  after=(root/'arcadium_game_bridge.py').read_text();self.assertEqual(updater.patch_bridge(after),after)
  catalog['activity'].append({'later':'keep'});(root/'data/arcadium.json').write_text(json.dumps(catalog));updater.rollback(backup)
  restored=json.loads((root/'data/arcadium.json').read_text());self.assertEqual(restored['games'],original['games']);self.assertTrue(restored['activity']);self.assertEqual((root/'arcadium_game_bridge.py').read_bytes(),oldbridge)
 def test_registration_placeholder_replaced_without_duplicates(self):
  c={'games':[{'id':'blob-drop-arcadium-ghost-race','name':'Blob Drop','image':'assets/games_mockup.png','custom':1},{'id':'other'}]}
  updater.registration(c);self.assertEqual(len(c['games']),2);self.assertEqual(c['games'][0]['custom'],1);self.assertEqual(c['games'][0]['image'],'/games/blob-drop-arcadium-ghost-race/carousel-v1.png')
 def test_exact_zip_install_repeat_rollback_and_integrity(self):
  import zipfile
  root=self.root;(root/'pinball_routes.py').write_bytes((ROOT.parent/'pinball-pandemonium/pinball_routes.py').read_bytes());(root/'arcadium_game_bridge.py').write_text(chain())
  original_bridge=(root/'arcadium_game_bridge.py').read_bytes();original_catalog=json.loads((root/'data/arcadium.json').read_text());source=updater.SOURCE
  with tempfile.TemporaryDirectory() as temp:
   release=ROOT.parents[1]/'downloads/ARCADIUM_PC_CONTROLLER_REPAIR_V2.zip'
   with zipfile.ZipFile(release) as archive:archive.extractall(temp)
   updater.SOURCE=Path(temp)/release.stem
   try:
    backup=updater.install(root);first=(root/'arcadium_game_bridge.py').read_bytes();again=updater.install(root)
    self.assertEqual((root/'arcadium_game_bridge.py').read_bytes(),first);self.assertEqual(len(json.loads((root/'data/arcadium.json').read_text())['games']),len(original_catalog['games'])+1)
    updater.rollback(again);self.assertEqual((root/'arcadium_game_bridge.py').read_bytes(),first)
    updater.rollback(backup);self.assertEqual((root/'arcadium_game_bridge.py').read_bytes(),original_bridge);self.assertEqual(json.loads((root/'data/arcadium.json').read_text())['games'],original_catalog['games'])
    (updater.SOURCE/'games/blob-drop-arcadium-ghost-race/assets/base.jpg').unlink()
    with self.assertRaisesRegex(RuntimeError,'Package file missing or changed'):updater.install(root)
    self.assertEqual((root/'arcadium_game_bridge.py').read_bytes(),original_bridge)
   finally:updater.SOURCE=source
 def test_blob_unknown_bridge_stops_before_writes(self):
  (self.root/'arcadium_game_bridge.py').write_text('def bridge(Parent):\n return Parent\n')
  with self.assertRaises(RuntimeError):updater.install(self.root)
  self.assertFalse((self.root/'arcadium_backups').exists())

class ModernRepair(unittest.TestCase):
 setUp=Install.setUp
 tearDown=Install.tearDown
 def seed_modern(self,existing_blob=False):
  root=self.root
  for folder,name in [('pinball-pandemonium','pinball_routes.py'),('dogfight-riot','dogfight_routes.py'),('npcs','npcs_routes.py')]:
   (root/name).write_bytes((ROOT.parent/folder/name).read_bytes())
  if existing_blob:(root/'blob_routes.py').write_bytes((ROOT/'blob_routes.py').read_bytes())
  (root/'arcadium_game_bridge.py').write_text(modern_chain(existing_blob))
  c=json.loads((root/'data/arcadium.json').read_text())
  c['games'] += [{'id':'dogfight-riot','image':'dog-approved.png','launchUrl':'/games/dogfight-riot/index.html','custom':'keep dog'}, {'id':'npcs','image':'npcs-approved.png','launchUrl':'/games/npcs-non-playable-characters-of-real-life/index.html','custom':'keep npcs'}]
  (root/'data/arcadium.json').write_text(json.dumps(c));return c
 def test_missing_blob_repair_preserves_later_games_and_receipt(self):
  from INSTALL_BLOB_DROP import install_with_receipt
  before=self.seed_modern();root=self.root
  helpers={name:(root/name).read_bytes() for name in ['arcadium_server.py','dogfight_routes.py','npcs_routes.py','pinball_routes.py','index.html']}
  receipt=install_with_receipt(root)
  self.assertFalse(receipt['blob_handler_previously_present']);self.assertTrue(receipt['installed_files_verified']);self.assertFalse(receipt['runtime_verified'])
  for name,data in helpers.items():self.assertEqual((root/name).read_bytes(),data,name)
  after=json.loads((root/'data/arcadium.json').read_text());self.assertEqual(after['games'][:-1],before['games'])
  bridge=(root/'arcadium_game_bridge.py').read_text();self.assertEqual(updater.patch_bridge(bridge),bridge)
  updater.rollback(Path(receipt['backup']));self.assertEqual(json.loads((root/'data/arcadium.json').read_text())['games'],before['games'])
 def test_blob_nested_under_dogfight_npcs_is_not_duplicated(self):
  self.seed_modern(existing_blob=True);source=(self.root/'arcadium_game_bridge.py').read_text()
  self.assertEqual(updater.patch_bridge(source),source)
  backup=updater.install(self.root);self.assertEqual((self.root/'arcadium_game_bridge.py').read_text(),source);updater.rollback(backup)
 def test_actual_missing_routes_then_active_six_modes_after_repair(self):
  self.seed_modern();bridge,worm=ref.reference.modules()
  # Reproduce the supplied report: native relay is available, Blob-specific URLs are 404.
  class Original(ref.reference.Base):
   def do_GET(self):
    if self.path.startswith('/blob-drop-arcadium-ghost-race/'):return self.send_error(404,'File not found')
    return super().do_GET()
  def serve(source):
   exec(compile(source,'arcadium_game_bridge.py','exec'),bridge.__dict__)
   server=ThreadingHTTPServer(('127.0.0.1',0),worm.wrap(bridge.bridge(Original)));server.events={'latest':266,'events':[],'slots':[{'color':'blue','connected':True}]}
   thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start();return server,thread
  def get(server,path,data=None):
   req=urllib.request.Request('http://127.0.0.1:'+str(server.server_port)+path,data=None if data is None else json.dumps(data).encode(),headers={'Content-Type':'application/json'})
   try:
    with urllib.request.urlopen(req) as response:return response.status,response.read()
   except urllib.error.HTTPError as error:return error.code,error.read()
  before=(self.root/'arcadium_game_bridge.py').read_text();server,thread=serve(before)
  try:
   self.assertEqual(get(server,'/'+updater.SLUG+'/status')[0],404)
   self.assertEqual(get(server,'/'+updater.SLUG+'/frame?color=blue')[0],404)
   self.assertEqual(json.loads(get(server,'/api/vibe/mode?color=blue')[1])['mode'],'controller')
   self.assertTrue(json.loads(get(server,'/api/vibe/events?after=0')[1])['slots'][0]['connected'])
  finally:server.shutdown();server.server_close();thread.join()
  updater.install(self.root);server,thread=serve((self.root/'arcadium_game_bridge.py').read_text())
  try:
   self.assertEqual(json.loads(get(server,'/'+updater.SLUG+'/status')[1])['build'],'blob-v3')
   self.assertEqual(get(server,routes.ACTIVATE,{})[0],200)
   for color in routes.COLORS:self.assertEqual(json.loads(get(server,'/api/vibe/mode?color='+color)[1])['game'],updater.SLUG)
   self.assertEqual(get(server,'/games/dogfight-riot/assets/plane_p1.png')[0],200)
   self.assertEqual(get(server,'/games/npcs-non-playable-characters-of-real-life/assets/sprites/portraits/p1.png')[0],200)
  finally:server.shutdown();server.server_close();thread.join()
