const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');const root=path.join(__dirname,'..'),original=fs.readFileSync(path.join(root,'project/original.html'),'utf8'),game=fs.readFileSync(path.join(root,'games/blob-drop-arcadium-ghost-race/index.html'),'utf8');
const scripts=s=>[...s.matchAll(/<script[^>]*>([\s\S]*?)<\/script>/g)].map(m=>m[1]);
const a=scripts(original),b=scripts(game);for(const code of b)new Function(code);assert.equal(b[0],a[0],'original MIT Matter library unchanged');assert(!game.includes('data:image/'));assert(!game.includes('data:font/'));
const src={window:{}},dst={window:{}};vm.runInNewContext(a[1],src);vm.runInNewContext(b[1],dst);let images=0,sounds=0;
function sameFile(raw,url){assert.equal(Buffer.compare(Buffer.from(raw,'base64'),fs.readFileSync(path.join(root,'games/blob-drop-arcadium-ghost-race',url.split('/blob-drop-arcadium-ghost-race/')[1]))),0)}
sameFile(src.window.BD_ART.base,dst.window.BD_ART.base);images++;
for(const [key,data]of Object.entries(src.window.BD_ART.sprites)){sameFile(data,dst.window.BD_ART.sprites[key]);images++}
for(const [key,data]of Object.entries(src.window.BD_SOUNDS)){sameFile(data,dst.window.BD_SOUNDS[key]);sounds++}
const hashes=JSON.parse(fs.readFileSync(path.join(root,'project/asset-sha256.json'),'utf8')),crypto=require('node:crypto');for(const[file,digest]of Object.entries(hashes))assert.equal(crypto.createHash('sha256').update(fs.readFileSync(path.join(root,'games/blob-drop-arcadium-ghost-race/assets',file))).digest('hex'),digest);
function fn(s,name){const start=s.indexOf('function '+name+'(');assert(start>=0,name);let i=s.indexOf('{',start),level=1;for(i++;level&&i<s.length;i++){if(s[i]==='{')level++;if(s[i]==='}')level--}return s.slice(start,i)}
for(const name of ['onMerge','makeGhost','spill','lowestAlive','endRound','finishMatch','ghostReady','useGhost','botGhost','tryDrop','laneX','botChooseX','wall','mulberry32'])assert.equal(fn(game,name),fn(original,name),name+' original gameplay unchanged');
const engine=s=>s.slice(s.indexOf('function GameEngine(seed)'),s.indexOf('/* =================',s.indexOf('function GameEngine(seed)')));assert.equal(engine(game),engine(original),'all original Matter engine methods unchanged');
const viewer=fs.readFileSync(path.join(root,'games/blob-drop-arcadium-ghost-race/vibe.html'),'utf8');assert(!viewer.includes('matter-js'));assert(!viewer.includes('GameEngine'));
console.log('PASS original Matter library, engine methods, merge/score/round/ghost rules and '+images+' image/'+sounds+' sound bytes preserved; scripts parse; viewer has no simulation');
