"""Local test harness only; never included in the Windows release."""
from http.server import ThreadingHTTPServer
import json
from test_blob import modules,ref
bridge,worm=modules()
class Handler(worm.wrap(bridge.bridge(ref.reference.Base))):
 def do_POST(self):
  if self.path=='/__test/events':
   self.server.events=json.loads(self.rfile.read(int(self.headers['Content-Length'])));self.send_response(204);self.send_header('Content-Length','0');self.end_headers();return
  return super().do_POST()
if __name__=='__main__':
 server=ThreadingHTTPServer(('127.0.0.1',8787),Handler);server.events={'latest':0,'events':[],'slots':[]};print('Blob test harness on 8787',flush=True);server.serve_forever()
