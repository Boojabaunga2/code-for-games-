# Arcadium PC Controller Repair V2

**PC only. Keep the existing universal Mini Vibe v16 app. No APK is included or needed.**

Updates Blob Drop and migrates the installed Cave Money, NPCs and RC Trigger Racing input readers to the shared universal input. It handles true held direction/release, action buttons and racing shoulders. Ordinary and raw copies of the same A/START action are matched so they cannot fire twice. These are PC game adapters; the universal receiver, app, pairing and native input contract are unchanged.

## Install

1. Exit the open game and extract the complete ZIP.
2. Double-click **START_INSTALL.cmd**.
3. Select the existing **Arcadium_OS_COMPACT** folder used by the working Kitty game.
4. Restart Windows once, open Arcadium normally, and test the games.

The installer inspects all targeted files before writing. Missing optional games are skipped. Unknown input-module versions stop the repair before writes. Cave Money, NPCs and RC receive only input-source edits and shared reader scripts: no models, tracks, backgrounds, assets or rules are replaced. Racing keeps ten laps, R1 gas and L1 brake. Kitty, Ghost Bubble, Boop, the native receiver, Home, main server, pairing and unrelated catalog entries remain untouched. Blob Drop retains a personal live board per colour, its original physics/ghost powers and A drop/B swap/START controls. D-pad aim now moves only while held and stops on release.

A guarded backup is created under arcadium_backups/blob_shared_v3_*. ROLLBACK_BLOB_DROP.py can restore this repair and refuses to overwrite later changes. It restores the compatibility edits as well as Blob Drop. Existing custom carousel art is retained.

## Project Ghost

**Project Ghost is not repaired by this build.** Its inspected OS relay uses digits/ENTER/BACK/CLR, and its actual game/view source was not supplied. Guessing an action map could break number entry. If installed, the installer saves **PROJECT_GHOST_SOURCE.zip beside itself** containing only that game's HTML/JS/CSS source. Attach that ZIP in chat so its PC adapter can be implemented. It excludes OS configuration, server source, pairing files, hidden files and vendor directories. Nothing is uploaded automatically.

## Validation and limits

Tests use the actual inspected authenticated OS input receiver with synthetic invitations, the unchanged native platform and real game runtimes. They cover six Blob seats, raw A/START, hold/release/reversal, action deduplication in both arrival orders, personal feeds; Cave Money joins/movement/pause; NPC actions and direction state; RC gas/brake/release and ten laps. Targeted patch and exact ZIP installer tests verify preservation, repeat install, checksums, rollback and unknown-version refusal. Physical handhelds, the user's running process and venue Wi-Fi/GPU throughput still require testing. No hardware fix is claimed solely from software checks.
