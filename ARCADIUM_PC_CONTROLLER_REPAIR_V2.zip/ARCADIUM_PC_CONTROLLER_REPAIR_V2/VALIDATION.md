# Blob Drop V2 validation

- Original uploaded HTML retained as project/original.html. All original Matter engine methods, physics library, merge/scoring/spill/elimination/round/ghost rules remain identical. 50 images, 16 sounds and two fonts externalized without byte changes.
- Native canonical red/blue/green/yellow/pink/white mapping aligns the PC frame artwork, player metadata, ghost/mascot sprites, event handling and per-colour frame routes. Original baked player numbers are covered by canonical labels at render time; original image files remain unchanged.
- Six native joins and START, continuous press-only aiming/stop/centre, actual drop/swap, real Matter merges, true releases, reconnect, disconnect and pause tested in Chromium.
- Six distinct 720×720 frame feeds tested through the existing wrapper chain. Mini pages have neither Matter nor an engine. Personal rendering preserves authoritative state; rendering-only transient effect copies avoid pruning live game lists.
- Ghost elimination, junk/fog/freeze, cooldown and target selection, round end, match results, exit and handoff to Pinball tested.
- Existing main server/Home/other game registrations preserved by targeted install; repeat installation and rollback guarded; later unrelated catalog activity retained. Invalid frames/colours/traversal and stale streams rejected.
- Actual game-specific Mini Vibe page, card and original assets return HTTP200 through the existing 8787 helper chain. New card displayed in chat before inclusion.
- Release CRC/per-file hashes and download verified. No antivirus scan was available.

Actual Windows installation, six physical Mini Vibe displays and controls, reconnect/exit on native hardware, live 3D carousel appearance and haptics remain unverified. Cloud results are not hardware acceptance.

## Live failure and V2 repair

The uploaded BLOB_DROP_CONNECTION_REPORT.json records a connected blue seat with 266 native inputs, HTTP200 native event/mode routes, controller mode for all colours, and HTTP404 for Blob-specific health and all frame routes. Running Blob integration is missing; the report alone cannot identify missing files versus an older loaded process or another selected OS copy.

V2 accepts current known Dogfight/NPCs wrapper chains. Tests cover a missing Blob wrapper beneath those later games, an existing nested Blob wrapper (idempotent), unchanged main server/Home/later helpers/catalog rows, and guarded rollback. A before/after HTTP test reproduces 404/Command Deck while blue is connected, then shows blob-v2 health and all six game modes after loading the repaired source. The real original Windows process has not yet been reloaded/verified.

The visible installer verifies the installed file hashes and preserves the main server byte-for-byte, writing a local receipt with runtime_verified=false. HTML/runtime URLs and the on-screen badge are versioned for V2. Original V1 gameplay, card, assets and personal-view behavior stay unchanged. The included checker now opens before network work and saves its report automatically. V1 ZIP is retained unchanged.
