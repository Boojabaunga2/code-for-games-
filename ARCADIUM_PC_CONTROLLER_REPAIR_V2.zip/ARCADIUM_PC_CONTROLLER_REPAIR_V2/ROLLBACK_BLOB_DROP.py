"""Restore a checksummed Blob Drop V1/V2 backup with normal Python file operations."""
from pathlib import Path
import tkinter
from tkinter import filedialog,messagebox
from update_blob import rollback

def main():
    window=tkinter.Tk();window.withdraw()
    try:
        folder=filedialog.askdirectory(title='Select the blob_personal_* V1/V2 backup to restore',parent=window)
        if not folder:return
        rollback(Path(folder))
        messagebox.showinfo('Blob Drop restored','Backup restored. Restart Windows once before reopening Arcadium.',parent=window)
    except Exception as error:
        messagebox.showerror('Rollback stopped',str(error),parent=window)
    finally:window.destroy()

if __name__=='__main__':main()
