"""Build from supplied HTML; external assets remain byte-identical."""
from pathlib import Path
import base64,hashlib,json,re,subprocess
ROOT=Path(__file__).resolve().parents[1];GAME=ROOT/'games/blob-drop-arcadium-ghost-race';GAME.mkdir(parents=True,exist_ok=True)
s=(ROOT/'project/original.html').read_text();scripts=list(re.finditer(r'<script[^>]*>([\s\S]*?)</script>',s))
asset_script=scripts[1]
result=subprocess.run(['node','-e',"const vm=require('vm');let s='';process.stdin.on('data',c=>s+=c).on('end',()=>{const c={window:{}};vm.runInNewContext(s,c);process.stdout.write(JSON.stringify(c.window))})"],input=asset_script[1],capture_output=True,text=True,check=True)
assets=json.loads(result.stdout);hashes={}
def save(name,raw):
 p=GAME/'assets'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);hashes[name]=hashlib.sha256(raw).hexdigest();return '/games/blob-drop-arcadium-ghost-race/assets/'+name
assets['BD_ART']['base']=save('base.jpg',base64.b64decode(assets['BD_ART']['base']))
for name,data in assets['BD_ART']['sprites'].items():assets['BD_ART']['sprites'][name]=save(name+'.png',base64.b64decode(data))
for name,data in assets['BD_SOUNDS'].items():assets['BD_SOUNDS'][name]=save(name+'.mp3',base64.b64decode(data))
s=s[:asset_script.start(1)]+'\n'.join('window.'+name+'='+json.dumps(data)+';' for name,data in assets.items())+s[asset_script.end(1):]
font_counter=0
def font(m):
 global font_counter
 font_counter+=1;return 'url('+save('font'+str(font_counter)+'.woff2',base64.b64decode(m[1]))+')'
s=re.sub(r'url\(data:font/woff2;base64,([A-Za-z0-9+/=]+)\)',font,s)
def rep(a,b):
 global s
 if a not in s:raise RuntimeError('Missing source marker: '+a[:80])
 s=s.replace(a,b)
rep("loadImg('base', 'data:image/jpeg;base64,' + ART.base)","loadImg('base', ART.base)")
rep("loadImg(k, 'data:image/png;base64,' + ART.sprites[k])", "loadImg(k, ART.sprites[k])")
a=s.index('      var bin = atob(src[name])');b=s.index('\n    });',a)
s=s[:a]+"      fetch(src[name]).then(function(r){if(!r.ok)throw Error('Audio unavailable');return r.arrayBuffer()}).then(function(buffer){return self.ctx.decodeAudioData(buffer)}).then(function(buf){self.bufs[kind].push(buf)}).catch(function(){});"+s[b:]
# Seat artwork and geometry are recomposed at render time, with original image bytes preserved.
a=s.index('var PLAYERS = [');b=s.index('\n];',a)+3
old=s[a:b];items=re.findall(r'\{ name:.*?\}',old)
order=[1,2,5,3,0,4];s=s[:a]+'var PLAYERS = [\n  '+',\n  '.join(items[i] for i in order)+'\n];'+s[b:]
rep('var ART = window.BD_ART, GEO = window.BD_GEO;', 'var ART = window.BD_ART, GEO = window.BD_GEO;\n'+(ROOT/'project/canonical-art.js').read_text())
rep('  if (S.paused) return;\n  S.clock += dt;', '  if (S.paused) return;\n  updateNative(dt);\n  S.clock += dt;')
rep('if (S.sandbox && who === 0) who = S.you;', 'if (S.sandbox && !nativeDispatching && who === 0) who = S.you;')
rep('function newMatch() {','function newMatch() {\n  clearAllNative();')
rep('function exitSandbox() {','function exitSandbox() {\n  clearAllNative();')
rep("  ctx.drawImage(IMG.base, 0, 0, W, H);", "  drawCanonicalBase();")
rep("fit('PRESS 0 ON YOUR PAD'", "fit('PRESS A ON MINI VIBE'")
rep("  var ok = n >= 2;", "  var ok = n >= 2;")
rep("label = 'SETUP'; timeStr = '+ GO';", "label = 'SETUP'; timeStr = 'START';")
# Build hooks share the actual engine/rendering scope; no second simulation.
rep('/* ================= LOOP ================= */', (ROOT/'project/native-controls.js').read_text()+'\n'+(ROOT/'project/personal-render.js').read_text()+'\n/* ================= LOOP ================= */')
rep('  makeGhost: makeGhost, spill: spill, TIERS: TIERS, COL: COL, IMG: IMG };', '  makeGhost: makeGhost, spill: spill, TIERS: TIERS, COL: COL, IMG: IMG,PLAYERS:PLAYERS,nativeEvent:nativeEvent,NATIVE:NATIVE,clearNative:clearNative,clearAllNative:clearAllNative,personalFrame:personalFrame,beginPlay:beginPlay,endRound:endRound,finishMatch:finishMatch,exitSandbox:exitSandbox,get ready(){return loaded===toLoad&&!!IMG.base.naturalWidth},get nativeTargets(){return ghostTargets},get nativeCodes(){return ghostCodes} };')
rep('</body>', '<script src="/games/blob-drop-arcadium-ghost-race/blob-runtime.js?v=blob-v2"></script></body>')
(GAME/'index.html').write_text(s)
(ROOT/'project/asset-sha256.json').write_text(json.dumps(hashes,indent=2)+'\n')
print('Built Blob Drop;',len(hashes),'byte-preserved external assets')
