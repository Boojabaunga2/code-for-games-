var SEATS=['red','blue','green','yellow','pink','white'];
var NATIVE=SEATS.map(function(){return {held:{},modern:{},connected:false}});
var nativeDispatching=false;
function nativeGameKey(i,key){nativeDispatching=true;try{handleKey(i,key,false)}finally{nativeDispatching=false}}
var ghostTargets=[0,0,0,0,0,0],ghostCodes=[1,1,1,1,1,1],lastNativeStart=-1000;
function clearNative(i){NATIVE[i].held={}}
function clearAllNative(){for(var i=0;i<6;i++)clearNative(i)}
function targetFor(i,dir){
 var targets=S.players.filter(function(p){return p.state==='alive'}).map(function(p){return p.idx});
 if(!targets.length)return;var n=targets.indexOf(ghostTargets[i]);if(n<0)n=dir>0?-1:0;ghostTargets[i]=targets[(n+dir+targets.length)%targets.length];
}
function nativeEvent(e){
 var i=SEATS.indexOf(String(e.color||'').toLowerCase());if(i<0)return;
 var key=String(e.button||'').toUpperCase().replace(/^DPAD_/,'');
 var up=['up','release','released','keyup'].includes(String(e.action||e.state||'').toLowerCase());
 var n=NATIVE[i];if(up){n.modern[key]=true;delete n.held[key];return}
 if(!['LEFT','RIGHT','UP','DOWN','A','B','X','Y','L1','R1','START','SELECT'].includes(key))return;
 Audio.init();
 if(key==='START'){
  var now=performance.now();if(now-lastNativeStart<350)return;lastNativeStart=now;clearAllNative();
  if(S.phase==='setup'){
   S.joined[i]=true;
   var count=S.joined.filter(Boolean).length;if(count>=2||S.botFill)newMatch();
  }else if(S.phase==='over'){nativeGameKey(i,'0')}else S.paused=!S.paused;
  return;
 }
 if(S.phase==='setup'){
  if(key==='SELECT')S.joined[i]=false;else S.joined[i]=true;
  S.pressFlash[i]=S.clock;return;
 }
 if(S.paused)return;
 if(S.phase==='over'){if(key==='A')nativeGameKey(i,'0');return}
 var p=S.players[i];if(!p)return;
 // Rejoining a pre-existing CPU seat takes control of that same board, never resets it.
 if(p.seat==='bot'){p.seat='human';S.joined[i]=true}
 if(p.seat!=='human')return;
 if(p.state==='ghost'){
  if(key==='B'||key==='UP')ghostCodes[i]=ghostCodes[i]%3+1;
  else if(key==='DOWN')ghostCodes[i]=(ghostCodes[i]+1)%3+1;
  else if(key==='LEFT'||key==='L1')targetFor(i,-1);
  else if(key==='RIGHT'||key==='R1')targetFor(i,1);
  else if(key==='SELECT')p.armed=0;
  else if(key==='A'&&ghostReady(p)){
   var target=S.players[ghostTargets[i]];if(!target||target.state!=='alive'){targetFor(i,1);target=S.players[ghostTargets[i]]}
   if(target)useGhost(p,ghostCodes[i],target);
  }
  if(ghostReady(p)&&key!=='SELECT'&&key!=='A')p.armed=ghostCodes[i];
  return;
 }
 if(p.state!=='alive')return;
 if(key==='LEFT'||key==='RIGHT'){
  var other=key==='LEFT'?'RIGHT':'LEFT';delete n.held[other];n.held[key]=n.modern[key]?true:!n.held[key];p.lane=0;
 }else if(key==='SELECT')clearNative(i);
 else if(key==='A')nativeGameKey(i,'0');
 else if(key==='B'||key==='X')nativeGameKey(i,'.');
 else if(key==='UP'){clearNative(i);p.lane=5;p.eng.setAim(laneX(p,5))}
}
function updateNative(dt){
 if(S.phase!=='play'&&S.phase!=='intro')return;
 for(var i=0;i<6;i++){
  var p=S.players[i];if(!p||p.seat!=='human'||p.state!=='alive')continue;
  var mx=(NATIVE[i].held.RIGHT?1:0)-(NATIVE[i].held.LEFT?1:0);
  if(mx){p.lane=0;p.eng.setAim(p.eng.aimX+mx*240*dt/1000)}
 }
}
