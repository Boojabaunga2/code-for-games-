from pathlib import Path
import hashlib,json,zipfile
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT.parents[1]/'downloads/ARCADIUM_BLOB_DROP_PERSONAL_MINI_VIBE_V2.zip';PREFIX=OUT.stem
paths=[ROOT/name for name in ['INSTALL_BLOB_DROP.py','ROLLBACK_BLOB_DROP.py','CHECK_BLOB_CONNECTION.py','update_blob.py','blob_routes.py','README.md','VALIDATION.md']]+sorted((ROOT/'games').rglob('*'))
files={p.relative_to(ROOT).as_posix():p.read_bytes() for p in paths if p.is_file()}
allowed={'.py','.html','.js','.json','.png','.jpg','.mp3','.woff2','.md'}
for name,data in files.items():
 assert Path(name).suffix in allowed,name
 if name.endswith('.py'):compile(data,name,'exec')
 if name.endswith('.html'):assert b'data:image/' not in data,name
checks={name:hashlib.sha256(data).hexdigest() for name,data in files.items()}
with zipfile.ZipFile(OUT,'w',zipfile.ZIP_DEFLATED) as archive:
 for name,data in files.items():archive.writestr(PREFIX+'/'+name,data)
 archive.writestr(PREFIX+'/CHECKSUMS.json',json.dumps(checks,indent=2)+'\n')
with zipfile.ZipFile(OUT) as archive:
 assert archive.testzip() is None
 for name,digest in checks.items():assert hashlib.sha256(archive.read(PREFIX+'/'+name)).hexdigest()==digest
print(OUT,OUT.stat().st_size,'bytes;',len(files)+1,'files; SHA256',hashlib.sha256(OUT.read_bytes()).hexdigest())
