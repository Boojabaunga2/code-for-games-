var personalCanvases=[],personalDrawing=false;
function personalFrame(seat){
 var out=personalCanvases[seat]||(personalCanvases[seat]=document.createElement('canvas'));
 if(out.width!==720){out.width=720;out.height=720}
 var previous=ctx,buttons=S.buttons;ctx=out.getContext('2d');S.buttons=[];personalDrawing=true;
 try{
  ctx.setTransform(1,0,0,1,0,0);ctx.fillStyle='#080910';ctx.fillRect(0,0,720,720);
  var info=PLAYERS[seat],original=S.players[seat],p=original&&Object.assign({},original,{junk:original.junk.slice(),swoops:(original.swoops||[]).slice(),bigMsg:original.bigMsg&&Object.assign({},original.bigMsg)});
  if(p&&p.state==='ghost'&&ghostReady(p))p.armed=ghostCodes[seat];
  var c={x0:160,y0:94,x1:560,y1:618,w:400,h:524,s:1};
  ctx.fillStyle=info.dark;rr(8,8,704,72,14);ctx.fill();
  txt('P'+(seat+1)+' '+info.name,24,30,25,info.color,'left');
  var phase=S.phase==='play'?'ROUND '+S.round+' · '+Math.ceil(roundLeft()/1000)+'s':S.phase.toUpperCase();
  txt(phase,695,30,22,'#fff','right');
  txt(p&&p.eng?'SCORE '+p.eng.score:'BLOB DROP · GHOST RACE',24,61,23,'#fff','left');
  if(S.phase==='setup'||!p){
   drawBlob([3,0,1,4,2,5][seat],0,360,314,110,0,0,1);
   txt(S.joined[seat]?'JOINED':'PRESS A TO JOIN',360,484,34,info.color,'center');
   txt('START: PLAY · EMPTY SEATS USE CPU OPPONENTS',360,548,21,'#e7e8f2','center');
  }else{
   if(p.state==='alive')drawAliveInterior(p,c);
   else if(p.state==='ghost')drawGhostInterior(p,c);
   else drawOffInterior(p,c);
   if(p.eng&&p.state==='alive'){
    txt('NEXT',77,150,22,'#d1d8e8','center');drawBlob(p.eng.next,p.eng.drops+1,77,212,40,0,0,1);
    txt('SWAPS',645,150,22,'#d1d8e8','center');txt(String(p.swaps),645,207,40,info.color,'center');
    txt('ATTACK',77,345,20,'#d1d8e8','center');txt(Math.round(p.meter.level()*100)+'%',77,390,28,info.color,'center');
    txt('BEST',645,345,22,'#d1d8e8','center');drawBlob(p.eng.maxTier,0,645,407,42,0,0,1);
   }
   if(p.state==='ghost'){
    var target=S.players[ghostTargets[seat]];if(target&&target.state==='alive'){
     txt('TARGET',77,450,18,'#d1d8e8','center');txt(PLAYERS[target.idx].name,77,480,19,PLAYERS[target.idx].color,'center');
    }
    txt('CODE '+ghostCodes[seat],645,450,20,info.color,'center');
    var cooldown=Math.max(0,Math.ceil((p.readyAt-S.clock)/1000));txt(cooldown?cooldown+'s':'READY',645,488,22,'#fff','center');
   }
  }
  ctx.fillStyle=info.dark;rr(8,628,704,84,12);ctx.fill();
  var hint=p&&p.state==='ghost'?'B: CODE · L1 / R1: TARGET · A: ATTACK':'D-PAD: AIM · A: DROP · B: SWAP';
  txt(hint,360,652,23,'#fff','center');txt(p&&p.state==='ghost'?'LEFT / RIGHT: TARGET · UP / DOWN: CODE · START: PAUSE':'TAP TO STEER · SAME TAP / SELECT: STOP · UP: CENTRE',360,687,17,'#cdd4e5','center');
  if(S.phase==='intro')txt('GET READY',360,296,48,'#ffe363','center');
  if(S.phase==='roundEnd'){
   ctx.fillStyle='rgba(6,6,12,.87)';ctx.fillRect(96,260,528,160);txt('ROUND COMPLETE',360,308,38,'#ffe363','center');
   var row=S.summary&&S.summary.rows.find(function(r){return r.p.idx===seat});txt(row?'SCORE '+row.score:'NEXT ROUND SOON',360,370,27,'#fff','center');
  }
  if(S.phase==='over'){
   ctx.fillStyle='rgba(6,6,12,.9)';ctx.fillRect(80,235,560,225);txt('MATCH COMPLETE',360,282,38,'#ffe363','center');
   var winner=S.results&&S.results.winner;txt(winner?'WINNER '+PLAYERS[winner.idx].name:'PRESS A FOR A NEW MATCH',360,350,26,'#fff','center');
  }
  if(S.paused){ctx.fillStyle='rgba(5,5,12,.7)';ctx.fillRect(0,80,720,548);txt('PAUSED',360,320,52,'#ffe363','center');txt('START TO RESUME',360,380,26,'#fff','center')}
  ctx.strokeStyle=info.color;ctx.lineWidth=4;ctx.strokeRect(2,2,716,716);
 }finally{ctx=previous;S.buttons=buttons;personalDrawing=false}
 return out;
}
