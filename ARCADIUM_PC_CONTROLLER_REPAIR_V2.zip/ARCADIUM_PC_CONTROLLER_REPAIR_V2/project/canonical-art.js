// Original order pink/red/blue/yellow/white/green -> canonical order. Original PNG/JPG unchanged.
var SOURCE_ORDER=[1,2,5,3,0,4],ART_EDGES=[28,330,645,957,1275,1588,1900];
var sourceColumns=GEO.cols;
GEO=Object.assign({},GEO,{cols:SOURCE_ORDER.map(function(sourceIndex,destIndex){
 var sourceLeft=ART_EDGES[sourceIndex],destLeft=ART_EDGES[destIndex];
 var ratio=(ART_EDGES[destIndex+1]-destLeft)/(ART_EDGES[sourceIndex+1]-sourceLeft),out={};
 Object.keys(sourceColumns[sourceIndex]).forEach(function(key){var r=sourceColumns[sourceIndex][key];out[key]=[destLeft+(r[0]-sourceLeft)*ratio,r[1],destLeft+(r[2]-sourceLeft)*ratio,r[3]]});return out;
})});
var originalSprites=Object.assign({},ART.sprites);
['g','m'].forEach(function(prefix){SOURCE_ORDER.forEach(function(sourceIndex,destIndex){ART.sprites[prefix+destIndex]=originalSprites[prefix+sourceIndex]})});
var canonicalBase=null;
function drawCanonicalBase(){
 if(!canonicalBase&&IMG.base&&IMG.base.naturalWidth){
  canonicalBase=document.createElement('canvas');canonicalBase.width=W;canonicalBase.height=H;
  var c=canonicalBase.getContext('2d');c.drawImage(IMG.base,0,0,W,H);
  SOURCE_ORDER.forEach(function(sourceIndex,destIndex){
   var sl=ART_EDGES[sourceIndex],sw=ART_EDGES[sourceIndex+1]-sl,dl=ART_EDGES[destIndex],dw=ART_EDGES[destIndex+1]-dl;
   c.drawImage(IMG.base,sl,205,sw,716,dl,205,dw,716);
   c.fillStyle='#08090e';c.fillRect(dl+31,300,65,39);c.font='bold 31px "Russo One",sans-serif';c.fillStyle=PLAYERS[destIndex].color;c.fillText('P'+(destIndex+1),dl+36,333);
  });
  c.fillStyle='#08090e';c.fillRect(1585,120,263,62);
  for(var i=0;i<6;i++){var im=IMG['b'+[3,0,1,4,2,5][i]+'_0'];if(im&&im.naturalWidth)c.drawImage(im,1598+i*40,128,36,36)}
 }
 if(canonicalBase)ctx.drawImage(canonicalBase,0,0,W,H);
}
