"""Collect only Project Ghost's game source locally, never OS config or tokens."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
def collect(root,output):
 folder=Path(root)/'games/project-ghost'
 if not folder.is_dir():return None
 files=[p for p in folder.rglob('*') if p.is_file() and not p.is_symlink() and p.suffix.lower() in ('.html','.js','.mjs','.css') and not any(n.startswith('.') or n in ('node_modules','vendor') for n in p.relative_to(folder).parts)]
 if not files or sum(p.stat().st_size for p in files)>30*1024*1024:return None
 output=Path(output)
 with ZipFile(output,'w',ZIP_DEFLATED) as z:
  for p in files:z.write(p,'project-ghost/'+p.relative_to(folder).as_posix())
 return str(output)
