"""Targeted in-place movement reader migration. No graphics/game replacement."""
from pathlib import Path
SHARED_MARKER='/* ARCADIUM_SHARED_PC_INPUT_V1 */'
GAMES={'cave-money-unga-boonga':('cave-runtime.js','CM','cave'),'npcs-non-playable-characters-of-real-life':('npcs-runtime.js','__NPCS','npcs')}
def prepare(root,source):
 writes={};shared=(source/'games/blob-drop-arcadium-ghost-race/native-input.js').read_bytes()
 for slug,(runtime,api,kind) in GAMES.items():
  folder=root/'games'/slug
  if not folder.exists():continue
  page=folder/'index.html';run=folder/runtime
  if not page.is_file() or not run.is_file():raise RuntimeError('Incomplete installed '+slug+'; no changes')
  html=page.read_text(encoding='utf-8-sig');js=run.read_text(encoding='utf-8-sig')
  if SHARED_MARKER in js:
   if 'native-input.js?v=shared-pc-v1' not in html:raise RuntimeError('Incomplete shared patch in '+slug)
   continue
  if 'game.nativeEvent(e)' not in js or 'function release()' not in js or 'var timers = [' not in js:raise RuntimeError('Unknown input runtime in '+slug+'; no changes')
  if kind=='cave':
   anchor="if(['UP','DOWN','LEFT','RIGHT'].indexOf(key)>=0)"
   if anchor not in html:raise RuntimeError('Unknown Cave Money direction reader')
   html=html.replace('TAP D-PAD TO MOVE','HOLD D-PAD TO MOVE')
   html=html.replace(anchor,"if(s.shared&&['UP','DOWN','LEFT','RIGHT'].indexOf(key)>=0)return;"+anchor,1)
  else:
   if 'relay:ArcadiumHeldDpad.create()' not in html:raise RuntimeError('Unknown NPCs state reader')
   html=html.replace('relay:ArcadiumHeldDpad.create()','relay:ArcadiumInputState.create()')
   anchor='if(n.relay.receive(e.button))'
   if anchor not in html:raise RuntimeError('Unknown NPCs direction dispatch')
   html=html.replace(anchor,"if(n.shared&&['LEFT','RIGHT','UP','DOWN'].includes(key))return;"+anchor,1)
  script='<script src="/games/'+slug+'/native-input.js?v=shared-pc-v1"></script>'
  # Must load before the inline game creates its native readers.
  pos=html.find('<script');
  if pos<0:raise RuntimeError('No script entry in '+slug)
  html=html[:pos]+script+'\n'+html[pos:]
  if kind=='cave':state="var n=game.NATIVE[i];n.shared=true;n.held={left:!!(mask&4),right:!!(mask&8),up:!!(mask&1),down:!!(mask&2)};if(mask&&game.players[i].active)game.players[i].bot=false;"
  else:state="var n=game.NATIVE[i];n.shared=true;n.needsUpgrade=false;if(packet)n.relay.receive(packet);else n.relay.clear();"
  support=SHARED_MARKER+"\nfunction clearLegacy(){for(var i=0;i<6;i++)if(!game.NATIVE[i].shared)game.clearNative(i)}\nvar sharedLink=ArcadiumPCInput.create({action:function(e){game.nativeEvent(e)},state:function(i,mask,packet){"+state+"},onError:function(e){diagnostics.nativeError=e}});\n"
  tick=''
  html=html.replace(script,script+'<script src="/games/'+slug+'/pc-input-compat.js?v=shared-pc-v1"></script>')
  js=js.replace('var timers = [',support+'  var timers = ['+tick,1).replace('running = false; lease = false;','running = false; lease = false; sharedLink.stop();game.clearAllNative();',1)
  js=js.replace('game.clearAllNative();cursor=payload.latest','clearLegacy();cursor=payload.latest').replace('game.clearAllNative();\n        events.forEach','clearLegacy();\n        events.forEach').replace('game.clearAllNative();diagnostics.inputError','clearLegacy();diagnostics.inputError').replace('for(var i=0;i<6;i++)game.clearNative(i)},200)','clearLegacy()},200)')
  js=js.replace('game.nativeEvent(e)}});','sharedLink.legacy(e)}});')
  js=js.replace('Install Mini Vibe held-control APK V3','Waiting for shared controller input')
  for file,data in [(page,html.encode()),(run,js.encode()),(folder/'native-input.js',shared),(folder/'pc-input-compat.js',(source/'games/blob-drop-arcadium-ghost-race/pc-input-compat.js').read_bytes())]:writes[file.relative_to(root)]=data
 return writes

def racing(root,source):
 folder=root/'games/rc-trigger-racing'
 if not folder.exists():return {}
 files={n:folder/n for n in ('index.html','input.mjs','native.mjs')}
 if not all(p.is_file() for p in files.values()):raise RuntimeError('Incomplete RC Racing integration; no files changed')
 html=files['index.html'].read_text(encoding='utf-8-sig');inp=files['input.mjs'].read_text(encoding='utf-8-sig');native=files['native.mjs'].read_text(encoding='utf-8-sig')
 if SHARED_MARKER in inp:return {}
 anchor='this.browseAt=[0,0,0,0,0,0];'
 if anchor not in inp or 'inputs.native(e);' not in native:raise RuntimeError('Unrecognized RC controller module; no files changed')
 support=SHARED_MARKER+"this.shared=ArcadiumPCInput.create({action:e=>this.native(e),shoulderActions:false,state:(i,mask,packet)=>{if(!packet){this.relays[i].clear();return;}const mapped=(mask&15)|((mask&2048)?8:0)|((mask&1024)?2:0);this.relays[i].receive('H'+packet.slice(1,13)+mapped.toString(16));this.game.connect(i,true);}});"
 inp=inp.replace(anchor,anchor+support,1)
 native=native.replace('inputs.native(e);','inputs.shared.legacy(e);').replace('inputs.clearAll();cursor=data.latest','clearLegacy();cursor=data.latest').replace('inputs.clearAll();for(const e','clearLegacy();for(const e').replace("inputs.clearAll();info.inputError","clearLegacy();info.inputError").replace('performance.now()-lastPoll>750)inputs.clearAll()','performance.now()-lastPoll>750)clearLegacy()').replace("if(!p||inputs.local.has(p.i))continue","if(!p||inputs.local.has(p.i)||inputs.shared.relays[p.i].seen)continue").replace(" let cursor=null"," function clearLegacy(){for(let i=0;i<6;i++)if(!inputs.shared.relays[i].seen)inputs.clear(i); }\n let cursor=null").replace('running=false;timers.forEach','running=false;inputs.shared.stop();timers.forEach')
 html=html.replace('<script type="module"', '<script src="./native-input.js?v=shared-pc-v1"></script><script src="./pc-input-compat.js?v=shared-pc-v1"></script><script type="module"',1)
 g=source/'games/blob-drop-arcadium-ghost-race'
 return {**{files[n].relative_to(root):s.encode() for n,s in [('index.html',html),('input.mjs',inp),('native.mjs',native)]},(folder/'native-input.js').relative_to(root):(g/'native-input.js').read_bytes(),(folder/'pc-input-compat.js').relative_to(root):(g/'pc-input-compat.js').read_bytes()}
