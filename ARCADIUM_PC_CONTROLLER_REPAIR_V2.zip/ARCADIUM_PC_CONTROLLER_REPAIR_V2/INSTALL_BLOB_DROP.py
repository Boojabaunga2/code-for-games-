"""Visible V3 installer. Repairs Blob Drop and the installed Cave/NPC/RC input adapters."""
import ast
import datetime
import json
from pathlib import Path
import update_blob


def install_with_receipt(root):
    root=root.resolve()
    original_server=(root/'arcadium_server.py').read_bytes()
    original_bridge=(root/'arcadium_game_bridge.py').read_text(encoding='utf-8-sig')
    present=any(isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='wrap_blob_handler' for n in ast.walk(ast.parse(original_bridge)))
    backup=update_blob.install(root)
    manifest=json.loads((backup/'manifest.json').read_text(encoding='utf-8'))
    for name,info in manifest['files'].items():
        file=root/name
        if not file.is_file() or update_blob.digest(file.read_bytes())!=info['installed_sha256']:
            raise RuntimeError('Installed file verification failed: '+name+'\nBackup: '+str(backup))
    if (root/'arcadium_server.py').read_bytes()!=original_server:
        raise RuntimeError('Main server changed during installation. Backup: '+str(backup))
    receipt={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'package':'Arcadium PC Controller Repair','selected_root':str(root),'backup':str(backup),
        'blob_handler_previously_present':present,'installed_files_verified':True,
        'main_server_preserved':True,'runtime_verified':False,
        'launch_url':'/games/blob-drop-arcadium-ghost-race/index.html?vibe=blob-v3',
        'expected_health_build':'blob-v3'}
    return receipt


def main():
    import tkinter as tk
    from tkinter import filedialog
    ui=tk.Tk();ui.title('Arcadium PC Controller Repair — repair existing integration');ui.geometry('650x380');ui.attributes('-topmost',True)
    tk.Label(ui,text='Arcadium PC Controller Repair installation repair',font=('Segoe UI',17,'bold')).pack(pady=(18,8))
    status=tk.StringVar(value='Select the same Arcadium_OS_COMPACT folder you normally launch.')
    tk.Label(ui,textvariable=status,wraplength=600,justify='left',font=('Segoe UI',11)).pack(padx=20,pady=10)
    detail=tk.StringVar(value='Uses the existing universal shared controller. NO NEW APK. Pairing, Home, main server and other games are preserved. A backup is created before changes.')
    tk.Label(ui,textvariable=detail,wraplength=600,justify='left',font=('Segoe UI',10)).pack(padx=20,pady=10)
    def run():
        chosen=filedialog.askdirectory(parent=ui,title='Select your existing Arcadium_OS_COMPACT folder')
        if not chosen:return
        button.config(state='disabled');status.set('Inspecting and repairing the selected installation...');ui.update_idletasks()
        try:
            receipt=install_with_receipt(Path(chosen))
            from collect_project_ghost import collect
            try: receipt['project_ghost_source']=collect(Path(chosen),Path(__file__).resolve().with_name('PROJECT_GHOST_SOURCE.zip'))
            except OSError: receipt['project_ghost_source']=None
            receipt_path=Path(__file__).resolve().with_name('BLOB_DROP_INSTALL_RECEIPT.json')
            try:receipt_path.write_text(json.dumps(receipt,indent=2),encoding='utf-8')
            except OSError:pass
            status.set('Files installed and verified. RESTART WINDOWS ONCE, then open Arcadium normally and test the games.')
            action='Existing Blob Drop handler refreshed.' if receipt['blob_handler_previously_present'] else 'Missing Blob Drop handler added to the existing bridge.'
            detail.set('Blob Drop repaired; installed Cave Money, NPCs and RC input readers migrated. NO APK.\nProject Ghost is not repaired yet. If PROJECT_GHOST_SOURCE.zip appears beside this installer, attach it in chat.\nBackup: '+receipt['backup']+'\n\nPhysical operation still needs your test.')
        except Exception as error:
            status.set('Installation stopped: '+str(error));detail.set('No success is being claimed. Copy this message or send a photo of this window.');button.config(state='normal')
    button=tk.Button(ui,text='Select Arcadium_OS_COMPACT and repair PC controls',command=run,padx=8,pady=8);button.pack(pady=10)
    tk.Button(ui,text='Close',command=ui.destroy).pack(pady=4)
    ui.mainloop()


if __name__=='__main__':main()
