"""Targeted Blob Drop installer; preserve Escape, Home, and every other game."""
import argparse
import ast
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import sys

SLUG = 'blob-drop-arcadium-ghost-race'
SOURCE = Path(__file__).resolve().parent


def digest(data):
    return hashlib.sha256(data).hexdigest()


def atomic_write(path, data):
    temp = path.with_name(path.name + '.blob-update.tmp')
    try:
        temp.write_bytes(data)
        os.replace(temp, path)
    finally:
        temp.unlink(missing_ok=True)


def patch_bridge(source):
    """Wrap the existing final Escape handler; never replace shared route code."""
    tree = ast.parse(source)
    functions = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'bridge']
    if len(functions) != 1:
        raise RuntimeError('Expected one existing bridge function; no files changed')
    returns = [n for n in functions[0].body if isinstance(n, ast.Return)]
    if len(returns) != 1:
        raise RuntimeError('Shared bridge return is not recognized; no files changed')
    node = returns[0]
    expression = ast.unparse(node.value)
    def known(n, names=None):
        names = set() if names is None else names
        if isinstance(n, ast.Name):
            return n.id == 'GameBridge' and 'wrap_e3mi_handler' in names
        if not isinstance(n, ast.Call) or not isinstance(n.func, ast.Name) or len(n.args)!=1 or n.keywords:
            return False
        name=n.func.id
        if name not in ('wrap_native_input_handler','wrap_e3mi_handler','wrap_tower_handler','wrap_reel_handler','wrap_agb_handler','wrap_agb_match_handler','wrap_ninja_handler','wrap_backyard_handler','wrap_cave_handler','wrap_pinball_handler','wrap_blob_handler','wrap_boop_handler','wrap_sniper_kitty_handler','wrap_ghost_bubble_handler','wrap_racing_handler','wrap_party_handler','wrap_dogfight_handler','wrap_npcs_handler','wrap_wormaldeon_handler') or name in names:
            return False
        return known(n.args[0], names | {name})
    if not known(node.value):
        raise RuntimeError('Expected the known working Escape/Tower/Reel bridge; nothing changed')
    # An installed handler remains valid inside later game wrappers. Preserve order.
    already = any(isinstance(n, ast.Call) and isinstance(n.func, ast.Name)
        and n.func.id == 'wrap_blob_handler' for n in ast.walk(node.value))
    # Require the real shared state used by the inspected current bridge.
    if not {'ACTIVE_WEB_GAME', 'ACTIVE_LOCK'} <= {
        n.id for n in ast.walk(tree) if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Store)}:
        raise RuntimeError('Existing shared game lease not found')
    lines = source.splitlines(keepends=True)
    newline = '\r\n' if '\r\n' in source else '\n'
    if not already:
        if node.lineno != node.end_lineno or lines[node.lineno-1].strip() != 'return '+expression:
            raise RuntimeError('Unexpected inline bridge return; no files changed')
        indent = lines[node.lineno-1][:node.col_offset]
        lines[node.lineno-1] = indent + 'return wrap_blob_handler(' + expression + ')' + newline
    patched = ''.join(lines)
    imported = any(isinstance(n, ast.ImportFrom) and n.module == 'blob_routes'
        and any(a.name == 'wrap_blob_handler' and a.asname is None for a in n.names) for n in tree.body)
    if not imported:
        patched = 'from blob_routes import wrap_blob_handler' + newline + patched
    compile(patched, 'arcadium_game_bridge.py', 'exec')
    return patched


def registration(catalog):
    if not isinstance(catalog.get('games'), list):
        raise RuntimeError('Unknown catalog format')
    matches=[]
    normalize=lambda value:re.sub('[^a-z0-9]','',str(value or '').lower())
    for index,game in enumerate(catalog['games']):
        if not isinstance(game,dict):raise RuntimeError('Invalid game record')
        # Read independent fields: an empty name must not hide a valid title.
        labels=[normalize(game.get(k)) for k in ('id','name','title')]
        paths=[str(game.get(k,'')).lower().replace('\\','/') for k in ('launchUrl','url','path','launchTarget')]
        if any('blobdrop'  in value for value in labels) or any('blob-drop-arcadium-ghost-race/' in value or 'blob_drop_arcadium_ghost_race/' in value for value in paths):
            matches.append((index,game))
    if len(matches)>1:
        details=[{'index':i,'id':g.get('id'),'name':g.get('name'),'title':g.get('title'),'launchUrl':g.get('launchUrl')} for i,g in matches]
        raise RuntimeError('Multiple Blob Drop entries found; no changes. Entries: '+json.dumps(details))
    if matches:
        game=matches[0][1]
        if not game.get('id'):game['id']=SLUG
    else:
        game=json.loads((SOURCE/'games'/SLUG/'arcadium-game.json').read_text(encoding='utf-8-sig'))
        game['id']=SLUG
        game['image']='/games/blob-drop-arcadium-ghost-race/carousel-v1.png'
        catalog['games'].append(game)
    if not game.get('image') or 'games_mockup' in str(game.get('image')):game['image']='/games/blob-drop-arcadium-ghost-race/carousel-v1.png'
    if not game.get('tagline') or game['tagline']=='Imported HTML game':game['tagline']='Drop, merge, survive — then haunt your rivals.'
    if not game.get('description') or str(game['description']).startswith('Imported into Arcadium OS. Edit this game'):
        game['description']='Six-player physics merge race with a personal live bucket and ghost sabotage view on each Mini Vibe.'
    game.update(launchUrl='/games/blob-drop-arcadium-ghost-race/index.html?vibe=blob-v3',gameType='html',active=True,
        miniVibeUrl='/games/blob-drop-arcadium-ghost-race/personal/vibe.html',vibeUrl='/games/blob-drop-arcadium-ghost-race/personal/vibe.html',
        controllerUrl='/games/blob-drop-arcadium-ghost-race/personal/vibe.html',
        controls='Hold LEFT/RIGHT to aim; release to stop; A drop/ghost attack; B swap/ghost code; L1/R1 ghost target; START start/pause')
    # Preserve its original card, ID, title, player data and every unrelated entry.
    return catalog


def verify_payload():
    checks=SOURCE/'CHECKSUMS.json'
    if not checks.is_file():
        if (SOURCE/'project/original.html').is_file():return
        raise RuntimeError('Incomplete extraction: CHECKSUMS.json is missing')
    for name,expected in json.loads(checks.read_text()).items():
        file=(SOURCE/name).resolve()
        if not file.is_relative_to(SOURCE.resolve()) or not file.is_file() or digest(file.read_bytes())!=expected:
            raise RuntimeError('Package file missing or changed: '+name+'; extract the complete ZIP again')


def prepare(root):
    verify_payload()
    server=(root/'arcadium_server.py').read_text(encoding='utf-8-sig')
    if 'arcadium_game_bridge' not in server:
        raise RuntimeError('Selected server does not load the existing shared game bridge')
    original=(root/'arcadium_game_bridge.py').read_bytes().decode('utf-8-sig')
    patched=patch_bridge(original)
    helpers={'e3mi_routes','tower_panic_routes','reel_mayhem_routes','agb_solo_routes','agb_match_routes','ninja_routes','backyard_routes','cave_routes','pinball_routes','dogfight_routes','npcs_routes'}
    for node in ast.parse(patched).body:
        if isinstance(node,ast.ImportFrom) and node.module in helpers:
            helper=root/(node.module+'.py')
            if not helper.is_file():raise RuntimeError('Current bridge requires missing '+helper.name)
            compile(helper.read_bytes(),str(helper),'exec')
    catalog=json.loads((root/'data/arcadium.json').read_text(encoding='utf-8-sig'))
    writes={Path('data/arcadium.json'):(json.dumps(registration(catalog),ensure_ascii=False,indent=2)+'\n').encode(),
        Path('arcadium_game_bridge.py'):patched.encode(),Path('blob_routes.py'):(SOURCE/'blob_routes.py').read_bytes()}
    compile(writes[Path('blob_routes.py')],'blob_routes.py','exec')
    for file in sorted((SOURCE/'games'/SLUG).rglob('*')):
        if file.is_file():
            relative=Path('games')/SLUG/file.relative_to(SOURCE/'games'/SLUG)
            writes[relative]=(root/relative).read_bytes() if file.name=='card.png' and (root/relative).is_file() else file.read_bytes()
    import compat_patch
    writes.update(compat_patch.prepare(root,SOURCE));writes.update(compat_patch.racing(root,SOURCE))
    return writes


def install(root):
    root = root.resolve()
    writes = prepare(root)
    for rel in writes:
        if not (root / rel).resolve().is_relative_to(root):
            raise RuntimeError('Destination escapes the installation')
    stamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    backup = root / 'arcadium_backups' / ('blob_shared_v3_' + stamp)
    backup.mkdir(parents=True)
    manifest = {'kind':'blob-shared-v3', 'root': str(root), 'files': {}, 'created_directories': []}
    after_catalog=json.loads(writes[Path('data/arcadium.json')])
    manifest['catalog_after_game']=next(g for g in after_catalog['games'] if g.get('launchUrl','').split('?')[0]=='/games/'+SLUG+'/index.html')
    old_catalog=json.loads((root/'data/arcadium.json').read_text(encoding='utf-8-sig'))
    index=after_catalog['games'].index(manifest['catalog_after_game'])
    manifest['catalog_before_game']=old_catalog['games'][index] if index<len(old_catalog['games']) else None
    for rel, data in writes.items():
        path = root / rel
        if path.exists():
            saved = backup / rel
            saved.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, saved)
        manifest['files'][rel.as_posix()] = {'existed': path.exists(), 'installed_sha256': digest(data), 'backup_sha256':digest((backup/rel).read_bytes()) if path.exists() else None}
    game_dir = root / 'games' / SLUG
    if not game_dir.exists():
        manifest['created_directories'].append('games/' + SLUG)
    (backup / 'manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    changed = []
    try:
        for rel, data in writes.items():
            path = root / rel
            if path.exists() and path.read_bytes() == data:
                continue
            path.parent.mkdir(parents=True, exist_ok=True)
            atomic_write(path, data)
            changed.append(rel)
    except Exception:
        for rel in reversed(changed):
            if manifest['files'][rel.as_posix()]['existed']:
                atomic_write(root / rel, (backup / rel).read_bytes())
            else:
                (root / rel).unlink(missing_ok=True)
        for name in manifest['created_directories']:
            folder = root / name
            if folder.exists() and not any(folder.iterdir()):
                folder.rmdir()
        raise
    return backup


def rollback(backup):
    backup = backup.resolve()
    manifest = json.loads((backup / 'manifest.json').read_text(encoding='utf-8'))
    if manifest.get('kind') not in ('blob-personal-v1','blob-personal-v2','blob-shared-v3'):
        raise RuntimeError('Select a blob_personal_* backup from this update, not an older OS/game backup')
    root = Path(manifest['root']).resolve()
    catalog_restore=None
    for name, info in manifest['files'].items():
        if Path(name).is_absolute() or '..' in Path(name).parts:
            raise RuntimeError('Invalid backup path')
        if info['existed'] and digest((backup/name).read_bytes()) != info['backup_sha256']:
            raise RuntimeError('Backup checksum failed; nothing restored')
        if name not in ('data/arcadium.json','arcadium_game_bridge.py','blob_routes.py') and not name.startswith('games/'+SLUG+'/') and not any(name=='games/'+slug+'/'+file for slug in ('cave-money-unga-boonga','npcs-non-playable-characters-of-real-life','rc-trigger-racing') for file in ('index.html','native-input.js','pc-input-compat.js','cave-runtime.js','npcs-runtime.js','input.mjs','native.mjs')):
            raise RuntimeError('Not a Blob Drop backup; no files restored')
        path = (root / name).resolve()
        if not path.is_relative_to(root) or not path.is_file():
            raise RuntimeError('Invalid restore destination: '+name)
        if digest(path.read_bytes()) == info['installed_sha256']:
            continue
        if name=='data/arcadium.json':
            # Launch activity and unrelated game edits must survive game rollback.
            current=json.loads(path.read_text(encoding='utf-8-sig'))
            expected=manifest['catalog_after_game']
            entries=[(i,g) for i,g in enumerate(current.get('games',[])) if g.get('id')==expected['id']]
            before=json.loads((backup/name).read_text(encoding='utf-8-sig'))
            original=manifest['catalog_before_game']
            if len(entries)==1 and entries[0][1]==expected:
                if original is None:current['games'].pop(entries[0][0])
                else:current['games'][entries[0][0]]=original
                catalog_restore=(json.dumps(current,ensure_ascii=False,indent=2)+'\n').encode()
                continue
        if digest(path.read_bytes()) != info['installed_sha256']:
            raise RuntimeError('Later changes detected in '+name+'. Refusing to overwrite later work.')
    for name, info in manifest['files'].items():
        path = root / name
        if name=='data/arcadium.json' and catalog_restore is not None:
            atomic_write(path,catalog_restore)
            continue
        if info['existed']:
            atomic_write(path, (backup / name).read_bytes())
        else:
            path.unlink()
    for name in manifest.get('created_directories', []):
        folder = (root / name).resolve()
        if folder.is_relative_to(root) and folder.is_dir() and not any(folder.iterdir()):
            folder.rmdir()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path)
    parser.add_argument('--rollback', type=Path)
    args = parser.parse_args()
    if args.rollback:
        rollback(args.rollback)
        print('Previous Blob Drop files restored. Restart Windows once before reopening Arcadium.')
        return
    root = args.root
    if root is None:
        import tkinter
        from tkinter import filedialog
        ui = tkinter.Tk(); ui.withdraw()
        chosen = filedialog.askdirectory(title='Select the existing Arcadium_OS_COMPACT installation')
        ui.destroy()
        if not chosen:
            raise RuntimeError('Cancelled; nothing changed')
        root = Path(chosen)
    backup = install(root)
    print('Blob Drop installed. Backup:', backup)
    print('RESTART WINDOWS ONCE to load the added game route, then open Arcadium normally on 8787.')
    print('Keep your existing pairing. Open Blob Drop from its existing carousel card.')
    print('Run CHECK_BLOB_CONNECTION.py for live checks. Installation alone is not hardware verification.')


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        print('STOP:', error)
        sys.exit(1)
