/* PC-only action compatibility for universal I1 controls. No Android mappings. */
(function(root){'use strict';
const colors=['red','blue','green','yellow','pink','white'],names=['UP','DOWN','LEFT','RIGHT','A','B','X','Y','START','SELECT','L1','R1'];
root.ArcadiumPCInput={create({action,state,directionEdges=false,shoulderActions=true,onError=()=>{},onCursor=()=>{}}){const relays=colors.map(()=>ArcadiumInputState.create()),prior=Array(6).fill(0),seen=Array(6).fill(false),pending=new Map();
function emit(e,source){const i=colors.indexOf(String(e.color).toLowerCase());if(i<0)return;const key=i+':'+e.button,now=Date.now(),at=Number.isFinite(e.at)&&Math.abs(e.at-now)<3000?e.at:now;let q=(pending.get(key)||[]).filter(p=>now-p.received<1000),match=q.findIndex(p=>p.source!==source&&Math.abs(p.at-at)<400);if(match>=0){q.splice(match,1);pending.set(key,q);return;}q.push({source,at,received:now});pending.set(key,q);action(e);}
function reset(){relays.forEach(r=>r.clear());for(let i=0;i<6;i++)state(i,0);}
const link=ArcadiumInputState.connect({onEvent(e){const i=colors.indexOf(String(e.color).toLowerCase());if(i<0||!relays[i].receive(e.button))return;const mask=relays[i].read(),edges=mask&~prior[i];prior[i]=mask;seen[i]=true;state(i,mask,e.button);for(let b=0;b<12;b++)if((edges&(1<<b))&&(b>=4||directionEdges)&&(b<10||shoulderActions))emit({...e,button:names[b]},'raw');},onReset:reset,onError,onCursor(n){root.ArcadiumPCInput.latest=n;onCursor(n);}});
const timer=setInterval(()=>{for(let i=0;i<6;i++)if(seen[i]&&!relays[i].read())state(i,0);},80);const blur=()=>reset();addEventListener('blur',blur);
return{legacy(e){const i=colors.indexOf(String(e.color).toLowerCase());if(i<0)return;if(seen[i]&&(/^H[0-9a-f]{13}$/i.test(e.button)||['UP','DOWN','LEFT','RIGHT'].includes(e.button)||(!shoulderActions&&['L1','R1'].includes(e.button))))return;emit(e,'legacy');},stop(){link.stop();clearInterval(timer);removeEventListener('blur',blur);reset();},relays};}};
})(window);
