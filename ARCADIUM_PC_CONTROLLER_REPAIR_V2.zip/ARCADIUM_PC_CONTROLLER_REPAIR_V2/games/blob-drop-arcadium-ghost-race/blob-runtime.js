if (location.port === '8787' && /^https?:$/.test(location.protocol)) {
(function () {
  'use strict';
  var game = window.__BD, canvas = document.getElementById('c');
  var colors = ['red', 'blue', 'green', 'yellow', 'pink', 'white'];
  var endpoint = '/arcadium-vibe/activate/blob-drop-arcadium-ghost-race';
  var relays=colors.map(function(){return ArcadiumInputState.create()}),nativeLink=null;
  function resetShared(){relays.forEach(function(r){r.clear()});game.clearAllNative();for(var i=0;i<6;i++)game.NATIVE[i].mask=0;}
  var running = true, lease = false, nextSeat=0, cursor=null, eventsBusy=false, framesBusy = false;
  var diagnostics = window.__BLOB_DROP_INTEGRATION = {inputError: '', mirrorError: '', frames: 0};

  function request(url, options) {
    var abort = new AbortController(), timer = setTimeout(function () { abort.abort(); }, 2000);
    return fetch(url, Object.assign({cache: 'no-store', signal: abort.signal}, options || {}))
      .then(function (r) { if (!r.ok) throw Error(url + ' HTTP ' + r.status); return r; })
      .finally(function () { clearTimeout(timer); });
  }
  function activate() {
    if (!running || document.hidden) return Promise.resolve();
    return request(endpoint, {method: 'POST'}).then(function () { lease = true; })
      .catch(function (e) { lease = false; diagnostics.mirrorError = e.message; });
  }
  function clearLegacy(){for(var i=0;i<6;i++)if(!game.NATIVE[i].shared)game.clearNative(i)}
  function poll(){
    if(!running||document.hidden||eventsBusy)return;eventsBusy=true;
    request('/api/vibe/events?after='+(cursor===null?0:cursor)).then(r=>r.json()).then(function(payload){
      if(!running||document.hidden)return;
      if(!Number.isSafeInteger(payload.latest)||!Array.isArray(payload.events))throw Error('Unsupported native event stream');
      if(cursor===null||payload.latest<cursor){clearLegacy();cursor=payload.latest}
      else{
        var events=payload.events.slice().sort((a,b)=>a.seq-b.seq);
        if(events.length&&events[0].seq>cursor+1&&cursor>0)clearLegacy();
        events.forEach(function(e){if(Number.isSafeInteger(e.seq)&&e.seq>cursor){cursor=e.seq;nativeLink.legacy(e)}});
        cursor=Math.max(cursor,payload.latest);
      }
      (payload.slots||[]).forEach(function(slot){var i=colors.indexOf(slot.color);if(i<0)return;var native=game.NATIVE[i];if(native.connected&&!slot.connected){game.clearNative(i);native.modern={}}native.connected=!!slot.connected});
      diagnostics.lastInputAt=performance.now();diagnostics.lastSeq=cursor;diagnostics.inputError='';
    }).catch(function(e){clearLegacy();diagnostics.inputError=e.message}).finally(function(){eventsBusy=false});
  }
  function publish() {
    if (!game.ready || !running || document.hidden || !lease || framesBusy || !canvas.width) return;
    framesBusy = true;
    var seat=nextSeat;nextSeat=(nextSeat+1)%6;
    var playerCanvas=game.personalFrame(seat);
    var jobs=[request('/blob-drop-arcadium-ghost-race/frame',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({seat:seat+1,image:playerCanvas.toDataURL('image/jpeg',.55).split(',')[1]})})];
    Promise.all(jobs).then(function () { diagnostics.frames++; diagnostics.mirrorError = ''; })
      .catch(function (e) { diagnostics.mirrorError = e.message; })
      .finally(function () { framesBusy = false; });
  }
  nativeLink=ArcadiumPCInput.create({action:function(e){game.nativeEvent(e)},state:function(i,mask){game.nativeHeld(i,mask)},onError:function(e){diagnostics.nativeError=e},onCursor:function(n){diagnostics.nativeSeq=n}});
  window.addEventListener('blur',resetShared);
  var timers = [setInterval(activate, 2500),setInterval(poll,40), setInterval(publish, 24), setInterval(function(){if(diagnostics.lastInputAt&&performance.now()-diagnostics.lastInputAt>750)clearLegacy()},200)];
  var connection=document.createElement('div');connection.id='arcadium-connection-status';connection.style='position:fixed;left:8px;bottom:8px;z-index:1100;max-width:65vw;padding:7px 10px;border-radius:6px;background:#102c36;color:white;font:12px sans-serif;pointer-events:none';document.body.appendChild(connection);
  timers.push(setInterval(function(){
    var count=game.NATIVE.filter(function(n){return n.connected}).length;
    var error=diagnostics.nativeError||diagnostics.inputError||diagnostics.mirrorError;
    connection.textContent='MINI VIBE · BLOB DROP V3 · '+count+'/6 paired · '+(error||(!lease?'Connecting to game bridge':diagnostics.frames?'Live view sending':'Waiting for game view'));
    connection.style.background=error?'#8b2424':'#102c36';
  },500));
  activate();poll();
  document.addEventListener('visibilitychange',function(){game.clearAllNative();if(!document.hidden){cursor=null;activate();poll()}});
  function release() {
    if (!running) return;
    running = false; lease = false; nativeLink.stop();resetShared(); timers.forEach(clearInterval);for(var i=0;i<6;i++)game.clearNative(i);
    fetch(endpoint, {method: 'POST', headers: {'Content-Type': 'application/json'},
      body: '{"active":false}', keepalive: true}).catch(function () {});
  }
  game.releaseVibe = release;
  var exit=document.createElement('button');exit.textContent='RETURN TO ARCADIUM';exit.style='position:fixed;right:8px;bottom:7px;z-index:1000;padding:8px 12px;border:1px solid #e8ce88;border-radius:8px;background:#102c36;color:#fff;font-weight:bold;cursor:pointer';document.body.appendChild(exit);
  exit.onclick=function(){release();if(window.parent!==window){window.parent.postMessage({type:'ARCADIUM_GAME_EXIT',game:'blob-drop-arcadium-ghost-race'},'*');window.parent.postMessage({type:'arcadium:exit',game:'blob-drop-arcadium-ghost-race'},'*')}else location.href='/'};
  window.addEventListener('pagehide', release);
  // A page restored from browser history must re-establish its timers and lease.
  window.addEventListener('pageshow', function (e) { if (e.persisted) location.reload(); });
})();

}
