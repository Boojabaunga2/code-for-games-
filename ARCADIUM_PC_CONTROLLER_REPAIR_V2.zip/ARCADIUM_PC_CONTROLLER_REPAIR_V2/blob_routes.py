"""Blob Drop-only routes, wrapped around the existing Arcadium 8787 bridge.

No listener, pairing service, or replacement OS. State is shared with the
installed bridge so switching to another game always takes precedence.
"""
import base64
import binascii
import importlib
import json
import threading
import time
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

SLUG = 'blob-drop-arcadium-ghost-race'
COLORS = ('red', 'blue', 'green', 'yellow', 'pink', 'white')
LOCK = threading.RLock()
FRAMES = {}
BASE = Path(__file__).resolve().parent
ACTIVATE = '/arcadium-vibe/activate/' + SLUG


def wrap_blob_handler(Parent):
    class BlobMirrorHandler(Parent):
        def _blob_state(self):
            bridge = importlib.import_module('arcadium_game_bridge')
            return bridge.ACTIVE_WEB_GAME, bridge.ACTIVE_LOCK

        def _blob_active(self):
            state, lock = self._blob_state()
            with lock:
                return state['game'] == SLUG and time.time() < state['until']

        def _blob_send(self, body, mime, status=200):
            self.send_response(status)
            self.send_header('Content-Type', mime)
            self.send_header('Cache-Control', 'no-store')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_POST(self):
            path = urlsplit(self.path).path
            if path not in (ACTIVATE, '/blob-drop-arcadium-ghost-race/frame'):
                return super().do_POST()
            # Retain the existing bridge's host-only producer policy.
            if self.client_address[0] not in ('127.0.0.1', '::1', '::ffff:127.0.0.1'):
                return self.send_error(403)
            try:
                length = int(self.headers.get('Content-Length', '0'))
                limit = 1024 if path == ACTIVATE else 300000
                if not 0 <= length <= limit:
                    return self.send_error(413)
                item = json.loads(self.rfile.read(length) or b'{}')
                if not isinstance(item, dict):
                    raise ValueError('Expected object')
                if path == ACTIVATE:
                    active = item.get('active', True)
                    if not isinstance(active, bool):
                        raise ValueError('Expected boolean')
                    state, lock = self._blob_state()
                    with lock:
                        if active:
                            if state['game'] != SLUG or time.time() >= state['until']:
                                with LOCK:
                                    FRAMES.clear()
                            state.update(game=SLUG, until=time.time() + 7)
                        elif state['game'] == SLUG:
                            state.update(game=None, until=0)
                            with LOCK:
                                FRAMES.clear()
                else:
                    if not self._blob_active():
                        return self.send_error(409, 'Blob Drop is not active')
                    seat = item['seat']
                    if type(seat) is not int or seat not in range(1, 7):
                        raise ValueError('Invalid seat')
                    data = base64.b64decode(item['image'], validate=True)
                    if len(data) > 200000 or not data.startswith(b'\xff\xd8'):
                        raise ValueError('Invalid JPEG')
                    with LOCK:
                        FRAMES[seat] = (time.monotonic(), data)
                return self._blob_send(b'{"ok":true}', 'application/json')
            except (ValueError, TypeError, KeyError, UnicodeError, binascii.Error):
                return self.send_error(400)

        def do_GET(self):
            path = urlsplit(self.path).path
            if path == '/blob-drop-arcadium-ghost-race/status':
                return self._blob_send(json.dumps(dict(build='blob-v3', game=SLUG, active=self._blob_active())).encode(), 'application/json')
            if path in ('/api/vibe/mode', '/api/vibe/launch') and self._blob_active():
                page = '/games/' + SLUG + '/personal/vibe.html'
                data = json.dumps(dict(mode='web-game', page=page, url=page,
                                       active=True, game=SLUG, nativeState=1)).encode()
                return self._blob_send(data, 'application/json')
            prefix = '/games/' + SLUG + '/'
            if path == prefix + 'personal/vibe.html':
                file = BASE / 'games' / SLUG / 'vibe.html'
                if not file.is_file():
                    return self.send_error(404)
                return self._blob_send(file.read_bytes(), 'text/html; charset=utf-8')
            # Only serve game files inside the supplied game's folder.
            if path.startswith(prefix):
                from urllib.parse import unquote
                relative = Path(unquote(path[len(prefix):]))
                folder = (BASE / 'games' / SLUG).resolve()
                file = (folder / relative).resolve()
                if not file.is_relative_to(folder) or not file.is_file():
                    return self.send_error(404)
                import mimetypes
                mime = mimetypes.guess_type(file.name)[0] or 'application/octet-stream'
                return self._blob_send(file.read_bytes(), mime)
            if path != '/blob-drop-arcadium-ghost-race/frame':
                return super().do_GET()
            color = parse_qs(urlsplit(self.path).query).get('color', [''])[0].lower()
            if color not in COLORS:
                return self.send_error(400)
            if not self._blob_active():
                return self.send_error(503, 'Blob Drop is not active')
            with LOCK:
                packet = FRAMES.get(COLORS.index(color) + 1)
            if not packet or time.monotonic() - packet[0] > 3:
                return self.send_error(503, 'Waiting for main game frame')
            return self._blob_send(packet[1], 'image/jpeg')
    return BlobMirrorHandler
