"""Visible, read-only Blob Drop connection check. Keep the PC game open."""
import concurrent.futures
import datetime
import json
from pathlib import Path
import queue
import threading
import urllib.error
import urllib.request

SLUG='blob-drop-arcadium-ghost-race'
COLORS=('red','blue','green','yellow','pink','white')
PATHS=['/'+SLUG+'/status','/api/vibe/events?after=0']
PATHS+=['/api/vibe/mode?color='+c for c in COLORS]
PATHS+=['/'+SLUG+'/frame?color='+c for c in COLORS]


def read_check(path,base='http://127.0.0.1:8787'):
    try:
        request=urllib.request.Request(base+path,headers={'Cache-Control':'no-cache'})
        with urllib.request.urlopen(request,timeout=1.5) as response:
            data=response.read(600000)
            result={'http':response.status,'bytes':len(data)}
            if 'json' in response.headers.get('Content-Type',''):
                body=json.loads(data)
                if path.startswith('/api/vibe/events'):
                    body={k:v for k,v in body.items() if k in ('latest','slots','events')}
                    body['events']=[{k:v for k,v in event.items() if k in ('seq','color','button','at','action')} for event in body.get('events',[])[-12:]]
                    body['slots']=[{k:v for k,v in slot.items() if k in ('color','connected','lastSeen','lastButton','count')} for slot in body.get('slots',[])]
                result['json']=body
            return result
    except urllib.error.HTTPError as error:
        return {'http':error.code,'reason':str(error.reason)}
    except Exception as error:
        return {'error':str(error)}


def diagnosis(checks):
    health=checks.get('/'+SLUG+'/status',{})
    modes=[checks.get('/api/vibe/mode?color='+c,{}) for c in COLORS]
    if health.get('http')==404:
        return 'The running server is not serving Blob Drop’s installed helper route. The report cannot distinguish an uninstalled helper from a server process that has not loaded it.'
    if health.get('http')!=200:
        return 'Could not read Blob Drop’s server status on 8787. The report contains the connection error.'
    if not health.get('json',{}).get('active'):
        return 'Blob Drop’s helper is loaded, but its game activation lease is inactive. Keep the game visible on the PC; its page/runtime or activation request needs inspection.'
    selected=[m for m in modes if m.get('json',{}).get('mode')=='web-game' and m.get('json',{}).get('game')==SLUG]
    if len(selected)!=6:
        return 'Blob Drop is active, but the mode checks did not all select its personal screen. The report records the actual mode responses.'
    frames=[checks.get('/'+SLUG+'/frame?color='+c,{}).get('http') for c in COLORS]
    if any(status!=200 for status in frames):
        return 'The server selects Blob Drop’s personal screen, but one or more player frame feeds are unavailable. See the per-colour responses in the report.'
    return 'The PC server selected Blob Drop for all six colours and returned all six frame feeds. This does not verify the physical Mini Vibe’s screen or polling connection.'


def collect(progress=None,base='http://127.0.0.1:8787'):
    checks={}
    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
        jobs={pool.submit(read_check,path,base):path for path in PATHS}
        for job in concurrent.futures.as_completed(jobs):
            path=jobs[job];checks[path]=job.result()
            if progress:progress(len(checks),len(PATHS))
    report={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'read_only':True,'summary':diagnosis(checks),'checks':checks}
    receipt=Path(__file__).resolve().with_name('BLOB_DROP_INSTALL_RECEIPT.json')
    if receipt.is_file():
        try:report['installation_receipt']=json.loads(receipt.read_text(encoding='utf-8'))
        except (OSError,ValueError):report['installation_receipt_error']='Could not read installation receipt'
    return report


def main():
    import tkinter as tk
    from tkinter import filedialog,messagebox
    # The window is created and painted BEFORE any network work starts.
    ui=tk.Tk();ui.title('Blob Drop connection check');ui.geometry('620x360');ui.resizable(False,False)
    ui.attributes('-topmost',True)
    tk.Label(ui,text='Keep Blob Drop running on the PC',font=('Segoe UI',16,'bold')).pack(pady=(18,8))
    progress=tk.StringVar(value='Checking the existing server on port 8787...')
    tk.Label(ui,textvariable=progress,wraplength=570,justify='left',font=('Segoe UI',11)).pack(padx=20,pady=8)
    detail=tk.StringVar(value='This only reads connection status. No installation or pairing is changed.')
    tk.Label(ui,textvariable=detail,wraplength=570,justify='left',font=('Segoe UI',10)).pack(padx=20,pady=8)
    copy_button=tk.Button(ui,text='Copy result',state='disabled');copy_button.pack(pady=8)
    tk.Button(ui,text='Close',command=ui.destroy).pack(pady=4)
    events=queue.Queue();saved_report={}
    def worker():
        try:events.put(('done',collect(lambda n,total:events.put(('progress',(n,total))))))
        except Exception as error:events.put(('error',str(error)))
    def poll():
        try:
            while True:
                kind,value=events.get_nowait()
                if kind=='progress':progress.set('Checking '+str(value[0])+' / '+str(value[1])+' endpoints...')
                elif kind=='error':progress.set('Check stopped: '+value)
                elif kind=='done':
                    saved_report.update(value);progress.set(value['summary'])
                    copy_button.config(state='normal',command=lambda:(ui.clipboard_clear(),ui.clipboard_append(json.dumps(saved_report,indent=2))))
                    target=Path(__file__).resolve().with_name('BLOB_DROP_CONNECTION_REPORT.json')
                    try:target.write_text(json.dumps(value,indent=2),encoding='utf-8')
                    except OSError:
                        chosen=filedialog.asksaveasfilename(parent=ui,title='Save Blob Drop report',initialfile=target.name,defaultextension='.json')
                        if not chosen:detail.set('Report not saved. Use Copy result and paste it in chat.');continue
                        target=Path(chosen)
                        try:target.write_text(json.dumps(value,indent=2),encoding='utf-8')
                        except OSError as error:messagebox.showerror('Could not save report',str(error),parent=ui);continue
                    detail.set('Saved beside this checker:\n'+str(target)+'\n\nUpload BLOB_DROP_CONNECTION_REPORT.json in chat.')
        except queue.Empty:pass
        ui.after(100,poll)
    ui.after(100,poll)
    ui.after(150,lambda:threading.Thread(target=worker,daemon=True).start())
    ui.mainloop()


if __name__=='__main__':
    main()
