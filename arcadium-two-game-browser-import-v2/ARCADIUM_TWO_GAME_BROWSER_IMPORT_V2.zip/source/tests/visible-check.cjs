const{chromium}=require('playwright'),fs=require('node:fs/promises'),path=require('node:path'),assert=require('node:assert/strict'),{createHash}=require('node:crypto');
const base=path.resolve(__dirname,'..'),root=process.argv[2];if(!root)throw Error('Pass installed bridge fixture directory');
(async()=>{const b=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});try{
const entries=['worm-whiplash','ghostshot'].map(id=>({id,name:id})),files=[];
for(const{ id }of entries)for(const name of ['arcadium-live.json','import-check.html']){const data=await fs.readFile(path.join(root,'games',id,name));files.push({game:id,path:`games/${id}/${name}`,data:data.toString('base64'),sha256:createHash('sha256').update(data).digest('hex')});}
const catalogueBefore=await fs.readFile(path.join(root,'data/arcadium.json'),'utf8'),bridgeBefore=await fs.readFile(path.join(root,'arcadium_game_bridge.py'),'utf8');
for(const missingHost of [false,true]){
 const ctx=await b.newContext(),p=await ctx.newPage(),errors=[];p.on('pageerror',e=>errors.push(e.message));
 await p.exposeBinding('disk',async(_,op,relative,data)=>{const target=path.resolve(root,relative);assert(target.startsWith(path.resolve(root)+path.sep));try{if(op==='read')return (await fs.readFile(target)).toString('base64');if(op==='write'){await fs.mkdir(path.dirname(target),{recursive:true});await fs.writeFile(target+'.test-write',Buffer.from(data));await fs.rename(target+'.test-write',target);}if(op==='remove')await fs.unlink(target);}catch(e){if(e.code==='ENOENT')return null;throw e;}});
 await p.goto('http://localhost:8787/test-importer');
 await p.setContent('<button id="install">Import</button><button id="restore">Restore</button><input type="checkbox" checked value="worm-whiplash"><input type="checkbox" checked value="ghostshot"><pre id="status"></pre><div id="links"></div>');
 await p.evaluate(payload=>{window.PAYLOAD=payload;window.showDirectoryPicker=async()=>dir();function dir(prefix=''){return{async getDirectoryHandle(n){return dir(prefix+n+'/')},async getFileHandle(n,{create=false}={}){const name=prefix+n,old=await disk('read',name);if(old===null&&!create)throw Object.assign(Error('missing'),{name:'NotFoundError'});return{async getFile(){const d=Uint8Array.from(atob(await disk('read',name)||''),c=>c.charCodeAt(0));return{async arrayBuffer(){return d.buffer}}},async createWritable(){let data;return{async write(b){data=Array.from(b)},async close(){await disk('write',name,data)},async abort(){}}}}},async removeEntry(n){await disk('remove',prefix+n)}}}}, {entries,files});
 if(missingHost)await ctx.route('**/arcadium-live/*/status',r=>r.fulfill({status:404,body:'missing'}));
 await p.addScriptTag({path:path.join(base,'importer.js')});await p.click('#install');await p.waitForSelector('#check-host');
 // The catalogue must remain untouched until the explicit visible check succeeds.
 const before=JSON.parse(await fs.readFile(path.join(root,'data/arcadium.json'),'utf8'));assert.equal(before.games.length,missingHost?62:60);
 const popupPromise=p.waitForEvent('popup');await p.click('#check-host');const popup=await popupPromise;await popup.waitForLoadState();
 if(missingHost){await p.waitForFunction(()=>document.querySelector('#status').textContent.includes('Staged game files rolled back.'));assert((await popup.locator('#result').textContent()).includes('HTTP 404'));}else{await p.waitForFunction(()=>document.querySelector('#status').textContent.includes('Installed.'));const after=JSON.parse(await fs.readFile(path.join(root,'data/arcadium.json'),'utf8'));assert.equal(after.games.length,62);assert.deepEqual(after.games.slice(0,60),JSON.parse(catalogueBefore).games);}
 assert.equal(await fs.readFile(path.join(root,'arcadium_game_bridge.py'),'utf8'),bridgeBefore);assert.deepEqual(errors,[]);await ctx.close();
}
console.log('PASS: supplied bridge constructor, visible cross-origin check tab, explicit user click before catalogue commit, both games verified, 60 entries and bridge preserved, exact HTTP 404 reported and rollback completed');
}finally{await b.close()}})().catch(e=>{console.error(e);process.exit(1)});
