"""Test the supplied bridge constructor. Other legacy game wrappers are stubs.
No claim of reproducing all of the user's OS or installed adapter versions.
"""
import ast, functools, importlib.util, json, os, pathlib, shutil, sys, types
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
BASE=pathlib.Path(__file__).resolve().parents[1]
source=pathlib.Path(sys.argv[1]).resolve(); root=pathlib.Path(sys.argv[2]).resolve();root.mkdir(parents=True,exist_ok=True)
shutil.copyfile(source,root/'arcadium_game_bridge.py')
for node in ast.walk(ast.parse(source.read_text())):
 if isinstance(node,ast.ImportFrom) and node.module.endswith('_routes'):
  module=types.ModuleType(node.module)
  for alias in node.names:setattr(module,alias.name,lambda handler:handler)
  sys.modules[node.module]=module
for game in ('pop-a-shot','ruin-runners'):
 origin=pathlib.Path('/workspace/work')/game/'integrations'/game/'games'/game/'_pc'
 dest=root/'games'/game/'_pc';dest.mkdir(parents=True,exist_ok=True)
 for p in origin.glob('*.py'):shutil.copyfile(p,dest/p.name)
for slug,parent in [('worm-whiplash','worm-whiplash'),('ghostshot','ghostshot-browser')]:
 origin=BASE.parent/parent/'games'/slug;dest=root/'games'/slug
 for p in origin.rglob('*'):
  if p.is_file() and '_pc' not in p.relative_to(origin).parts:
   d=dest/p.relative_to(origin);d.parent.mkdir(parents=True,exist_ok=True)
   if not d.exists():
    try:os.link(p,d)
    except OSError:shutil.copyfile(p,d)
 (dest/'import-check.html').write_text((BASE/'connection-check.html').read_text())
(root/'arcadium_server.py').write_text('# fixture only; server must not be modified\n')
(root/'data').mkdir(exist_ok=True)
(root/'data'/'arcadium.json').write_text(json.dumps({'games':[{'id':f'legacy-{n}'} for n in range(60)],'pairing':'unchanged'}))
spec=importlib.util.spec_from_file_location('arcadium_game_bridge',root/'arcadium_game_bridge.py');bridge=importlib.util.module_from_spec(spec);sys.modules[spec.name]=bridge;spec.loader.exec_module(bridge)
class Parent(SimpleHTTPRequestHandler):
 def __init__(self,*a,**kw):super().__init__(*a,directory=str(root),**kw)
 def log_message(self,*a):pass
 def do_POST(self):self.send_error(404)
 def do_GET(self):
  if self.path=='/test-importer':
   data=b'<!doctype html><title>Browser test parent</title>'
   self.send_response(200);self.end_headers();self.wfile.write(data);return
  if self.path.startswith('/api/vibe/events'):
   data=b'{"latest":0,"events":[]}'
   self.send_response(200);self.send_header('Content-Type','application/json');self.end_headers();self.wfile.write(data);return
  super().do_GET()
server=ThreadingHTTPServer(('127.0.0.1',8787),bridge.bridge(Parent));server.native_app=types.SimpleNamespace(VIBE_PAIR_TOKEN='pool-test-invitation',PINK_DEVICE_IP=None)
print('User-supplied bridge with reference installed adapters on 8787',flush=True);server.serve_forever()
