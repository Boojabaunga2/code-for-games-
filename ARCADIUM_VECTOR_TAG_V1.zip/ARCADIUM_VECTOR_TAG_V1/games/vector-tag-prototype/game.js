
(function(){

// ---------------------------------------------------------------
// BASIC SETUP
// ---------------------------------------------------------------
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x020207);
scene.fog = new THREE.Fog(0x020207, 55, 95);

const renderer = new THREE.WebGLRenderer({antialias:true,preserveDrawingBuffer:true});
renderer.setPixelRatio(Math.min(window.devicePixelRatio||1, 2));
renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);

const VIEW_RADIUS = 30;
let camera;
function buildCamera(){
  const aspect = window.innerWidth / window.innerHeight;
  let halfH = VIEW_RADIUS;
  let halfW = VIEW_RADIUS * aspect;
  if (aspect < 1){ halfH = VIEW_RADIUS / aspect; halfW = VIEW_RADIUS; }
  camera = new THREE.OrthographicCamera(-halfW, halfW, halfH, -halfH, 0.1, 300);
  camera.position.set(0, 46, 46);
  camera.lookAt(0,0,0);
}
buildCamera();
window.addEventListener('resize', ()=>{
  renderer.setSize(window.innerWidth, window.innerHeight);
  buildCamera();
});

// ---------------------------------------------------------------
// COLORS
// ---------------------------------------------------------------
const COL_ARENA_DIM = 0x0c2f66;
const COL_ARENA     = 0x1b6fff;
const COL_PAD       = 0xffe23d;
const COL_PILLAR    = 0x2fdc6e;
const COL_GATE      = 0xff2bd1;
const COL_IT        = 0xff2222;
const COL_ACCENT    = 0x9d4bff;

function edgeLines(geometry, color, opacity){
  const edges = new THREE.EdgesGeometry(geometry);
  const mat = new THREE.LineBasicMaterial({color:color, transparent:true, opacity: opacity===undefined?1:opacity});
  return new THREE.LineSegments(edges, mat);
}
function glowSprite(color, size, opacity){
  const c = document.createElement('canvas');
  c.width = c.height = 128;
  const ctx = c.getContext('2d');
  const g = ctx.createRadialGradient(64,64,0,64,64,64);
  const hex = '#'+color.toString(16).padStart(6,'0');
  g.addColorStop(0, 'rgba(255,255,255,0.9)');
  g.addColorStop(0.25, hex);
  g.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = g;
  ctx.fillRect(0,0,128,128);
  const tex = new THREE.CanvasTexture(c);
  const mat = new THREE.SpriteMaterial({map:tex, blending:THREE.AdditiveBlending, transparent:true, depthWrite:false, opacity:opacity===undefined?0.9:opacity});
  const spr = new THREE.Sprite(mat);
  spr.scale.set(size,size,1);
  return spr;
}

// ---------------------------------------------------------------
// SHARED BOUNDARY — same octagon for every arena, built once.
// ---------------------------------------------------------------
const B = 24;
const CHAMFER = 9;
const SLAB_THICK = 0.35;
const RAMP_W = 4;
const LEG_R = 0.4;
const PLAYER_R = 1.0;
const ARENA_DIAG_LIMIT = 2*B - CHAMFER;
const PAD_R = 1.5;
const JUMP_DIST = 9;
const JUMP_DUR = 0.42;
const JUMP_ARC = 3.2;

function octagonPoints(radiusB, chamfer, y){
  return [
    [radiusB-chamfer,-radiusB],[radiusB,-radiusB+chamfer],
    [radiusB,radiusB-chamfer],[radiusB-chamfer,radiusB],
    [-radiusB+chamfer,radiusB],[-radiusB,radiusB-chamfer],
    [-radiusB,-radiusB+chamfer],[-radiusB+chamfer,-radiusB],
    [radiusB-chamfer,-radiusB]
  ].map(([x,z])=>new THREE.Vector3(x,y,z));
}

scene.add(new THREE.HemisphereLight(0x8edfff,0x191131,1.3));const keyLight=new THREE.DirectionalLight(0xffffff,1.7);keyLight.position.set(-12,24,15);scene.add(keyLight);
const floor=new THREE.Mesh(new THREE.CircleGeometry(38,8),new THREE.MeshBasicMaterial({color:0x071525}));floor.rotation.x=-Math.PI/2;floor.position.y=-.08;scene.add(floor);
for(let j=0;j<3;j++){const ring=new THREE.Mesh(new THREE.TorusGeometry(32+j*3,.045,4,96),new THREE.MeshBasicMaterial({color:j===1?0x9d4bff:0x12667d}));ring.rotation.x=Math.PI/2;ring.position.y=-.12-j*.05;scene.add(ring);}
const stars=new Float32Array(450);for(let i=0;i<450;i+=3){stars[i]=(Math.random()-.5)*150;stars[i+1]=8+Math.random()*28;stars[i+2]=(Math.random()-.5)*150;}const starsGeo=new THREE.BufferGeometry();starsGeo.setAttribute('position',new THREE.BufferAttribute(stars,3));scene.add(new THREE.Points(starsGeo,new THREE.PointsMaterial({color:0x4797b4,size:.09,transparent:true,opacity:.5})));
const grid = new THREE.GridHelper(B*2, 24, COL_ARENA_DIM, COL_ARENA_DIM);
grid.position.y = 0.01;
scene.add(grid);

const octPts = octagonPoints(B, CHAMFER, 0.05);
scene.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(octPts), new THREE.LineBasicMaterial({color:COL_ARENA})));

for (let i=0;i<octPts.length-1;i++){
  const a = octPts[i], b = octPts[i+1];
  const midX=(a.x+b.x)/2, midZ=(a.z+b.z)/2;
  const len = Math.hypot(b.x-a.x,b.z-a.z);
  const angle = Math.atan2(b.x-a.x, b.z-a.z);
  const wallGeo = new THREE.BoxGeometry(0.05, 2.4, len);
  const wall = edgeLines(wallGeo, COL_ARENA_DIM, 0.5);
  wall.position.set(midX, 1.2, midZ);
  wall.rotation.y = angle;
  scene.add(wall);
}

function withinOctagon(x,z){
  if (Math.abs(x) > B || Math.abs(z) > B) return false;
  return (Math.abs(x)+Math.abs(z)) <= ARENA_DIAG_LIMIT + 0.5;
}
function clampToArena(x,z){
  x = THREE.MathUtils.clamp(x, -B+PLAYER_R, B-PLAYER_R);
  z = THREE.MathUtils.clamp(z, -B+PLAYER_R, B-PLAYER_R);
  const limit = ARENA_DIAG_LIMIT - PLAYER_R*1.3;
  const s = Math.abs(x)+Math.abs(z);
  if (s > limit && s > 0){
    const scale = limit/s;
    x *= scale; z *= scale;
  }
  return {x,z};
}

// Gates: every octagon wall segment gets a portal, paired with the
// segment directly opposite it. Shared across all arenas.
const GATE_HALF_WIDTH = 1.6;
const gates = [];
for (let i=0;i<octPts.length-1;i++){
  const a = octPts[i], b = octPts[i+1];
  const midX=(a.x+b.x)/2, midZ=(a.z+b.z)/2;
  const dx=b.x-a.x, dz=b.z-a.z;
  const len = Math.hypot(dx,dz);
  const tangent = {x:dx/len, z:dz/len};
  let normal = {x:-tangent.z, z:tangent.x};
  if (normal.x*midX + normal.z*midZ < 0){ normal.x*=-1; normal.z*=-1; }
  gates.push({center:{x:midX,z:midZ}, normal, tangent, angle:Math.atan2(dx,dz)});
}
gates.forEach((g,i)=>{ g.pair = gates[(i+4)%8]; });

const GATE_TRIGGER_MARGIN = PLAYER_R + 0.6;
const GATE_LANDING_INSET = GATE_TRIGGER_MARGIN + 1.0;
const portalFlashes = [];
function spawnPortalFlash(x,z){
  const spr = glowSprite(COL_GATE, 1.2, 1.0);
  spr.position.set(x, 1.4, z);
  scene.add(spr);
  portalFlashes.push({spr, age:0, dur:0.35});
}
function applyGatePortal(x,z){
  for (const g of gates){
    const rx = x-g.center.x, rz = z-g.center.z;
    const normalDist = rx*g.normal.x + rz*g.normal.z;
    const tangentDist = rx*g.tangent.x + rz*g.tangent.z;
    if (normalDist > -GATE_TRIGGER_MARGIN && Math.abs(tangentDist) <= GATE_HALF_WIDTH){
      const p = g.pair;
      const nx = p.center.x - p.normal.x*GATE_LANDING_INSET + p.tangent.x*tangentDist;
      const nz = p.center.z - p.normal.z*GATE_LANDING_INSET + p.tangent.z*tangentDist;
      spawnPortalFlash(g.center.x, g.center.z);
      spawnPortalFlash(p.center.x, p.center.z);
      return {x:nx, z:nz, teleported:true};
    }
  }
  return {x,z,teleported:false};
}

const gatePortals = [];
gates.forEach(g=>{
  const normalAngle = Math.atan2(g.normal.x, g.normal.z);
  const frameGeo = new THREE.BoxGeometry(0.3, 2.6, GATE_HALF_WIDTH*2);
  const wire = edgeLines(frameGeo, COL_GATE, 0.95);
  wire.position.set(g.center.x, 1.4, g.center.z);
  wire.rotation.y = g.angle;
  scene.add(wire);
  const fill = new THREE.Mesh(frameGeo, new THREE.MeshBasicMaterial({color:COL_GATE, transparent:true, opacity:0.08, blending:THREE.AdditiveBlending}));
  fill.position.copy(wire.position); fill.rotation.y = g.angle;
  scene.add(fill);
  const glow = glowSprite(COL_GATE, 5, 0.4);
  glow.position.set(g.center.x, 1.4, g.center.z);
  scene.add(glow);
  const portalMat = new THREE.MeshBasicMaterial({color:COL_GATE, transparent:true, opacity:0.35, side:THREE.DoubleSide, blending:THREE.AdditiveBlending});
  const portalPlane = new THREE.Mesh(new THREE.PlaneGeometry(GATE_HALF_WIDTH*2*0.85, 2.2), portalMat);
  portalPlane.position.set(g.center.x, 1.4, g.center.z);
  portalPlane.rotation.y = normalAngle;
  scene.add(portalPlane);
  gatePortals.push(portalMat);
});

// ---------------------------------------------------------------
// GENERALIZED LAYER SYSTEM — any arena is: 'ground' (height 0) plus
// any number of named platforms, connected by ramp zones. A runner
// tracks which named layer it's currently standing on.
// ---------------------------------------------------------------
function makeSquareFootprint(half){
  return {
    test:(x,z)=> Math.abs(x)<=half && Math.abs(z)<=half,
    clamp:(x,z)=>({x:THREE.MathUtils.clamp(x,-half,half), z:THREE.MathUtils.clamp(z,-half,half)})
  };
}
function makeRingFootprint(holeHalf){
  return {
    test:(x,z)=> withinOctagon(x,z) && !(Math.abs(x)<=holeHalf && Math.abs(z)<=holeHalf),
    clamp:(x,z)=>{
      if (Math.abs(x)<=holeHalf && Math.abs(z)<=holeHalf){
        const dx = holeHalf-Math.abs(x), dz = holeHalf-Math.abs(z);
        if (dx < dz) return {x:(x<0?-1:1)*holeHalf, z};
        return {x, z:(z<0?-1:1)*holeHalf};
      }
      return clampToArena(x,z);
    }
  };
}
function rampZone(axis, sign, mAtFrom, mAtTo, halfWidth, fromId, toId){
  return { fromId, toId, test(x,z){
    const main = axis==='z' ? z : x;
    const cross = axis==='z' ? x : z;
    if (Math.abs(cross) > halfWidth) return null;
    const m = sign>0 ? main : -main;
    const lo = Math.min(mAtFrom, mAtTo), hi = Math.max(mAtFrom, mAtTo);
    if (m < lo || m > hi) return null;
    return (m - mAtFrom) / (mAtTo - mAtFrom);
  }};
}
function applyLayerGeneric(state, nx, nz){
  const ctx = currentArenaCtx;
  for (const ramp of ctx.ramps){
    const t = ramp.test(nx,nz);
    if (t !== null){
      const fromH = ctx.heights[ramp.fromId] || 0;
      const toH = ctx.heights[ramp.toId] || 0;
      const tt = Math.max(0, Math.min(1, t));
      const targetH = THREE.MathUtils.lerp(fromH, toH, tt);
      if (t >= 0.95) state.layer = ramp.toId;
      else if (t <= 0.05) state.layer = ramp.fromId;
      return {x:nx, z:nz, yTarget: targetH};
    }
  }
  if (state.layer !== 'ground'){
    const plat = ctx.platforms[state.layer];
    if (plat){
      if (plat.footprint.test(nx,nz)) return {x:nx, z:nz, yTarget: plat.height};
      const c = plat.footprint.clamp(nx,nz);
      return {x:c.x, z:c.z, yTarget: plat.height};
    }
  }
  return {x:nx, z:nz, yTarget: 0};
}
function arenaHeightOf(layerId){ return currentArenaCtx.heights[layerId] || 0; }

// ---------------------------------------------------------------
// ARENA BUILDING BLOCKS — shared visual/collision helpers used by
// all three arena layouts.
// ---------------------------------------------------------------
function buildTablePlatform(ctx, group, id, half, topY, color, legBaseY){
  legBaseY = legBaseY || 0;
  ctx.heights[id] = topY;
  ctx.platforms[id] = { height: topY, footprint: makeSquareFootprint(half) };
  const legInset = half - 0.55;
  const legH = topY - SLAB_THICK - legBaseY;
  [[legInset,legInset],[legInset,-legInset],[-legInset,legInset],[-legInset,-legInset]].forEach(([lx,lz])=>{
    const legGeo = new THREE.CylinderGeometry(LEG_R, LEG_R, legH, 8);
    const legWire = edgeLines(legGeo, color, 0.7);
    legWire.position.set(lx, legBaseY + legH/2, lz);
    group.add(legWire);
    collidables.push({x:lx, z:lz, r:LEG_R+0.35});
  });
  const slabGeo = new THREE.BoxGeometry(half*2, SLAB_THICK, half*2);
  const slabFill = new THREE.Mesh(slabGeo, new THREE.MeshBasicMaterial({color, transparent:true, opacity:0.08, blending:THREE.AdditiveBlending}));
  slabFill.position.set(0, topY-SLAB_THICK/2, 0);
  group.add(slabFill);
  const slabWire = edgeLines(slabGeo, color, 0.95);
  slabWire.position.copy(slabFill.position);
  group.add(slabWire);
  const markerWire = edgeLines(new THREE.BoxGeometry(1.6,0.05,1.6), color, 0.9);
  markerWire.rotation.y = Math.PI/4;
  markerWire.position.set(0, topY+0.05, 0);
  group.add(markerWire);
  const rimGlow = glowSprite(color, Math.max(half*1.3,5), 0.3);
  rimGlow.position.set(0, topY-SLAB_THICK-0.2, 0);
  group.add(rimGlow);
}
function addRamp(ctx, group, axis, sign, mAtFrom, mAtTo, halfWidth, fromId, toId, color){
  ctx.ramps.push(rampZone(axis, sign, mAtFrom, mAtTo, halfWidth, fromId, toId));
  const fromH = ctx.heights[fromId]||0, toH = ctx.heights[toId]||0;
  const len = Math.abs(mAtTo-mAtFrom);
  const midM = sign*(mAtFrom+mAtTo)/2;
  const w = halfWidth*2;
  const shape = new THREE.BoxGeometry(axis==='x'?len:w, 0.35, axis==='x'?w:len);
  const wire = edgeLines(shape, color, 0.8);
  const fill = new THREE.Mesh(shape, new THREE.MeshBasicMaterial({color, transparent:true, opacity:0.06, blending:THREE.AdditiveBlending}));
  const grp = new THREE.Group(); grp.add(fill); grp.add(wire);
  const treadCount = 5;
  for (let i=1;i<treadCount;i++){
    const off = -len/2 + (len/treadCount)*i;
    const tGeo = axis==='x'
      ? new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(off,0.18,-w/2), new THREE.Vector3(off,0.18,w/2)])
      : new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(-w/2,0.18,off), new THREE.Vector3(w/2,0.18,off)]);
    grp.add(new THREE.Line(tGeo, new THREE.LineBasicMaterial({color, transparent:true, opacity:0.5})));
  }
  const midHeight = (fromH+toH)/2;
  const tilt = Math.atan2(Math.abs(toH-fromH), len) || 0.001;
  const tiltSign = (toH>=fromH) ? 1 : -1;
  if (axis === 'z'){
    grp.position.set(0, midHeight, midM);
    grp.rotation.x = -sign*tiltSign*tilt;
  } else {
    grp.position.set(midM, midHeight, 0);
    grp.rotation.z = sign*tiltSign*tilt;
  }
  group.add(grp);
}
function buildPillarVisual(group, x, z, r, h, color){
  const geo = new THREE.CylinderGeometry(r, r, h, 8);
  const wire = edgeLines(geo, color||COL_PILLAR, 0.9);
  wire.position.set(x, h/2, z);
  group.add(wire);
  const glow = glowSprite(color||COL_PILLAR, 3.2);
  glow.position.set(x, h+0.6, z);
  group.add(glow);
  collidables.push({x, z, r:r*0.9});
}
function buildPadVisual(group, x, z){
  const diamondGeo = new THREE.PlaneGeometry(PAD_R*1.5, PAD_R*1.5);
  const mesh = new THREE.Mesh(diamondGeo, new THREE.MeshBasicMaterial({color:COL_PAD, transparent:true, opacity:0.45, side:THREE.DoubleSide}));
  mesh.rotation.x=-Math.PI/2; mesh.rotation.z=Math.PI/4; mesh.position.set(x,0.06,z);
  group.add(mesh);
  const wire = edgeLines(diamondGeo, COL_PAD, 0.95);
  wire.rotation.x=-Math.PI/2; wire.rotation.z=Math.PI/4; wire.position.set(x,0.07,z);
  group.add(wire);
  const glow = glowSprite(COL_PAD,4.5); glow.position.set(x,0.4,z);
  group.add(glow);
  padMeshes.push({x,z});
}

// ---------------------------------------------------------------
// ARENA 01 — THE GRID: one central table platform, 4 ramps
// ---------------------------------------------------------------
function buildArenaGrid(ctx, group){
  const PLAT_HALF=5.5, TOP_Y=3.8, RAMP_LEN=4.5;
  buildTablePlatform(ctx, group, 'center', PLAT_HALF, TOP_Y, COL_ARENA);
  addRamp(ctx, group, 'z', 1, PLAT_HALF+RAMP_LEN, PLAT_HALF, RAMP_W/2, 'ground','center', COL_ARENA);
  addRamp(ctx, group, 'z', -1, PLAT_HALF+RAMP_LEN, PLAT_HALF, RAMP_W/2, 'ground','center', COL_ARENA);
  addRamp(ctx, group, 'x', 1, PLAT_HALF+RAMP_LEN, PLAT_HALF, RAMP_W/2, 'ground','center', COL_ARENA);
  addRamp(ctx, group, 'x', -1, PLAT_HALF+RAMP_LEN, PLAT_HALF, RAMP_W/2, 'ground','center', COL_ARENA);

  [
    {x:9,z:9,r:1.0,h:6.2},{x:9,z:-9,r:1.0,h:6.2},{x:-9,z:9,r:1.0,h:6.2},{x:-9,z:-9,r:1.0,h:6.2},
    {x:9.5,z:16.5,r:1.1,h:7},{x:9.5,z:-16.5,r:1.1,h:7},{x:-9.5,z:16.5,r:1.1,h:7},{x:-9.5,z:-16.5,r:1.1,h:7}
  ].forEach(p=>buildPillarVisual(group,p.x,p.z,p.r,p.h));

  [{x:0,z:13},{x:0,z:-13},{x:13,z:0},{x:-13,z:0},{x:15,z:15},{x:-15,z:-15}]
    .forEach(p=>buildPadVisual(group,p.x,p.z));
}

// ---------------------------------------------------------------
// ARENA 02 — THE BOWL: elevated outer ring with a central pit hole,
// plus a small raised platform inside the pit for a third tier.
// ---------------------------------------------------------------
function buildArenaBowl(ctx, group){
  const RING_Y=2.6, HOLE_HALF=9, RING_HALF=17, RAMP_LEN=4.5;
  const PIT_HALF=3.6, PIT_Y=5.4, PIT_RAMP_LEN=3.5;

  ctx.heights.ring = RING_Y;
  ctx.platforms.ring = { height:RING_Y, footprint: makeRingFootprint(HOLE_HALF) };

  const shape = new THREE.Shape();
  shape.moveTo(-RING_HALF,-RING_HALF); shape.lineTo(RING_HALF,-RING_HALF);
  shape.lineTo(RING_HALF,RING_HALF); shape.lineTo(-RING_HALF,RING_HALF); shape.closePath();
  const hole = new THREE.Path();
  hole.moveTo(-HOLE_HALF,-HOLE_HALF); hole.lineTo(HOLE_HALF,-HOLE_HALF);
  hole.lineTo(HOLE_HALF,HOLE_HALF); hole.lineTo(-HOLE_HALF,HOLE_HALF); hole.closePath();
  shape.holes.push(hole);
  const ringGeo = new THREE.ExtrudeGeometry(shape, {depth:SLAB_THICK, bevelEnabled:false});
  ringGeo.rotateX(-Math.PI/2);
  ringGeo.translate(0, RING_Y-SLAB_THICK, 0);
  group.add(new THREE.Mesh(ringGeo, new THREE.MeshBasicMaterial({color:COL_ARENA, transparent:true, opacity:0.08, blending:THREE.AdditiveBlending})));
  group.add(edgeLines(ringGeo, COL_ARENA, 0.9));

  [[15,15],[15,-15],[-15,15],[-15,-15],[15.5,0],[-15.5,0],[0,15.5],[0,-15.5]].forEach(([lx,lz])=>{
    const legGeo = new THREE.CylinderGeometry(LEG_R, LEG_R, RING_Y-SLAB_THICK, 8);
    const wire = edgeLines(legGeo, COL_ARENA, 0.6);
    wire.position.set(lx, (RING_Y-SLAB_THICK)/2, lz);
    group.add(wire);
    collidables.push({x:lx, z:lz, r:LEG_R+0.35});
  });

  addRamp(ctx, group, 'z', 1, HOLE_HALF-RAMP_LEN, HOLE_HALF, RAMP_W/2, 'ground','ring', COL_ARENA);
  addRamp(ctx, group, 'z', -1, HOLE_HALF-RAMP_LEN, HOLE_HALF, RAMP_W/2, 'ground','ring', COL_ARENA);
  addRamp(ctx, group, 'x', 1, HOLE_HALF-RAMP_LEN, HOLE_HALF, RAMP_W/2, 'ground','ring', COL_ARENA);
  addRamp(ctx, group, 'x', -1, HOLE_HALF-RAMP_LEN, HOLE_HALF, RAMP_W/2, 'ground','ring', COL_ARENA);

  buildTablePlatform(ctx, group, 'pit', PIT_HALF, PIT_Y, COL_ACCENT);
  addRamp(ctx, group, 'z', 1, PIT_HALF+PIT_RAMP_LEN, PIT_HALF, (RAMP_W/2)*0.85, 'ground','pit', COL_ACCENT);
  addRamp(ctx, group, 'z', -1, PIT_HALF+PIT_RAMP_LEN, PIT_HALF, (RAMP_W/2)*0.85, 'ground','pit', COL_ACCENT);

  [
    {x:5.5,z:5.5,r:0.85,h:5},{x:5.5,z:-5.5,r:0.85,h:5},{x:-5.5,z:5.5,r:0.85,h:5},{x:-5.5,z:-5.5,r:0.85,h:5},
    {x:13,z:0,r:1.0,h:6.5},{x:-13,z:0,r:1.0,h:6.5}
  ].forEach(p=>buildPillarVisual(group,p.x,p.z,p.r,p.h));

  [{x:12,z:12},{x:-12,z:-12},{x:12,z:-12},{x:-12,z:12},{x:0,z:6},{x:0,z:-6}]
    .forEach(p=>buildPadVisual(group,p.x,p.z));
}

// ---------------------------------------------------------------
// ARENA 03 — THE TOWER: two-tier central spire — a base platform
// reachable from all 4 sides, and a smaller cap reachable only by
// a single ramp from the base. Verticality over footprint.
// ---------------------------------------------------------------
function buildArenaTower(ctx, group){
  const BASE_HALF=4.5, BASE_Y=3.6, BASE_RAMP_LEN=4.0;
  const CAP_HALF=2.0, CAP_Y=6.8, CAP_RAMP_LEN=2.4;

  buildTablePlatform(ctx, group, 'base', BASE_HALF, BASE_Y, COL_ARENA);
  addRamp(ctx, group, 'z', 1, BASE_HALF+BASE_RAMP_LEN, BASE_HALF, RAMP_W/2, 'ground','base', COL_ARENA);
  addRamp(ctx, group, 'z', -1, BASE_HALF+BASE_RAMP_LEN, BASE_HALF, RAMP_W/2, 'ground','base', COL_ARENA);
  addRamp(ctx, group, 'x', 1, BASE_HALF+BASE_RAMP_LEN, BASE_HALF, RAMP_W/2, 'ground','base', COL_ARENA);
  addRamp(ctx, group, 'x', -1, BASE_HALF+BASE_RAMP_LEN, BASE_HALF, RAMP_W/2, 'ground','base', COL_ARENA);

  buildTablePlatform(ctx, group, 'cap', CAP_HALF, CAP_Y, COL_GATE, BASE_Y);
  addRamp(ctx, group, 'z', 1, CAP_HALF+CAP_RAMP_LEN, CAP_HALF, (RAMP_W/2)*0.75, 'base','cap', COL_GATE);

  const spikeGeo = new THREE.ConeGeometry(0.45, 5, 4);
  const spike = edgeLines(spikeGeo, COL_GATE, 0.7);
  spike.position.set(0, CAP_Y+2.5, 0);
  group.add(spike);
  const spikeGlow = glowSprite(COL_GATE, 4, 0.35);
  spikeGlow.position.set(0, CAP_Y+1.2, 0);
  group.add(spikeGlow);

  [
    {x:10,z:10,r:1.0,h:6.5},{x:10,z:-10,r:1.0,h:6.5},{x:-10,z:10,r:1.0,h:6.5},{x:-10,z:-10,r:1.0,h:6.5},
    {x:15,z:0,r:1.0,h:6.5},{x:-15,z:0,r:1.0,h:6.5},{x:0,z:16,r:1.0,h:6.5},{x:0,z:-16,r:1.0,h:6.5}
  ].forEach(p=>buildPillarVisual(group,p.x,p.z,p.r,p.h));

  [{x:9,z:0},{x:-9,z:0},{x:13,z:13},{x:-13,z:-13},{x:13,z:-13},{x:-13,z:13}]
    .forEach(p=>buildPadVisual(group,p.x,p.z));
}

// ---------------------------------------------------------------
// ARENA SWITCHER
// ---------------------------------------------------------------
const ARENA_BUILDERS = [buildArenaGrid, buildArenaBowl, buildArenaTower];
const ARENA_NAMES = ['ARENA 01 — THE GRID','ARENA 02 — THE BOWL','ARENA 03 — THE TOWER'];
const collidables = [];
const padMeshes = [];
let currentArenaCtx = null;
let activeArenaIndex = 0;
const arenaGroup = new THREE.Group();
scene.add(arenaGroup);

function clearArenaGroup(){
  while (arenaGroup.children.length){
    const obj = arenaGroup.children.pop();
    obj.traverse(o=>{
      if (o.geometry) o.geometry.dispose();
      if (o.material){
        if (Array.isArray(o.material)) o.material.forEach(m=>m.dispose());
        else o.material.dispose();
      }
    });
  }
  collidables.length = 0;
  padMeshes.length = 0;
}

function buildArena(index){
  if (typeof session!=='undefined' && session.phase==='play') return;
  clearArenaGroup();
  activeArenaIndex = index;
  document.getElementById('arenaLabel').textContent = ARENA_NAMES[index];
  for (let i=0;i<3;i++){
    const btn = document.getElementById('aBtn'+i);
    if (btn) btn.classList.toggle('active', i===index);
  }
  const ctx = { platforms:{}, ramps:[], heights:{ground:0} };
  ARENA_BUILDERS[index](ctx, arenaGroup);
  currentArenaCtx = ctx;
  if (typeof resetMatch === 'function') resetMatch();
}

// ---------------------------------------------------------------
// CRYSTAL RUNNER FACTORY
// ---------------------------------------------------------------
function crystalGeometry(rx,ry,rz,jitter){
  const geo = new THREE.IcosahedronGeometry(1, 0);
  const pos = geo.attributes.position;
  const cache = {};
  for (let i=0;i<pos.count;i++){
    const ox=pos.getX(i), oy=pos.getY(i), oz=pos.getZ(i);
    const key = ox.toFixed(3)+','+oy.toFixed(3)+','+oz.toFixed(3);
    let j = cache[key];
    if (!j){
      j = [(Math.random()-0.5)*jitter,(Math.random()-0.5)*jitter,(Math.random()-0.5)*jitter];
      cache[key] = j;
    }
    pos.setXYZ(i, ox*rx+j[0], oy*ry+j[1], oz*rz+j[2]);
  }
  geo.computeVertexNormals();
  return geo;
}
function crystalPart(rx,ry,rz,jitter,color,opacity){
  const geo = crystalGeometry(rx,ry,rz,jitter);
  const g = new THREE.Group();
  g.add(new THREE.Mesh(geo, new THREE.MeshStandardMaterial({color,roughness:.4,metalness:.3,flatShading:true,transparent:true,opacity:opacity===undefined?0.85:opacity})));
  g.add(edgeLines(geo, color, 1));
  return g;
}
function boxPart(w,h,d,color,opacity){
  const geo = new THREE.BoxGeometry(w,h,d);
  const g = new THREE.Group();
  g.add(new THREE.Mesh(geo, new THREE.MeshStandardMaterial({color,roughness:.4,metalness:.3,flatShading:true,transparent:true,opacity:opacity===undefined?0.85:opacity})));
  g.add(edgeLines(geo, color, 1));
  return g;
}
function bladeSpike(color,px,py,pz,rx,ry,rz,length,radius){
  const geo = new THREE.ConeGeometry(radius||0.09, length, 3);
  const wire = edgeLines(geo, color, 1);
  const fill = new THREE.Mesh(geo, new THREE.MeshBasicMaterial({color, transparent:true, opacity:0.18, blending:THREE.AdditiveBlending}));
  const g = new THREE.Group(); g.add(fill); g.add(wire);
  g.scale.set(1,1,0.45);
  g.position.set(px,py,pz); g.rotation.set(rx,ry,rz);
  return g;
}
function eyeShard(size){
  const geo = new THREE.ConeGeometry(size*0.4, size, 3);
  const mesh = new THREE.Mesh(geo, new THREE.MeshBasicMaterial({color:0xffffff}));
  mesh.rotation.z = Math.PI/2;
  mesh.scale.set(1,1,0.4);
  return mesh;
}
function makeItHalo(){
  const pts=[]; const segs=24, r=0.44;
  for (let i=0;i<=segs;i++){ const a=(i/segs)*Math.PI*2; pts.push(new THREE.Vector3(Math.cos(a)*r,0,Math.sin(a)*r)); }
  const geo = new THREE.BufferGeometry().setFromPoints(pts);
  const mat = new THREE.LineBasicMaterial({color:COL_IT, transparent:true, opacity:0.95});
  const ring = new THREE.Line(geo,mat);
  const glow = glowSprite(COL_IT, 2.3, 0.85);
  const g = new THREE.Group();
  g.add(ring); g.add(glow);
  g.position.y = 2.08;
  g.visible = false;
  g.userData.ringMat = mat;
  return g;
}

function decorateHead(head, color, earType){
  if (earType === 'spikes'){
    head.add(bladeSpike(color,0,0.3,-0.08,-0.6,0,0,0.62,0.11));
    head.add(bladeSpike(color,0.14,0.27,-0.05,-0.5,0,0.35,0.5,0.09));
    head.add(bladeSpike(color,-0.14,0.27,-0.05,-0.5,0,-0.35,0.5,0.09));
    head.add(bladeSpike(color,0.24,0.2,-0.02,-0.35,0,0.6,0.38,0.08));
    head.add(bladeSpike(color,-0.24,0.2,-0.02,-0.35,0,-0.6,0.38,0.08));
  } else if (earType === 'batspikes'){
    head.add(bladeSpike(color,0.16,0.28,-0.06,-0.7,0,0.5,0.68,0.13));
    head.add(bladeSpike(color,-0.16,0.28,-0.06,-0.7,0,-0.5,0.68,0.13));
  } else if (earType === 'rabbit'){
    head.add(bladeSpike(color,0.11,0.32,0.02,-0.2,0,0.22,0.78,0.075));
    head.add(bladeSpike(color,-0.11,0.32,0.02,-0.2,0,-0.22,0.78,0.075));
  }
}

function createRunner(color, opts){
  opts = opts || {};
  const runner = new THREE.Group();
  const parts = {};
  const ghost = !!opts.ghost;
  const bodyOpacity = ghost ? 0.48 : 0.9;
  const edgeOpacity = ghost ? 0.65 : 1;

  let head;
  if (opts.boxy){
    head = boxPart(0.56,0.5,0.5,color,bodyOpacity*1.1);
  } else if (opts.tall){
    head = crystalPart(0.32,0.46,0.3,0.05,color,bodyOpacity);
  } else {
    head = crystalPart(0.36,0.4,0.34,0.12,color,bodyOpacity);
  }
  head.position.y = 1.62;
  if (edgeOpacity < 1) head.children[1].material.opacity = edgeOpacity;
  runner.add(head);
  decorateHead(head, color, opts.earType);

  const eyeCount = opts.singleEye ? 1 : 2;
  if (eyeCount === 1){
    const e = eyeShard(0.16); e.position.set(0,1.63,0.22); runner.add(e);
  } else {
    const eL = eyeShard(0.11); eL.position.set(0.13,1.64,0.22); runner.add(eL);
    const eR = eyeShard(0.11); eR.position.set(-0.13,1.64,0.22); runner.add(eR);
  }

  const torso = opts.boxy
    ? boxPart(0.6,0.7,0.42,color,bodyOpacity*1.1)
    : crystalPart(0.3,0.4,0.24,0.07,color,bodyOpacity);
  torso.position.y = 1.05;
  if (edgeOpacity < 1) torso.children[1].material.opacity = edgeOpacity;
  runner.add(torso);

  const armGeomFn = ()=> opts.boxy ? boxPart(0.18,0.6,0.18,color,bodyOpacity) : crystalPart(0.13,0.32,0.13,0.05,color,bodyOpacity);
  const handFn = ()=> opts.boxy ? boxPart(0.24,0.22,0.24,color,bodyOpacity) : crystalPart(0.17,0.15,0.17,0.05,color,bodyOpacity);

  const shoulderL = new THREE.Group(); shoulderL.position.set(0.42,1.35,0);
  const armL = armGeomFn(); armL.position.y=-0.3; shoulderL.add(armL);
  const handL = handFn(); handL.position.y=-0.58; shoulderL.add(handL);
  runner.add(shoulderL);

  const shoulderR = new THREE.Group(); shoulderR.position.set(-0.42,1.35,0);
  const armR = armGeomFn(); armR.position.y=-0.3; shoulderR.add(armR);
  const handR = handFn(); handR.position.y=-0.58; shoulderR.add(handR);
  runner.add(shoulderR);

  const legGeomFn = ()=> opts.boxy ? boxPart(0.22,0.6,0.22,color,bodyOpacity) : crystalPart(0.15,0.32,0.15,0.05,color,bodyOpacity);
  const footFn = ()=> opts.boxy ? boxPart(0.26,0.15,0.44,color,bodyOpacity) : crystalPart(0.2,0.12,0.28,0.05,color,bodyOpacity);

  const hipL = new THREE.Group(); hipL.position.set(0.2,0.68,0);
  const legL = legGeomFn(); legL.position.y=-0.3; hipL.add(legL);
  const footL = footFn(); footL.position.set(0,-0.6,0.12); hipL.add(footL);
  runner.add(hipL);

  const hipR = new THREE.Group(); hipR.position.set(-0.2,0.68,0);
  const legR = legGeomFn(); legR.position.y=-0.3; hipR.add(legR);
  const footR = footFn(); footR.position.set(0,-0.6,0.12); hipR.add(footR);
  runner.add(hipR);

  const burstGlow = glowSprite(color, 3.2); burstGlow.position.y = 1.1; burstGlow.visible = false;
  runner.add(burstGlow);

  const itHalo = makeItHalo();
  runner.add(itHalo);

  (opts.targetScene || scene).add(runner);
  parts.torso=torso; parts.shoulderL=shoulderL; parts.shoulderR=shoulderR;
  parts.hipL=hipL; parts.hipR=hipR; parts.burstGlow=burstGlow; parts.itHalo=itHalo;
  return {mesh:runner, parts};
}

function createTrail(color){
  const TRAIL_LEN = 8;
  const positions = new Float32Array(TRAIL_LEN*3);
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.BufferAttribute(positions,3));
  const mat = new THREE.LineBasicMaterial({color:color, transparent:true, opacity:0.5});
  const line = new THREE.Line(geo, mat);
  line.visible = false;
  scene.add(line);
  return {line, geo, len:TRAIL_LEN, pts:[]};
}

// ---------------------------------------------------------------
// THE SIX RUNNERS
// ---------------------------------------------------------------
function makeState(x,z,heading){
  return {
    x, z, y:0, heading, layer:'ground',
    speed:0,
    maxFwd:9, maxBack:5, accel:26, decel:36, turnRate:2.9,
    burstActive:false, burstTimer:0, burstDuration:1.0,
    burstCooldown:3.0, burstCooldownTimer:0, burstReady:true, burstMult:1.5,
    jumping:false, jumpT:0, jumpFrom:{x:0,z:0}, jumpTo:{x:0,z:0},
    runPhase:0
  };
}

const CHAR_DEFS = [
  {key:'blaze', name:'BLAZE', epithet:'THE SPEEDSTER', tagline:'Fast. Fearless. Always ahead.',
   color:0x39ff6a, opts:{earType:'spikes', singleEye:true}, controlled:true,
   x:0, z:-17, heading:0, side:'left'},

  {key:'nova', name:'NOVA', epithet:'THE TRICKSTER', tagline:'Clever moves. Dirty routes.',
   color:0xffd400, opts:{tall:true}, controlled:false,
   x:13.4, z:13.4, heading:Math.PI*0.75, side:'left'},

  {key:'brick', name:'BRICK', epithet:'THE TANK', tagline:'Bigger lines. Bigger problems.',
   color:0x33bbff, opts:{boxy:true}, controlled:false,
   x:-13.4, z:-13.4, heading:Math.PI*-0.25, side:'left'},

  {key:'rush', name:'RUSH', epithet:'THE HUNTER', tagline:'Relentless. No escape.',
   color:0xff5a1f, opts:{earType:'batspikes', singleEye:true}, controlled:false,
   x:13.4, z:-13.4, heading:Math.PI*1.25, side:'right'},

  {key:'zipp', name:'ZIPP', epithet:'THE WILDCARD', tagline:'Unpredictable. Unforgettable.',
   color:0xff0099, opts:{earType:'rabbit'}, controlled:false,
   x:-13.4, z:13.4, heading:Math.PI*-0.75, side:'right'},

  {key:'echo', name:'ECHO', epithet:'THE PHANTOM', tagline:'Smooth moves. Plays later.',
   color:0xe8f0ff, opts:{tall:true, ghost:true}, controlled:false,
   x:0, z:19, heading:Math.PI, side:'right'}
];

CHAR_DEFS.forEach((d,i)=>d.color=[0xff405d,0x33bbff,0x39ff6a,0xffd400,0xff48cf,0xe8f0ff][i]);
const runners = CHAR_DEFS.map((def)=>{
  const state = makeState(def.x, def.z, def.heading);
  state.aiTarget = {x:def.x, z:def.z}; state.aiTimer = 0;
  const visual = createRunner(def.color, def.opts);
  const trail = createTrail(def.color);
  return {def, state, visual, trail, timeAsIt:0, immuneUntil:-Infinity};
});
runners.forEach((r,i)=>r.def.controlled=i===0);
const player = runners.find(r=>r.def.controlled);

// ---------------------------------------------------------------
// TAG STATE
// ---------------------------------------------------------------
let itIndex = Math.floor(Math.random()*runners.length);
const TAG_RADIUS = 1.5;
const MATCH_DURATION = 180;
let matchTime = MATCH_DURATION;
let matchEnded = false;

function resetMatch(){
  runners.forEach(r=>{
    const fresh = makeState(r.def.x, r.def.z, r.def.heading);
    Object.assign(r.state, fresh);
    r.state.aiTarget = {x:r.def.x, z:r.def.z};
    r.state.aiTimer = 0;
    r.timeAsIt = 0;
    r.immuneUntil = -Infinity;
  });
  itIndex = Math.floor(Math.random()*runners.length);
  matchTime = MATCH_DURATION;
  matchEnded = false;
  const wb = document.getElementById('winBanner');
  if (wb) wb.style.display = 'none';
}

// ---------------------------------------------------------------
// ROSTER HUD
// ---------------------------------------------------------------
function buildRoster(){
  const left = document.getElementById('rosterLeft');
  const right = document.getElementById('rosterRight');
  runners.forEach((r,i)=>{
    const hex = '#'+r.def.color.toString(16).padStart(6,'0');
    const box = document.createElement('div');
    box.className = 'pbox';
    box.id = 'pbox-'+r.def.key;
    box.style.borderTopColor = hex;
    box.style.boxShadow = '0 0 10px '+hex+'33';
    box.innerHTML =
      '<canvas id="icon-'+r.def.key+'" class="picon" width="108" height="108"></canvas>'+
      '<div class="pnum">0'+(i+1)+'</div>'+
      '<div class="pname" style="color:'+hex+';text-shadow:0 0 6px '+hex+'">'+r.def.name+'</div>'+
      '<div class="pepithet" style="color:'+hex+'">'+r.def.epithet+'</div>'+
      '<div class="ptagline">"'+r.def.tagline+'"</div>'+
      '<div class="prow"><span>STATE</span><span id="state-'+r.def.key+'">IDLE</span></div>'+
      '<div class="prow"><span>TAG</span><span id="tag-'+r.def.key+'">SAFE</span></div>'+
      '<div class="prow"><span>IT TIME</span><span id="ittime-'+r.def.key+'">0.0s</span></div>'+
      '<div class="prow"><span>BURST</span><span id="burstlabel-'+r.def.key+'">READY</span></div>'+
      '<div class="pmini"><div class="pminifill" id="burstfill-'+r.def.key+'" style="background:'+hex+';box-shadow:0 0 6px '+hex+'"></div></div>';
    (r.def.side==='left'?left:right).appendChild(box);
  });
}
buildRoster();

// ---------------------------------------------------------------
// ROSTER ICONS
// ---------------------------------------------------------------
const iconPreviews = [];
function buildIcons(){runners.forEach((r,i)=>{const c=document.getElementById('icon-'+r.def.key),g=c.getContext('2d');g.fillStyle='#'+r.def.color.toString(16).padStart(6,'0');g.font='bold 42px Arial';g.fillText('P'+(i+1),2,48);});}buildIcons();
// ---------------------------------------------------------------
// INPUT (BLAZE / player only)
// ---------------------------------------------------------------
const keys = {};
let debugOn = false;
window.addEventListener('keydown', (e)=>{
  const codesUsed = ['ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Numpad8','Numpad2','Numpad4','Numpad6','Numpad5','KeyW','KeyS','KeyA','KeyD','Space'];
  if (codesUsed.includes(e.code)) e.preventDefault();
  keys[e.code] = true;
  if (!e.repeat && (e.code === 'Numpad5' || e.code === 'Space')) action(0,'A');
  if (!e.repeat && e.code==='Enter') action(0,'START');
  if (!e.repeat && e.code==='Escape') pause();
  if (e.code === 'KeyP' || e.code === 'Backquote'){
    debugOn = !debugOn;
    document.getElementById('debugPanel').style.display = debugOn ? 'block' : 'none';
  }
  if (e.code === 'Digit1') buildArena(0);
  if (e.code === 'Digit2') buildArena(1);
  if (e.code === 'Digit3') buildArena(2);
});
window.addEventListener('keyup', (e)=>{ keys[e.code] = false; });

// ---------------------------------------------------------------
// TOUCH CONTROLS — map on-screen buttons to the same `keys` object
// ---------------------------------------------------------------
function updateTouchUI(){
  const show = ('ontouchstart' in window) || navigator.maxTouchPoints>0 || window.innerWidth < 900;
  document.body.classList.toggle('touchable', show);
}
updateTouchUI();
window.addEventListener('resize', updateTouchUI);

const touchMap = {tUp:'Numpad8', tDown:'Numpad2', tLeft:'Numpad4', tRight:'Numpad6'};
Object.keys(touchMap).forEach(id=>{
  const el = document.getElementById(id);
  const code = touchMap[id];
  const press = (e)=>{ e.preventDefault(); keys[code]=true; el.classList.add('pressed'); };
  const release = (e)=>{ e.preventDefault(); keys[code]=false; el.classList.remove('pressed'); };
  el.addEventListener('touchstart', press, {passive:false});
  el.addEventListener('touchend', release, {passive:false});
  el.addEventListener('touchcancel', release, {passive:false});
  el.addEventListener('mousedown', press);
  el.addEventListener('mouseup', release);
  el.addEventListener('mouseleave', release);
});
const tBoostEl = document.getElementById('tBoost');
const boostPress = (e)=>{
  e.preventDefault();
  tryBurst(player.state);
  tBoostEl.classList.add('pressed');
  setTimeout(()=>tBoostEl.classList.remove('pressed'), 150);
};
tBoostEl.addEventListener('touchstart', boostPress, {passive:false});
tBoostEl.addEventListener('mousedown', boostPress);

function tryBurst(state){
  if(session.phase!=='play' || session.paused) return;
  if (state.burstReady && !state.burstActive){
    state.burstActive = true; state.burstTimer = state.burstDuration;
    state.burstReady = false; state.burstCooldownTimer = state.burstCooldown;
  }
}

// ---------------------------------------------------------------
// COLLISION HELPERS
// ---------------------------------------------------------------
function resolvePillarCollision(x,z){
  for (const c of collidables){
    const dx = x-c.x, dz = z-c.z;
    const dist = Math.sqrt(dx*dx+dz*dz);
    const minDist = c.r + PLAYER_R*0.7;
    if (dist < minDist && dist > 0.0001){
      const push = (minDist-dist);
      x += (dx/dist)*push; z += (dz/dist)*push;
    }
  }
  return {x,z};
}

function triggerJumpIfOnPad(state){
  if (state.jumping || state.y>1.25) return;
  for (const pad of padMeshes){
    const dx = state.x-pad.x, dz = state.z-pad.z;
    if (dx*dx+dz*dz < (PAD_R+PLAYER_R*0.6)*(PAD_R+PLAYER_R*0.6) && Math.abs(state.speed) > 0.6){
      const dir = {x:Math.sin(state.heading), z:Math.cos(state.heading)};
      let target = {x: state.x + dir.x*JUMP_DIST, z: state.z + dir.z*JUMP_DIST};
      target = clampToArena(target.x, target.z);
      state.jumping = true; state.jumpT = 0;
      state.jumpFrom = {x:state.x, z:state.z}; state.jumpTo = target;
      return;
    }
  }
}

// ---------------------------------------------------------------
// SHARED STEP FUNCTION
// ---------------------------------------------------------------
function stepRunner(state, input, dt){
  if (state.burstActive){
    state.burstTimer -= dt;
    if (state.burstTimer <= 0) state.burstActive = false;
  }
  if (!state.burstReady){
    state.burstCooldownTimer -= dt;
    if (state.burstCooldownTimer <= 0){ state.burstReady = true; state.burstCooldownTimer = 0; }
  }

  if (state.jumping){
    state.jumpT += dt/JUMP_DUR;
    const tt = Math.min(state.jumpT,1);
    state.x = THREE.MathUtils.lerp(state.jumpFrom.x, state.jumpTo.x, tt);
    state.z = THREE.MathUtils.lerp(state.jumpFrom.z, state.jumpTo.z, tt);
    const arc = Math.sin(tt*Math.PI)*JUMP_ARC;
    state.y = arenaHeightOf(state.layer) + arc;
    if (tt>=1) state.jumping = false;
  } else {
    if(input.direct){
      const len=Math.hypot(input.dx,input.dz);
      if(len){state.heading=Math.atan2(input.dx/len,input.dz/len);state.speed=state.maxFwd*(state.burstActive?state.burstMult:1);}
      else state.speed=0;
    }else{
    const desired = input.fwd - input.back;
    const maxSpeed = (desired>=0?state.maxFwd:state.maxBack) * (state.burstActive?state.burstMult:1);
    const targetSpeed = desired*maxSpeed;
    const rate = (Math.abs(targetSpeed) > Math.abs(state.speed)) ? state.accel : state.decel;
    if (state.speed < targetSpeed) state.speed = Math.min(state.speed+rate*dt, targetSpeed);
    else if (state.speed > targetSpeed) state.speed = Math.max(state.speed-rate*dt, targetSpeed);

    const turn = (input.right - input.left);
    state.heading += turn*state.turnRate*dt;

    }
    const dirX = Math.sin(state.heading), dirZ = Math.cos(state.heading);
    let nx = state.x + dirX*state.speed*dt;
    let nz = state.z + dirZ*state.speed*dt;
    const portal = applyGatePortal(nx, nz);
    if (portal.teleported){
      nx = portal.x; nz = portal.z;
    } else {
      const clamped = clampToArena(nx, nz);
      nx = clamped.x; nz = clamped.z;
    }

    const resolved = resolvePillarCollision(nx,nz);
    const layered = applyLayerGeneric(state, resolved.x, resolved.z);
    state.x = layered.x; state.z = layered.z;
    state.y += (layered.yTarget - state.y) * Math.min(1, dt*10);

    triggerJumpIfOnPad(state);
    state.runPhase += dt * (2 + Math.abs(state.speed)*0.9);
  }
}

function applyVisuals(state, rv, trail, t){
  rv.mesh.position.set(state.x, state.y, state.z);
  rv.mesh.rotation.y = state.heading;
  const {parts} = rv;
  const movingFast = !state.jumping && Math.abs(state.speed) > 0.4;
  if (movingFast){
    const swing = Math.sin(state.runPhase)*0.7*Math.min(1, Math.abs(state.speed)/state.maxFwd+0.3);
    parts.hipL.rotation.x = swing; parts.hipR.rotation.x = -swing;
    parts.shoulderL.rotation.x = -swing*0.8; parts.shoulderR.rotation.x = swing*0.8;
    parts.torso.position.y = 1.05 + Math.abs(Math.sin(state.runPhase*2))*0.03;
  } else {
    const idle = Math.sin(t*2.2)*0.04;
    parts.hipL.rotation.x = idle*0.3; parts.hipR.rotation.x = -idle*0.3;
    parts.shoulderL.rotation.x = idle*0.5; parts.shoulderR.rotation.x = -idle*0.5;
    parts.torso.position.y = 1.05 + idle*0.4;
  }
  parts.burstGlow.visible = state.burstActive;
  if (state.burstActive){
    trail.pts.push(new THREE.Vector3(state.x, state.y+1, state.z));
    if (trail.pts.length > trail.len) trail.pts.shift();
    const arr = trail.geo.attributes.position.array;
    for (let i=0;i<trail.len;i++){
      const p = trail.pts[i] || trail.pts[0];
      if (p){ arr[i*3]=p.x; arr[i*3+1]=p.y; arr[i*3+2]=p.z; }
    }
    trail.geo.attributes.position.needsUpdate = true;
    trail.line.visible = trail.pts.length>1;
  } else {
    trail.pts = []; trail.line.visible = false;
  }
}

// ---------------------------------------------------------------
// BOT AI
// ---------------------------------------------------------------
function botThink(r, dt, t){
  const state = r.state;
  const isIT = (runners[itIndex] === r);

  if (isIT){
    let nearest=null, nd=Infinity;
    runners.forEach(o=>{
      if (o===r) return;
      if (t < o.immuneUntil) return;
      const dx=o.state.x-state.x, dz=o.state.z-state.z;
      const d=dx*dx+dz*dz;
      if (d<nd){ nd=d; nearest=o; }
    });
    if (nearest) state.aiTarget = {x:nearest.state.x, z:nearest.state.z};
  } else {
    const itR = runners[itIndex];
    const dx = state.x-itR.state.x, dz = state.z-itR.state.z;
    const dist = Math.sqrt(dx*dx+dz*dz) || 0.001;
    if (dist < 9){
      const fx = state.x + (dx/dist)*10;
      const fz = state.z + (dz/dist)*10;
      const c = clampToArena(fx,fz);
      state.aiTarget = {x:c.x, z:c.z};
      state.aiTimer = 0.4;
    } else {
      state.aiTimer -= dt;
      const dx0 = state.aiTarget.x-state.x, dz0 = state.aiTarget.z-state.z;
      const distToTarget = Math.sqrt(dx0*dx0+dz0*dz0);
      if (state.aiTimer <= 0 || distToTarget < 2.5){
        let tx, tz;
        do {
          tx = THREE.MathUtils.randFloat(-B+3, B-3);
          tz = THREE.MathUtils.randFloat(-B+3, B-3);
        } while (Math.abs(tx)+Math.abs(tz) > ARENA_DIAG_LIMIT-3);
        state.aiTarget = {x:tx, z:tz};
        state.aiTimer = THREE.MathUtils.randFloat(3, 6);
      }
    }
  }

  const dx = state.aiTarget.x-state.x, dz = state.aiTarget.z-state.z;
  const desiredHeading = Math.atan2(dx, dz);
  let diff = desiredHeading - state.heading;
  while (diff > Math.PI) diff -= Math.PI*2;
  while (diff < -Math.PI) diff += Math.PI*2;
  const input = {fwd:1, back:0, left:0, right:0};
  if (diff > 0.06) input.right = 1;
  else if (diff < -0.06) input.left = 1;
  if (Math.random() < dt*(isIT?0.35:0.12)) tryBurst(state);
  return input;
}

// ---------------------------------------------------------------
// WIN BANNER
// ---------------------------------------------------------------
function canTag(a,b){return Math.abs(a.y-b.y)<=1.25 && Math.hypot(a.x-b.x,a.z-b.z)<TAG_RADIUS;}
function endMatch(){
  session.phase="results";session.epoch++;window.VECTOR?.clear();
  matchEnded = true;
  const ranked = runners.slice().sort((a,b)=>a.timeAsIt-b.timeAsIt);
  const rankList = document.getElementById('rankList');
  rankList.innerHTML = ranked.map((r,i)=>{
    const hex = '#'+r.def.color.toString(16).padStart(6,'0');
    const label = i===0 ? '🏆 WINNER — ' : (i+1)+'. ';
    return '<div class="rankRow" style="color:'+hex+'">'+label+r.def.name+' — '+r.timeAsIt.toFixed(1)+'s as IT</div>';
  }).join('');
  document.getElementById('winBanner').style.display = 'flex';
}

// ---------------------------------------------------------------
// MAIN LOOP
// ---------------------------------------------------------------
const clock = new THREE.Clock();
let fpsSmooth = 60;

function update(){
  const dt = Math.min(clock.getDelta(), 0.05);
  if(session.phase==='play'&&!session.paused)session.elapsed+=dt;
  const t=session.elapsed;
  fpsSmooth += ((1/Math.max(dt,0.0001)) - fpsSmooth)*0.08;

  gatePortals.forEach((mat,i)=>{ mat.opacity = 0.25 + 0.25*Math.sin(t*3 + i*Math.PI); });

  for (let i=portalFlashes.length-1; i>=0; i--){
    const f = portalFlashes[i];
    f.age += dt;
    const p = Math.min(f.age/f.dur, 1);
    f.spr.scale.setScalar(1.2 + p*4.5);
    f.spr.material.opacity = 1 - p;
    if (p >= 1){
      scene.remove(f.spr);
      f.spr.material.map.dispose();
      f.spr.material.dispose();
      portalFlashes.splice(i,1);
    }
  }

  runners.forEach(r=>{
    let input;
    if (matchEnded || session.phase!=='play' || session.paused){
      input = {fwd:0, back:0, left:0, right:0};
    } else if (session.seats[runners.indexOf(r)]==='human'){
      const i=runners.indexOf(r),m=window.VECTOR?.mask(i)||0;
      let dx=(m&8?1:0)-(m&4?1:0),dz=(m&2?1:0)-(m&1?1:0);
      if(i===0){dx+=(keys.KeyD||keys.Numpad6||keys.ArrowRight?1:0)-(keys.KeyA||keys.Numpad4||keys.ArrowLeft?1:0);dz+=(keys.KeyS||keys.Numpad2||keys.ArrowDown?1:0)-(keys.KeyW||keys.Numpad8||keys.ArrowUp?1:0);}
      input={direct:true,dx:Math.sign(dx),dz:Math.sign(dz)};
    } else {
      input = botThink(r, dt, t);
    }
    if(session.phase==='play' && !session.paused) stepRunner(r.state, input, dt);
    else r.state.speed=0;
    applyVisuals(r.state, r.visual, r.trail, t);
  });

  if (!matchEnded && session.phase==='play' && !session.paused){
    matchTime -= dt;
    const itR = runners[itIndex];
    itR.timeAsIt += dt;

    for (let i=0;i<runners.length;i++){
      if (i===itIndex) continue;
      if (t < runners[i].immuneUntil) continue;
      if(canTag(itR.state,runners[i].state)){
        runners[itIndex].immuneUntil = t + 3;
        itIndex = i; session.tags++; beep(220, .12);
        break;
      }
    }

    if (matchTime <= 0){ matchTime = 0; endMatch(); }
  }

  runners.forEach((r,i)=>{
    const isIT = (i===itIndex);
    r.visual.parts.itHalo.visible = isIT;
    if (isIT) r.visual.parts.itHalo.userData.ringMat.opacity = 0.6+0.4*Math.sin(t*6);

    const stateEl = document.getElementById('state-'+r.def.key);
    if (stateEl) stateEl.textContent = session.seats[i].toUpperCase();

    const tagEl = document.getElementById('tag-'+r.def.key);
    if (tagEl){
      if (isIT){ tagEl.textContent='IT'; tagEl.style.color='#ff3333'; }
      else if (t < r.immuneUntil){ tagEl.textContent='IMMUNE'; tagEl.style.color='#28d9ff'; }
      else { tagEl.textContent='SAFE'; tagEl.style.color=''; }
    }
    const ittimeEl = document.getElementById('ittime-'+r.def.key);
    if (ittimeEl) ittimeEl.textContent = r.timeAsIt.toFixed(1)+'s';

    const burstLabelEl = document.getElementById('burstlabel-'+r.def.key);
    const burstFillEl = document.getElementById('burstfill-'+r.def.key);
    if (burstLabelEl) burstLabelEl.textContent = r.state.burstActive ? 'ACTIVE' : (r.state.burstReady ? 'READY' : 'RECHG');
    if (burstFillEl){
      const pct = r.state.burstReady?100:Math.max(0,100*(1-r.state.burstCooldownTimer/r.state.burstCooldown));
      burstFillEl.style.width = pct+'%';
    }

    const box = document.getElementById('pbox-'+r.def.key);
    if (box) box.classList.toggle('isIT', isIT);
  });

  const itName = runners[itIndex].def.name;
  const itHex = '#'+runners[itIndex].def.color.toString(16).padStart(6,'0');
  const itAlertEl = document.getElementById('itAlert');
  if(false){
    itAlertEl.textContent = 'YOU ARE IT — TAG SOMEONE!';
    itAlertEl.style.color = '#ff3333';
    itAlertEl.style.textShadow = '0 0 8px #ff3333';
  } else {
    itAlertEl.textContent = itName.toUpperCase() + ' IS IT — RUN!';
    itAlertEl.style.color = itHex;
    itAlertEl.style.textShadow = '0 0 8px '+itHex;
  }

  const mm = Math.floor(matchTime/60), ss = Math.floor(matchTime%60);
  document.getElementById('matchTimer').textContent = session.phase==='join'?'READY?':session.paused?'PAUSED':mm+':'+(ss<10?'0':'')+ss;

  document.getElementById('burstLabel').textContent = player.state.burstActive?'ACTIVE':(player.state.burstReady?'READY':'RECHARGING');
  const pct = player.state.burstReady?100:Math.max(0,100*(1-player.state.burstCooldownTimer/player.state.burstCooldown));
  document.getElementById('burstBarInner').style.width = pct+'%';

  if (debugOn){
    document.getElementById('dbgFps').textContent = 'FPS: '+fpsSmooth.toFixed(0);
    document.getElementById('dbgSpeed').textContent = 'SPEED: '+player.state.speed.toFixed(2);
    document.getElementById('dbgPos').textContent = 'POS: '+player.state.x.toFixed(1)+', '+player.state.z.toFixed(1);
    document.getElementById('dbgLayer').textContent = 'LAYER: '+player.state.layer.toUpperCase();
  }

  renderer.render(scene, camera);

  iconPreviews.forEach(p=>{
    p.mesh.rotation.y += dt*0.4;
    const idle = Math.sin(t*2.2)*0.05;
    p.parts.hipL.rotation.x = idle*0.3; p.parts.hipR.rotation.x = -idle*0.3;
    p.parts.shoulderL.rotation.x = idle*0.5; p.parts.shoulderR.rotation.x = -idle*0.5;
    p.renderer.render(p.scene, p.camera);
  });

  requestAnimationFrame(update);
}


const session={phase:'join',paused:false,epoch:0,tags:0,elapsed:0,seats:['human','cpu','cpu','cpu','cpu','cpu'],sound:true};
let audio;
function beep(freq=440,len=.08){if(!session.sound)return;try{audio ||= new (window.AudioContext||window.webkitAudioContext)();if(audio.state==='suspended')audio.resume();const o=audio.createOscillator(),g=audio.createGain();o.frequency.value=freq;g.gain.setValueAtTime(.035,audio.currentTime);g.gain.exponentialRampToValueAtTime(.001,audio.currentTime+len);o.connect(g).connect(audio.destination);o.start();o.stop(audio.currentTime+len);}catch{}}
function clearKeys(){for(const k in keys)keys[k]=false;window.VECTOR?.clear();}
function seats(){document.querySelector('#seats').innerHTML=runners.map((r,i)=>'<button style="--seat:#'+r.def.color.toString(16).padStart(6,'0')+'" data-seat="'+i+'"><b>P'+(i+1)+' / '+r.def.name.toUpperCase()+'</b><span>'+session.seats[i].toUpperCase()+'</span></button>').join('');document.querySelectorAll('[data-seat]').forEach(el=>el.onclick=()=>{const i=+el.dataset.seat;session.seats[i]=session.seats[i]==='human'?'cpu':'human';seats();});}
function lobby(){session.phase='join';session.paused=false;session.epoch++;clearKeys();document.querySelector('#winBanner').style.display='none';document.querySelector('#lobby').hidden=false;seats();}
function launch(){if(session.phase!=='join')return;resetMatch();session.phase='play';session.paused=false;session.tags=0;session.elapsed=0;session.epoch++;clearKeys();document.querySelector('#lobby').hidden=true;beep(620,.2);}
function pause(){if(session.phase!=='play')return;session.paused=!session.paused;clearKeys();session.epoch++;}
function action(i,key){if(i<0||i>5)return;if(session.phase==='join'){if(key==='A'||key==='START'){session.seats[i]='human';seats();beep();}if(key==='B')launch();return;}if(session.phase==='results'){if(key==='START'||key==='A')lobby();return;}session.seats[i]='human';if(key==='START'){pause();return;}if(!session.paused&&(key==='A'||key==='R1')){const ready=runners[i].state.burstReady;tryBurst(runners[i].state);if(ready)beep(780);}}
const miniCamera=new THREE.PerspectiveCamera(52,1.9,.1,160);
function renderPersonal(g,i,wide=false){const r=runners[i],s=r.state;const w=renderer.domElement.width,h=renderer.domElement.height;const vw=Math.min(w,664),vh=Math.min(h,350);renderer.setViewport(0,0,vw,vh);renderer.setScissor(0,0,vw,vh);renderer.setScissorTest(true);miniCamera.position.set(s.x,s.y+(wide?28:13),s.z+(wide?24:12));miniCamera.lookAt(s.x,s.y+1,s.z);renderer.render(scene,miniCamera);g.drawImage(renderer.domElement,0,h-vh,vw,vh,28,112,664,350);renderer.setScissorTest(false);renderer.setViewport(0,0,w,h);renderer.render(scene,camera);}

window.VT={session,runners,action,launch,lobby,pause,seats,renderPersonal,buildArena,tryBurst,stepRunner,get time(){return matchTime;},get it(){return itIndex;},get arena(){return activeArenaIndex;},get clock(){return session.elapsed;},endMatch,canTag,applyGatePortal,triggerJumpIfOnPad,get renderer(){return renderer;},get scene(){return scene;},get camera(){return camera;}};
addEventListener('blur',clearKeys);document.addEventListener('visibilitychange',()=>{clearKeys();if(document.hidden&&session.phase==='play'&&!session.paused)pause();});
buildArena(0);
document.getElementById('aBtn0').addEventListener('click', ()=>buildArena(0));
document.getElementById('aBtn1').addEventListener('click', ()=>buildArena(1));
document.getElementById('aBtn2').addEventListener('click', ()=>buildArena(2));
seats();
update();

})();
