@echo off
setlocal EnableExtensions DisableDelayedExpansion
title Arcadium Vector Tag Setup
cd /d "%~dp0"
if not exist "INSTALL_VECTOR_TAG.py" goto incomplete
if not exist "CHECKSUMS.json" goto incomplete
if not exist "games\vector-tag-prototype\index.html" goto incomplete

rem Use the normal command-line Python. Do not enumerate installation directories or probe each discovered program.
set "ARCADIUM_INSTALL_PYTHON="
for /f "delims=" %%P in ('where python.exe 2^>nul') do if not defined ARCADIUM_INSTALL_PYTHON if /i not "%%P"=="%LOCALAPPDATA%\Microsoft\WindowsApps\python.exe" set "ARCADIUM_INSTALL_PYTHON=%%P"
if not defined ARCADIUM_INSTALL_PYTHON goto launcher
"%ARCADIUM_INSTALL_PYTHON%" -c "import sys, tkinter; assert sys.version_info >= (3,9)" >nul 2>&1
if errorlevel 1 goto launcher
"%ARCADIUM_INSTALL_PYTHON%" "%~dp0INSTALL_VECTOR_TAG.py"
goto result

:launcher
where py.exe >nul 2>&1
if errorlevel 1 goto no_python
py -3 -c "import sys, tkinter; assert sys.version_info >= (3,9)" >nul 2>&1
if errorlevel 1 goto no_python
py -3 "%~dp0INSTALL_VECTOR_TAG.py"

:result
if errorlevel 1 goto failed
exit /b 0

:incomplete
echo Extract the WHOLE ZIP first. Keep the games folder and checksums beside this launcher.
pause
exit /b 1

:no_python
echo Python 3.9 or newer with Tkinter is required. This setup downloads no software.
echo Use the Python installation that runs your Arcadium OS, then retry this launcher.
pause
exit /b 1

:failed
echo The installer stopped. Keep this window open and read the message above.
pause
exit /b 1
