# Arcadium Vector Tag V1

Extract the complete ZIP. Double-click START_INSTALL.cmd, select your existing Arcadium_OS_COMPACT folder, wait for the installed message, and restart Windows once. Launch Vector Tag from the carousel. Python 3.9+ with Tkinter is required (the same installation used by Arcadium). No dependencies are downloaded during installation.

No APK. Uses your installed shared Mini Vibe controller app and normal OS pairing on port 8787. No new listener, receiver replacement, firewall edits or security exclusions.

## Play

Six players, three arenas: Grid, Bowl and Tower. A / START joins your color in the lobby. Empty seats begin as clearly labeled CPUs; tap a seat on the PC to change CPU/human. Any player presses B in the lobby, or click LAUNCH MATCH on PC. Choose the arena before launching. Three-minute rounds: contact passes IT; least time spent IT wins. The previous IT receives three seconds of immunity. Tagging respects vertical separation. Echo is a translucent runner, not an eliminated player.

Hold D-pad to run directly in that direction. Release stops movement immediately on the ground. Momentum continues while a jump pad carries you through the air. A or R1 activates a one-second burst, recharged after three seconds. Yellow pads launch you; pink gates teleport you. Ramps connect the arena levels. B switches your personal camera between close and wide. START pauses/resumes. PC: WASD/arrows/numpad 8/2/4/6, Space burst, Enter join/pause, Escape pause. Results return to the lobby with A/START. No forced auto-start or arena reset during play.

Each Mini Vibe has a live 3D camera, IT/safe/immunity status, timer, level, time as IT, burst meter, and touch controls. The PC simulates one shared world and uses one WebGL renderer for every view. No Internet is required to play. Sound can be toggled on PC.

## Preservation and rollback

Only this game's files, its route helper, its catalogue entry and a guarded additive bridge wrapper are written. All other game code, cards, OS startup, shared input and pairing remain untouched. Existing target game metadata is preserved where appropriate. Checksums validate extraction. Backups are under arcadium_backups/vector_tag_v1_*. Rollback is available in the installer and refuses to overwrite later edits.

## Verification limits

Automated receiver/browser and install/rollback checks are documented in VALIDATION.md. Real six-device Mini Vibe / Wi-Fi acceptance remains a physical test. If Windows blocks a download, leave it blocked; do not disable protection or add exclusions.
