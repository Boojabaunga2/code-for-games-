from pathlib import Path
import json,tkinter as tk
from tkinter import filedialog
from update_vector_tag import install,rollback
ui=tk.Tk();ui.title('Arcadium / Vector Tag');ui.geometry('750x430');status=tk.StringVar(value='Vector Tag: six runners, three arenas, jump pads, portals and live personal cameras. Existing shared controller app. No new APK. Select Arcadium_OS_COMPACT.')
tk.Label(ui,text='VECTOR TAG / SIX RUNNERS. ONE TARGET.',font=('Segoe UI',15,'bold')).pack(pady=20);tk.Label(ui,textvariable=status,wraplength=700,justify='left',font=('Segoe UI',12)).pack(padx=20,pady=20)
def run():
 folder=filedialog.askdirectory(title='Select your existing Arcadium_OS_COMPACT folder')
 if not folder:return
 try:
  backup=install(Path(folder));Path(__file__).with_name('VECTOR_TAG_RECEIPT.json').write_text(json.dumps({'backup':str(backup)},indent=2));status.set('Installed. Backup: '+str(backup)+'\n\nRestart Windows once, then launch Vector Tag. Press A or START on each Mini Vibe to join. CPU seats are labeled in the lobby. Hold D-pad to run; release to stop. A or R1 bursts. B changes your personal camera. Least time as IT wins. No APK or separate relay.\n\nReal Mini Vibe / LAN acceptance still needed.')
 except Exception as e:status.set('Stopped: '+str(e))
def undo():
 folder=filedialog.askdirectory(title='Select the vector_tag_v1_* backup')
 if not folder:return
 try:rollback(Path(folder));status.set('Previous Vector Tag restored. Restart Windows once.')
 except Exception as e:status.set('Rollback stopped: '+str(e))
tk.Button(ui,text='INSTALL VECTOR TAG',command=run,padx=20,pady=12).pack(pady=8);tk.Button(ui,text='Rollback this update',command=undo).pack();ui.mainloop()
