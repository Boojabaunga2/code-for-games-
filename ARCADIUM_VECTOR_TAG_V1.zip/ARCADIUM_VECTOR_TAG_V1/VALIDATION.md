# Validation

Run python integrations/vector-tag/build_package.py, then python -m unittest discover -s integrations/vector-tag/tests -p test_vector_tag.py. Tests cover exact ZIP installation, repeat installation, rollback, corruption and later-edit refusal, other game preservation, same shared native reader, six personal routes, frame expiry, scoped tokens, replay/epoch rejection and lease handoff.

Browser tests in tests/browser.cjs exercise the actual WebGL game against the exact shared native receiver, with six color seats, held movement/release/expiry, burst, pause/resume, all three arenas, jumps/portals, tags across height differences, results/replay and personal frame routes. Synthetic packets are test fixtures, not physical-controller evidence.

Windows launcher and enabled Microsoft Defender/Internet attachment scans are checked separately in CI before delivery. A successful scan is not a guarantee or a manual Microsoft review. Physical Mini Vibes and recipient Windows acceptance are not available in this environment.
