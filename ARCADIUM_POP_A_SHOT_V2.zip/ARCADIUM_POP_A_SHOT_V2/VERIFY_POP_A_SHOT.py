"""Read-only HTTP verification against the running 8787 process."""
import json,urllib.request
BASE='http://127.0.0.1:8787'
def get(path):
 with urllib.request.urlopen(BASE+path,timeout=5) as r:return r.status,r.read()
def main():
 for path in ['/games/pop-a-shot/index.html','/games/pop-a-shot/engine.mjs','/games/pop-a-shot/render.mjs','/games/pop-a-shot/vibe.html','/games/pop-a-shot/card.png','/games/pop-a-shot/cast.png','/games/pop-a-shot/logo.png','/games/pop-a-shot/hoop.png','/api/vibe/native-events?after=0']:
  status,data=get(path);print(status,path,len(data),'bytes')
 status,data=get('/arcadium-live/pop-a-shot/status');state=json.loads(data);assert state['protocol']==1;print('Shared live host:',state)
 if state.get('active'):
  for color in ['red','blue','green','yellow','pink','white']:
   _,data=get('/api/vibe/mode?color='+color);mode=json.loads(data);assert mode['game']=='pop-a-shot' and mode['mode']=='web-game';print(color,'->',mode['page'])
 else:print('Open Pop-A-Shot Showdown from the Games catalogue, then rerun to check six-seat handoff.')
 print('HTTP routes passed. This does not verify physical Mini Vibe controls, Windows graphics, or antivirus acceptance.')
if __name__=='__main__':
 try:main()
 except Exception as e:print('VERIFICATION FAILED:',e)
 input('Press Enter to close...')
