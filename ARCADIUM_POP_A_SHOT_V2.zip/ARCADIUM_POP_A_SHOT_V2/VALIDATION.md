# Validation and acceptance boundaries

## Automated checks

- Ten engine tests cover six simultaneous hoops, delayed two-point scoring, timing/aim misses, cadence without quotas, buzzer grace, deterministic tie ranking, seat-authorized challenge decisions, exact one-time +10 carryover, all listed hand outcomes/redraws, survival, pause, eliminated-seat rejection, a complete five-elimination CPU match, and free practice with score reset.
- Installer tests exercise preservation of server/bridge/Home/pairing/unrelated games, repeat installs, Unicode metadata, append-only persistent host registration, unknown-constructor refusal, backup, selective restore with later unrelated edits, refusal to overwrite later game edits, and the exact extracted ZIP launching an original-server fixture through both normal OS startup and the included launcher. All six mode/native routes are checked after normal startup.
- Broker tests check all six scoped personal state/frame routes, tokens, sequence replay, stale phase rejection, owner leases and existing-game passthrough.
- Browser test uses six real personal pages plus authenticated native packets, simultaneous shots, held/released/expired input, touch, reconnect, pause, challenge roles, ten-point carryover, accelerated actual-engine completion, 720p layout and other-game activation. V2 also checks blocked start/demo on 404 and practice scoring before match reset.

Challenge branch test arranges the round-end fixture and hand RNG explicitly. The remainder of the match is accelerated through the real engine. These are QA fixtures, not evidence of a physical full-match play session. Review screenshots are excluded from the shipped ZIP.

## Windows delivery

The CI workflow checks Linux and Windows using the exact tracked release ZIP/checksum and tests its extracted launcher. Windows Defender is scanned when its service is available; the log distinguishes unavailable scanning from an actual completed scan. No protection settings are modified. Refer to the final delivery/CI evidence for the result; recipient PC acceptance remains unverified.

## Physical acceptance still required

On the user's existing PC installation: verify catalogue card/PLAY, all six Mini Vibe screens, actual A/B/START and D-pad behavior, simultaneous shooting latency, focus/exit and another-game handoff. Confirm on that machine that existing Home, pairing and other games are preserved. Physical hoops, physical dice, haptics, Home Vibe Android and phone-browser controllers are not added to this main-OS game.
