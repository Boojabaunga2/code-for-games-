"""Data-only live-game broker on the existing Arcadium server and shared input.

No listener, source patch, script discovery/execution or controller replacement.
Only registered game JSON descriptors are read from the existing games directory.
"""
import base64
import binascii
import importlib
import hashlib
import ipaddress
import json
import mimetypes
from pathlib import Path
import re
import secrets
import threading
import time
from urllib.parse import parse_qs, unquote, urlsplit

COLORS=('red','blue','green','yellow','pink','white')
LOCK=threading.RLock()
LIVE={'owner':None,'game':None,'frames':{},'state':{},'state_at':0,'sessions':{},'events':[],'seq':0}

def wrap_live_handler(Parent,games_root):
    root=Path(games_root).resolve()
    def descriptor(slug):
        if not re.fullmatch(r'[a-z0-9][a-z0-9-]{0,59}',slug):return None
        folder=(root/slug).resolve()
        if not folder.is_relative_to(root):return None
        try:
            data=json.loads((folder/'arcadium-live.json').read_text(encoding='utf-8'))
            return data if data.get('protocol')==1 and data.get('id')==slug else None
        except (OSError,ValueError,TypeError,AttributeError):return None
    class LiveGameHandler(Parent):
        def _live_shared(self):
            mod=importlib.import_module('arcadium_game_bridge')
            return mod.ACTIVE_WEB_GAME,mod.ACTIVE_LOCK
        def _live_active(self,slug):
            state,lock=self._live_shared()
            with lock:return state.get('game')==slug and time.time()<state.get('until',0)
        def _live_host(self):
            try:
                peer=ipaddress.ip_address(self.client_address[0]);local=ipaddress.ip_address(self.connection.getsockname()[0])
                peer=getattr(peer,'ipv4_mapped',None) or peer;local=getattr(local,'ipv4_mapped',None) or local
                return peer.is_loopback or peer==local
            except (ValueError,OSError,AttributeError):return False
        def _live_send(self,obj,status=200,mime='application/json'):
            data=obj if isinstance(obj,bytes) else json.dumps(obj,separators=(',',':')).encode()
            self.send_response(status);self.send_header('Content-Type',mime);self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
        def _live_body(self,limit):
            n=int(self.headers.get('Content-Length','0'))
            if not 0<n<=limit:raise ValueError('size')
            data=json.loads(self.rfile.read(n))
            if not isinstance(data,dict):raise ValueError('object')
            return data
        def _live_path(self):
            parts=urlsplit(self.path).path.strip('/').split('/')
            if len(parts)>=3 and parts[0]=='arcadium-live' and descriptor(parts[1]):return parts[1],'/'.join(parts[2:])
            return None,None
        def do_POST(self):
            path=urlsplit(self.path).path
            if path.startswith('/arcadium-vibe/activate/'):
                slug=path.rsplit('/',1)[-1]
                if not descriptor(slug):return super().do_POST()
                if not self._live_host():return self.send_error(403)
                try:
                    data=self._live_body(1024);owner=data.get('owner');enabled=data.get('active',True);renew=data.get('renew',False)
                    if not isinstance(owner,str) or not 1<=len(owner)<=100 or type(enabled) is not bool or type(renew) is not bool:raise ValueError()
                    state,lock=self._live_shared()
                    with lock,LOCK:
                        if enabled and renew and (state.get('game')!=slug or LIVE['owner']!=owner):return self.send_error(409)
                        if enabled:
                            if LIVE['owner']!=owner or LIVE['game']!=slug or state.get('game')!=slug or time.time()>=state.get('until',0):
                                LIVE.update(owner=owner,game=slug,frames={},state={},state_at=0,sessions={},events=[])
                            state.update(game=slug,until=time.time()+7)
                        elif state.get('game')==slug and LIVE['owner']==owner:
                            state.update(game=None,until=0);LIVE.update(frames={},state={},state_at=0,sessions={},events=[])
                    return self._live_send({'ok':True})
                except (ValueError,TypeError,UnicodeError):return self.send_error(400)
            slug,route=self._live_path()
            if not slug:return super().do_POST()
            if not self._live_active(slug):return self.send_error(409)
            try:
                if route=='frame':
                    if not self._live_host():return self.send_error(403)
                    data=self._live_body(300000)
                    if data.get('owner')!=LIVE['owner']:return self.send_error(409)
                    seat=data.get('seat');state=data.get('state');image=base64.b64decode(data.get('image',''),validate=True)
                    if type(seat) is not int or not 1<=seat<=6 or not image.startswith(b'\xff\xd8') or len(image)>200000:raise ValueError()
                    if not isinstance(state,dict) or state.get('phase') not in ('lobby','countdown','play','results','finished') or type(state.get('paused')) is not bool or not isinstance(state.get('turnId'),str) or len(state['turnId'])>100:raise ValueError()
                    boards=state.get('dashboards')
                    if not isinstance(boards,list) or len(boards)!=6 or any(not isinstance(v,dict) or len(json.dumps(v))>2048 for v in boards):raise ValueError()
                    shared,shared_lock=self._live_shared()
                    with shared_lock,LOCK:
                        if shared.get('game')!=slug or data.get('owner')!=LIVE['owner'] or time.time()>=shared.get('until',0):return self.send_error(409)
                        LIVE['frames'][seat]=(time.monotonic(),image);LIVE['state']={k:state[k] for k in ('phase','paused','turnId','dashboards')};LIVE['state_at']=time.monotonic()
                    return self._live_send({'ok':True})
                if route!='touch/key':return self.send_error(404)
                data=self._live_body(1024);token=data.get('token');n=data.get('seq');key=data.get('key')
                if type(n) is not int or not 1<=n<=0x7fffffff or not isinstance(key,str) or not (key in ('A','B','X','Y','START','SELECT','L1','R1') or key in descriptor(slug).get('keys',[]) or re.fullmatch(r'M[0-9a-fA-F]{3}',key)):raise ValueError()
                with LOCK:
                    session=LIVE['sessions'].get(token) if isinstance(token,str) else None
                    if not session or session['ip']!=self.client_address[0] or session['owner']!=LIVE['owner'] or time.monotonic()-session['at']>7200:return self.send_error(403)
                    if n<=session['last']:return self._live_send({'ok':True,'duplicate':True})
                    if time.monotonic()-LIVE['state_at']>2.5 or data.get('turnId')!=LIVE['state'].get('turnId'):return self.send_error(409)
                    session['last']=n;LIVE['seq']+=1;LIVE['events'].append({'seq':LIVE['seq'],'color':session['color'],'key':key,'turnId':data['turnId'],'at':round(time.time()*1000)});LIVE['events']=LIVE['events'][-300:]
                return self._live_send({'ok':True})
            except (ValueError,TypeError,UnicodeError,binascii.Error):return self.send_error(400)
        def do_GET(self):
            path=urlsplit(self.path).path;q=parse_qs(urlsplit(self.path).query)
            if path in ('/api/vibe/mode','/api/vibe/launch'):
                state,lock=self._live_shared()
                with lock:slug=state.get('game') if time.time()<state.get('until',0) else None
                if slug and descriptor(slug):
                    page='/games/'+slug+'/vibe.html'
                    return self._live_send({'mode':'web-game','game':slug,'page':page,'url':page,'active':True,'nativeState':1})
                return super().do_GET()
            if path.startswith('/games/'):
                parts=path.split('/',3)
                if len(parts)==4 and descriptor(parts[2]):
                    folder=(root/parts[2]).resolve();file=(folder/unquote(parts[3])).resolve()
                    if not file.is_relative_to(folder) or not file.is_file():return self.send_error(404)
                    return self._live_send(file.read_bytes(),mime=('application/javascript' if file.suffix=='.mjs' else mimetypes.guess_type(file.name)[0]) or 'application/octet-stream')
            slug,route=self._live_path()
            if not slug:return super().do_GET()
            if route=='status':
                active=self._live_active(slug)
                with LOCK:seats=[COLORS[i-1] for i,(t,_) in LIVE['frames'].items() if time.monotonic()-t<2.5]
                return self._live_send({'protocol':1,'game':slug,'active':active,'liveSeats':seats})
            if not self._live_active(slug):return self.send_error(409)
            color=q.get('color',[''])[0].lower()
            if route=='frame':
                if color not in COLORS:return self.send_error(400)
                if descriptor(slug).get('privateFrames'):
                    with LOCK:s=LIVE['sessions'].get(q.get('token',[''])[0])
                    if not s or s['color']!=color or s['ip']!=self.client_address[0] or s['owner']!=LIVE['owner'] or time.monotonic()-s['at']>7200:return self.send_error(403)
                with LOCK:packet=LIVE['frames'].get(COLORS.index(color)+1)
                if not packet or time.monotonic()-packet[0]>2.5:return self.send_error(503)
                tag='\"'+hashlib.sha256(packet[1]).hexdigest()[:24]+'\"'
                if self.headers.get('If-None-Match')==tag:
                    self.send_response(304);self.send_header('ETag',tag);self.send_header('Cache-Control','no-store');self.end_headers();return
                self.send_response(200);self.send_header('Content-Type','image/jpeg');self.send_header('Cache-Control','no-store');self.send_header('ETag',tag);self.send_header('Content-Length',str(len(packet[1])));self.end_headers();self.wfile.write(packet[1]);return
            if route=='touch/events':
                if not self._live_host():return self.send_error(403)
                try:after=max(0,int(q.get('after',['0'])[0]))
                except ValueError:return self.send_error(400)
                with LOCK:return self._live_send({'latest':LIVE['seq'],'events':[e for e in LIVE['events'] if e['seq']>after]})
            if route=='touch/session':
                if color not in COLORS:return self.send_error(400)
                with LOCK:
                    now=time.monotonic();LIVE['sessions']={k:v for k,v in LIVE['sessions'].items() if now-v['at']<7200}
                    if len(LIVE['sessions'])>=64:del LIVE['sessions'][next(iter(LIVE['sessions']))]
                    token=secrets.token_urlsafe(24);LIVE['sessions'][token]={'ip':self.client_address[0],'color':color,'at':now,'last':0,'owner':LIVE['owner']}
                    return self._live_send({'token':token,'color':color})
            if route=='touch/state':
                with LOCK:
                    s=LIVE['sessions'].get(q.get('token',[''])[0])
                    if not s or s['ip']!=self.client_address[0] or s['owner']!=LIVE['owner'] or time.monotonic()-s['at']>7200:return self.send_error(403)
                    data=LIVE['state'];i=COLORS.index(s['color']);board=data.get('dashboards',[{}]*6)[i]
                    return self._live_send({'stale':time.monotonic()-LIVE['state_at']>2.5,'state':{k:v for k,v in data.items() if k!='dashboards'},'dashboard':board})
            return self.send_error(404)
        def log_message(self,format,*args):
            path=urlsplit(getattr(self,'path','')).path
            if path.startswith('/arcadium-live/') or path in ('/api/vibe/events','/api/vibe/native-events'):return
            return super().log_message(format,*args)
    return LiveGameHandler

