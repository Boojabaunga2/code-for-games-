export const COLORS = ['red','blue','green','yellow','pink','white'];
export const HEX = ['#ff3554','#249eff','#43e35b','#ffd337','#ff49ce','#e9f3ff'];
export const HANDS = ['ROCK','PAPER','MONKEY','SCISSORS','GHOST','WILD'];
// Only matchups printed in the supplied reference are decisive. Others redraw.
const BEATS = [[3],[0],[1],[2],[3],[0,1,2,3,4]];
export function duelWinner(a,b) {
  if (a===b) return -1;
  if (BEATS[a]?.includes(b)) return 0;
  if (BEATS[b]?.includes(a)) return 1;
  return -1;
}
export function secureRandom() {
  const a=new Uint32Array(1);globalThis.crypto.getRandomValues(a);return a[0]/4294967296;
}
export class Showdown {
  constructor(random=secureRandom) {this.random=random;this.serial=0;this.lobby();}
  setPhase(phase,clock=0) {this.phase=phase;this.clock=clock;this.turnId=`${++this.serial}:${phase}`;}
  lobby() {
    this.round=0;this.paused=false;this.time=0;this.elapsed=0;this.winner=null;this.low=null;this.second=null;this.result=null;this.duel=null;this.history=[];this.shots=[];this.shotId=0;
    this.players=COLORS.map((color,i)=>({i,color,human:true,alive:true,score:0,baskets:0,attempts:0,bonus:0,aim:0,cooldown:0,lastBasket:Infinity,flash:0,feedback:"",feedbackTime:0,streak:0,cpuTarget:.7}));
    this.setPhase('lobby');
  }
  join(i) {if(this.phase==='lobby'&&this.players[i]) this.players[i].human=true;}
  practice() {if(this.phase!=='lobby')return false;this.paused=false;this.setPhase('practice');return true;}
  start() {if(!['lobby','practice'].includes(this.phase))return false;this.round=0;this.paused=false;this.nextRound();return true;}
  nextRound() {
    this.round++;this.elapsed=0;this.shots=[];this.low=this.second=null;this.duel=null;this.result=null;
    for(const p of this.players) {if(!p.alive)continue;p.score=p.bonus;p.bonus=0;p.baskets=p.attempts=p.streak=0;p.lastBasket=Infinity;p.cooldown=0;p.aim=0;p.flash=0;p.feedback='';p.feedbackTime=0;p.cpuTarget=.7+(this.random()-.5)*.22;}
    this.setPhase('countdown',3);
  }
  meter(i) {const t=(this.time*.65+i*.137)%2;return t<=1?t:2-t;}
  adjust(i,dir,dt) {const p=this.players[i];if(['round','practice'].includes(this.phase)&&!this.paused&&p?.alive)p.aim=Math.max(-1,Math.min(1,p.aim+dir*dt*.75));}
  shoot(i) {
    const p=this.players[i];if(this.paused||!['round','practice'].includes(this.phase)||!p?.alive||p.cooldown>0)return false;
    const release=this.meter(i),error=(release-.7)*2.1,hit=Math.abs(error)<.22&&Math.abs(p.aim)<.2;
    this.shots.push({id:++this.shotId,seat:i,t:0,hit,error,aim:p.aim,scored:false});
    p.cooldown=.48;p.attempts++;p.lastRelease=release;return true;
  }
  action(i,key) {
    const p=this.players[i];if(!p)return false;
    if(this.phase==='lobby'){if(key==='A')this.join(i);if(key==='START')return this.start();return true;}
    if(!p.human)return false;
    if(key==='START'&&this.phase!=='champion'){this.paused=!this.paused;return true;}
    if(this.paused||!p.alive)return false;
    if(['round','practice'].includes(this.phase)&&key==='A')return this.shoot(i);
    if(this.phase==='risk'&&i===this.low){if(key==='A'){this.setPhase('decision',8);return true;}if(key==='B'){this.eliminate(this.low,'ELIMINATION ACCEPTED');return true;}}
    if(this.phase==='decision'&&i===this.second){if(key==='A'){this.drawHands();return true;}if(key==='B'){this.eliminate(this.low,'CHALLENGE DECLINED');return true;}}
    return false;
  }
  rank() {
    // Equal scores: earlier final basket ranks ahead. All-zero ties rotate seat order per round.
    return this.players.filter(p=>p.alive).sort((a,b)=>b.score-a.score||a.lastBasket-b.lastBasket||((a.i+6-this.round%6)%6)-((b.i+6-this.round%6)%6));
  }
  endRound() {const r=this.rank();this.low=r.at(-1).i;this.second=r.at(-2).i;this.setPhase('risk',8);}
  drawHands() {
    const hands=[Math.floor(this.random()*6),Math.floor(this.random()*6)],win=duelWinner(...hands);
    this.duel={seats:[this.low,this.second],hands,win,draw:win<0,number:(this.duel?.number||0)+1};this.setPhase('duel',2.4);
  }
  eliminate(i,reason,bonusSeat=null) {
    this.players[i].alive=false;
    if(bonusSeat!==null)this.players[bonusSeat].bonus=10;
    this.result={out:i,reason,bonusSeat,round:this.round,scores:this.players.map(p=>p.score)};this.history.push(this.result);this.setPhase('result',4);
  }
  dashboard(i) {
    const p=this.players[i];return {seat:i,color:p.color,phase:this.phase,turnId:this.turnId,paused:this.paused,round:this.round,clock:Math.max(0,this.clock),score:p.score,baskets:p.baskets,alive:p.alive,human:p.human,bonus:p.bonus,low:this.low,second:this.second,winner:this.winner,meter:this.meter(i),aim:p.aim,result:this.result,duel:this.duel};
  }
  update(dt) {
    if(this.paused||this.phase==='lobby'||this.phase==='champion')return;
    dt=Math.max(0,Math.min(dt,.1));this.time+=dt;
    for(const p of this.players){p.cooldown=Math.max(0,p.cooldown-dt);p.flash=Math.max(0,p.flash-dt);p.feedbackTime=Math.max(0,p.feedbackTime-dt);}
    if(['round','buzzer','practice'].includes(this.phase)) {
      for(const s of this.shots) {
        s.t+=dt;
        if(s.t>=.74&&!s.scored){s.scored=true;const p=this.players[s.seat];if(s.hit){p.score+=2;p.baskets++;p.streak++;p.lastBasket=this.elapsed;p.flash=.6;p.feedback='SWISH +2';}else {p.streak=0;p.feedback=Math.abs(s.aim)>=.2?'AIM AT THE HOOP':s.error<0?'EARLY':'LATE';}p.feedbackTime=.9;}
      }
      this.shots=this.shots.filter(s=>s.t<1.15);
    }
    if(['round','buzzer','practice'].includes(this.phase))this.elapsed+=dt;
    if(this.phase==='round') {
      for(const p of this.players) if(p.alive&&!p.human&&p.cooldown===0&&Math.abs(this.meter(p.i)-p.cpuTarget)<.025){this.shoot(p.i);p.cpuTarget=.7+(this.random()-.5)*.27;}
    }
    this.clock=Math.max(0,this.clock-dt);
    if(this.phase==='countdown'&&this.clock===0)this.setPhase('round',30);
    else if(this.phase==='round'&&this.clock===0)this.setPhase('buzzer',1.2);
    else if(this.phase==='buzzer'&&this.clock===0)this.endRound();
    else if(this.phase==='risk') {
      if(!this.players[this.low].human&&this.clock<6.5){if(this.random()<.8)this.setPhase('decision',8);else this.eliminate(this.low,'ELIMINATION ACCEPTED');}
      else if(this.clock===0)this.eliminate(this.low,'DECISION TIMED OUT');
    } else if(this.phase==='decision') {
      if(!this.players[this.second].human&&this.clock<6.5){if(this.random()<.65)this.drawHands();else this.eliminate(this.low,'CHALLENGE DECLINED');}
      else if(this.clock===0)this.eliminate(this.low,'CHALLENGE DECLINED · TIME EXPIRED');
    } else if(this.phase==='duel'&&this.clock===0) {
      if(this.duel.draw)this.drawHands();
      else {const winner=this.duel.seats[this.duel.win],loser=this.duel.seats[1-this.duel.win];this.eliminate(loser,'SHOWDOWN WON BY '+COLORS[winner].toUpperCase(),winner===this.second?winner:null);}
    } else if(this.phase==='result'&&this.clock===0) {
      const alive=this.players.filter(p=>p.alive);if(alive.length===1){this.winner=alive[0].i;this.setPhase('champion');}else this.nextRound();
    }
  }
}
