import {COLORS,HEX,HANDS} from './engine.mjs';
export const cast=new Image();cast.src='cast.png';
const hoopArt=new Image();hoopArt.src='hoop.png';const hoopCache=new Map();
const mix=(a,b,t)=>a+(b-a)*t;
function round(ctx,x,y,w,h,r=12){ctx.beginPath();ctx.roundRect(x,y,w,h,r);}
export function basketball(ctx,x,y,r,spin=0){
 ctx.save();ctx.translate(x,y);ctx.rotate(spin);
 const g=ctx.createRadialGradient(-r*.35,-r*.45,1,0,0,r);g.addColorStop(0,'#ffda6a');g.addColorStop(.35,'#ff9829');g.addColorStop(.8,'#ca4a0d');g.addColorStop(1,'#732405');
 ctx.fillStyle=g;ctx.beginPath();ctx.arc(0,0,r,0,7);ctx.fill();ctx.strokeStyle='#3c1b13';ctx.lineWidth=Math.max(1,r*.06);ctx.stroke();
 ctx.beginPath();ctx.moveTo(-r,0);ctx.lineTo(r,0);ctx.moveTo(0,-r);ctx.lineTo(0,r);ctx.stroke();
 for(const sign of [-1,1]){ctx.beginPath();ctx.ellipse(sign*r*.55,0,r*.43,r,0,-Math.PI/2,Math.PI/2,sign<0);ctx.stroke();}
 ctx.restore();
}
function hoop(ctx,w,h,p){
 const x=w*.75,y=h*.40,hw=w*.26,bh=h*.30;
 if(hoopArt.complete&&hoopArt.naturalWidth){
   const aw=w*.43,ah=aw*hoopArt.naturalHeight/hoopArt.naturalWidth;
   const k=`${w}:${h}`;if(!hoopCache.has(k)){const c=document.createElement('canvas');c.width=Math.ceil(aw);c.height=Math.ceil(ah);c.getContext('2d').drawImage(hoopArt,0,0,c.width,c.height);hoopCache.set(k,c);}
   ctx.save();const jiggle=p.flash>0?Math.sin(p.flash*30)*2:0;ctx.translate(jiggle,0);ctx.drawImage(hoopCache.get(k),x-aw/2,y-ah*.50,aw,ah);ctx.restore();return;
 }
 ctx.save();ctx.shadowColor='#000b';ctx.shadowBlur=15;
 const glass=ctx.createLinearGradient(x-hw/2,y-bh,x+hw/2,y);glass.addColorStop(0,'#b1e8ff2a');glass.addColorStop(1,'#103d7b60');
 ctx.fillStyle=glass;ctx.strokeStyle='#e6f5ff';ctx.lineWidth=2;round(ctx,x-hw/2,y-bh,hw,bh,3);ctx.fill();ctx.stroke();
 ctx.shadowBlur=0;ctx.strokeStyle=HEX[p.i];ctx.lineWidth=3;ctx.strokeRect(x-hw*.21,y-bh*.50,hw*.42,bh*.43);
 ctx.fillStyle='#dcecff';ctx.font=`italic 1000 ${h*.07}px Arial`;ctx.textAlign='center';ctx.fillText('A',x,y-bh*.68);
 const netBottom=y+h*.18,spread=p.flash>0?Math.sin(p.flash*28)*w*.012:0;
 ctx.strokeStyle='#edf6ffd9';ctx.lineWidth=1.3;
 for(let i=0;i<7;i++){
  const u=i/6;ctx.beginPath();ctx.moveTo(x-hw*.29+u*hw*.58,y);ctx.lineTo(x-hw*.13+u*hw*.26+spread,netBottom);ctx.stroke();
 }
 for(let row=1;row<4;row++){
  const v=row/4,rad=mix(hw*.29,hw*.13,v);ctx.beginPath();ctx.ellipse(x+spread*v,mix(y,netBottom,v),rad,h*.016,0,0,7);ctx.stroke();
 }
 ctx.strokeStyle='#511404';ctx.lineWidth=7;ctx.beginPath();ctx.ellipse(x,y,hw*.30,h*.035,0,0,7);ctx.stroke();
 ctx.strokeStyle='#ff781e';ctx.lineWidth=4;ctx.stroke();
 ctx.strokeStyle='#ffc26a';ctx.lineWidth=1;ctx.beginPath();ctx.ellipse(x,y-1,hw*.30,h*.035,0,Math.PI,Math.PI*2);ctx.stroke();
 ctx.restore();
}
const laneCache=new Map();
function staticLane(ctx,w,h,p,i){
 const bg=ctx.createLinearGradient(0,0,w,h);bg.addColorStop(0,'#19264b');bg.addColorStop(1,'#030b1a');ctx.fillStyle=bg;ctx.fillRect(0,0,w,h);
 if(cast.complete&&cast.naturalWidth){
  const sw=cast.naturalWidth/3,sh=cast.naturalHeight/2;
  ctx.drawImage(cast,(i%3)*sw,Math.floor(i/3)*sh,sw,sh,-w*.02,h*.01,w*.68,h*.91);
 }
 const shade=ctx.createLinearGradient(0,0,w,0);shade.addColorStop(0,'#02061600');shade.addColorStop(.38,'#02071622');shade.addColorStop(.65,'#030b16bb');shade.addColorStop(1,'#061328bb');ctx.fillStyle=shade;ctx.fillRect(0,0,w,h);
 // Perspective court and arcade cage.
 const floor=ctx.createLinearGradient(0,h*.62,0,h);floor.addColorStop(0,'#17284300');floor.addColorStop(1,'#0c122e');ctx.fillStyle=floor;ctx.fillRect(0,h*.57,w,h*.43);
 ctx.save();ctx.strokeStyle=HEX[i]+'66';ctx.lineWidth=1.5;
 for(const side of [-1,1]){ctx.beginPath();ctx.moveTo(w*.75+side*w*.17,h*.45);ctx.lineTo(w*.75+side*w*.28,h*.88);ctx.stroke();}
 ctx.strokeStyle='#98caff18';for(let k=0;k<7;k++){ctx.beginPath();ctx.moveTo(w*.52+k*w*.075,h*.88);ctx.lineTo(w*.61+k*w*.045,h*.05);ctx.stroke();}
 for(let k=0;k<7;k++){ctx.beginPath();ctx.moveTo(w*.51,h*(.1+k*.10));ctx.lineTo(w,h*(.1+k*.10));ctx.stroke();}ctx.restore();


}
export function lane(ctx,game,i,w,h,{mini=false}={}){
 const p=game.players[i];ctx.clearRect(0,0,w,h);
 const key=`${i}:${w}:${h}:${cast.complete&&cast.naturalWidth}:${hoopArt.complete&&hoopArt.naturalWidth}`;
 if(!laneCache.has(key)){
   const c=document.createElement('canvas');c.width=w;c.height=h;
   staticLane(c.getContext('2d'),w,h,p,i);laneCache.set(key,c);
 }
 ctx.drawImage(laneCache.get(key),0,0);
 hoop(ctx,w,h,p);
 if(p.alive&&['round','practice'].includes(game.phase)){
  const ax=w*.75+p.aim*w*.15,ay=h*.4;ctx.strokeStyle=Math.abs(p.aim)<.2?'#8affb7':'#ff4e73';ctx.lineWidth=1.5;
  ctx.beginPath();ctx.arc(ax,ay,5,0,7);ctx.moveTo(ax-10,ay);ctx.lineTo(ax-6,ay);ctx.moveTo(ax+6,ay);ctx.lineTo(ax+10,ay);ctx.stroke();
 }
 if(p.alive){
  basketball(ctx,w*.75,h*.75,w*.065,game.time*.15);
  for(const s of game.shots.filter(s=>s.seat===i)){
   const t=Math.min(1,s.t/.74),rimY=h*.4,rx=w*.75+(s.hit?0:s.aim*w*.15+s.error*w*.14);
   let x=mix(w*.75,rx,t),y=mix(h*.75,rimY,t)-Math.sin(t*Math.PI)*h*.45,r=mix(w*.065,w*.038,t);
   if(s.t>.74){const q=(s.t-.74)/.41;y=rimY+q*h*.25;x=rx+(s.hit?0:q*w*.17);r=w*.038;}
   ctx.save();ctx.shadowColor='#ff932a66';ctx.shadowBlur=10;basketball(ctx,x,y,r,s.t*7);ctx.restore();
  }
 }
 // Timing window: the authoritative release meter, not a separate mini-game.
 const mx=w*.08,my=h*.87,mw=w*.84,mh=h*.045;
 ctx.fillStyle='#030915dd';round(ctx,mx-5,my-10,mw+10,mh+28,5);ctx.fill();
 ctx.fillStyle='#25405d';round(ctx,mx,my,mw,mh,2);ctx.fill();
 ctx.fillStyle='#45fc85';ctx.fillRect(mx+mw*.595,my,mw*.21,mh);
 const needle=mx+mw*game.meter(i);ctx.fillStyle='#fff';ctx.shadowColor='#d8f8ff';ctx.shadowBlur=7;ctx.fillRect(needle-2,my-4,4,mh+8);ctx.shadowBlur=0;
 ctx.textAlign='center';ctx.fillStyle='#a9c6e4';ctx.font=`bold ${h*.047}px Arial`;ctx.fillText('PRESS A IN GREEN TO SHOOT',w*.5,h*.983);
 if(p.feedbackTime>0){ctx.save();ctx.globalAlpha=Math.min(1,p.feedbackTime*3);ctx.fillStyle=p.flash>0?'#b8ff6a':'#ffb852';ctx.strokeStyle='#061021';ctx.lineWidth=5;ctx.font=`italic 1000 ${h*.075}px Arial`;ctx.strokeText(p.feedback,w*.72,h*.67);ctx.fillText(p.feedback,w*.72,h*.67);ctx.restore();}
 if(!p.alive){ctx.fillStyle='#020713b8';ctx.fillRect(0,0,w,h);ctx.fillStyle='#9bb0ca';ctx.font=`italic 900 ${h*.15}px Arial`;ctx.fillText('ELIMINATED',w*.5,h*.56);}
 if(game.phase==='countdown'&&p.alive){ctx.fillStyle='#03102966';ctx.fillRect(0,0,w,h);ctx.fillStyle='#fff';ctx.font=`italic 1000 ${h*.34}px Arial`;ctx.shadowColor=HEX[i];ctx.shadowBlur=25;ctx.fillText(String(Math.ceil(game.clock)),w*.75,h*.73);ctx.shadowBlur=0;}
 if(mini){ctx.textAlign='left';}
}
export function drawMini(ctx,game,i){
 const p=game.players[i],c=HEX[i];ctx.fillStyle='#050d1c';ctx.fillRect(0,0,720,720);
 ctx.fillStyle=c;ctx.fillRect(0,0,720,6);ctx.font='italic 1000 26px Arial';ctx.textAlign='left';ctx.fillText('ARCADIUM',30,45);
 ctx.font='italic 1000 28px Arial';ctx.fillStyle='#fff';ctx.fillText('POP-A-SHOT',30,82);
 ctx.textAlign='right';ctx.fillStyle=c;ctx.font='1000 26px Arial';ctx.fillText(COLORS[i].toUpperCase(),690,45);
 ctx.font='900 22px Arial';ctx.fillStyle='#c3d7ee';ctx.fillText(game.phase==='practice'?'PRACTICE':'ROUND '+Math.max(1,game.round)+' / 5',690,81);
 ctx.save();ctx.translate(0,105);lane(ctx,game,i,720,430,{mini:true});ctx.restore();
 ctx.textAlign='left';ctx.fillStyle='#9ab4d3';ctx.font='bold 16px Arial';ctx.fillText('SCORE',30,568);ctx.fillText('TIME',280,568);ctx.fillText('BASKETS',520,568);
 ctx.fillStyle='#fff';ctx.font='900 46px Arial';ctx.fillText(String(p.score).padStart(2,'0'),30,605);ctx.fillText(game.phase==='practice'?'—':Math.ceil(game.clock).toString().padStart(2,'0'),280,605);ctx.fillText(String(p.baskets),520,605);
 let text=game.phase==='lobby'?'A JOIN · START TO PLAY':game.phase==='practice'?'PRACTICE · PRESS A IN GREEN':game.phase==='round'?'A SHOOT':game.phase==='countdown'?'GET READY':game.phase==='buzzer'?'BUZZER · FINAL SHOTS':game.phase==='champion'?(game.winner===i?'YOU ARE THE CHAMPION':COLORS[game.winner].toUpperCase()+' WINS'):!p.alive?'YOU ARE OUT · WATCH THE SHOWDOWN':'WAIT FOR THE NEXT ROUND';
 if(game.phase==='risk')text=i===game.low?'A CHALLENGE · B ACCEPT ELIMINATION':COLORS[game.low].toUpperCase()+' IS AT RISK';
 if(game.phase==='decision')text=i===game.second?'A ACCEPT · B DECLINE':COLORS[game.second].toUpperCase()+' IS DECIDING';
 if(game.phase==='duel'&&game.duel.seats.includes(i))text=HANDS[game.duel.hands[game.duel.seats.indexOf(i)]]+(game.duel.draw?' · REDRAW':'');
 if(game.paused)text='PAUSED · START TO RESUME';
 ctx.fillStyle=c;ctx.fillRect(25,620,670,4);ctx.fillStyle='#fff';ctx.font='italic 900 23px Arial';ctx.textAlign='center';ctx.fillText(text,360,646,660);
}
