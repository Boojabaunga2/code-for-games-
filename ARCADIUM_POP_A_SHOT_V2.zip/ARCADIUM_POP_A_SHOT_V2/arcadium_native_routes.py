"""Independent authenticated raw input on the existing 8787 server.
Legacy /api/vibe/input, its event list/slots and every other route pass through unchanged.
"""
import hmac,ipaddress,json,re,threading,time
from urllib.parse import urlsplit,parse_qs
COLORS=('red','blue','green','yellow','pink','white');PACKET=re.compile(r'^I[0-9a-f]{15}$',re.I)
LOCK=threading.RLock();EVENTS=[];SEQUENCE=0;SLOTS={}
def wrap_native_input_handler(Parent):
 class NativeInputHandler(Parent):
  def _native_app(self):
   import __main__
   return getattr(self.server,'native_app',__main__)
  def _native_host(self):
   try:
    peer=ipaddress.ip_address(self.client_address[0]);local=ipaddress.ip_address(self.connection.getsockname()[0]);peer=getattr(peer,'ipv4_mapped',None) or peer;local=getattr(local,'ipv4_mapped',None) or local;return peer.is_loopback or peer==local
   except (ValueError,OSError,AttributeError):return False
  def _native_json(self,obj,status=200):
   data=json.dumps(obj,separators=(',',':')).encode();self.send_response(status);self.send_header('Content-Type','application/json');self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
  def do_POST(self):
   if urlsplit(self.path).path!='/api/vibe/native-input':return super().do_POST()
   global SEQUENCE
   try:
    n=int(self.headers.get('Content-Length','0'))
    if not 0<n<=2048:return self._native_json({'error':'invalid size'},413)
    body=json.loads(self.rfile.read(n));app=self._native_app();token=getattr(app,'VIBE_PAIR_TOKEN',None)
    if not isinstance(token,str):return self._native_json({'error':'pairing service unavailable'},503)
    pair=body.get('pair') if isinstance(body,dict) else None
    if not isinstance(pair,str) or not hmac.compare_digest(pair,token):return self._native_json({'error':'invalid invitation'},403)
    color=body.get('color');packet=body.get('button')
    if color not in COLORS or not isinstance(packet,str) or not PACKET.fullmatch(packet):return self._native_json({'error':'invalid native state'},400)
    if getattr(app,'PINK_DEVICE_IP',None)==self.client_address[0]:color='pink'
    with LOCK:
     SEQUENCE+=1;now=time.time();EVENTS.append({'seq':SEQUENCE,'color':color,'button':packet,'at':round(now*1000)})
     if len(EVENTS)>400:del EVENTS[:-300]
     SLOTS[color]={'color':color,'at':now,'mask':int(packet[-3:],16)}
    return self._native_json({'ok':True})
   except (ValueError,TypeError,UnicodeError):return self._native_json({'error':'bad native request'},400)
  def do_GET(self):
   path=urlsplit(self.path).path
   if path not in ('/api/vibe/native-events','/api/vibe/native-state'):return super().do_GET()
   if not self._native_host():return self._native_json({'error':'PC only'},403)
   if path.endswith('native-state'):return self._native_json({'protocol':'I1','controls':12,'legacy_feed_unchanged':True})
   try:after=max(0,int(parse_qs(urlsplit(self.path).query).get('after',['0'])[0]))
   except (ValueError,TypeError):return self._native_json({'error':'invalid sequence'},400)
   with LOCK:data={'latest':SEQUENCE,'events':[dict(e) for e in EVENTS if e['seq']>after],'slots':[dict(s,connected=time.time()-s['at']<2) for s in SLOTS.values()]}
   return self._native_json(data)
 return NativeInputHandler

