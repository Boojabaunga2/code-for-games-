// Same 120 Hz air drag and gravity as the bundled Matter world, before contact.
// Contact marker uses expanded block bounds; moving/rotating structures can change it.
export function launchPoint(pull){return{x:200+pull[0]*.6,y:640+pull[1]*.6};}
export function aimInfo(pull){return {power:Math.round(Math.hypot(...pull)/175*100),angle:Math.round(Math.atan2(pull[1],-pull[0])*180/Math.PI)};}
export function predictFlight(pull,blocks=[],defs=[]){
 let {x,y}=launchPoint(pull);let vx=-pull[0]*.12*.5,vy=-pull[1]*.12*.5;
 const points=[[x,y]];let hit=null;
 for(let step=1;step<500;step++){
  vx*=.99925;vy=vy*.99925+1000/14400;x+=vx;y+=vy;
  for(let i=0;i<blocks.length;i++){
   const b=blocks[i],d=defs[i];if(!b[3]||!d)continue;
   const a=b[2]/100,dx=x-b[0],dy=y-b[1],xx=dx*Math.cos(a)+dy*Math.sin(a),yy=-dx*Math.sin(a)+dy*Math.cos(a);
   const contact=['core','bonus'].includes(d.kind)?Math.hypot(dx,dy)<41:Math.abs(xx)<d.w/2+22&&Math.abs(yy)<d.h/2+22;
   if(contact){hit={x,y,index:i};break;}
  }
  if(step%4===0||hit||y>=748)points.push([x,Math.min(748,y)]);
  if(hit||y>=748||x>1500){hit??={x,y:Math.min(748,y),index:-1};break;}
 }
 return {points,hit};
}
