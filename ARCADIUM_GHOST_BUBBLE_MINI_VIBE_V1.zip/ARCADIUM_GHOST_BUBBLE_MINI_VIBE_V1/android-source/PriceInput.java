package com.arcadium.og9;
/** The touch keypad can emit only original price-game keys, only on its own page. */
public final class PriceInput {
    private PriceInput() { }
    public static String encode(String key, String page) {
        if (!"/games/what-the-freaking-price/personal/vibe.html".equals(page)
                || key == null || !key.matches("[0-9]|BACK|CLEAR|ENTER")) return null;
        return "BID:" + key;
    }
}
