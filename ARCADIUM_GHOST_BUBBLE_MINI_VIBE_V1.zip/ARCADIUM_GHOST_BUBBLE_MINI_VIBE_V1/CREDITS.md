# Source and artwork

The original Ghost Bubble game, matching/shot/ghost mechanics, original carousel card and twenty embedded artworks were supplied by the user in `arcadium-ghost-bubble (2).zip`. Embedded JPEG images are extracted byte-for-byte into local assets. Their existing ownership is unchanged. The approved carousel card is preserved.

The observatory background is original artwork generated with OpenAI image generation for this game. It is a game asset, not a screenshot of finished gameplay. Review screenshots are captured separately from the actual browser-rendered game. New bubble symbols, higher-resolution ghost/bubble sprites, personal dashboards, camera compositions, procedural sound and integration code are original implementation work.

There are no runtime CDNs, external fonts, tracking services or downloaded art dependencies. All assets are bundled. Existing repository and applicable artwork terms continue to apply; this file does not assign a new blanket license to the user's game or Arcadium.
