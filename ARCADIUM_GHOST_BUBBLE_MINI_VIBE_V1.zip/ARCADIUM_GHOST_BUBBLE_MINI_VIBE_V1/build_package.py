from pathlib import Path
import argparse,hashlib,json,zipfile
ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[1]
def payload():
 files={p.relative_to(ROOT).as_posix():p.read_bytes() for p in ROOT.rglob('*') if p.is_file() and not any(part in ('__pycache__','tests','review') for part in p.relative_to(ROOT).parts) and p.name not in ('CHECKSUMS.json','.gitignore') and not p.name.endswith(('.pyc','RECEIPT.json','REPORT.json'))}
 return files
def manifest():
 files=payload();(ROOT/'CHECKSUMS.json').write_text(json.dumps({n:hashlib.sha256(b).hexdigest() for n,b in files.items()},indent=2));return files
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--output',default='ARCADIUM_GHOST_BUBBLE_MINI_VIBE_V1.zip');parser.add_argument('--apk',type=Path);args=parser.parse_args();files=manifest()
 if args.apk:
  with zipfile.ZipFile(args.apk) as apk:
   for p in (REPO/'app/src/main/assets').rglob('*'):
    if p.is_file():assert apk.read('assets/'+p.relative_to(REPO/'app/src/main/assets').as_posix())==p.read_bytes()
  files['Mini Vibe/Arcadium-Ghost-Bubble.apk']=args.apk.read_bytes()
  for p in (REPO/'app/src/main/java').rglob('*.java'):files['android-source/'+p.name]=p.read_bytes()
  files['android-source/build.gradle']=(REPO/'app/build.gradle').read_bytes()
 files['CHECKSUMS.json']=json.dumps({n:hashlib.sha256(b).hexdigest() for n,b in files.items()},indent=2).encode()
 for p in (ROOT/'tests').glob('*'):
  if p.is_file():files['tests/'+p.name]=p.read_bytes()
 target=REPO/'downloads'/args.output
 with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
  for n,b in files.items():z.writestr(target.stem+'/'+n,b)
 print(target,target.stat().st_size)
