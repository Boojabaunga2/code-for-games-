from pathlib import Path
import importlib.util,sys,json
from http.server import ThreadingHTTPServer
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
spec=importlib.util.spec_from_file_location('gb_racing_reference',ROOT.parent/'rc-trigger-racing/tests/harness.py');ref=importlib.util.module_from_spec(spec);spec.loader.exec_module(ref)
import ghost_bubble_routes as routes
import update_ghost_bubble as updater
def modules():
 bridge,Parent=ref.modules()
 return bridge,routes.wrap_ghost_bubble_handler(Parent)
if __name__=='__main__':
 bridge,Parent=modules()
 class Handler(Parent):
  def do_POST(self):
   if self.path=='/__test/events':
    self.server.events=json.loads(self.rfile.read(int(self.headers['Content-Length'])));self.send_response(204);self.send_header('Content-Length','0');self.end_headers();return
   return super().do_POST()
 server=ThreadingHTTPServer(('127.0.0.1',8787),Handler);server.events={'latest':0,'events':[],'slots':[]};print('Ghost Bubble isolated prior-wrapper-chain harness on 8787',flush=True);server.serve_forever()
