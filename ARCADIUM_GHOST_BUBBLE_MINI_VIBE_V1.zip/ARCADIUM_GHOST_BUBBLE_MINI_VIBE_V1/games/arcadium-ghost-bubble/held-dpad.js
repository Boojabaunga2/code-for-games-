/* Actual Mini Vibe state snapshots. Timing below is only a lost-link failsafe. */
(function(root){'use strict';
 function create(now){now=now||function(){return performance.now()};var session=null,seq=-1,mask=0,at=-Infinity,retired=[];
  return {
   receive:function(button){var m=/^H([0-9a-f]{6})([0-9a-f]{6})([0-9a-f])$/i.exec(String(button));if(!m)return false;
    var next=parseInt(m[2],16),id=m[1].toLowerCase();
    if(session!==id){if(retired.indexOf(id)>=0)return true;if(session!==null){retired.push(session);if(retired.length>8)retired.shift();}session=id;seq=-1;}
    if(seq>=0){var delta=(next-seq+0x1000000)%0x1000000;if(delta===0||delta>=0x800000)return true;}
    seq=next;mask=parseInt(m[3],16);at=now();return true;
   },
   read:function(){return now()-at<=450?mask:0;},
   clear:function(){mask=0;at=-Infinity;},
   get seen(){return session!==null;}
  };
 }
 var api={create:create};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.ArcadiumHeldDpad=api;
})(typeof window!=='undefined'?window:globalThis);
