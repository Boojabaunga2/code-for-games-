# Arcadium Ghost Bubble / Mini Vibe Deluxe

Six-player shared-board bubble shooting on the existing Windows Arcadium OS, port **8787**. The original matching, bouncing shots, misses becoming ghosts, heart loss, player-ghost diving and 90-second match structure remain. The update adds a sharper observatory presentation, colour symbols, personal Mini Vibe cameras and three selectable ghost powers.

## Install

1. Exit any open game and extract the complete ZIP.
2. Double-click **START_INSTALL.cmd** and select the existing **Arcadium_OS_COMPACT** folder. The installer creates an automatic backup and preserves Home, the main server, other games, pairing and approved carousel art.
3. On the first Ghost Bubble installation, **restart Windows once** to load its new server helper. On a repeat installation with an unchanged helper, follow the refresh message instead.
4. On each Mini Vibe, install **Mini Vibe/Arcadium-Ghost-Bubble.apk** as an **update**. Keep app data and pairing; do not uninstall. This signed version 12 enables Ghost Bubble held aiming. The package ID and signing identity are retained.
5. Open Ghost Bubble from its existing Games carousel card. A joins; START begins. A single joined player gets one CPU opponent automatically.

This is an update to the existing 8787 OS, not a replacement OS or standalone server. Startup configuration is not changed. If an unknown bridge, duplicate registration or conflicting later edit is found, the installer stops without overwriting it.

## Physical controls

- **Hold LEFT / RIGHT:** aim the launcher; after elimination, steer your ghost. Release stops immediately. There is no tap latch or guessed key-release timer; a 450ms lost-link failsafe clears stale state.
- **A / R1:** fire a bubble; as a ghost, cast the selected power.
- **B / L1:** swap loaded/next bubble; as a ghost, select the next power.
- **X:** previous ghost power.
- **Y:** toggle your living-player camera between your lane and the whole board.
- **START:** ready/start, pause/resume, or play again after results.
- **SELECT:** clear your held input; leave a lobby slot.

The PC keeps the original six customisable keyboard layouts, mouse lobby and local gamepad support. **SPACE** fires P1 in play. **Shift + that player's fire key** cycles ghost power on a keyboard. Existing keyboard layouts are preserved. Native seats always follow **red, blue, green, yellow, pink, white**. Previously saved original colour IDs are migrated to a new score key without deleting the old score data.

The Mini Vibe shows actual game state. While alive, its personal camera centres your launcher and incoming threats, with a magnified aim-target inset, loaded/next bubbles, hearts, angle and score. After elimination, the camera follows your actual ghost and the power panel shows your target, power, availability, charges, cooldown and return penalty. There are no fake touch buttons or independent simulations.

## Ghost powers

- **Dive:** original ghost attack. Steer above a living player's lane, press A, and a **0.9-second warning** precedes the dive. A hit steals one heart and awards the original 150 points. It does not consume the extra-power charges. The original return/re-arm sequence remains.
- **Chill:** after a **0.9-second target warning**, aiming is reduced to **65% for two seconds**. It does not reverse input or stop movement. The target gains **six seconds of immunity** against another Chill. Casting at an empty/protected lane does not spend a charge.
- **Haunt Pulse:** after a **0.9-second warning**, adds **8 percentage points** to the shared haunt meter, capped at 100.

Chill and Haunt Pulse share **three charges per match** and an **eight-second cooldown**. Returning after being busted does not refill them. Matching-colour shots can bust a player ghost; it returns after the original **five-second penalty**. A cast is cancelled if its ghost is busted during the warning. Powers are unavailable during countdown, pause, results or the match-ending sequence. A new match resets hearts, ghosts and charges.

## Why one app update is included

Version 11 used a fixed list of held-D-pad games. Version 12 preserves that list and adds an explicit capability probe for future game pages. Unknown game pages must provide `input-capabilities.json` with `arcadiumHeldDpad: 1` and the existing `held-dpad.js` protocol asset. Older games without that opt-in keep their legacy input. Auction, bidding and RC/sports shoulder mappings remain scoped to their existing games. Future games using this compatible D-pad protocol can opt in on the PC without another per-game APK update.

## Backup, rollback and verification

The installer window includes **Rollback this update**. Select its `arcadium_backups/ghost_bubble_v1_*` backup. Later conflicting edits are protected. Reload the server after a rollback.

With Ghost Bubble open on the PC, double-click **VERIFY_GHOST_BUBBLE.py** to save a read-only route/frame report beside the verifier. It never sends controller input.

See **VALIDATION.md**, **CREDITS.md**, **APP_BUILD.json** and **ASSET_MANIFEST.json** for evidence. Automated tests do not establish physical-device latency, six real Mini Vibes, actual venue PLAY/carousel appearance or antivirus acceptance. Those still require a hardware test.
