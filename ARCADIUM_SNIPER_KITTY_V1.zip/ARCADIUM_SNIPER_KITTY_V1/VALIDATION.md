# Verification

Software checks and physical device acceptance are distinct.

- Pure-engine tests cover pane breach, targeted precision hit, ammo/cooldown, hold/release/reversal, independent helicopter steering, reload, pause, alarm elimination, ghost tagging/assist and all three ghost powers, five-round resets/results/replay, and a full timed CPU championship with real target scoring.
- Chromium/native receiver tests use the exact reviewed OS input receiver with synthetic invitation/state and the existing common native route. They exercise six native colour joins, aim/release/reversal and shoulders, actual A glass/target scoring without duplicate actions, zoom/reload/focus, pause/resume, six distinct pure scope images and fresh JPEG routes, six-view TV layout, ghost power, results/replay, responsive fit and clean return to controller mode. No new Android build is used.
- Package and route tests check targeted install/repeat/rollback, preservation of Home/main server/shared native helper/other games and catalog fields, refusal without shared platform or with unknown/duplicate registrations, exact ZIP/corruption guards, six view URLs, static asset traversal protection, stale images and safe owner/lease handoff.
- Windows START_INSTALL.cmd is tested through the existing real CMD workflow with Python/Tkinter, path spaces/ampersand and no .py association. Workflow 41905913254 passed the real Windows launcher job; the Android build was deliberately skipped. Details are recorded in review/final-summary.json.

Physical Mini Vibe controls, six simultaneous Wi-Fi scopes, real GPU performance, the exact user's carousel and antivirus acceptance remain unverified until tested on the Arcadium hardware. The generated concept image is not implementation evidence. Review images are real Chromium captures, with repeatable fixture aiming/elimination where indicated.

Final graphics checks cover actual shared/six-view rendering, all six distinct camera poses, pure scope draws, finite glass matrices after round reset, visible ghost Reveal and a usable launch button at 1024×600. Main presentation captures freeze simulation only after real gameplay actions to keep framing repeatable; personal scope and six-view images come from the same executable world.
