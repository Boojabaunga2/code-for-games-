"""Read-only checks of the existing venue server. No input injection."""
from urllib.request import urlopen
import json,tkinter as tk
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
COLORS=['red','blue','green','yellow','pink','white']
def read(path):
 try:
  with urlopen('http://127.0.0.1:8787'+path,timeout=3) as r:
   data=r.read();result={'status':r.status,'bytes':len(data)}
   if 'json' in r.headers.get('Content-Type',''):result['data']=json.loads(data)
   return result
 except Exception as error:return {'error':str(error)}
paths=['/api/vibe/native-events?after=0','/api/vibe/native-state','/api/vibe/events?after=0','/arcadium-kitty/sniper-kitty/status','/games/sniper-kitty/card.svg']+['/api/vibe/mode?color='+c for c in COLORS]+['/arcadium-kitty/sniper-kitty/frame?color='+c for c in COLORS]
with ThreadPoolExecutor(max_workers=6) as pool:results=dict(zip(paths,pool.map(read,paths)))
target=Path(__file__).with_name('SNIPER_KITTY_VERIFY_REPORT.json');target.write_text(json.dumps(results,indent=2))
ui=tk.Tk();ui.title('Sniper Kitty connection check');tk.Label(ui,text='Keep Sniper Kitty open on the PC. Report saved:\n'+str(target)+'\n\nHTTP success is not proof of physical controls.',wraplength=650,padx=20,pady=25).pack();tk.Button(ui,text='Close',command=ui.destroy).pack();ui.mainloop()
