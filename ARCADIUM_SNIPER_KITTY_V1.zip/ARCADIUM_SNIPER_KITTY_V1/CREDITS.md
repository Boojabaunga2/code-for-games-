# Credits

Sniper Kitty concept and direction: user-approved original Arcadium helicopter/glass-tower concept.

Original game engine, interface, 3D arena and procedural fallback helicopter/cat models, glass and target mechanics, scope rendering and synthesized audio: this build. Three.js r170 is used under the included MIT licence in games/sniper-kitty/vendor/THREE-LICENSE.txt.

The city panorama, sixteen-room texture atlas and six kitty pilot portraits and illustrated helicopter sprite atlas are original AI-generated game art made for this build. The main arena places illustrated helicopter billboards at their real 3D flight positions; the procedural model remains a loading fallback. Personal scopes are actual 3D cameras into the glass-tower world. The earlier concept mockup is a separate illustration. Actual implementation screenshots in review are Chromium captures from the executable; staged target/ghost states are documented as test fixtures. No commercial cat/game character assets or remote game/CDN dependencies are used.
