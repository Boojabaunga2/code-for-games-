"""Sniper Kitty on the existing Arcadium 8787 lease and server; no new listener."""
import base64,binascii,importlib,ipaddress,json,mimetypes,threading,time
from pathlib import Path
from urllib.parse import urlsplit,parse_qs,unquote
SLUG='sniper-kitty';COLORS=('red','blue','green','yellow','pink','white')
BASE=Path(__file__).resolve().parent;LOCK=threading.RLock();FRAMES={};OWNER=None
def wrap_sniper_kitty_handler(Parent):
 class SniperKittyHandler(Parent):
  def log_message(self,format,*args):
   path=urlsplit(getattr(self,'path','')).path
   if path.startswith('/arcadium-kitty/sniper-kitty/') or path=='/arcadium-vibe/activate/sniper-kitty':return
   if path in ('/api/vibe/events','/api/vibe/native-events') and self._sniper_kitty_active():return
   return super().log_message(format,*args)
  def _sniper_kitty_shared(self):
   bridge=importlib.import_module('arcadium_game_bridge');return bridge.ACTIVE_WEB_GAME,bridge.ACTIVE_LOCK
  def _sniper_kitty_active(self):
   state,lock=self._sniper_kitty_shared()
   with lock:return state['game']==SLUG and time.time()<state['until']
  def _sniper_kitty_send(self,data,mime='application/json',status=200):
   self.send_response(status);self.send_header('Content-Type',mime);self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
  def _sniper_kitty_host(self):
   try:
    peer=ipaddress.ip_address(self.client_address[0]);local=ipaddress.ip_address(self.connection.getsockname()[0])
    peer=getattr(peer,'ipv4_mapped',None) or peer;local=getattr(local,'ipv4_mapped',None) or local
    return peer.is_loopback or peer==local
   except (ValueError,OSError,AttributeError):return False
  def do_POST(self):
   path=urlsplit(self.path).path;activate=path=='/arcadium-vibe/activate/'+SLUG;frame=path=='/arcadium-kitty/'+SLUG+'/frame'
   if not activate and not frame:return super().do_POST()
   if not self._sniper_kitty_host():return self.send_error(403)
   global OWNER
   try:
    size=int(self.headers.get('Content-Length','0'))
    if size<0 or size>(1024 if activate else 300000):return self.send_error(413)
    body=json.loads(self.rfile.read(size) or b'{}')
    if not isinstance(body,dict):raise ValueError()
    if activate:
     enabled=body.get('active',True);renew=body.get('renew',False);owner=body.get('owner')
     if owner is not None and (not isinstance(owner,str) or not 1<=len(owner)<=100):raise ValueError()
     if not isinstance(enabled,bool) or not isinstance(renew,bool):raise ValueError()
     state,lock=self._sniper_kitty_shared()
     with lock:
      if enabled and renew and (state['game']!=SLUG or (owner is not None and OWNER!=owner)):return self.send_error(409)
      if enabled:
       if state['game']!=SLUG or time.time()>=state['until'] or (owner is not None and OWNER!=owner):
        with LOCK:FRAMES.clear()
       state.update(game=SLUG,until=time.time()+7)
       if owner is not None:OWNER=owner
      elif state['game']==SLUG and (owner is None or OWNER==owner):
       state.update(game=None,until=0)
       with LOCK:FRAMES.clear()
    else:
     if not self._sniper_kitty_active() or (body.get('owner') is not None and body['owner']!=OWNER):return self.send_error(409)
     seat=body['seat'];image=base64.b64decode(body['image'],validate=True)
     if type(seat) is not int or seat not in range(1,7) or len(image)>200000 or not image.startswith(b'\xff\xd8'):raise ValueError()
     with LOCK:FRAMES[seat]=(time.monotonic(),image)
    return self._sniper_kitty_send(b'{"ok":true}')
   except (ValueError,TypeError,KeyError,UnicodeError,binascii.Error):return self.send_error(400)
  def do_GET(self):
   path=urlsplit(self.path).path
   if path in ('/api/vibe/mode','/api/vibe/launch') and self._sniper_kitty_active():
    page='/games/'+SLUG+'/personal/vibe.html';return self._sniper_kitty_send(json.dumps(dict(mode='web-game',game=SLUG,page=page,url=page,active=True,nativeState=1)).encode())
   prefix='/games/'+SLUG+'/'
   if path.startswith(prefix):
    relative=unquote(path[len(prefix):]);relative='vibe.html' if relative=='personal/vibe.html' else relative
    folder=(BASE/'games'/SLUG).resolve();file=(folder/relative).resolve()
    if not file.is_relative_to(folder) or not file.is_file():return self.send_error(404)
    return self._sniper_kitty_send(file.read_bytes(),('application/javascript' if file.suffix=='.mjs' else mimetypes.guess_type(file.name)[0]) or 'application/octet-stream')
   if path=='/arcadium-kitty/'+SLUG+'/status':
    with LOCK:seats=[COLORS[i-1] for i,p in FRAMES.items() if time.monotonic()-p[0]<2.5]
    return self._sniper_kitty_send(json.dumps(dict(build='sniper-kitty-v1',game=SLUG,active=self._sniper_kitty_active(),liveSeats=seats)).encode())
   if path!='/arcadium-kitty/'+SLUG+'/frame':return super().do_GET()
   color=parse_qs(urlsplit(self.path).query).get('color',[''])[0].lower()
   if color not in COLORS:return self.send_error(400)
   if not self._sniper_kitty_active():return self.send_error(503)
   with LOCK:
    packet=FRAMES.get(COLORS.index(color)+1)
    if not packet or time.monotonic()-packet[0]>2.5:return self.send_error(503)
    return self._sniper_kitty_send(packet[1],'image/jpeg')
 return SniperKittyHandler
