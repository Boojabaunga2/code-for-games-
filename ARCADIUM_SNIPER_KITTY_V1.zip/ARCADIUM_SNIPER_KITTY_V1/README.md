# ARCADIUM / SNIPER KITTY

Six kitty pilots, six helicopters, one glass tower and six independent Mini Vibe scopes. A complete original five-round arcade target championship with a real shared 3D tower, reflective glass panes, moving mouse/fish/bell targets and breakable windows. The main TV can show the shared arena or six simultaneous player cameras. This executable build uses a 3D tower/city, illustrated kitty helicopter billboards at their actual flight positions, generated room textures and procedural fallback models; the earlier concept illustration is not a screenshot.

## Install

Requires your existing **Shared Mini Vibe Controls** PC platform and **Arcadium universal v16 app**. **This game does not include or require a game-specific APK.** All game mappings are in the PC code.

1. Exit the open game and extract the entire ZIP.
2. Double-click **START_INSTALL.cmd** on the PC and select **Arcadium_OS_COMPACT**. It adds one game, one scoped route wrapper and its carousel registration. It preserves the main server, shared native input route, pairing, Home, approved existing card artwork and all other games.
3. Restart Windows once to load the new game route. Open Arcadium normally and choose **SNIPER KITTY** from Games.
4. Connect the six Mini Vibes normally using the existing universal app. **A joins your colour; START launches.** Empty seats are CPU opponents. A can explicitly take over your own CPU seat during a round; it does not restore lost hearts or move you to another colour.

If the shared PC platform is missing, the installer stops before changes. Install that platform first; do not reinstall an old per-game controller app. The package has checksums, targeted backups under `arcadium_backups/sniper_kitty_v1_*` and guarded game-only rollback in the installer. Repeated installation updates the same carousel entry. Unknown bridge shapes/duplicate registrations are refused.

## Controls

| Input | Pilot | Ghost pilot |
|---|---|---|
| Hold D-pad | Aim left/right/up/down; release stops aim | Aim your tag |
| Hold L1 / R1 | Steer helicopter around tower | Same |
| A | Fire one shot | Tag a target for an assist |
| B | Toggle wide/zoom scope | Next power |
| X | Reload | Previous power |
| Y | Focus / one glass-piercing shot | Cast selected power |
| START | Join/start, pause/resume, next round/replay | Same |
| SELECT | Leave lobby seat | No extra round action |

The helicopters automatically orbit and cycle altitude so every colour can reach all floors over a round. The shoulders add steering; the D-pad controls the scope independently. Focus steadies your own flight for three seconds, reduces aiming speed and lets your next shot pierce glass. It recharges in twelve active seconds. Zoom also reduces aim speed for precision. Native state is the existing isolated I1 feed; ordinary A/B/X/Y/START actions remain on their unchanged channel and do not double-fire from held-state packets.

PC: arrow keys aim P1; Q/E steer; Space or F fires; B zooms; R reloads; Y focuses; Enter starts/pauses; Escape pauses/resumes. Local gamepads use D-pad/stick, LB/RB and A/B/X/Y/START. Mouse joins lobby seats and can launch a solo match with five CPUs. The TV's SIX SCOPES button switches to six live camera views; DETAIL + raises rendering resolution where hardware allows.

## Targets, glass and scoring

First shot breaks a window pane (+25). A second accurate shot scores the target behind it. A focused piercing shot can do both. Mouse targets score160, fish220 and golden bells500, plus combo and perfect-centre bonuses. Combos cap at five and reset on a miss. Eight-round magazine, .32s shot cooldown and 1.25s reload; empty magazines begin reloading automatically.

The hazard diamond with a red X is an alarm: hitting it loses a heart and100 points. Normal targets are bullseye robots/cutouts, never people, animals or the other pilots. Three alarm strikes turn your helicopter spectral for the rest of the round. You keep steering and aiming. A tags a target: when another pilot hits it you get assist points. Ghost powers are Reveal Targets (temporarily exposes glass), Slow Field and Lucky Tag (one enhanced assist), each with a shared six-second cooldown. Tagged targets get a coloured ring so other pilots can spot assist opportunities. Slowing changes target motion rate without a position jump.

Five ninety-second rounds: Sunset Glass, Neon Penthouse, Skyline Storm, Golden Bell Run and Midnight Riot. Orbit speed/target motion and bell frequency vary. If every pilot becomes a ghost, the round redeploys after five seconds instead of leaving everyone waiting. Between rounds the scores and ranking stay, the glass/targets reset and every kitty gets a fresh helicopter, three hearts and full ammo. Final results rank cumulative score, with precision as a tie-break. START replays the complete match.

## Six personal screens

Each colour receives its own actual camera rendered by the PC from the shared world, not a second simulation or the entire TV screen. The720×720 personal screen shows the pilot portrait, crosshair, scope zoom, hearts, ammo/reload, combo and focus status. Ghosts get their own power/assist panel. The PC renders connected seats in rotation and sends JPEGs through the existing8787 server. Frames expire after2.5 seconds. Browser performance, six-device Wi-Fi throughput and physical control acceptance need venue testing; no specific frame rate is promised.

The PC runs one authority; the viewer draws only its colour's fresh frame and has no fake on-screen input buttons. Native direction states expire safely on stale input. Pause/hidden window clears local controls and pauses the match while retaining only this game's lease. Instance ownership prevents a stale page exit from clearing a newer page's lease. A hidden old page cannot reclaim a different game. Exit returns controllers to Command Deck without changing pairing.

All art, vendor code and audio are local/offline. Chrome with WebGL and hardware acceleration is required. If WebGL cannot initialize, the game displays a clear message. Sound unlocks through a browser interaction; use SOUND ON if autoplay is blocked. VERIFY_SNIPER_KITTY.py saves a read-only connection report while the game is open.
