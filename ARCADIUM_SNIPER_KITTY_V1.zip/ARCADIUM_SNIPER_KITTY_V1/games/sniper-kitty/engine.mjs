export const COLORS=['#ff3b64','#43a6ff','#52ec91','#ffd64d','#ff79d4','#eef6ff'];
export const NAMES=['RED','BLUE','GREEN','YELLOW','PINK','WHITE'];
export const R=20,COLS=24,FLOORS=9,FH=6,TAU=Math.PI*2;
export const ROUNDS=[{name:'SUNSET GLASS',sky:'#dd7e9b',orbit:.032,motion:.65},{name:'NEON PENTHOUSE',sky:'#72549b',orbit:.04,motion:.9},{name:'SKYLINE STORM',sky:'#547995',orbit:.045,motion:1.1},{name:'GOLDEN BELL RUN',sky:'#e8aa79',orbit:.05,motion:1.2},{name:'MIDNIGHT RIOT',sky:'#343d78',orbit:.055,motion:1.4}];
export const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));export const wrap=a=>(a%TAU+TAU)%TAU;export const delta=(a,b)=>Math.atan2(Math.sin(a-b),Math.cos(a-b));
export function createGame(seed=41026){let rng=seed>>>0;const random=()=>{rng=(Math.imul(rng,1664525)+1013904223)>>>0;return rng/4294967296;},rnd=(a,b)=>a+(b-a)*random();
 const S={mode:'lobby',round:0,t:0,time:90,countdown:0,joined:Array(6).fill(false),players:[],targets:[],glass:Array(COLS*FLOORS).fill(true),events:[],history:[],roundWait:0,revealUntil:0,slowUntil:0,winner:null};
 function player(i){return{id:i,human:S.joined[i],score:0,roundScore:0,hp:3,ammo:8,reload:0,cooldown:0,zoom:false,aimX:0,aimY:0,orbit:0,flightTime:0,focus:0,focusCharge:false,abilityCd:0,ghost:false,power:0,luckyUntil:0,combo:0,stats:{shots:0,hits:0,miss:0,glass:0,perfect:0,assists:0},botT:0,botTarget:-1,flash:0};}
 S.players=Array.from({length:6},(_,i)=>player(i));
 function emit(type,data={}){S.events.push({type,at:S.t,...data});if(S.events.length>100)S.events.shift();}
 function pose(i){const p=S.players[i],a=wrap(i*TAU/6+S.t*(ROUNDS[S.round]?.orbit||.032)+p.orbit);return{x:Math.cos(a)*(38+(i%2)*3),y:29+Math.sin(p.flightTime*.07+i*TAU/6)*16,z:Math.sin(a)*(38+(i%2)*3),a};}
 function aim(i){const p=S.players[i],h=pose(i),theta=wrap(h.a-p.aimX),y=clamp(h.y+p.aimY,2,55);return{x:Math.cos(theta)*R,y,z:Math.sin(theta)*R,theta};}
 function pane(theta,y){return clamp(Math.floor((y-1)/FH),0,FLOORS-1)*COLS+Math.floor(wrap(theta)/TAU*COLS)%COLS;}
 function targetPosition(t){const phase=t.phase+t.seed;return{theta:(t.window%COLS+.5)*TAU/COLS+Math.sin(phase)*.015,y:Math.floor(t.window/COLS)*FH+4+Math.sin(phase*.8)*.65};}
 function spawn(t){const occupied=new Set(S.targets.filter(q=>q!==t&&q.alive).map(q=>q.window));let w;for(let n=0;n<400;n++){w=Math.floor(random()*COLS*FLOORS);if(!occupied.has(w))break;}const type=random();t.window=w;t.type=type<.1?'alarm':type<(S.round===3?.36:.2)?'bell':type<.52?'fish':'mouse';t.radius=t.type==='bell'?.95:1.2;t.alive=true;t.respawn=0;t.tag=null;t.seed=rnd(0,TAU);t.phase=0;}
 function beginRound(){S.mode='countdown';S.countdown=3;S.time=90;S.glass.fill(true);S.targets=[];S.revealUntil=S.slowUntil=0;for(const p of S.players){p.roundScore=0;p.hp=3;p.ammo=8;p.reload=p.cooldown=p.abilityCd=p.focus=p.combo=p.orbit=p.aimX=p.aimY=0;p.flightTime=0;p.ghost=false;p.focusCharge=false;p.luckyUntil=0;p.botT=.4;p.botTarget=-1;}
  for(let i=0;i<48;i++){const t={id:i};S.targets.push(t);spawn(t);}emit('round',{round:S.round});}
 function start(){S.players=Array.from({length:6},(_,i)=>player(i));S.round=0;S.t=0;S.history=[];S.events=[];S.winner=null;beginRound();}
 function award(i,value){const p=S.players[i];p.score+=value;p.roundScore+=value;}
 function reload(i){const p=S.players[i];if(S.mode!=='play'||p.ghost||p.reload>0||p.ammo===8)return false;p.reload=1.25;emit('reload',{i});return true;}
 function miss(p,i,point){p.combo=0;p.stats.miss++;emit('miss',{i,point});return{type:'miss'};}
 function fire(i){const p=S.players[i];if(S.mode!=='play'||p.cooldown>0||p.reload>0)return false;const point=aim(i),w=pane(point.theta,point.y),target=S.targets.find(t=>t.alive&&t.window===w),position=target?targetPosition(target):null,distance=position?Math.hypot(delta(position.theta,point.theta)*R,position.y-point.y):Infinity;
  if(p.ghost){p.cooldown=1;if(target&&target.type!=='alarm'&&distance<target.radius*1.5){const lucky=S.t<p.luckyUntil,value=Math.max(lucky?350:150,target.tag?.owner===i?target.tag.value:0);target.tag={owner:i,until:S.t+10,value};if(lucky)p.luckyUntil=0;emit('tag',{i,target:target.id,point});return{type:'tag'};}emit('miss',{i,point});return false;}
  if(p.ammo<=0){reload(i);return false;}p.ammo--;p.stats.shots++;p.cooldown=.32;p.flash=.12;emit('shot',{i,from:pose(i),point});
  if(S.glass[w]){S.glass[w]=false;p.stats.glass++;award(i,25);emit('glass',{i,window:w,point});if(!p.focusCharge){if(!p.ammo)reload(i);return{type:'glass',window:w};}}
  p.focusCharge=false;if(!target||distance>target.radius){if(!p.ammo)reload(i);return miss(p,i,point);}
  target.alive=false;target.respawn=rnd(2,4);if(target.type==='alarm'){p.hp--;p.combo=0;p.score=Math.max(0,p.score-100);p.roundScore=Math.max(0,p.roundScore-100);emit('alarm',{i,point});if(p.hp<=0){p.ghost=true;p.reload=0;p.abilityCd=1;emit('ghost',{i});}return{type:'alarm'};}
  p.combo=Math.min(5,p.combo+1);p.stats.hits++;const perfect=distance<target.radius*.34;if(perfect)p.stats.perfect++;const value=(target.type==='bell'?500:target.type==='fish'?220:160)+p.combo*40+(perfect?120:0);award(i,value);
  if(target.tag&&target.tag.until>S.t&&target.tag.owner!==i){award(target.tag.owner,target.tag.value);S.players[target.tag.owner].stats.assists++;emit('assist',{i:target.tag.owner,value:target.tag.value});}
  emit('hit',{i,point,value,perfect,type:target.type,combo:p.combo});if(!p.ammo)reload(i);return{type:'hit',value,perfect};}
 function ability(i){const p=S.players[i];if(S.mode!=='play'||p.abilityCd>0)return false;if(p.ghost){p.abilityCd=6;if(p.power===0)S.revealUntil=S.t+4;else if(p.power===1)S.slowUntil=S.t+4;else p.luckyUntil=S.t+10;emit('power',{i,power:['REVEAL','SLOW FIELD','LUCKY TAG'][p.power]});}
  else{p.focus=3;p.focusCharge=true;p.abilityCd=12;emit('power',{i,power:'FOCUS / PIERCE'});}return true;}
 function finishRound(){const ranks=[...S.players].sort((a,b)=>b.roundScore-a.roundScore||a.id-b.id);ranks.forEach((p,n)=>award(p.id,[500,300,150,75,50,25][n]));S.history.push({round:S.round,scores:S.players.map(p=>p.roundScore),winner:ranks[0].id});S.mode='round-end';S.roundWait=7;emit('round-end',{winner:ranks[0].id});if(S.round===4){S.mode='results';S.winner=[...S.players].sort((a,b)=>b.score-a.score||b.stats.perfect-a.stats.perfect||a.id-b.id)[0].id;emit('results',{winner:S.winner});}}
 function next(){if(S.mode!=='round-end')return false;S.round++;beginRound();return true;}
 function button(i,b){const p=S.players[i];if(b==='START'){if(S.mode==='lobby'){S.joined[i]=true;start();}else if(S.mode==='play')S.mode='pause';else if(S.mode==='pause')S.mode='play';else if(S.mode==='round-end')next();else if(S.mode==='results')start();return;}
  if(S.mode==='lobby'){if(b==='A'){S.joined[i]=!S.joined[i];p.human=S.joined[i];}if(b==='SELECT'){S.joined[i]=false;p.human=false;}return;}
  if(S.mode!=='play')return;if(!p.human){if(b==='A'){p.human=true;S.joined[i]=true;p.botTarget=-1;emit('join',{i});}return;}if(b==='A')fire(i);if(b==='B'){if(p.ghost)p.power=(p.power+1)%3;else p.zoom=!p.zoom;}if(b==='X'){if(p.ghost)p.power=(p.power+2)%3;else reload(i);}if(b==='Y')ability(i);}
 function aimFor(i,t){const h=pose(i),q=targetPosition(t);return{x:clamp(-delta(q.theta,h.a),-.65,.65),y:clamp(q.y-h.y,-17,17)};}
 function bot(p,dt){p.botT-=dt;if(p.botT<=0){p.botT=rnd(.3,.7);const h=pose(p.id),visible=S.targets.filter(t=>t.alive&&t.type!=='alarm'&&Math.abs(delta(targetPosition(t).theta,h.a))<.6&&Math.abs(targetPosition(t).y-h.y)<16);p.botTarget=visible.length?visible[Math.floor(random()*visible.length)].id:-1;}
  const t=S.targets[p.botTarget];if(!t?.alive)return;const a=aimFor(p.id,t),rate=Math.min(1,dt*3);p.aimX+=(a.x-p.aimX)*rate;p.aimY+=(a.y-p.aimY)*rate;if(Math.abs(a.x-p.aimX)<.018&&Math.abs(a.y-p.aimY)<.45&&p.cooldown<=0){fire(p.id);p.cooldown=Math.max(p.cooldown,rnd(.5,.95));}if(p.ghost&&p.abilityCd<=0)ability(p.id);}
 function update(dt,masks=Array(6).fill(0)){if(!Number.isFinite(dt)||dt<0)return;dt=Math.min(.1,dt);if(S.mode==='pause'||S.mode==='results'||S.mode==='lobby')return;S.t+=dt;if(S.mode==='round-end'){S.roundWait-=dt;if(S.roundWait<=0)next();return;}
  if(S.mode==='countdown'){S.countdown-=dt;if(S.countdown<=0){S.mode='play';S.countdown=0;}return;}S.time=Math.max(0,S.time-dt);
  for(const p of S.players){p.cooldown=Math.max(0,p.cooldown-dt);p.abilityCd=Math.max(0,p.abilityCd-dt);p.focus=Math.max(0,p.focus-dt);p.flash=Math.max(0,p.flash-dt);if(p.reload>0){p.reload=Math.max(0,p.reload-dt);if(!p.reload)p.ammo=8;}
   if(p.focus>0)p.orbit-=ROUNDS[S.round].orbit*dt;else p.flightTime+=dt;
   if(p.human){const m=masks[p.id]||0,precision=(p.zoom?.48:1)*(p.focus>0?.5:1);p.aimX=clamp(p.aimX+((m&8?1:0)-(m&4?1:0))*.36*precision*dt,-.65,.65);p.aimY=clamp(p.aimY+((m&1?1:0)-(m&2?1:0))*11*precision*dt,-17,17);p.orbit+=((m&2048?1:0)-(m&1024?1:0))*.38*dt;}else bot(p,dt);}
  if(S.time>5&&S.players.every(p=>p.ghost)){S.time=5;emit('all-ghosts');}
  for(const t of S.targets){t.phase+=dt*(S.t<S.slowUntil?.23:1)*ROUNDS[S.round].motion;if(!t.alive){t.respawn-=dt;if(t.respawn<=0)spawn(t);}if(t.tag&&t.tag.until<S.t)t.tag=null;}if(S.time<=0)finishRound();}
 return{S,start,update,button,fire,reload,ability,pose,aim,pane,targetPosition,aimFor,next,finishRound,drainEvents(){return S.events.splice(0);}};
}
