from pathlib import Path
import argparse,importlib.util,sys,json,time
from http.server import ThreadingHTTPServer
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'ghost-bubble/tests'))
spec=importlib.util.spec_from_file_location('shared_native_reference',ROOT/'ghost-bubble/tests/native_transport.py');ref=importlib.util.module_from_spec(spec);spec.loader.exec_module(ref)
sys.path.insert(0,str(ROOT/'boop'));import boop_routes
sys.path.insert(0,str(ROOT/'universal-mini-vibe-input'));import universal_input_routes
sys.path.insert(0,str(ROOT/'sniper-kitty'));import sniper_kitty_routes
from types import SimpleNamespace
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--server-reference',type=Path,required=True);a=ap.parse_args();native=ref.receiver(a.server_reference);Real=native['ExactReceiver'];bridge,Base=ref.harness.modules();Parent=sniper_kitty_routes.wrap_sniper_kitty_handler(universal_input_routes.wrap_native_input_handler(boop_routes.wrap_boop_handler(Base)))
 class Handler(Parent):
  def log_message(self,*args):pass
  json_out=Real.json_out;body_json=Real.body_json
  def do_POST(self):
   if self.path=='/api/vibe/input':
    Real.do_POST(self)
    with native['VIBE_LOCK']:self.server.events={'latest':native['VIBE_SEQUENCE'],'events':[dict(e) for e in native['VIBE_EVENTS']],'slots':[dict(s,connected=time.time()-s['lastSeen']<8) for s in native['VIBE_SLOTS'].values()]}
    return
   if self.path=='/__test/reset':
    self.rfile.read(int(self.headers.get('Content-Length',0)))
    with native['VIBE_LOCK']:native['VIBE_SEQUENCE']=0;native['VIBE_EVENTS'].clear();universal_input_routes.EVENTS.clear();universal_input_routes.SEQUENCE=0;universal_input_routes.SLOTS.clear()
    self.server.events={'latest':0,'events':[],'slots':[]};self.send_response(204);self.send_header('Content-Length','0');self.end_headers();return
   if self.path=='/__test/events':
    self.server.events=json.loads(self.rfile.read(int(self.headers['Content-Length'])));self.send_response(204);self.send_header('Content-Length','0');self.end_headers();return
   return super().do_POST()
 server=ThreadingHTTPServer(('127.0.0.1',8787),Handler);server.events={'latest':0,'events':[],'slots':[]};server.native_app=SimpleNamespace(VIBE_PAIR_TOKEN=native['VIBE_PAIR_TOKEN'],PINK_DEVICE_IP=None);print('Sniper Kitty exact native receiver and prior games on8787',flush=True);server.serve_forever()
