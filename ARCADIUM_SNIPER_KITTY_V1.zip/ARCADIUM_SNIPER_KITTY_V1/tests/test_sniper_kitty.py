import base64,hashlib,importlib.util,json,sys,tempfile,threading,time,unittest,urllib.request,urllib.error,zipfile
from pathlib import Path
from http.server import ThreadingHTTPServer
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import update_sniper_kitty as updater
import sniper_kitty_routes as routes
spec=importlib.util.spec_from_file_location('kitty_shared_reference',ROOT.parent/'universal-mini-vibe-input/tests/harness.py');ref=importlib.util.module_from_spec(spec);spec.loader.exec_module(ref)
class Install(unittest.TestCase):
 def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);self.seed()
 def tearDown(self):self.tmp.cleanup()
 def seed(self):
  (self.root/'data').mkdir();(self.root/'data/arcadium.json').write_text(json.dumps({'games':[{'id':'sniper-kitty','name':'SNIPER KITTY','image':'approved-card.png','custom':'KEEP'},{'id':'rc-trigger-racing','controls':'KEEP TRIGGERS'}]}))
  (self.root/'arcadium_server.py').write_text('import arcadium_game_bridge\n# main server and pairing fixes remain untouched\n')
  (self.root/'arcadium_game_bridge.py').write_text('import threading\nfrom e3mi_routes import wrap_e3mi_handler\nfrom universal_input_routes import wrap_native_input_handler\nfrom ghost_bubble_routes import wrap_ghost_bubble_handler\nfrom boop_routes import wrap_boop_handler\nACTIVE_WEB_GAME={"game":None,"until":0}\nACTIVE_LOCK=threading.RLock()\ndef bridge(Base):\n    class GameBridge(Base):pass\n    return wrap_native_input_handler(wrap_boop_handler(wrap_ghost_bubble_handler(wrap_e3mi_handler(GameBridge))))\n')
  (self.root/'e3mi_routes.py').write_text('def wrap_e3mi_handler(Base):return Base\n')
  for source,name in [('universal-mini-vibe-input','universal_input_routes.py'),('ghost-bubble','ghost_bubble_routes.py'),('boop','boop_routes.py')]:(self.root/name).write_bytes((ROOT.parent/source/name).read_bytes())
  for name,data in [('HOME.html',b'HOME PRESERVED'),('data/pink_vibe_device.json',b'PINK PAIRING'),('games/wormaldeon/index.html',b'TENNIS FIX'),('games/rc-trigger-racing/engine.mjs',b'RC FIX'),('games/arcadium-boop/index.html',b'BOOP FIX')]:
   p=self.root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 def snap(self):return {p.relative_to(self.root).as_posix():p.read_bytes() for p in self.root.rglob('*') if p.is_file()}
 def test_install_repeat_rollback_preserves_all_prior_platform(self):
  before=self.snap();first=updater.install(self.root);second=updater.install(self.root);self.assertEqual(updater.patch_bridge((self.root/'arcadium_game_bridge.py').read_text()),(self.root/'arcadium_game_bridge.py').read_text());cat=json.loads((self.root/'data/arcadium.json').read_text());self.assertEqual(len(cat['games']),2);self.assertEqual(cat['games'][0]['image'],'approved-card.png');self.assertEqual(cat['games'][0]['custom'],'KEEP');self.assertEqual(cat['games'][0]['miniVibeUrl'],'/games/sniper-kitty/personal/vibe.html');updater.rollback(second);updater.rollback(first)
  for name,b in before.items():
   if name=='data/arcadium.json':self.assertEqual(json.loads((self.root/name).read_text()),json.loads(b))
   else:self.assertEqual((self.root/name).read_bytes(),b,name)
 def test_guard_and_fresh_registration(self):
  cat={'games':[{'id':'other','name':'OTHER'}]};updater.registration(cat);self.assertEqual(len(cat['games']),2);self.assertEqual(cat['games'][1]['id'],'sniper-kitty');cat['games'].append({'id':'copy','name':'Sniper Kitty'});self.assertRaises(RuntimeError,updater.registration,cat)
  before=self.snap();(self.root/'universal_input_routes.py').unlink();self.assertRaises(RuntimeError,updater.install,self.root);self.assertFalse((self.root/'games/sniper-kitty').exists());(self.root/'universal_input_routes.py').write_bytes(before['universal_input_routes.py']);(self.root/'arcadium_game_bridge.py').write_text('def bridge(Base):return Base\n');self.assertRaises(RuntimeError,updater.install,self.root)
 def test_exact_zip_no_apk_integrity_and_later_edit_guard(self):
  path=ROOT.parents[1]/'downloads/ARCADIUM_SNIPER_KITTY_V1.zip'
  with tempfile.TemporaryDirectory() as d:
   with zipfile.ZipFile(path) as z:
    self.assertFalse(any(n.endswith('.apk') for n in z.namelist()));z.extractall(d)
   package=Path(d)/path.stem;spec=importlib.util.spec_from_file_location('kitty_exact_release',package/'update_sniper_kitty.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);one=m.install(self.root);two=m.install(self.root);m.rollback(two);m.rollback(one);(package/'games/sniper-kitty/main.mjs').write_text('corrupt');self.assertRaises(RuntimeError,m.install,self.root)
  one=updater.install(self.root);(self.root/'games/sniper-kitty/main.mjs').write_text('later work');self.assertRaises(RuntimeError,updater.rollback,one)
class Routes(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  bridge,Parent=ref.ref.harness.modules();cls.H=routes.wrap_sniper_kitty_handler(Parent);cls.server=ThreadingHTTPServer(('127.0.0.1',0),cls.H);cls.server.events={'latest':0,'events':[],'slots':[]};cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True);cls.thread.start();cls.base='http://127.0.0.1:'+str(cls.server.server_port)
 @classmethod
 def tearDownClass(cls):cls.server.shutdown();cls.server.server_close();cls.thread.join()
 def req(self,path,data=None):
  try:
   with urllib.request.urlopen(urllib.request.Request(self.base+path,data=None if data is None else json.dumps(data).encode(),headers={'Content-Type':'application/json'})) as r:return r.status,r.read()
  except urllib.error.HTTPError as e:return e.code,e.read()
 def test_six_scopes_static_stale_and_owner_handoff(self):
  self.assertEqual(self.req('/arcadium-vibe/activate/sniper-kitty',{'owner':'first'})[0],200)
  for i,color in enumerate(routes.COLORS):
   mode=json.loads(self.req('/api/vibe/mode?color='+color)[1]);self.assertEqual(mode['game'],'sniper-kitty');self.assertEqual(mode['nativeState'],1);image=b'\xff\xd8'+color.encode();self.assertEqual(self.req('/arcadium-kitty/sniper-kitty/frame',{'owner':'first','seat':i+1,'image':base64.b64encode(image).decode()})[0],200);self.assertEqual(self.req('/arcadium-kitty/sniper-kitty/frame?color='+color),(200,image))
  for path in ['index.html','main.mjs','engine.mjs','world.mjs','native-input.js','personal/vibe.html','assets/cats.png','assets/rooms.png','assets/sky.png','vendor/three.module.js','card.svg']:self.assertEqual(self.req('/games/sniper-kitty/'+path)[0],200,path)
  self.assertEqual(self.req('/games/sniper-kitty/%2e%2e/%2e%2e/update_sniper_kitty.py')[0],404);routes.FRAMES[1]=(time.monotonic()-4,b'old');self.assertEqual(self.req('/arcadium-kitty/sniper-kitty/frame?color=red')[0],503)
  self.req('/arcadium-vibe/activate/sniper-kitty',{'owner':'second'});self.assertEqual(self.req('/arcadium-kitty/sniper-kitty/frame?color=blue')[0],503);self.req('/arcadium-vibe/activate/sniper-kitty',{'owner':'first','active':False});self.assertEqual(json.loads(self.req('/api/vibe/mode?color=red')[1])['game'],'sniper-kitty');self.assertEqual(self.req('/arcadium-vibe/activate/sniper-kitty',{'owner':'first','renew':True})[0],409)
  self.req('/arcadium-vibe/activate/rc-trigger-racing',{});self.assertEqual(self.req('/arcadium-vibe/activate/sniper-kitty',{'owner':'second','renew':True})[0],409);self.req('/arcadium-vibe/activate/sniper-kitty',{'owner':'second','active':False});self.assertEqual(json.loads(self.req('/api/vibe/mode?color=red')[1])['game'],'rc-trigger-racing')
if __name__=='__main__':unittest.main()
