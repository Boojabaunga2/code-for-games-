export const COLORS=['#ff4055','#3ba9ff','#5ce786','#ffd04b','#ff6aca','#edf4ff'];
export const NAMES=['RED','BLUE','GREEN','YELLOW','PINK','WHITE'];
export const CREW=['CAPS','DRIP','ROLLIE','SPARK','BRISTLE','GHOST'];
export const ROLES=['SPRAY-CAN ROBOT','PAINT-DROP CREATURE','ROLLER RACCOON','SPLATTER INVENTOR','PUNK PAINT CAT','MASKED PAINT THIEF'];
export const PHASES=['lobby','flip','flipReview','choose','double','doubleReview','target','duel','duelReview','draw','drawReview','pick','stealReview','feedback','results'];
export const coinPhase=p=>['flip','flipReview','double','doubleReview','duel','duelReview'].includes(p);
const clone=v=>JSON.parse(JSON.stringify(v));
export function createGame(){
 const S={phase:'lobby',paused:false,selected:Array(6).fill(true),ready:Array(6).fill(false),inv:Array.from({length:6},()=>Array(6).fill(0)),active:-1,target:-1,stealer:-1,victim:-1,choice:0,paint:-1,drawSeat:-1,queue:[],lastGhost:null,contenders:[],coinPlayers:[],coinResults:Array(6).fill(null),coinCursor:Array(6).fill(-1),flipLevel:1,winner:null,elapsed:0,round:0,message:'MEET YOUR GHOST CREW',detail:'Real coins. Real bag. Bank four ghosts of your own color.',log:[],reaction:Array(6).fill('idle'),reactUntil:Array(6).fill(0),tauntUntil:Array(6).fill(0),stats:Array.from({length:6},()=>({draws:0,steals:0,robbed:0})),serial:0,next:'flip'};
 const events=[],history=[],held=Array(6).fill(0),repeat=Array(6).fill(0);
 const players=()=>S.selected.flatMap((on,i)=>on?[i]:[]),total=i=>S.inv[i].reduce((a,b)=>a+b,0),targets=()=>players().filter(i=>i!==S.active&&(total(i)>0||total(S.active)>0)),paints=()=>S.victim<0?[]:S.inv[S.victim].flatMap((n,i)=>n>0?[i]:[]);
 function checkpoint(){history.push(clone(S));if(history.length>64)history.shift();}
 function log(m){S.log.unshift(m);if(S.log.length>6)S.log.pop();}
 function react(i,r,seconds=2){if(i<0)return;S.reaction[i]=r;S.reactUntil[i]=S.elapsed+seconds;}
 function enter(p,m,d=''){S.phase=p;S.message=m;S.detail=d;S.serial++;held.fill(0);repeat.fill(0);}
 function coins(p,participants,title){S.coinPlayers=participants.slice();S.coinResults.fill(null);S.coinCursor.fill(-1);enter(p,title,'Flip your REAL coin. L = GREEN, R = RED, then A to submit.');}
 function flip(){S.active=-1;S.target=-1;S.stealer=-1;S.victim=-1;S.choice=0;S.round++;S.flipLevel=1;S.contenders=players();coins('flip',S.contenders,'EVERYONE — FLIP YOUR REAL COIN!');}
 function chooseMenu(){enter('choose','YOUR MOVE, '+CREW[S.active],'Draw from the real bag, risk Double Up, or go head-to-head.');}
 function win(i){S.winner=i;react(i,'win',999);enter('results',CREW[i]+' WINS!',NAMES[i]+' collected four ghosts of their own color!');events.push({type:'winner',seat:i});}
 function feedback(m,d,next='flip'){S.next=next;enter('feedback',m,d+'  ·  A to continue.');}
 function nextDraw(){S.drawSeat=S.queue[0];S.paint=-1;enter('draw',CREW[S.drawSeat]+' — REACH INTO THE REAL BAG','Draw ONE real ghost. Select its actual color, then A to review.');}
 function startDraws(seats){S.queue=seats.slice();nextDraw();}
 function coinEntry(i,color){if(S.paused||!coinPhase(S.phase)||S.phase.endsWith('Review')||!S.coinPlayers.includes(i)||!['green','red'].includes(color))return false;S.coinCursor[i]=color==='green'?0:1;return true;}
 function submitCoin(i){if(!S.coinPlayers.includes(i)||S.coinCursor[i]<0||S.coinResults[i]!==null)return false;S.coinResults[i]=S.coinCursor[i]===0?'green':'red';log(CREW[i]+' entered '+S.coinResults[i].toUpperCase());if(S.coinPlayers.every(k=>S.coinResults[k]!==null))enter(S.phase+'Review','CHECK THE REAL FLIPS','B edits your entry. A reveals when the group agrees.');return true;}
 function reveal(){if(S.paused||!['flipReview','doubleReview','duelReview'].includes(S.phase))return false;checkpoint();
  if(S.phase==='flipReview'){const green=S.coinPlayers.filter(i=>S.coinResults[i]==='green');if(green.length===1){S.active=green[0];react(S.active,'happy');log(CREW[S.active]+' wins the real flip-off');chooseMenu();events.push({type:'turn',seat:S.active});}else{S.flipLevel++;if(green.length)S.contenders=green;coins('flip',S.contenders,green.length?'GREEN COINS — FLIP AGAIN!':'ALL RED — SAME PLAYERS FLIP AGAIN');}return true;}
  if(S.phase==='doubleReview'){const green=S.coinResults[S.active]==='green';react(S.active,green?'happy':'tantrum',3);log(CREW[S.active]+(green?' doubled up: two real bag draws':' flipped RED: ALL players draw one'));startDraws(green?[S.active,S.active]:players());return true;}
  const[a,b]=S.coinPlayers;if(S.coinResults[a]===S.coinResults[b]){coins('duel',[a,b],'MATCHING COINS — BOTH FLIP AGAIN!');return true;}
  S.stealer=S.coinResults[a]==='green'?a:b;S.victim=S.stealer===a?b:a;react(S.stealer,'happy');react(S.victim,'panic',6);log(CREW[S.stealer]+' wins the head-to-head');if(total(S.victim)===0){feedback(CREW[S.stealer]+' WINS THE DUEL','The loser has no ghosts to transfer. No ghost is invented.');return true;}S.paint=paints()[0];enter('pick',CREW[S.stealer]+' — CHOOSE ONE GHOST','Select a ghost from '+CREW[S.victim]+'’s real collection. A to review.');return true;
 }
 function choose(n){if(S.paused||S.phase!=='choose'||!Number.isInteger(n)||n<0||n>2)return false;if(n===2&&!targets().length){S.detail='No ghosts to contest yet. Draw from the bag or Double Up.';return false;}checkpoint();S.choice=n;if(n===0)startDraws([S.active]);else if(n===1)coins('double',[S.active],'DOUBLE UP — FLIP YOUR REAL COIN');else{S.target=targets()[0];enter('target','CHOOSE YOUR HEAD-TO-HEAD OPPONENT','L / R to choose. A invites both players to flip real coins.');}return true;}
 function lock(){if(S.paused||S.phase!=='target'||!targets().includes(S.target))return false;checkpoint();coins('duel',[S.active,S.target],CREW[S.active]+' VS '+CREW[S.target]+' — REAL FLIPS!');return true;}
 function bank(){if(S.paused||S.phase!=='drawReview'||S.paint<0)return false;checkpoint();const i=S.drawSeat,c=S.paint;S.inv[i][c]++;S.stats[i].draws++;S.lastGhost={seat:i,color:c};S.queue.shift();react(i,c===i?'happy':'roll',3);events.push({type:'ghost',seat:i,color:c});log(CREW[i]+' banked a real '+NAMES[c]+' ghost');if(S.inv[i][i]>=4)win(i);else feedback(NAMES[c]+' GHOST BANKED',CREW[i]+' keeps the actual ghost',S.queue.length?'nextDraw':'flip');return true;}
 function steal(){if(S.paused||S.phase!=='stealReview'||S.inv[S.victim]?.[S.paint]<=0)return false;checkpoint();const a=S.stealer,v=S.victim,c=S.paint;S.inv[v][c]--;S.inv[a][c]++;S.stats[a].steals++;S.stats[v].robbed++;react(a,'taunt',3);react(v,'tantrum',3);events.push({type:'steal',seat:a,target:v,color:c});log(CREW[a]+' took '+NAMES[c]+' from '+CREW[v]);if(S.inv[a][a]>=4)win(a);else feedback('GHOST TRANSFER RECORDED',CREW[v]+' hands the '+NAMES[c]+' ghost to '+CREW[a]);return true;}
 function advance(){if(S.paused||S.phase!=='feedback')return false;checkpoint();if(S.next==='nextDraw')nextDraw();else flip();return true;}
 function move(i,d){if(S.paused||!S.selected[i])return;const delta=d<0?-1:1;if(coinPhase(S.phase)&&!S.phase.endsWith('Review')&&S.coinPlayers.includes(i)&&S.coinResults[i]===null){S.coinCursor[i]=delta<0?0:1;return;}if(i===S.active&&S.phase==='choose')S.choice=(S.choice+delta+3)%3;else if(i===S.active&&S.phase==='target'){const t=targets();S.target=t[(t.indexOf(S.target)+delta+t.length)%t.length];}else if(i===S.drawSeat&&S.phase==='draw')S.paint=S.paint<0?(delta<0?5:0):(S.paint+delta+6)%6;else if(i===S.stealer&&S.phase==='pick'){const p=paints();S.paint=p[(p.indexOf(S.paint)+delta+p.length)%p.length];}}
 function button(i,b){if(!Number.isInteger(i)||i<0||i>5||(!S.selected[i]&&S.phase!=='lobby'))return false;
  if(S.phase==='lobby'){if(b==='A'){S.selected[i]=true;S.ready[i]=true;}else if(b==='B'){S.selected[i]=!S.selected[i];S.ready[i]=false;}else if(b==='START')return start();return true;}
  if(b==='START'){if(S.phase==='results')return start();S.paused=!S.paused;return true;}if(S.paused)return false;
  if(b==='X'||b==='Y'){if(S.elapsed>=S.tauntUntil[i]){react(i,'taunt',1.4);S.tauntUntil[i]=S.elapsed+3;}return true;}
  if(b==='L1'||b==='R1')return move(i,b==='L1'?-1:1);
  if(b==='GREEN'||b==='RED')return coinEntry(i,b.toLowerCase());
  if(/^COLOR_[0-5]$/.test(b)){if(S.phase==='draw'&&i===S.drawSeat){S.paint=Number(b.slice(-1));return true;}if(S.phase==='pick'&&i===S.stealer&&S.inv[S.victim][Number(b.slice(-1))]>0){S.paint=Number(b.slice(-1));return true;}return false;}
  if(b==='B'){
   if(coinPhase(S.phase)&&S.coinPlayers.includes(i)){if(S.phase.endsWith('Review'))enter(S.phase.slice(0,-6),'EDIT YOUR REAL FLIP','L = GREEN, R = RED; A submits.');S.coinResults[i]=null;return true;}
   if(S.phase==='drawReview'&&i===S.drawSeat){enter('draw','CORRECT YOUR BAG COLOR','Choose the color of the actual ghost. A to review.');return true;}
   if(S.phase==='stealReview'&&i===S.stealer){enter('pick','CORRECT THE GHOST TO TRANSFER','Choose an available ghost. A to review.');return true;}
   if(S.phase==='target'&&i===S.active){S.target=-1;chooseMenu();return true;}return false;
  }
  if(b!=='A')return false;
  if(coinPhase(S.phase)&&S.coinPlayers.includes(i)){if(S.phase.endsWith('Review'))return reveal();return submitCoin(i);}
  if(S.phase==='choose'&&i===S.active)return choose(S.choice);
  if(S.phase==='target'&&i===S.active)return lock();
  if(S.phase==='draw'&&i===S.drawSeat&&S.paint>=0){enter('drawReview','CONFIRM YOUR REAL BAG DRAW',CREW[i]+' drew '+NAMES[S.paint]+'. A banks it; B corrects it.');return true;}
  if(S.phase==='drawReview'&&i===S.drawSeat)return bank();
  if(S.phase==='pick'&&i===S.stealer){enter('stealReview','CONFIRM THE PHYSICAL TRANSFER',CREW[S.victim]+' gives '+NAMES[S.paint]+' to '+CREW[S.stealer]+'. A records; B edits.');return true;}
  if(S.phase==='stealReview'&&i===S.stealer)return steal();
  if(S.phase==='feedback')return advance();return false;
 }
 function start(){if(players().length<2)return false;checkpoint();S.inv=Array.from({length:6},()=>Array(6).fill(0));S.stats=Array.from({length:6},()=>({draws:0,steals:0,robbed:0}));S.reaction.fill('idle');S.reactUntil.fill(0);S.tauntUntil.fill(0);S.winner=null;S.queue=[];S.lastGhost=null;S.paused=false;S.round=0;S.elapsed=0;S.log=[];log('IRL coins and bag only. First to four ghosts of your own color!');flip();return true;}
 function update(dt,masks=[]){dt=Math.max(0,Math.min(Number.isFinite(dt)?dt:0,.25));if(S.paused)return;S.elapsed+=dt;for(let i=0;i<6;i++){if(S.reactUntil[i]<S.elapsed)S.reaction[i]='idle';const m=masks[i]||0,d=m&5?-1:m&10?1:0;if(d){repeat[i]-=dt;if(m!==held[i]||repeat[i]<=0){move(i,d);repeat[i]=m!==held[i]?.38:.18;}}else repeat[i]=0;held[i]=m;}}
 function undo(){if(!history.length)return false;const n=S.serial+1,previous=history.pop();Object.assign(S,previous,{serial:n,paused:true});held.fill(0);repeat.fill(0);events.splice(0);return true;}
 function snapshot(){return{version:2,state:clone(S),history:clone(history)};}
 function valid(s){return s&&PHASES.includes(s.phase)&&typeof s.paused==='boolean'&&Array.isArray(s.selected)&&s.selected.length===6&&s.selected.every(v=>typeof v==='boolean')&&Array.isArray(s.inv)&&s.inv.length===6&&s.inv.every(row=>Array.isArray(row)&&row.length===6&&row.every(n=>Number.isInteger(n)&&n>=0&&n<=999))&&['active','target','stealer','victim','drawSeat'].every(k=>Number.isInteger(s[k])&&s[k]>=-1&&s[k]<=5)&&Number.isInteger(s.serial)&&s.serial>=0&&Number.isInteger(s.paint)&&s.paint>=-1&&s.paint<6&&Array.isArray(s.queue)&&s.queue.length<=6&&s.queue.every(n=>Number.isInteger(n)&&n>=0&&n<6)&&['coinPlayers','contenders'].every(k=>Array.isArray(s[k])&&s[k].length<=6&&s[k].every(n=>Number.isInteger(n)&&n>=0&&n<6))&&['coinResults','coinCursor','reaction','reactUntil','ready','stats','tauntUntil'].every(k=>Array.isArray(s[k])&&s[k].length===6)&&s.coinResults.every(v=>[null,'green','red'].includes(v))&&s.coinCursor.every(v=>[-1,0,1].includes(v))&&s.stats.every(v=>v&&['draws','steals','robbed'].every(k=>Number.isInteger(v[k])&&v[k]>=0))&&Array.isArray(s.log)&&s.log.every(v=>typeof v==='string')&&typeof s.message==='string'&&typeof s.detail==='string';}
 function restore(data){if(data?.version!==2||!valid(data.state)||!Array.isArray(data.history)||data.history.length>64||!data.history.every(valid))return false;const n=Math.max(S.serial,data.state.serial)+1;Object.assign(S,clone(data.state),{serial:n,paused:data.state.phase!=='lobby'});history.splice(0,history.length,...clone(data.history));held.fill(0);repeat.fill(0);events.splice(0);return true;}
 return{S,start,update,button,move,choose,targets,paints,total,coinEntry,reveal,bank,steal,advance,undo,snapshot,restore,drainEvents:()=>events.splice(0),get canUndo(){return history.length>0;},get rollSeat(){return S.drawSeat;},lobby(){checkpoint();S.paused=false;S.active=-1;S.target=-1;enter('lobby','MEET YOUR GHOST CREW','Real coins. Real bag. Four ghosts of your own color wins.');}};
}
