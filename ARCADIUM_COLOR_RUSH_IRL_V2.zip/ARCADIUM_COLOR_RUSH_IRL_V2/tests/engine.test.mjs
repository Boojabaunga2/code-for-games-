import assert from'node:assert/strict';import{createGame}from'../games/color-rush/engine.mjs';
function tick(g,t=120){for(let n=0;n<t*4;n++)g.update(.25);}
function enter(g,i,color){g.button(i,color.toUpperCase());g.button(i,'A');}
function table(g,results){for(const[i,color]of results.entries())if(g.S.coinPlayers.includes(i))enter(g,i,color);assert.ok(g.S.phase.endsWith('Review'));}
function winner(n=0){const g=createGame();g.start();for(let i=0;i<6;i++)enter(g,i,i===n?'green':'red');g.button(n,'A');assert.equal(g.S.phase,'choose');return g;}
function draw(g,seat,color){g.button(seat,'COLOR_'+color);g.button(seat,'A');assert.equal(g.S.phase,'drawReview');g.button(seat,'A');}
{
 const g=createGame();g.start();tick(g);assert.equal(g.S.phase,'flip');assert.equal(g.S.active,-1);assert.deepEqual(g.S.coinResults,Array(6).fill(null),'No result may be invented by waiting');
 for(let i=0;i<6;i++)enter(g,i,i%2===0?'green':'red');assert.equal(g.S.phase,'flipReview');g.button(1,'B');assert.equal(g.S.phase,'flip');assert.equal(g.S.coinResults[1],null);enter(g,1,'red');g.button(0,'A');assert.deepEqual(g.S.coinPlayers,[0,2,4]);
 enter(g,1,'green');assert.equal(g.S.coinResults[1],null,'Red coins sit out subsequent flip-off rounds');for(const i of[0,2,4])enter(g,i,'red');g.button(0,'A');assert.deepEqual(g.S.coinPlayers,[0,2,4],'All-red reflip retains this round participants');for(const i of[0,2,4])enter(g,i,i===4?'green':'red');g.button(4,'A');assert.equal(g.S.active,4);assert.equal(g.S.phase,'choose');assert.equal(g.S.selected.filter(Boolean).length,6,'Flip-off losses never eliminate a player from the game');
}
{
 const g=winner();g.update(.1,[8]);assert.equal(g.S.choice,1);g.update(.1,[0]);tick(g,2);assert.equal(g.S.choice,1,'Release stops held movement');g.button(2,'A');assert.equal(g.S.phase,'choose','Wrong seat cannot choose');g.choose(0);tick(g);assert.equal(g.S.phase,'draw');assert.equal(g.total(0),0,'No bag result may appear automatically');g.button(1,'COLOR_2');assert.equal(g.S.paint,-1);g.button(0,'COLOR_3');g.button(0,'A');g.button(0,'B');g.button(0,'COLOR_2');g.button(0,'A');g.button(0,'A');assert.equal(g.S.inv[0][2],1,'Bank other colors exactly as drawn');assert.equal(g.S.inv[0][0],0);g.undo();assert.equal(g.S.phase,'drawReview');assert.equal(g.S.inv[0][2],0);assert.equal(g.S.paused,true);g.button(0,'START');g.button(0,'A');assert.equal(g.S.inv[0][2],1);tick(g);assert.equal(g.S.phase,'feedback','Next round waits for the table');g.button(0,'A');assert.equal(g.S.phase,'flip');
}
{
 const g=winner(2);g.choose(1);tick(g);assert.equal(g.S.phase,'double');enter(g,2,'green');g.button(2,'A');assert.deepEqual(g.S.queue,[2,2]);draw(g,2,0);g.button(2,'A');assert.equal(g.S.drawSeat,2);draw(g,2,4);assert.equal(g.S.inv[2][0],1);assert.equal(g.S.inv[2][4],1);
 const h=winner(3);h.choose(1);enter(h,3,'red');h.button(3,'A');assert.deepEqual(h.S.queue,[0,1,2,3,4,5],'Red Double Up gives ALL players one real draw, including the gambler');for(let i=0;i<6;i++){assert.equal(h.S.drawSeat,i);draw(h,i,(i+1)%6);if(i<5)h.button(i,'A');}assert.ok(h.S.inv.every(row=>row.reduce((a,b)=>a+b)===1));
}
{
 const g=winner();g.S.inv[0][2]=2;g.S.inv[1][1]=1;g.choose(2);assert.equal(g.S.target,1);g.button(0,'A');enter(g,0,'green');enter(g,1,'green');g.button(0,'A');assert.equal(g.S.phase,'duel');assert.deepEqual(g.S.coinResults,Array(6).fill(null),'Tied real coins require another real flip');enter(g,0,'red');enter(g,1,'green');g.button(1,'A');assert.equal(g.S.stealer,1);assert.equal(g.S.victim,0,'Losing challenger gives a ghost to defender');g.button(0,'A');assert.equal(g.S.phase,'pick','Only the duel winner chooses');g.button(1,'COLOR_2');g.button(1,'A');assert.equal(g.S.phase,'stealReview');g.button(1,'B');assert.equal(g.S.phase,'pick');g.button(1,'A');g.button(1,'A');assert.equal(g.S.inv[0][2],1);assert.equal(g.S.inv[1][2],1);assert.equal(g.S.stats[1].steals,1);assert.equal(g.S.stats[0].robbed,1);
}
{
 const g=winner();g.S.inv[0][0]=3;g.S.inv[1][0]=1;g.choose(2);g.button(0,'A');enter(g,0,'green');enter(g,1,'red');g.button(0,'A');g.button(0,'A');g.button(0,'A');assert.equal(g.S.winner,0);assert.equal(g.S.inv[0][0],4);assert.equal(g.S.inv[1][0],0);g.undo();assert.equal(g.S.inv[0][0],3);assert.equal(g.S.phase,'stealReview');g.button(0,'START');g.button(0,'A');g.button(0,'START');assert.equal(g.S.phase,'flip');assert.ok(g.S.inv.flat().every(n=>n===0));
}
{
 const g=winner();g.choose(0);g.button(0,'COLOR_4');g.button(0,'A');const saved=g.snapshot(),h=createGame();assert.equal(h.restore(saved),true);assert.equal(h.S.phase,'drawReview');assert.equal(h.S.paused,true);h.button(0,'START');h.button(0,'A');assert.equal(h.S.inv[0][4],1);assert.ok(h.canUndo);const bad=g.snapshot();bad.state.inv[0][0]=-1;assert.equal(h.restore(bad),false);assert.equal(h.S.inv[0][4],1);const time=h.S.elapsed;h.button(1,'START');tick(h);assert.equal(h.S.elapsed,time);
}
// A full six-player physical-result transcript. There is no RNG or CPU in the engine.
{
 const g=createGame();g.start();for(let round=0;round<4;round++){for(let i=0;i<6;i++)enter(g,i,i===0?'green':'red');g.button(0,'A');g.choose(0);draw(g,0,0);if(round<3)g.button(0,'A');}assert.equal(g.S.phase,'results');assert.equal(g.S.winner,0);assert.equal(g.S.stats[0].draws,4);
}
console.log('PASS: real flip tournament, all-red reflip, editable/reviewed inputs, manual bag colors, green/red Double Up, defender steals after challenger loss, tied duels reflip, physical transfer, victory, undo, save/resume, no automatic outcomes');
