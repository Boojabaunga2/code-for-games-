# Color Rush IRL V2 validation

Engine: `node integrations/color-rush/tests/engine.test.mjs`.
Package: `python integrations/color-rush/build_package.py`.
Python: `python -m unittest discover -s integrations/color-rush/tests -p 'test_*.py'`.
Exact receiver harness: `python integrations/color-rush/tests/harness.py --server-reference PATH_TO_ORIGINAL_arcadium_server.py`.
Browser: `NODE_PATH=/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules node integrations/color-rush/tests/browser.cjs`.

The V2 engine suite verifies real flip rounds, red players sitting out subsequent flips, all-red reflip, editable/reviewed inputs, no timed outcomes, actual bag-color banking, both double outcomes (red includes all six), head-to-head ties, defender stealing after challenger loss, transfer conservation, wins/replay, undo and save/restore.

The Python route/installer suite checks six personal routes, stale frames, owner handoff, touch tokens and sequences, ZIP hashes, two installs and rollback, prior games/pairing preservation and later-edit guards. The Chromium suite uses the original PC input receiver and unchanged shared raw state transport. It tests physical-button packet equivalents and actual touch controls, not six physical devices.

Windows CMD launcher and public ZIP download results are recorded in repository review/v2/delivery.json. V1 review images/logs describe the superseded digital game, not these IRL rules.

Physical acceptance still needed: six Mini Vibes with your real coins/bag/ghosts, actual D-pad/shoulders and LAN, table corrections, refresh recovery and return to other games. No antivirus scan is claimed.
