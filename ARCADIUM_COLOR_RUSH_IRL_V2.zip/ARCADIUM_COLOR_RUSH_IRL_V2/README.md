# Color Rush IRL V2 — Real coins. Real ghosts.

This is the companion scoreboard for your physical game. Everyone flips actual red/green coins and draws actual colored ghosts from the physical bag. Screens ONLY record what happened. No digital outcome generation, dice, CPU players, timeouts or automatic banking.

Extract the entire ZIP. Double-click **START_INSTALL.cmd**, select **Arcadium_OS_COMPACT**, restart Windows once. Keep the existing universal Mini Vibe v16 app and pairing. **No new APK.** Requires the already installed Shared Mini Vibe Controls PC platform. Previous game files are backed up. Original approved characters, arena and cover art are retained unchanged.

## Table rules

1. All selected players flip their REAL coins. Each player enters green/red on their Mini Vibe. After all entries arrive, everyone reviews them and a participating player presses A to reveal.
2. Green players flip again until exactly one green remains. Red players sit out this flip-off, but remain in the game. If everyone in the current group gets red, that same group flips again. All-green also repeats with the same group.
3. The flip-off winner chooses DRAW, DOUBLE UP or HEAD-TO-HEAD.
4. DRAW: take ONE ghost from the physical bag and enter its actual color. Review, then bank it. Keep every color you draw.
5. DOUBLE UP: the winner physically flips again. GREEN gives them two real bag draws. RED gives EVERY selected player one real bag draw, including the gambler and players who lost the flip-off. The game shows whose draw is next so entries never get assigned to the wrong collection.
6. HEAD-TO-HEAD: choose an opponent. Both flip real coins. Matching colors mean both flip again. Green beats red. The winner chooses one existing ghost from the loser's collection; record the actual physical transfer. If the challenger loses, the defender steals from the challenger. A loser with no ghosts transfers nothing; the game invents no ghost.
7. First to collect four ghosts matching YOUR PLAYER COLOR wins. Other colors stay banked and can be stolen. Reaching four on a confirmed draw or transfer ends the game immediately.

## Mini Vibe entry

- A joins/readies, START launches. The PC can toggle seats on/off; all six are on initially.
- Coin entry: LEFT/UP or L shoulder selects GREEN. RIGHT/DOWN or R shoulder selects RED. A submits. Touch GREEN/RED works too; A submits afterward.
- Submitted flips remain visible. B edits your own result while others are entering or during group review. When everyone's entered, A reveals the reviewed table. No result is revealed by a timer.
- Bag draw: tap the actual ghost color, or use D-pad/shoulders to select it. A opens confirmation. A again banks it; B corrects it before banking. Do not draw a second ghost when correcting an entry.
- Opponent/steal selection: D-pad/shoulders select, A reviews/confirms. The winner selects the real ghost to transfer, then A reviews and A records. B corrects the selection.
- A on a recorded-result screen moves to the next real draw or next flip-off only when the table is ready.
- START pauses/resumes. X/Y are cosmetic taunts. No inputs are accepted for another player's pending draw or flip.

## Correcting mistakes and recovery

PC **UNDO LAST STEP** restores the last confirmed step (including bank/steal/flip resolution) and pauses. Resume when the physical ghosts match the corrected screen. Before confirmation, use B instead. The host input panel can select any player and enter actual coin/ghost results if someone needs help.

The PC saves the current IRL match and up to 64 undo steps in this browser's local storage. After refresh, choose **RESUME SAVED IRL MATCH**, then resume the paused table. Use the same browser/profile and 8787 origin; clearing browser data removes this recovery copy. Crew Setup preserves the current match for Resume. A new match replaces it. Refresh never generates or banks results.

## Preservation and rollback

Only this game's files/helper, its existing carousel registration and the wrapper call in the existing shared bridge are updated. Main server, Home, pairing, shared input receiver and all other games are unchanged. No controller app changes.

Use the installer rollback button and choose its **color_rush_irl_v2_*** backup. Rollback checks for later edits rather than overwriting them. CLI: `python update_color_rush.py --rollback PATH`.

PC preview: arrows select, Q/E shoulders, Space/Enter A, Backspace B, Escape pause. Host Input can enter results for any seat. USB gamepads use standard seat 1–6 mapping.

See VALIDATION.md for automated results and physical-device acceptance limits.
