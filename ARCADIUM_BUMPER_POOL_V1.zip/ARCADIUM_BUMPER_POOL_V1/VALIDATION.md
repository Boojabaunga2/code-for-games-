# Bumper Pool V1 verification

## Passed locally

- Nine engine/physics tests: 18 legally spaced balls, three per canonical colour, target pocket opposite every starting group; active-seat-only controls; one shot per turn; all-ball settling; equal-mass momentum transfer; wall/bumper rebounds; correct owner scoring; legal wrong-pocket respots; pause and aiming-clock timeout; match victory after rolling ends; finite bank guide; a full CPU-driven match reaches a winner.
- Three installation tests, including the **exact extracted ZIP**: selected-folder validation, own-game-only catalogue insertion, repeat installation, server/Home/pairing/other-game preservation, automatic backup, rollback retaining later unrelated catalogue edits, refusal to overwrite later game edits, and launching an original-server fixture without source rewrites. The original Home route and actual shared native input route pass through the wrapped process.
- Three broker tests: all six scoped dashboards/private frames, replay/stale-turn rejection, owner and legacy-game handoff, descriptor asset serving/path safety, and invalid pairing rejection.
- Chromium with real Three.js WebGL geometry and software rendering: six actual 720×720 private pages load their PC-rendered JPEG views; shared native held aim, direction release and heartbeat expiry; wrong-seat action rejection; native ball selection and power; held START toggles once; one-shot lock; all balls settle before blue's turn; blue-page reconnect; actual touch-pad dispatch; and switching to an existing game without Bumper Pool stealing its lease back. No page errors. See review/browser.json and the actual screenshots in source.

The live browser fixture listens on **8787**. Unit-test-only server fixtures use temporary local ports to isolate tests; no alternative game server is shipped. The reused live host and native reader are unchanged. The final square cover also shows the red target across the table rather than beside the foreground red ball. Native routes are bundled as the generic shared platform wrapper and loaded in memory alongside the existing bridge.

## Corrected during verification

- Target pockets are across the table, per the owner's clarification.
- Windows CI exposed implicit text decoding in metadata handling; installer and restore reads now explicitly use UTF-8, with a Unicode metadata regression check.
- Fixed the felt being obscured by the beveled table base and corrected sRGB material/texture handling.
- Player views now publish as a synchronized batch instead of waiting through six separate 3D render cycles. A pending image request is allowed to finish before refreshing.
- Input/physics ticking is separate from visual rendering, so a slow 3D frame does not slow held-control processing or turn logic.

## Remaining limits

The complete installed Arcadium Windows OS and six physical Mini Vibes are not reachable from this Linux environment. Installed Windows graphics performance, actual paired-device input/display acceptance, Wi-Fi behaviour and the recipient's antivirus acceptance remain **unverified**. The browser test uses the real shared receiver/broker and a minimal installed-bridge fixture, not a claim of a live-user-PC test. A clean CI/runner scan, when available, does not guarantee recipient Defender acceptance.

V1 is a complete first-to-three single pool match. Five-round elimination and ghost powers are not implemented or advertised as working. Physical haptics are not claimed.
