import { PoolGame, COLORS, HEX } from "./engine.mjs";
import { PoolRenderer, drawMini } from "./render.mjs";
const game = new PoolGame(),
  slug = "bumper-pool",
  base = "/arcadium-live/" + slug,
  owner = crypto.randomUUID?.() || String(Date.now()),
  readers = COLORS.map(() => ArcadiumInputState.create()),
  blocked = Array(6).fill(0),
  touch = Array(6).fill(0),
  touchAt = Array(6).fill(-Infinity),
  pads = Array(6).fill(0),
  previous = Array(6).fill(0),
  surfaces = COLORS.map(() =>
    Object.assign(document.createElement("canvas"), {
      width: 720,
      height: 720,
    }),
  );
for (const c of surfaces) c.getContext("2d", { willReadFrequently: true });
const el = (id) => document.getElementById(id),
  timers = [];
let render,
  active = false,
  ever = false,
  displaced = false,
  running = true,
  error = "",
  legacyCursor = null,
  touchCursor = null,
  legacyBusy = false,
  touchBusy = false,
  publishBusy = false,
  nextSeat = 0,
  last = 0,
  lastTurn = "",
  uiKey = "",
  localMask = 0,
  native,
  dragging = false;
try {
  render = new PoolRenderer(el("table"));
} catch (e) {
  el("fatal").hidden = false;
  el("fatal").textContent =
    "3D graphics could not start. Enable WebGL / hardware acceleration in this browser. " +
    e.message;
}
const fresh = (e, limit = 1000) => {
  let at = Number(e.at);
  if (at < 1e11) at *= 1000;
  return (
    Number.isFinite(at) && Date.now() - at >= -250 && Date.now() - at <= limit
  );
};
function mask(i) {
  return (
    (readers[i].read() & ~blocked[i]) |
    (Date.now() - touchAt[i] < 650 ? touch[i] : 0) |
    pads[i] |
    (i === game.turn ? localMask : 0)
  );
}
function clear() {
  for (let i = 0; i < 6; i++) {
    blocked[i] |= readers[i].read();
    readers[i].clear();
    touch[i] = pads[i] = previous[i] = 0;
    touchAt[i] = -Infinity;
  }
  localMask = 0;
}
function action(i, key) {
  if (displaced || document.hidden || !active || !render || !game.players[i])
    return;
  if (game.phase === "lobby") {
    if (key === "A") game.join(i);
    else if (key === "START") {
      game.join(i);
      game.start();
      clear();
    }
    return;
  }
  if (!game.players[i].human) return;
  if (key === "START") {
    game.pause();
    clear();
    return;
  }
  if (game.paused) return;
  if (game.phase === "finished") {
    if (key === "A") {
      game.lobby();
      clear();
    }
    return;
  }
  if (key === "A") game.shoot(i);
  if (key === "L1") game.choose(i, -1);
  if (key === "R1" || key === "B") game.choose(i, 1);
}
async function req(path, body) {
  const c = new AbortController(),
    timer = setTimeout(() => c.abort(), 1800);
  try {
    const r = await fetch(path, {
      cache: "no-store",
      signal: c.signal,
      ...(body
        ? {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(body),
          }
        : {}),
    });
    if (!r.ok) throw Error("HTTP " + r.status);
    return r.json();
  } finally {
    clearTimeout(timer);
  }
}
async function activate() {
  if (!running || displaced || document.hidden) return;
  try {
    await req("/arcadium-vibe/activate/" + slug, { owner, renew: ever });
    active = ever = true;
    error = "";
  } catch (e) {
    active = false;
    error = e.message;
    if (ever) {
      game.paused = true;
      clear();
    }
    if (ever && e.message === "HTTP 409") displaced = true;
  }
}
async function poll(kind) {
  if (
    !running ||
    displaced ||
    document.hidden ||
    (kind === "touch" ? touchBusy : legacyBusy)
  )
    return;
  kind === "touch" ? (touchBusy = true) : (legacyBusy = true);
  try {
    const cursor = kind === "touch" ? touchCursor : legacyCursor,
      d = await req(
        kind === "touch"
          ? base + "/touch/events?after=" + (cursor ?? 0)
          : "/api/vibe/events?after=" + (cursor ?? 0),
      );
    if (cursor !== null && d.latest >= cursor)
      for (const e of d.events
        .filter((e) => e.seq > cursor)
        .sort((a, b) => a.seq - b.seq)) {
        const i = COLORS.indexOf(e.color);
        if (
          i < 0 ||
          !fresh(e, kind === "touch" && e.key?.startsWith("M") ? 650 : 1200)
        )
          continue;
        if (kind === "touch") {
          if (e.turnId !== game.turnId) continue;
          if (/^M[\da-f]{3}$/i.test(e.key)) {
            touch[i] = parseInt(e.key.slice(1), 16);
            touchAt[i] = Date.now();
          } else action(i, e.key);
        } else if (
          !readers[i].seen &&
          ["A", "B", "L1", "R1", "START"].includes(e.button)
        )
          action(i, e.button);
      }
    if (kind === "touch") touchCursor = d.latest;
    else legacyCursor = d.latest;
  } catch (e) {
    error = e.message;
  } finally {
    kind === "touch" ? (touchBusy = false) : (legacyBusy = false);
  }
}
async function publish() {
  if (!active || !running || publishBusy || displaced || document.hidden)
    return;
  publishBusy = true;
  try {
    const state = {
      phase: game.phase,
      paused: game.paused,
      turnId: game.turnId,
      dashboards: COLORS.map((_, i) => game.dashboard(i)),
    };
    const packets = surfaces.map((c, i) => {
      drawMini(c.getContext("2d"), game, i);
      return {
        owner,
        seat: i + 1,
        image: c.toDataURL("image/jpeg", 0.66).split(",")[1],
        state,
      };
    });
    await Promise.all(packets.map((packet) => req(base + "/frame", packet)));
  } catch (e) {
    error = e.message;
  } finally {
    publishBusy = false;
  }
}
function view() {
  const lobby = game.phase === "lobby",
    finished = game.phase === "finished",
    rolling = game.mode === "rolling",
    key = JSON.stringify([
      game.phase,
      game.turn,
      game.players.map((p) => [p.human, p.potted]),
    ]);
  if (key !== uiKey) {
    uiKey = key;
    el("players").replaceChildren();
    for (const p of game.players) {
      const box = document.createElement("div");
      box.className = "player" + (!lobby && p.i === game.turn ? " active" : "");
      box.style.setProperty("--c", HEX[p.i]);
      const text = document.createElement("div"),
        name = document.createElement("strong"),
        type = document.createElement("small");
      name.textContent = p.color.toUpperCase();
      type.textContent = p.human ? "HUMAN" : "CPU";
      text.append(name, type);
      const balls = document.createElement("div");
      balls.className = "balls";
      for (let k = 0; k < 3; k++) {
        const b = document.createElement("i");
        b.className = k < p.potted ? "potted" : "";
        balls.append(b);
      }
      const score = document.createElement("b");
      score.textContent = p.potted + "/3";
      balls.append(score);
      box.append(text, balls);
      if (lobby) {
        box.style.cursor = "pointer";
        box.onclick = () => {
          p.human = !p.human;
        };
      }
      el("players").append(box);
    }
  }
  el("turnName").textContent = lobby
    ? "YOUR TABLE IS READY"
    : finished
      ? COLORS[game.winner].toUpperCase() + " WINS!"
      : game.paused
        ? "TABLE PAUSED"
        : rolling
          ? "BALLS IN MOTION"
          : COLORS[game.turn].toUpperCase() + "'S TURN";
  el("turnName").style.color = lobby
    ? "#ffe2a4"
    : HEX[game.winner ?? game.turn];
  el("turnHint").textContent = lobby
    ? "THREE BALLS EACH · POCKET ACROSS THE TABLE"
    : rolling
      ? "WAIT UNTIL ALL BALLS STOP"
      : "ONE SHOT PER TURN · TARGET YOUR MATCHING POCKET";
  el("message").textContent = game.message;
  el("connection").textContent = displaced
    ? "ANOTHER GAME IS ACTIVE — REOPEN BUMPER POOL"
    : active
      ? "SHARED MINI VIBES · NO NEW APK"
      : error
        ? "SHARED HOST: " + error
        : "START WITH START_BUMPER_POOL.py";
  el("powerFill").style.width = Math.round(game.power * 100) + "%";
  el("powerValue").textContent = Math.round(game.power * 100) + "%";
  el("clock").textContent = lobby
    ? "—"
    : rolling
      ? "…"
      : finished
        ? "✓"
        : Math.ceil(game.clock) + "s";
  el("pause").textContent = game.paused ? "RESUME" : "PAUSE";
  el("pause").disabled = lobby || finished;
  el("paused").hidden = !game.paused || displaced;
  el("overlay").hidden = !lobby && !finished;
  el("start").disabled =
    !active || !render || !game.players.some((p) => p.human);
  el("shoot").disabled =
    !active || !game.canAim(game.turn) || !game.players[game.turn].human;
  el("lobbyActions").hidden = !lobby;
  el("replay").hidden = !finished;
  if (finished) {
    el("overlayTitle").textContent =
      COLORS[game.winner].toUpperCase() + " OWNS THE TABLE";
    el("overlayText").textContent =
      "All three home. " +
      game.players[game.winner].shots +
      " shots. Play another match, or return to Arcadium.";
  } else if (lobby) {
    el("overlayTitle").innerHTML = "One shot.<br>Make it count.";
    el("overlayText").textContent =
      "Join with A on your Mini Vibe, or click your colour above. Your matching pocket is across the table. Empty seats are CPU.";
  }
}
function logic(time) {
  const dt = Math.min(0.05, (time - last) / 1000 || 0);
  last = time;
  if (game.turnId !== lastTurn) {
    lastTurn = game.turnId;
    for (let i = 0; i < 6; i++) {
      blocked[i] |= readers[i].read();
      previous[i] = mask(i);
    }
    localMask = 0;
  }
  const gp = navigator.getGamepads?.() || [];
  for (let i = 0; i < 6; i++) {
    const p = gp[i];
    pads[i] = p
      ? (p.axes[0] < -0.3 || p.buttons[14]?.pressed ? 4 : 0) |
        (p.axes[0] > 0.3 || p.buttons[15]?.pressed ? 8 : 0) |
        (p.axes[1] < -0.3 || p.buttons[12]?.pressed ? 1 : 0) |
        (p.axes[1] > 0.3 || p.buttons[13]?.pressed ? 2 : 0) |
        (p.buttons[0]?.pressed ? 16 : 0) |
        (p.buttons[1]?.pressed ? 32 : 0) |
        (p.buttons[4]?.pressed ? 1024 : 0) |
        (p.buttons[5]?.pressed ? 2048 : 0) |
        (p.buttons[9]?.pressed ? 256 : 0)
      : 0;
    const m = mask(i),
      edge = m & ~previous[i];
    if (active && !displaced) {
      game.adjust(
        i,
        Number(!!(m & 8)) - Number(!!(m & 4)),
        Number(!!(m & 1)) - Number(!!(m & 2)),
        dt,
      );
      for (const [b, k] of [
        [16, "A"],
        [32, "B"],
        [1024, "L1"],
        [2048, "R1"],
        [256, "START"],
      ])
        if (edge & b) action(i, k);
    }
    previous[i] = m;
  }
  if (active && !displaced) {
    if (
      game.phase === "play" &&
      !game.paused &&
      game.mode === "aim" &&
      !game.players[game.turn].human
    ) {
      game.cpuWait -= dt;
      if (game.cpuWait <= 0) {
        const p = game.cpuPlan();
        if (p) {
          game.selected = p.ball;
          game.angle = p.angle;
          game.power = p.power;
          game.shoot(game.turn);
        }
      }
    }
    game.update(dt);
  }
  view();
}
function frame(time) {
  render?.draw(game, time / 1000);
  if (running) requestAnimationFrame(frame);
}

function pause() {
  game.pause();
  clear();
}
el("pause").onclick = pause;
el("resume").onclick = pause;
el("allHuman").onclick = () => game.players.forEach((p) => (p.human = true));
el("start").onclick = () => {
  if (active) {
    game.start();
    clear();
  }
};
el("shoot").onclick = () => action(game.turn, "A");
el("replay").onclick = () => {
  game.lobby();
  clear();
};
el("new").onclick = () => {
  if (
    game.phase === "lobby" ||
    game.phase === "finished" ||
    confirm("End this match and set up a new table?")
  ) {
    game.lobby();
    clear();
  }
};
el("help").onclick = () => {
  if (game.phase === "play" && !game.paused) pause();
  el("rules").showModal();
};
el("closeHelp").onclick = () => el("rules").close();
addEventListener("keydown", (e) => {
  if (el("rules").open) return;
  if (
    ["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", " ", "Enter"].includes(
      e.key,
    )
  )
    e.preventDefault();
  const bit = { ArrowUp: 1, ArrowDown: 2, ArrowLeft: 4, ArrowRight: 8 }[e.key];
  if (bit) {
    localMask |= bit;
    return;
  }
  if (e.repeat) return;
  if (e.key === "Enter") {
    if (game.phase === "lobby" && active && render) {
      game.join(0);
      game.start();
      clear();
    } else action(game.turn, "START");
  }
  if (e.key === " ") action(game.turn, "A");
  if (e.key === "q" || e.key === "Q") action(game.turn, "L1");
  if (e.key === "e" || e.key === "E") action(game.turn, "R1");
  if (e.key === "Escape" && game.phase === "play") pause();
});
addEventListener("keyup", (e) => {
  localMask &= ~(
    { ArrowUp: 1, ArrowDown: 2, ArrowLeft: 4, ArrowRight: 8 }[e.key] || 0
  );
});
if (render) {
  const canvas = render.renderer.domElement;
  canvas.addEventListener("pointerdown", (e) => {
    if (!game.canAim(game.turn) || !game.players[game.turn].human) return;
    const p = render.worldPoint(e);
    if (!p) return;
    const ball = game.balls.find(
      (b) =>
        b.active &&
        b.seat === game.turn &&
        Math.hypot(b.x - p.x, b.y - p.y) < 0.55,
    );
    if (ball) {
      game.selected = ball.id;
      game.aimHome();
    } else {
      dragging = true;
      canvas.setPointerCapture(e.pointerId);
      const b = game.balls[game.selected];
      game.angle = Math.atan2(p.y - b.y, p.x - b.x);
    }
  });
  canvas.addEventListener("pointermove", (e) => {
    if (!dragging || !game.canAim(game.turn)) return;
    const p = render.worldPoint(e),
      b = game.balls[game.selected];
    if (p && b) game.angle = Math.atan2(p.y - b.y, p.x - b.x);
  });
  for (const k of ["pointerup", "pointercancel", "lostpointercapture"])
    canvas.addEventListener(k, () => (dragging = false));
}
function lose() {
  clear();
  if (game.phase === "play" && !game.paused) game.pause();
}
addEventListener("blur", lose);
document.addEventListener("visibilitychange", () => {
  if (document.hidden) lose();
  else {
    legacyCursor = touchCursor = null;
    activate();
  }
});
function exit() {
  if (!running) return;
  running = false;
  clear();
  native?.stop();
  timers.forEach(clearInterval);
  fetch("/arcadium-vibe/activate/" + slug, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ owner, active: false }),
    keepalive: true,
  }).catch(() => {});
}
el("exit").onclick = (e) => {
  e.preventDefault();
  exit();
  if (parent !== window)
    parent.postMessage({ type: "ARCADIUM_GAME_EXIT", game: slug }, "*");
  else location.href = "/";
};
addEventListener("pagehide", exit);
window.BUMPER_POOL = {
  game,
  action,
  mask,
  clear,
  surfaces,
  publish,
  render,
  get error() {
    return error;
  },
  get active() {
    return active;
  },
  get displaced() {
    return displaced;
  },
};
native = ArcadiumInputState.connect({
  onEvent: (e) => {
    const i = COLORS.indexOf(e.color);
    if (i >= 0 && !displaced && fresh(e, 650)) {
      readers[i].receive(e.button);
      blocked[i] &= readers[i].read();
    }
  },
  onReset: clear,
  onError: (e) => {
    if (e) error = e;
  },
});
await activate();
await poll("legacy");
await poll("touch");
timers.push(
  setInterval(() => logic(performance.now()), 16),
  setInterval(activate, 2200),
  setInterval(() => poll("legacy"), 45),
  setInterval(() => poll("touch"), 45),
  setInterval(publish, 250),
);
requestAnimationFrame(frame);
