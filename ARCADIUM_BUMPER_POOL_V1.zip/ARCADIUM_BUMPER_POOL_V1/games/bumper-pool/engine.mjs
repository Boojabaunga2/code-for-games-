export const COLORS = ["red", "blue", "green", "yellow", "pink", "white"];
export const HEX = [
  "#ff4357",
  "#3995ff",
  "#45db7b",
  "#ffd43b",
  "#ff7dc8",
  "#f2f5ff",
];
export const RADIUS = 7,
  A = RADIUS * Math.cos(Math.PI / 6),
  BALL_R = 0.23,
  BUMPER_R = 0.46,
  STEP = 1 / 120;
const angles = [150, 90, 270, 330, 30, 210].map((d) => (d * Math.PI) / 180);
export const STARTS = angles.map((a) => ({ x: Math.cos(a), y: Math.sin(a) }));
export const POCKETS = STARTS.map((n, seat) => ({
  seat,
  x: -n.x * A,
  y: -n.y * A,
  nx: -n.x,
  ny: -n.y,
}));
export const BUMPERS = [
  { x: 0, y: 0 },
  { x: 1.7, y: 0 },
  { x: -1.7, y: 0 },
  { x: 0, y: 1.7 },
  { x: 0, y: -1.7 },
];
const dot = (x, y, n) => x * n.nx + y * n.ny,
  clamp = (v, a, b) => Math.max(a, Math.min(b, v));
export function inside(x, y, r = BALL_R) {
  return POCKETS.every((n) => dot(x, y, n) <= A - r + 0.00001);
}
export function free(x, y, balls, ignore = -1) {
  return (
    inside(x, y) &&
    BUMPERS.every(
      (p) => Math.hypot(x - p.x, y - p.y) > BUMPER_R + BALL_R + 0.04,
    ) &&
    balls.every(
      (b) =>
        !b.active ||
        b.id === ignore ||
        Math.hypot(x - b.x, y - b.y) > BALL_R * 2 + 0.025,
    )
  );
}
function reflect(b, nx, ny, restitution) {
  const speed = b.vx * nx + b.vy * ny;
  if (speed > 0) {
    b.vx -= (1 + restitution) * speed * nx;
    b.vy -= (1 + restitution) * speed * ny;
  }
}
export function physics(balls, dt, onPocket = () => {}) {
  const captured = [];
  for (const b of balls) {
    if (!b.active) continue;
    const ox = b.x,
      oy = b.y;
    b.x += b.vx * dt;
    b.y += b.vy * dt;
    for (const p of POCKETS) {
      const d = dot(b.x, b.y, p),
        t = b.x * -p.ny + b.y * p.nx;
      if (d >= A - 0.3 && Math.abs(t) < 0.45) {
        const before = dot(ox, oy, p),
          f = clamp((A - 0.3 - before) / (d - before || 1), 0, 1);
        captured.push({ b, p, f });
        b.active = false;
        break;
      }
    }
    if (!b.active) continue;
    for (const p of POCKETS) {
      const d = dot(b.x, b.y, p);
      if (d > A - BALL_R) {
        const overlap = d - (A - BALL_R);
        b.x -= p.nx * overlap;
        b.y -= p.ny * overlap;
        reflect(b, p.nx, p.ny, 0.86);
      }
    }
    for (const p of BUMPERS) {
      const dx = b.x - p.x,
        dy = b.y - p.y,
        d = Math.hypot(dx, dy),
        r = BUMPER_R + BALL_R;
      if (d < r) {
        const nx = d > 1e-9 ? dx / d : 1,
          ny = d > 1e-9 ? dy / d : 0;
        b.x = p.x + nx * r;
        b.y = p.y + ny * r;
        reflect(b, -nx, -ny, 0.91);
      }
    }
  }
  for (let iteration = 0; iteration < 2; iteration++)
    for (let i = 0; i < balls.length; i++)
      for (let j = i + 1; j < balls.length; j++) {
        const b = balls[i],
          c = balls[j];
        if (!b.active || !c.active) continue;
        const dx = c.x - b.x,
          dy = c.y - b.y,
          d = Math.hypot(dx, dy),
          r = 2 * BALL_R;
        if (d >= r) continue;
        const nx = d > 1e-9 ? dx / d : 1,
          ny = d > 1e-9 ? dy / d : 0,
          overlap = (r - d + 0.00001) / 2;
        b.x -= nx * overlap;
        b.y -= ny * overlap;
        c.x += nx * overlap;
        c.y += ny * overlap;
        const speed = (b.vx - c.vx) * nx + (b.vy - c.vy) * ny;
        if (speed > 0) {
          const impulse = speed * 0.965;
          b.vx -= impulse * nx;
          b.vy -= impulse * ny;
          c.vx += impulse * nx;
          c.vy += impulse * ny;
        }
      }
  for (const b of balls) {
    if (!b.active) continue;
    const speed = Math.hypot(b.vx, b.vy),
      next = Math.max(0, speed - 1.05 * dt);
    if (next < 0.035) {
      b.vx = b.vy = 0;
    } else {
      b.vx *= next / speed;
      b.vy *= next / speed;
    }
  }
  captured.sort((a, b) => a.f - b.f || a.b.id - b.b.id);
  for (const c of captured) onPocket(c.b, c.p.seat);
}
export function traceAim(ball, angle, balls, max = 15) {
  let x = ball.x,
    y = ball.y,
    dx = Math.cos(angle),
    dy = Math.sin(angle),
    left = max;
  const points = [{ x, y }];
  for (let bounce = 0; bounce < 3 && left > 0.01; bounce++) {
    let hit = left,
      normal = null,
      stop = false;
    for (const p of POCKETS) {
      const den = dx * p.nx + dy * p.ny;
      if (den <= 1e-8) continue;
      const t = (A - BALL_R - dot(x, y, p)) / den;
      if (t > 0.005 && t < hit) {
        hit = t;
        normal = { x: p.nx, y: p.ny };
        stop = Math.abs((x + dx * t) * -p.ny + (y + dy * t) * p.nx) < 0.45;
      }
    }
    for (const p of [
      ...BUMPERS.map((p) => ({ ...p, r: BUMPER_R + BALL_R, stop: false })),
      ...balls
        .filter((b) => b.active && b.id !== ball.id)
        .map((b) => ({ ...b, r: 2 * BALL_R, stop: true })),
    ]) {
      const ox = x - p.x,
        oy = y - p.y,
        v = ox * dx + oy * dy,
        disc = v * v - (ox * ox + oy * oy - p.r * p.r);
      if (disc < 0) continue;
      const t = -v - Math.sqrt(disc);
      if (t > 0.005 && t < hit) {
        hit = t;
        const hx = x + dx * t,
          hy = y + dy * t,
          d = Math.hypot(hx - p.x, hy - p.y);
        normal = { x: (hx - p.x) / d, y: (hy - p.y) / d };
        stop = p.stop;
      }
    }
    x += dx * hit;
    y += dy * hit;
    points.push({ x, y });
    left -= hit;
    if (!normal || stop) break;
    const v = dx * normal.x + dy * normal.y;
    dx -= 2 * v * normal.x;
    dy -= 2 * v * normal.y;
    x += dx * 0.01;
    y += dy * 0.01;
  }
  return points;
}
export class PoolGame {
  constructor() {
    this.serial = 0;
    this.match = 0;
    this.lobby();
  }
  lobby() {
    this.phase = "lobby";
    this.mode = "aim";
    this.paused = false;
    this.winner = null;
    this.turn = 0;
    this.turnNumber = 1;
    this.clock = 20;
    this.power = 0.65;
    this.selected = 0;
    this.angle = 0;
    this.message = "Join your colour. Your target pocket is across the table.";
    this.players = COLORS.map((color, i) => ({
      i,
      color,
      human: false,
      potted: 0,
      shots: 0,
      passes: 0,
    }));
    this.events = [];
    this.finishOrder = [];
    this.spawn();
    this.newTurnId();
  }
  newTurnId() {
    this.turnId = "pool-" + this.match + "-" + ++this.serial;
  }
  spawn() {
    this.balls = [];
    for (let i = 0; i < 6; i++) {
      const n = STARTS[i],
        t = { x: -n.y, y: n.x };
      for (let j = 0; j < 3; j++)
        this.balls.push({
          id: i * 3 + j,
          seat: i,
          number: j + 1,
          x: n.x * (4.65 - (j === 1 ? 0.48 : 0)) + t.x * (j - 1) * 0.63,
          y: n.y * (4.65 - (j === 1 ? 0.48 : 0)) + t.y * (j - 1) * 0.63,
          vx: 0,
          vy: 0,
          active: true,
          pending: false,
        });
    }
  }
  join(i) {
    if (this.phase === "lobby" && i >= 0 && i < 6) {
      this.players[i].human = true;
      return true;
    }
    return false;
  }
  start() {
    if (this.phase !== "lobby" || !this.players.some((p) => p.human))
      return false;
    this.match++;
    this.players.forEach((p) => {
      p.potted = p.shots = p.passes = 0;
    });
    this.spawn();
    this.phase = "play";
    this.paused = false;
    this.winner = null;
    this.finishOrder = [];
    this.turn = 0;
    this.turnNumber = 1;
    this.events = [];
    this.beginTurn();
    return true;
  }
  beginTurn() {
    this.mode = "aim";
    this.clock = 20;
    this.cpuWait = 1.1;
    this.settled = 0;
    this.shotTime = 0;
    this.selected =
      this.balls.find((b) => b.active && b.seat === this.turn)?.id ?? -1;
    this.power = 0.65;
    this.aimHome();
    this.newTurnId();
    this.message = COLORS[this.turn].toUpperCase() + "'S TURN — ONE SHOT";
  }
  aimHome() {
    const b = this.balls[this.selected],
      p = POCKETS[this.turn];
    if (b) this.angle = Math.atan2(p.y - b.y, p.x - b.x);
  }
  choose(i, delta) {
    if (!this.canAim(i)) return false;
    const own = this.balls.filter((b) => b.active && b.seat === i);
    const n = own.findIndex((b) => b.id === this.selected);
    this.selected = own[(n + delta + own.length) % own.length].id;
    this.aimHome();
    return true;
  }
  canAim(i) {
    return (
      this.phase === "play" &&
      !this.paused &&
      this.mode === "aim" &&
      i === this.turn
    );
  }
  adjust(i, dx, dy, dt) {
    if (!this.canAim(i)) return;
    this.angle += dx * dt * 1.05;
    this.power = clamp(this.power + dy * dt * 0.55, 0.08, 1);
  }
  shoot(i) {
    if (!this.canAim(i)) return false;
    const b = this.balls[this.selected];
    if (!b?.active || b.seat !== i) return false;
    const speed = 1.5 + this.power * 8.5;
    b.vx = Math.cos(this.angle) * speed;
    b.vy = Math.sin(this.angle) * speed;
    this.players[i].shots++;
    this.mode = "rolling";
    this.shotTime = 0;
    this.settled = 0;
    this.message = "BALLS IN MOTION — WAIT FOR THE TABLE";
    this.newTurnId();
    return true;
  }
  pocket(b, seat) {
    b.vx = b.vy = 0;
    const good = b.seat === seat;
    b.pending = !good;
    this.events.push({
      type: good ? "pot" : "wrong",
      id: b.id,
      seat: b.seat,
      at: this.serial,
    });
    if (good) {
      const p = this.players[b.seat];
      p.potted++;
      this.message =
        COLORS[b.seat].toUpperCase() + " SCORES · " + p.potted + "/3";
      if (p.potted === 3 && !this.finishOrder.includes(b.seat))
        this.finishOrder.push(b.seat);
    } else this.message = "WRONG POCKET — BALL RETURNS AFTER THE SHOT";
  }
  respot() {
    for (const b of this.balls.filter((b) => b.pending)) {
      const n = STARTS[b.seat],
        t = { x: -n.y, y: n.x };
      let found = false;
      for (let row = 0; row < 9 && !found; row++)
        for (let c = -5; c <= 5 && !found; c++) {
          const x = n.x * (4.7 - row * 0.56) + t.x * c * 0.55,
            y = n.y * (4.7 - row * 0.56) + t.y * c * 0.55;
          if (free(x, y, this.balls, b.id)) {
            Object.assign(b, {
              x,
              y,
              vx: 0,
              vy: 0,
              active: true,
              pending: false,
            });
            found = true;
          }
        }
      if (!found) throw Error("No legal respot");
    }
  }
  advance() {
    this.respot();
    if (this.finishOrder.length) {
      this.phase = "finished";
      this.winner = this.finishOrder[0];
      this.message = COLORS[this.winner].toUpperCase() + " WINS BUMPER POOL";
      this.newTurnId();
      return;
    }
    this.turn = (this.turn + 1) % 6;
    this.turnNumber++;
    this.beginTurn();
  }
  update(dt) {
    if (this.phase !== "play" || this.paused) return;
    dt = clamp(dt, 0, 0.05);
    if (this.mode === "aim") {
      this.clock = Math.max(0, this.clock - dt);
      if (this.clock === 0) {
        this.players[this.turn].passes++;
        this.message = "SHOT CLOCK EXPIRED";
        this.advance();
      }
      return;
    }
    this.shotTime += dt;
    let steps = Math.ceil(dt / STEP);
    for (let k = 0; k < steps; k++)
      physics(this.balls, dt / steps, (b, p) => this.pocket(b, p));
    const moving = this.balls.some(
      (b) => b.active && Math.hypot(b.vx, b.vy) > 0.02,
    );
    this.settled = moving ? 0 : this.settled + dt;
    if (this.shotTime > 15) {
      for (const b of this.balls) b.vx = b.vy = 0;
      this.settled = 0.4;
    }
    if (this.settled > 0.33) this.advance();
  }
  pause() {
    if (this.phase === "play") {
      this.paused = !this.paused;
      this.newTurnId();
    }
  }
  cpuPlan() {
    const home = POCKETS[this.turn],
      own = this.balls.filter((b) => b.active && b.seat === this.turn);
    let best = null;
    for (const b of own) {
      const direct = Math.atan2(home.y - b.y, home.x - b.x),
        angles = [direct];
      for (const wall of POCKETS) {
        const d = A - (home.x * wall.nx + home.y * wall.ny);
        angles.push(
          Math.atan2(
            home.y + 2 * d * wall.ny - b.y,
            home.x + 2 * d * wall.nx - b.x,
          ),
        );
      }
      angles.push(direct - 0.32, direct + 0.32, direct - 0.65, direct + 0.65);
      for (const angle of angles)
        for (const power of [0.44, 0.65, 0.88]) {
          const clone = {
              ...b,
              vx: Math.cos(angle) * (1.5 + 8.5 * power),
              vy: Math.sin(angle) * (1.5 + 8.5 * power),
            },
            others = this.balls.filter((c) => c.active && c.id !== b.id),
            sim = [clone];
          let pot = -1;
          for (
            let t = 0;
            t < 9 && clone.active && Math.hypot(clone.vx, clone.vy) > 0.03;
            t += 1 / 75
          ) {
            physics(sim, 1 / 75, (_, p) => (pot = p));
            for (const c of others) {
              const dx = clone.x - c.x,
                dy = clone.y - c.y,
                d = Math.hypot(dx, dy);
              if (d < 2 * BALL_R && d > 0) {
                clone.x = c.x + (dx / d) * 2 * BALL_R;
                clone.y = c.y + (dy / d) * 2 * BALL_R;
                reflect(clone, -dx / d, -dy / d, 0.65);
              }
            }
          }
          const score =
            pot === this.turn
              ? -100
              : pot >= 0
                ? 100
                : Math.hypot(clone.x - home.x, clone.y - home.y);
          if (!best || score < best.score)
            best = { ball: b.id, angle, power, score };
        }
    }
    return best;
  }
  dashboard(i) {
    return {
      seat: i,
      color: COLORS[i],
      phase: this.phase,
      paused: this.paused,
      turn: this.turn,
      mode: this.mode,
      human: this.players[i].human,
      potted: this.players[i].potted,
      shots: this.players[i].shots,
      clock: Math.ceil(this.clock),
      power: Math.round(this.power * 100),
      selected: this.selected,
      angle: Math.round(this.angle * 1000) / 1000,
      winner: this.winner,
      turnId: this.turnId,
    };
  }
}
