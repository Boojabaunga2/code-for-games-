import {
  COLORS,
  HEX,
  RADIUS,
  A,
  BALL_R,
  BUMPER_R,
  POCKETS,
  BUMPERS,
  STARTS,
  traceAim,
} from "./engine.mjs";
const T = window.THREE;
function label(text, color = "#ffffff") {
  const c = document.createElement("canvas");
  c.width = 512;
  c.height = 96;
  const g = c.getContext("2d");
  g.font = "900 48px Arial";
  g.textAlign = "center";
  g.textBaseline = "middle";
  g.fillStyle = color;
  g.shadowColor = color;
  g.shadowBlur = 12;
  g.fillText(text, 256, 48);
  return new T.CanvasTexture(c);
}
export class PoolRenderer {
  constructor(container) {
    this.renderer = new T.WebGLRenderer({ antialias: true, alpha: true });
    this.renderer.setPixelRatio(Math.min(devicePixelRatio || 1, 1.25));
    this.renderer.outputEncoding = T.sRGBEncoding;
    this.renderer.toneMapping = T.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.2;
    this.renderer.shadowMap.enabled = false;
    this.renderer.shadowMap.type = T.PCFSoftShadowMap;
    container.append(this.renderer.domElement);
    this.container = container;
    this.scene = new T.Scene();
    this.scene.fog = new T.Fog(0x070e19, 25, 65);
    this.camera = new T.PerspectiveCamera(27, 1, 0.1, 100);
    this.camera.position.set(0, 10.5, 17);
    this.camera.lookAt(0, 0, 1.1);
    this.scene.add(new T.HemisphereLight(0xa5e4ff, 0x18101b, 0.65));
    const light = new T.DirectionalLight(0xffefd5, 1.45);
    light.position.set(-3, 12, 4);
    light.castShadow = true;
    light.shadow.mapSize.set(1024, 1024);
    Object.assign(light.shadow.camera, {
      left: -9,
      right: 9,
      top: 9,
      bottom: -9,
    });
    light.shadow.bias = -0.0007;
    this.scene.add(light);
    const rim = new T.PointLight(0x548cff, 0.6, 35);
    rim.position.set(8, 6, -7);
    this.scene.add(rim);
    const red = new T.PointLight(0xff305b, 0.35, 30);
    red.position.set(-8, 4, 5);
    this.scene.add(red);
    const material = (color, roughness = 0.35, metalness = 0.3) =>
      new T.MeshPhongMaterial({
        color: new T.Color(color).convertSRGBToLinear(),
        shininess: Math.round((1 - roughness) * 120 + 10),
        specular: metalness > 0.5 ? 0xb8c8da : 0x333333,
      });
    this.chrome = material(0xb8c8d8, 0.18, 0.83);
    this.wood = material(0x413026, 0.32, 0.5);
    const shape = new T.Shape();
    for (let k = 0; k < 6; k++) {
      const a = (k * Math.PI) / 3,
        x = RADIUS * Math.cos(a),
        y = RADIUS * Math.sin(a);
      k ? shape.lineTo(x, y) : shape.moveTo(x, y);
    }
    shape.closePath();
    const base = new T.Mesh(
      new T.ExtrudeGeometry(shape, {
        depth: 0.65,
        bevelEnabled: true,
        bevelSegments: 3,
        steps: 1,
        bevelSize: 0.22,
        bevelThickness: 0.15,
      }),
      material(0x182333, 0.25, 0.65),
    );
    base.rotation.x = -Math.PI / 2;
    base.position.y = -0.85;
    base.receiveShadow = true;
    this.scene.add(base);
    const felt = document.createElement("canvas");
    felt.width = felt.height = 256;
    const ctx = felt.getContext("2d");
    ctx.fillStyle = "#086b68";
    ctx.fillRect(0, 0, 256, 256);
    for (let i = 0; i < 12000; i++) {
      ctx.fillStyle = i % 2 ? "#147e77" : "#075653";
      ctx.globalAlpha = 0.35;
      ctx.fillRect(
        (i * 37) % 256,
        (i * 71 + Math.floor(i / 256) * 19) % 256,
        1,
        2,
      );
    }
    const texture = new T.CanvasTexture(felt);
    texture.encoding = T.sRGBEncoding;
    texture.wrapS = texture.wrapT = T.RepeatWrapping;
    texture.repeat.set(3, 3);
    const bed = new T.Mesh(
      new T.ShapeGeometry(shape),
      new T.MeshLambertMaterial({ map: texture, color: 0xffffff }),
    );
    bed.rotation.x = -Math.PI / 2;
    bed.position.y = 0.005;
    bed.receiveShadow = true;
    this.scene.add(bed);
    for (const p of POCKETS) {
      const tx = -p.ny,
        ty = p.nx;
      for (const s of [-1, 1]) {
        const rail = new T.Mesh(
          new T.BoxGeometry(RADIUS / 2 - 0.66, 0.43, 0.42),
          this.wood,
        );
        rail.position.set(
          p.nx * (A + 0.2) + tx * s * (RADIUS / 4 + 0.33),
          0.2,
          p.ny * (A + 0.2) + ty * s * (RADIUS / 4 + 0.33),
        );
        rail.rotation.y = -Math.atan2(ty, tx);
        rail.castShadow = rail.receiveShadow = true;
        this.scene.add(rail);
        const trim = new T.Mesh(
          new T.BoxGeometry(RADIUS / 2 - 0.65, 0.04, 0.055),
          this.chrome,
        );
        trim.position.copy(rail.position);
        trim.position.y = 0.44;
        trim.rotation.copy(rail.rotation);
        this.scene.add(trim);
      }
      const hole = new T.Mesh(
        new T.CircleGeometry(0.54, 48),
        new T.MeshBasicMaterial({ color: 0x010407 }),
      );
      hole.rotation.x = -Math.PI / 2;
      hole.position.set(p.x - p.nx * 0.08, 0.024, p.y - p.ny * 0.08);
      this.scene.add(hole);
      const ring = new T.Mesh(
        new T.TorusGeometry(0.55, 0.085, 12, 48),
        new T.MeshStandardMaterial({
          color: new T.Color(HEX[p.seat]).convertSRGBToLinear(),
          emissive: new T.Color(HEX[p.seat]).convertSRGBToLinear(),
          emissiveIntensity: 0.32,
          metalness: 0.55,
          roughness: 0.22,
        }),
      );
      ring.rotation.x = -Math.PI / 2;
      ring.position.set(hole.position.x, 0.065, hole.position.z);
      this.scene.add(ring);
      const sprite = new T.Sprite(
        new T.SpriteMaterial({
          map: label(COLORS[p.seat].toUpperCase() + " HOME", HEX[p.seat]),
          depthTest: false,
        }),
      );
      sprite.position.set(p.nx * (A + 0.75), 0.65, p.ny * (A + 0.75));
      sprite.scale.set(1.55, 0.29, 1);
      this.scene.add(sprite);
    }
    for (const p of BUMPERS) {
      const group = new T.Group();
      group.position.set(p.x, 0, p.y);
      for (const [r, h, y, mat] of [
        [0.53, 0.09, 0.065, this.chrome],
        [BUMPER_R, 0.39, 0.29, material(0x151a23, 0.65, 0.06)],
        [0.42, 0.09, 0.53, this.chrome],
      ]) {
        const m = new T.Mesh(new T.CylinderGeometry(r, r, h, 40), mat);
        m.position.y = y;
        m.castShadow = m.receiveShadow = true;
        group.add(m);
      }
      this.scene.add(group);
    }
    const floor = new T.Mesh(
      new T.PlaneGeometry(100, 100),
      new T.MeshBasicMaterial({
        color: new T.Color(0x080d19).convertSRGBToLinear(),
      }),
    );
    floor.rotation.x = -Math.PI / 2;
    floor.position.y = -1.02;
    floor.receiveShadow = true;
    this.scene.add(floor);
    const sc = document.createElement("canvas");
    sc.width = sc.height = 64;
    const sg = sc.getContext("2d"),
      gradient = sg.createRadialGradient(32, 32, 2, 32, 32, 32);
    gradient.addColorStop(0, "rgba(0,0,0,.48)");
    gradient.addColorStop(1, "rgba(0,0,0,0)");
    sg.fillStyle = gradient;
    sg.fillRect(0, 0, 64, 64);
    const shadowMat = new T.MeshBasicMaterial({
      map: new T.CanvasTexture(sc),
      transparent: true,
      depthWrite: false,
    });
    this.shadows = Array.from({ length: 18 }, () => {
      const m = new T.Mesh(new T.PlaneGeometry(0.95, 0.95), shadowMat);
      m.rotation.x = -Math.PI / 2;
      m.position.y = 0.018;
      this.scene.add(m);
      return m;
    });
    this.ballMeshes = Array.from({ length: 18 }, (_, id) => {
      const seat = Math.floor(id / 3),
        c = document.createElement("canvas");
      c.width = 512;
      c.height = 256;
      const g = c.getContext("2d");
      g.fillStyle = HEX[seat];
      g.fillRect(0, 0, 512, 256);
      g.fillStyle = "#f7f7f0";
      g.beginPath();
      g.arc(256, 128, 25, 0, Math.PI * 2);
      g.fill();
      g.fillStyle = "#17212e";
      g.font = "bold 38px Arial";
      g.textAlign = "center";
      g.textBaseline = "middle";
      g.fillText(String((id % 3) + 1), 256, 130);
      const mesh = new T.Mesh(
        new T.SphereGeometry(BALL_R, 28, 20),
        new T.MeshPhongMaterial({
          map: Object.assign(new T.CanvasTexture(c), {
            encoding: T.sRGBEncoding,
          }),
          shininess: 80,
          specular: 0x333333,
        }),
      );
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      mesh.userData = { x: null, y: null };
      this.scene.add(mesh);
      return mesh;
    });
    this.halo = new T.Mesh(
      new T.TorusGeometry(BALL_R + 0.08, 0.025, 8, 48),
      new T.MeshBasicMaterial({ color: 0xffdf8c }),
    );
    this.halo.rotation.x = -Math.PI / 2;
    this.scene.add(this.halo);
    this.guide = new T.Line(
      new T.BufferGeometry(),
      new T.LineDashedMaterial({
        color: 0xffffff,
        dashSize: 0.19,
        gapSize: 0.14,
        transparent: true,
        opacity: 0.8,
      }),
    );
    this.scene.add(this.guide);
    this.cue = new T.Group();
    const shaft = new T.Mesh(
      new T.CylinderGeometry(0.035, 0.07, 2.3, 16),
      material(0xb97f47, 0.35, 0.15),
    );
    shaft.rotation.x = Math.PI / 2;
    shaft.position.z = 1.15;
    this.cue.add(shaft);
    const tip = new T.Mesh(
      new T.CylinderGeometry(0.04, 0.04, 0.1, 12),
      material(0x7ac9e9),
    );
    tip.rotation.x = Math.PI / 2;
    this.cue.add(tip);
    this.scene.add(this.cue);
    this.raycaster = new T.Raycaster();
    this.resize = () => {
      const w = container.clientWidth,
        h = container.clientHeight;
      this.renderer.setSize(w, h);
      this.camera.aspect = w / h;
      this.camera.position.set(
        0,
        this.camera.aspect < 1.3 ? 18 : 10.5,
        this.camera.aspect < 1.3 ? 25 : 17,
      );
      this.camera.lookAt(0, 0, 1.1);
      this.camera.updateProjectionMatrix();
    };
    new ResizeObserver(this.resize).observe(container);
    this.resize();
  }
  worldPoint(event) {
    const rect = this.renderer.domElement.getBoundingClientRect();
    this.raycaster.setFromCamera(
      new T.Vector2(
        ((event.clientX - rect.left) / rect.width) * 2 - 1,
        -((event.clientY - rect.top) / rect.height) * 2 + 1,
      ),
      this.camera,
    );
    const v = new T.Vector3();
    return this.raycaster.ray.intersectPlane(
      new T.Plane(new T.Vector3(0, 1, 0), -BALL_R),
      v,
    )
      ? { x: v.x, y: v.z }
      : null;
  }
  draw(game, time) {
    for (const b of game.balls) {
      const mesh = this.ballMeshes[b.id],
        old = mesh.userData;
      if (old.x !== null && b.active) {
        const dx = b.x - old.x,
          dy = b.y - old.y,
          d = Math.hypot(dx, dy);
        if (d > 0.0001 && d < 1) {
          const q = new T.Quaternion().setFromAxisAngle(
            new T.Vector3(dy / d, 0, -dx / d),
            d / BALL_R,
          );
          mesh.quaternion.premultiply(q);
        }
      }
      this.shadows[b.id].visible = b.active;
      this.shadows[b.id].position.set(b.x, 0.018, b.y);
      mesh.visible = b.active;
      mesh.position.set(b.x, BALL_R + 0.02, b.y);
      old.x = b.x;
      old.y = b.y;
    }
    const b = game.balls[game.selected],
      show =
        game.phase === "play" &&
        game.mode === "aim" &&
        !game.paused &&
        b?.active;
    this.halo.visible = this.guide.visible = this.cue.visible = !!show;
    if (show) {
      this.halo.position.set(b.x, 0.035, b.y);
      this.halo.material.color.set(HEX[game.turn]);
      this.halo.scale.setScalar(1 + 0.08 * Math.sin(time * 4));
      const points = traceAim(
        b,
        game.angle,
        game.balls,
        5 + game.power * 10,
      ).map((p) => new T.Vector3(p.x, 0.045, p.y));
      this.guide.geometry.dispose();
      this.guide.geometry = new T.BufferGeometry().setFromPoints(points);
      this.guide.computeLineDistances();
      this.cue.position.set(
        b.x - Math.cos(game.angle) * 0.38,
        0.19,
        b.y - Math.sin(game.angle) * 0.38,
      );
      this.cue.rotation.y = -Math.PI / 2 - game.angle;
    }
    this.renderer.render(this.scene, this.camera);
  }
}
export function drawMini(ctx, game, seat) {
  const d = game.dashboard(seat),
    w = 720;
  ctx.fillStyle = "#0a1424";
  ctx.fillRect(0, 0, w, w);
  ctx.fillStyle = HEX[seat];
  ctx.font = "900 29px Arial";
  ctx.textAlign = "center";
  ctx.fillText("ARCADIUM · BUMPER POOL", 360, 42);
  ctx.fillStyle = "#fff";
  ctx.font = "900 36px Arial";
  ctx.fillText(
    COLORS[seat].toUpperCase() + " · " + d.potted + "/3 HOME",
    360,
    90,
  );
  ctx.font = "bold 23px Arial";
  ctx.fillStyle = "#b6c9df";
  ctx.fillText(
    game.phase === "lobby"
      ? "A JOIN · START WHEN READY"
      : game.phase === "finished"
        ? COLORS[game.winner].toUpperCase() + " WINS"
        : game.paused
          ? "PAUSED"
          : game.turn === seat
            ? game.mode === "aim"
              ? "YOUR SHOT · " + Math.ceil(game.clock) + "s"
              : "WAIT FOR BALLS TO STOP"
            : COLORS[game.turn].toUpperCase() + "'S TURN",
    360,
    126,
  );
  const scale = 29,
    cx = 360,
    cy = 345;
  ctx.beginPath();
  for (let k = 0; k < 6; k++) {
    const a = (k * Math.PI) / 3;
    const x = cx + Math.cos(a) * RADIUS * scale,
      y = cy + Math.sin(a) * RADIUS * scale;
    k ? ctx.lineTo(x, y) : ctx.moveTo(x, y);
  }
  ctx.closePath();
  ctx.fillStyle = "#08746d";
  ctx.fill();
  ctx.strokeStyle = "#617c98";
  ctx.lineWidth = 10;
  ctx.stroke();
  for (const p of POCKETS) {
    ctx.beginPath();
    ctx.arc(cx + p.x * scale, cy + p.y * scale, 15, 0, 7);
    ctx.fillStyle = "#020810";
    ctx.fill();
    ctx.strokeStyle = HEX[p.seat];
    ctx.lineWidth = p.seat === seat ? 6 : 3;
    ctx.stroke();
  }
  for (const p of BUMPERS) {
    ctx.beginPath();
    ctx.arc(cx + p.x * scale, cy + p.y * scale, BUMPER_R * scale, 0, 7);
    ctx.fillStyle = "#102033";
    ctx.fill();
    ctx.strokeStyle = "#b3c1ce";
    ctx.lineWidth = 3;
    ctx.stroke();
  }
  const selected = game.balls[game.selected];
  if (game.turn === seat && game.mode === "aim" && selected?.active) {
    const points = traceAim(selected, game.angle, game.balls, 13);
    ctx.setLineDash([7, 6]);
    ctx.strokeStyle = "#fff";
    ctx.lineWidth = 2;
    ctx.beginPath();
    points.forEach((p, i) =>
      i
        ? ctx.lineTo(cx + p.x * scale, cy + p.y * scale)
        : ctx.moveTo(cx + p.x * scale, cy + p.y * scale),
    );
    ctx.stroke();
    ctx.setLineDash([]);
  }
  for (const b of game.balls) {
    if (!b.active) continue;
    ctx.beginPath();
    ctx.arc(
      cx + b.x * scale,
      cy + b.y * scale,
      BALL_R * scale * (b.seat === seat ? 1.25 : 1),
      0,
      7,
    );
    ctx.fillStyle = HEX[b.seat];
    ctx.fill();
    ctx.strokeStyle =
      b.id === game.selected && game.turn === seat ? "#fff" : "#17232f";
    ctx.lineWidth = b.id === game.selected ? 3 : 1;
    ctx.stroke();
  }
  ctx.fillStyle = "#b9ccdf";
  ctx.font = "bold 21px Arial";
  ctx.fillText("TARGET POCKET: ACROSS THE TABLE", 360, 573);
  ctx.fillStyle = "#293b52";
  ctx.fillRect(80, 601, 560, 19);
  ctx.fillStyle = HEX[seat];
  ctx.fillRect(80, 601, 560 * game.power, 19);
  ctx.font = "bold 25px Arial";
  ctx.fillStyle = "#fff";
  ctx.fillText(
    "POWER " +
      Math.round(game.power * 100) +
      "%   ·   BALL " +
      ((game.selected % 3) + 1),
    360,
    653,
  );
  ctx.font = "19px Arial";
  ctx.fillStyle = "#b9ccdf";
  ctx.fillText("← → AIM   ↑ ↓ POWER   L/R BALL   A SHOOT", 360, 694);
}
