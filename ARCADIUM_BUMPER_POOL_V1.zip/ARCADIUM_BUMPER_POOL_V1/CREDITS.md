# Credits

Game engine, 3D table construction, Mini Vibe live views, integration and tests: original Arcadium Bumper Pool implementation.

Square cover: generated specifically for this game using OpenAI image generation and shown to the owner before inclusion. The playable scene is real Three.js geometry; the cover is not used as a fake gameplay image.

Three.js r128: Copyright 2010–2021 Three.js Authors; MIT licence included at games/bumper-pool/vendor/THREE-LICENSE.txt. Vendored for offline play.

Shared native-input.js and the generic live-game broker are reused unchanged from the established Arcadium shared-controller integration. Generic native receiver is the same platform implementation with the existing in-memory constructor wrapper; no per-game Android code was added.
