@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
title Arcadium Bumper Pool
if not exist "CHECKSUMS.json" goto incomplete
if not exist "START_BUMPER_POOL.py" goto incomplete
where py.exe >nul 2>&1
if errorlevel 1 goto use_python
py -3 -c "import sys, tkinter; assert sys.version_info >= (3,9)" >nul 2>&1
if errorlevel 1 goto use_python
py -3 "START_BUMPER_POOL.py"
goto finish
:use_python
python -c "import sys, tkinter; assert sys.version_info >= (3,9)" >nul 2>&1
if errorlevel 1 goto missing
python "START_BUMPER_POOL.py"
:finish
if errorlevel 1 pause
exit /b
:incomplete
echo Extract the entire ZIP before running START_INSTALL.cmd.
pause
exit /b 1
:missing
echo Use the Python 3.9 or newer with Tkinter that runs your existing Arcadium OS.
echo No dependency was downloaded and no Arcadium file was changed.
pause
exit /b 1
