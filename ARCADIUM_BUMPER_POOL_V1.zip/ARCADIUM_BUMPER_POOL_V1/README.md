# ARCADIUM · BUMPER POOL

Six players take turns on one 3D hexagonal bumper-pool table. Each colour starts with three balls; its matching pocket is **directly across the table**, not beside its starting balls. There are 18 balls and six pockets. First to send all three of your balls home wins this complete single-match build.

## Install and play on the existing Windows PC OS

1. Extract the **entire** `ARCADIUM_BUMPER_POOL_V1.zip`. Keep its files and folders together.
2. Close the existing black Arcadium **server console**, not just the browser.
3. Double-click **START_INSTALL.cmd**. Select your existing **Arcadium_OS_COMPACT** folder containing `arcadium_server.py`, `arcadium_game_bridge.py`, and `data/arcadium.json`.
4. The launcher installs only this game's files and catalogue entry, makes an automatic backup under `arcadium_backups/bumper_pool_*`, starts the original server on **8787**, and opens Bumper Pool. The existing Games carousel gets its own square cover and PLAY entry.
5. Use **START_INSTALL.cmd** for later sessions too. It remembers the selected OS folder; unchanged files do not make another backup. Your old OS shortcut remains unchanged, but does not load this session's extra live-game routing.

Use your existing shared Mini Vibe app. **No APK update.** No dependency download, compiled installer, server-source patch, new HTTP port, Home replacement, security exclusion, or process termination is used. The original Python 3.9+ installation with Tkinter that runs your OS is required. The original server and ordinary controller routes run normally, with the existing generic native-input/live-game wrappers attached in memory. Other registered live-descriptor games remain supported by the same wrapper.

## Controls and rules

- **Mini Vibe:** hold D-pad left/right to aim continuously, up/down to adjust power. Release stops the adjustment; lost heartbeats expire after 650ms. L/R chooses one of your remaining balls. **A takes one shot**. START pauses/resumes.
- Each Mini Vibe receives the PC engine's actual live table, matching target pocket, own count, current turn, power and selected ball. Touch controls use a colour-scoped live session. Inactive players can look at the table but cannot aim, select or shoot for someone else.
- **PC:** arrows aim/power; Q/E changes ball; Space shoots. Click your ball to select; drag on felt to aim. Enter starts/pauses. PC controls apply to the active human seat. The main Shoot button does the same thing.
- Press A in the lobby to join your colour, or click the colour on the PC. Empty seats are explicitly CPU. CPU players aim and shoot their own balls; a disconnected human is never silently converted into a CPU.
- Turns cycle red, blue, green, yellow, pink, white. **One shot per turn, even after a successful pot.** The next turn starts only once all balls stop. There is a 20-second aiming clock; an idle turn passes. Rolling time does not consume another player's clock.
- Wrong-pocket balls return to a legal, unoccupied start position after the shot. Knocking a rival's ball into their correct pocket credits that rival. Matching third pots finish the match after all remaining movement settles.
- The guide predicts static bank directions and stops at another ball. It does not predict a whole chain of moving collisions. Physics runs in small fixed steps on a flat plane; the table, rolling balls, pockets, cue and bumpers are rendered in real WebGL 3D.
- This first build is a complete **single pool match**, following the plan to establish shot feel before adding five-round elimination/ghost powers. Those extra modes are not claimed as built.

## Verification, backup and restore

Run `VERIFY_BUMPER_POOL.py` after the host starts to check the running 8787 routes and six-colour handoff. See VALIDATION.md for actual automated and browser evidence; a responding route is not proof of physical device acceptance.

To undo this installation, close the server and run **RESTORE_BUMPER_POOL.py**. Choose the OS folder and its specific `arcadium_backups/bumper_pool_*` backup. Restore changes only Bumper Pool's own files and entry, preserving later unrelated catalogue edits. If this game's files were edited after installation, restore stops rather than overwrite them. Your original server source never needs restoring because it was not modified.

The package contains transparent CMD/Python source plus HTML/JS/PNG assets. Keep Windows protection enabled. No recipient Defender acceptance, Microsoft review verdict, physical Mini Vibe acceptance, or installed Windows OS verification is claimed from Linux tests.
