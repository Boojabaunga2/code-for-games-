# Validation scope

- Node real Matter.js engine: all six distinct single-use abilities, unlimited practice, pause, three complete CPU rounds, cumulative ranking, under-2048-byte personal dashboards (observed maximum 893 bytes).
- Temporary installed OS fixtures: preserve unrelated Home/games/pairing/settings, idempotent install, exact delivered ZIP normal startup and included launcher, six controller routes, original server bytes unchanged, selective restore with later unrelated edits, stop safely on unknown bridge/edited owned files.
- Generic HTTP host fixtures: scoped private frames and dashboards, replay deduplication, stale turn rejection, token/owner invalidation, path traversal, native input authentication.
- Chromium: missing-host start blocked, six live personal canvases, native held A + D-pad pull, release launches, B ability, heartbeat expiry cancels, touch A hold/release, reconnect, pause, practice reset, 1280×720 layout and other-game handoff.

Screenshots and video are actual browser rendering. The video includes human mouse input followed by the labelled CPU demo; it is not a mockup. Test fixture replaces only the unavailable installed OS bridge, not the gameplay engine or controller adapter.

Remaining: physical Mini Vibes and native Android WebView, exact owner's installed OS, real Wi-Fi/TV, cross-device latency, balance testing with six human players, recipient antivirus acceptance. CI results and runner Defender status are recorded in the review PR; a clean runner scan cannot guarantee the recipient's PC.
