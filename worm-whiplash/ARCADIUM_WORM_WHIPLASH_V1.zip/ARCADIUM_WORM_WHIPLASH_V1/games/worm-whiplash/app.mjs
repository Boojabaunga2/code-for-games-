import { WhiplashGame, COLORS, HEX } from "./engine.mjs";
import { drawScene, drawMini, worldPoint } from "./render.mjs";
const game = new WhiplashGame(),
  slug = "worm-whiplash",
  base = "/arcadium-live/" + slug,
  owner = crypto.randomUUID?.() || String(Date.now()),
  readers = COLORS.map(() => ArcadiumInputState.create()),
  blocked = Array(6).fill(0),
  touch = Array(6).fill(0),
  touchAt = Array(6).fill(-Infinity),
  pads = Array(6).fill(0),
  previous = Array(6).fill(0),
  surfaces = COLORS.map(() =>
    Object.assign(document.createElement("canvas"), {
      width: 720,
      height: 720,
    }),
  );
for (const c of surfaces) c.getContext("2d", { willReadFrequently: true });
const el = (id) => document.getElementById(id),
  timers = [];
let render,
  active = false,
  ever = false,
  displaced = false,
  running = true,
  error = "",
  legacyCursor = null,
  touchCursor = null,
  legacyBusy = false,
  touchBusy = false,
  publishBusy = false,
  nextSeat = 0,
  last = 0,
  lastTurn = "",
  uiKey = "",
  localMask = 0,
  native,
  selectedSeat = 0,
  stageKey = "",
  renderTime = 0,
  viewTime = 0,
  soundOn = false,
  audio = null,
  hostChecked = false,
  hostError = "",
  scoreSnapshot = Array(6).fill(0),
  inputStats = {received:0, lastAge:null}, nextFrame=0;
const releases=Array(6).fill(false),pcTouch=Array(6).fill(0),sessions=Array(6).fill(null),retiredSessions=Array.from({length:6},()=>[]);
const fresh = (e, limit = 1000) => {
  let at = Number(e.at);
  if (at < 1e11) at *= 1000;
  return (
    Number.isFinite(at) && Date.now() - at >= -250 && Date.now() - at <= limit
  );
};
function mask(i) {
  return (
    (readers[i].read() & ~blocked[i]) |
    (Date.now() - touchAt[i] < 650 ? touch[i] : 0) |
    pads[i] | pcTouch[i] |
    (i === selectedSeat ? localMask : 0)
  );
}
function clear() {
  for (let i = 0; i < 6; i++) {
    blocked[i] |= readers[i].read();
    readers[i].clear();
    touch[i] = pads[i] = previous[i] = 0;
    touchAt[i] = -Infinity;releases[i]=false;pcTouch[i]=0;game.cancelPull(i);
  }
  localMask = 0;
}
async function req(path, body) {
  const c = new AbortController(),
    timer = setTimeout(() => c.abort(), 1800);
  try {
    const r = await fetch(path, {
      cache: "no-store",
      priority: body?.image ? "low" : "auto",
      signal: c.signal,
      ...(body
        ? {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(body),
          }
        : {}),
    });
    if (!r.ok) throw Error("HTTP " + r.status);
    return r.json();
  } finally {
    clearTimeout(timer);
  }
}
async function activate() {
  if (!running || displaced || document.hidden) return;
  try {
    const status=await req(base+"/status");
    if(status.protocol!==1)throw Error("Shared host unavailable");
    await req("/arcadium-vibe/activate/" + slug, { owner, renew: ever });
    active = ever = hostChecked = true;
    hostError = "";
    error = "";
  } catch (e) {
    active = false;
    hostChecked = true;
    hostError = e.message;
    error = e.message;
    if (ever) {
      game.paused = true;
      clear();
    }
    if (ever && e.message === "HTTP 409") displaced = true;
  }
}
async function poll(kind) {
  if (
    !running ||
    displaced ||
    document.hidden ||
    (kind === "touch" ? touchBusy : legacyBusy)
  )
    return;
  kind === "touch" ? (touchBusy = true) : (legacyBusy = true);
  try {
    const cursor = kind === "touch" ? touchCursor : legacyCursor,
      d = await req(
        kind === "touch"
          ? base + "/touch/events?after=" + (cursor ?? 0)
          : "/api/vibe/events?after=" + (cursor ?? 0),
      );
    if (cursor !== null && d.latest >= cursor)
      for (const e of d.events
        .filter((e) => e.seq > cursor)
        .sort((a, b) => a.seq - b.seq)) {
        const i = COLORS.indexOf(e.color);
        if (
          i < 0 ||
          !fresh(e, kind === "touch" && e.key?.startsWith("M") ? 650 : 1200)
        )
          continue;
        if (kind === "touch") {
          if (e.turnId !== game.turnId) continue;
          if (/^M[\da-f]{3}$/i.test(e.key)) {
            const next=parseInt(e.key.slice(1),16);if((touch[i]&16)&&!(next&16))releases[i]=true;touch[i]=next;
            touchAt[i] = Date.now();
          } else action(i, e.key);
        } else if (
          !readers[i].seen &&
          ["A", "B", "L1", "R1", "START"].includes(e.button)
        )
          action(i, e.button);
      }
    if (kind === "touch") touchCursor = d.latest;
    else legacyCursor = d.latest;
  } catch (e) {
    error = e.message;
  } finally {
    kind === "touch" ? (touchBusy = false) : (legacyBusy = false);
  }
}
const views=[];let pointer=null;
for(let i=0;i<6;i++){const box=document.createElement('section');box.className='lane';box.id='lane-'+i;box.style.setProperty('--c',HEX[i]);box.innerHTML=`<div class="lane-head"><strong>P${i+1} ${COLORS[i].toUpperCase()}</strong><button class="type" id="type-${i}">HUMAN</button><b class="stars" id="stars-${i}">☆☆☆</b><b class="score" id="score-${i}">0</b></div><canvas width="720" height="430" aria-label="${COLORS[i]} live demolition arena"></canvas><div class="lane-foot"><button class="hold" id="hold-${i}">HOLD A</button><span id="ammo-${i}">3 LAUNCHES</span><button id="ability-${i}" class="ability">B · ${['BLAST','SPLIT','ACID','RICOCHET','GRAPPLE','SHOCKWAVE'][i]}</button></div>`;el('lanes').append(box);const c=box.querySelector('canvas');views.push(c);box.onclick=()=>selectedSeat=i;el('type-'+i).onclick=()=>{if(game.phase==='lobby')game.players[i].human=!game.players[i].human;};
 const hold=el('hold-'+i);hold.onpointerdown=e=>{e.preventDefault();selectedSeat=i;if(active&&game.players[i].human){hold.setPointerCapture(e.pointerId);pcTouch[i]|=16;}};const release=()=>{if(pcTouch[i]&16)releases[i]=true;pcTouch[i]&=~16;};hold.onpointerup=release;hold.onpointercancel=hold.onlostpointercapture=()=>{if(pcTouch[i]&16){game.cancelPull(i);pcTouch[i]&=~16;releases[i]=false;}};
 el('ability-'+i).onclick=()=>action(i,'B');
 c.onpointerdown=e=>{if(!active||!game.players[i].human||document.hidden)return;selectedSeat=i;if(game.players[i].projectiles.length){action(i,'B');return;}const p=worldPoint(c,e);if(p.x>420||!game.beginPull(i))return;c.setPointerCapture(e.pointerId);pointer={i,id:e.pointerId};game.setPull(i,p.x-200,p.y-640);};
 c.onpointermove=e=>{if(pointer?.i!==i||pointer.id!==e.pointerId)return;const p=worldPoint(c,e);game.setPull(i,p.x-200,p.y-640);};c.onpointerup=e=>{if(pointer?.i===i&&pointer.id===e.pointerId){game.launch(i);pointer=null;}};c.onpointercancel=c.onlostpointercapture=()=>{if(pointer?.i===i){game.cancelPull(i);pointer=null;}};
}
async function publish(){if(!active||!running||publishBusy||displaced||document.hidden)return;publishBusy=true;try{const i=nextFrame++%6,d=game.dashboard(i),c=surfaces[i];drawMini(c.getContext('2d'),d);await req(base+'/frame',{owner,seat:i+1,image:c.toDataURL('image/jpeg',.62).split(',')[1],state:{phase:({practice:'play',settling:'results'})[game.phase]||game.phase,paused:game.paused,turnId:game.turnId,dashboards:COLORS.map((_,n)=>game.dashboard(n))}});}catch(e){error=e.message;}finally{publishBusy=false;}}
function action(i,key){if(!active||displaced||document.hidden||!game.players[i])return false;if(game.phase!=='lobby'&&!game.players[i].human)return false;if(/^P[0-9a-f]{2}$/i.test(key)&&!game.players[i].charging&&(touch[i]&16))game.beginPull(i);const r=game.action(i,key);if(key==='START')clear();return r;}
function stageView(){const key=game.turnId+':'+active+':'+hostChecked+':'+displaced;if(stageKey===key)return;stageKey=key;el('stage').hidden=active&&!['lobby','results','finished'].includes(game.phase);let html='';
 if(game.phase==='lobby')html=`<div class="stage-card"><div class="intro"><img src="card.png" alt="Worm Whiplash cover"><div><small>THE WORM IS THE LAUNCHER</small><h1>HOLD A. PULL.<br>LET IT FLY.</h1><p>Three rounds. Three launches each.<br>Smash the forts. Highest destruction total wins.</p></div></div><div class="guide"><span><kbd>A</kbd> HOLD</span><span><kbd>← ↑ ↓ →</kbd> PULL</span><span><kbd>A</kbd> RELEASE</span><span><kbd>B</kbd> ABILITY IN FLIGHT</span></div><div class="ability-grid">${['BLAST','SPLIT','ACID','RICOCHET','GRAPPLE','SHOCKWAVE'].map((n,i)=>`<button id="setup-${i}" style="--c:${HEX[i]}"><strong>${COLORS[i].toUpperCase()} · ${n}</strong><span>HUMAN</span></button>`).join('')}</div><div class="actions"><button id="practice" class="primary">TRY STRETCHING IN PRACTICE</button><button id="start" class="primary gold">START MATCH →</button></div><div class="secondary"><button id="allHuman">ALL HUMAN</button><button id="demo">WATCH CPU DEMO</button><span>You can also drag the worm directly.</span></div></div>`;
 if(['results','finished'].includes(game.phase)){const final=game.phase==='finished';html=`<div class="stage-card"><small>${final?'WORM WHIPLASH CHAMPIONSHIP':'ROUND '+game.round+' · '+game.level().name}</small><h1>${final?COLORS[game.winner].toUpperCase()+' WINS!':'FORTS FALL. SCORES RISE.'}</h1><div class="ranking">${game.rank().map((p,j)=>`<div style="--c:${HEX[p.i]}"><b>${j+1}</b><strong>${p.color.toUpperCase()}</strong><span>${'★'.repeat(p.targets)+'☆'.repeat(3-p.targets)}</span><b>${p.total.toLocaleString()}</b></div>`).join('')}</div>${final?'<button id="replay" class="primary gold">PLAY AGAIN →</button>':'<p>Next fort loads in a moment.</p>'}</div>`;}
 if(!active)html=hostChecked?`<div class="stage-card"><small>MINI VIBE HOST NOT LOADED</small><h1>CONNECT YOUR<br>WORMS FIRST</h1><p>Close the Arcadium server console. Extract the complete ZIP and run<br><b>START_INSTALL.cmd</b>. Select your existing<br><b>Arcadium_OS_COMPACT</b> folder. Play waits until the host is ready.</p><button id="retry" class="primary">CHECK CONNECTION</button></div>`:`<div class="stage-card"><h1>WARMING UP<br>THE WORMS…</h1><p>Checking the shared Mini Vibe host.</p></div>`;
 if(displaced)html=`<div class="stage-card"><h1>ANOTHER GAME<br>IS ACTIVE</h1><p>Return to Arcadium and choose Worm Whiplash again.</p></div>`;
 el('stageContent').innerHTML=html;const bind=(id,fn)=>{if(el(id))el(id).onclick=fn;};bind('retry',activate);bind('practice',()=>{if(active){game.practice();clear();}});bind('start',()=>{if(active){game.start();clear();}});bind('allHuman',()=>game.players.forEach(p=>p.human=true));bind('demo',()=>{if(active){game.players.forEach(p=>p.human=false);game.start();clear();}});bind('replay',()=>{game.lobby();clear();});for(let i=0;i<6;i++)bind('setup-'+i,()=>game.players[i].human=!game.players[i].human);
}
function view(){stageView();el('phase').textContent=game.phase==='practice'?'PRACTICE':'ROUND '+game.round+' / 3';el('level').textContent=game.level().name;el('clock').textContent=game.phase==='practice'?'∞':game.phase==='lobby'?'01:30':game.phase==='finished'?'WIN!':game.phase==='results'?'SCORE':Math.floor(game.clock/60).toString().padStart(2,'0')+':'+Math.min(59,Math.ceil(game.clock%60)).toString().padStart(2,'0');el('connection').textContent=displaced?'ANOTHER GAME ACTIVE':active?'MINI VIBE HOST READY':'CONNECTING MINI VIBES';el('pause').disabled=['lobby','finished'].includes(game.phase);el('pause').textContent=game.paused?'RESUME':'PAUSE';el('pauseScreen').hidden=!game.paused||!active||displaced;el('beginMatch').hidden=game.phase!=='practice'||!active;el('rebuild').hidden=game.phase!=='practice'||!active;
 for(const p of game.players){const i=p.i;el('score-'+i).textContent=p.score.toLocaleString();el('stars-'+i).textContent='★'.repeat(p.targets)+'☆'.repeat(3-p.targets);el('type-'+i).textContent=p.human?'HUMAN':'CPU';el('type-'+i).disabled=game.phase!=='lobby';el('ammo-'+i).textContent=p.charging?Math.round(Math.hypot(p.pullX,p.pullY)/175*100)+'% POWER':game.phase==='practice'?'∞ LAUNCHES':p.shots+' LAUNCHES';const rebuild=game.phase==='practice'&&!p.projectiles.length&&!p.charging;el('ability-'+i).disabled=!active||!p.human||(!rebuild&&(!p.projectiles.length||p.abilityUsed))||game.paused;el('ability-'+i).textContent=rebuild?'B · REBUILD':'B · '+['BLAST','SPLIT','ACID','RICOCHET','GRAPPLE','SHOCKWAVE'][i];el('hold-'+i).disabled=!active||!p.human||!game.canAim(i);el('hold-'+i).textContent=p.charging?'RELEASE A':'HOLD A';el('lane-'+i).className='lane'+(selectedSeat===i?' selected':'');if(el('setup-'+i))el('setup-'+i).querySelector('span').textContent=p.human?'HUMAN':'CPU';}
}
function logic(time){const dt=Math.min(.05,(time-last)/1000||0);last=time;if(lastTurn!==game.turnId){lastTurn=game.turnId;clear();}const gp=navigator.getGamepads?.()||[];
 for(let i=0;i<6;i++){const p=gp[i],oldPad=pads[i];pads[i]=p?((p.axes[0]<-.3||p.buttons[14]?.pressed?4:0)|(p.axes[0]>.3||p.buttons[15]?.pressed?8:0)|(p.axes[1]<-.3||p.buttons[12]?.pressed?1:0)|(p.axes[1]>.3||p.buttons[13]?.pressed?2:0)|(p.buttons[0]?.pressed?16:0)|(p.buttons[1]?.pressed?32:0)|(p.buttons[9]?.pressed?256:0)):0;if(p&&(oldPad&16)&&!(pads[i]&16))releases[i]=true;const m=mask(i),edge=m&~previous[i],fall=previous[i]&~m;
  if(active&&!displaced&&game.players[i].human){if(edge&256){action(i,'START');}else if(!game.paused){if(game.phase==='lobby'){if(edge&16)game.players[i].human=true;}else{if(edge&16)game.beginPull(i);if(m&16)game.movePull(i,Number(!!(m&8))-Number(!!(m&4)),Number(!!(m&2))-Number(!!(m&1)),dt);if(fall&16){if(releases[i])game.launch(i);else game.cancelPull(i);}if(edge&32)action(i,'B');}}}
  releases[i]=false;previous[i]=m;
 }
 if(active&&!displaced)game.update(dt);if(time-viewTime>80){viewTime=time;view();}
}
render={draw:()=>views.forEach((c,i)=>drawScene(c.getContext('2d'),game.dashboard(i),c.width,c.height))};function frame(t){if(t-renderTime>32){renderTime=t;render.draw();}if(running)requestAnimationFrame(frame);}
function pause(){if(!['lobby','finished'].includes(game.phase)){game.paused=!game.paused;clear();pointer=null;}}
el('pause').onclick=el('resume').onclick=pause;el('beginMatch').onclick=()=>{if(active){game.start();clear();}};el('rebuild').onclick=()=>{if(active&&game.phase==='practice'){game.players.forEach(p=>game.buildFort(p));clear();}};
el('new').onclick=()=>{if(['lobby','finished'].includes(game.phase)||confirm('End this demolition match?')){game.lobby();clear();}};el('help').onclick=()=>{if(!['lobby','finished'].includes(game.phase)&&!game.paused)pause();el('rules').showModal();};el('closeHelp').onclick=()=>el('rules').close();
function selectSeat(i){game.cancelPull(selectedSeat);localMask=0;selectedSeat=i;el('pcSeat').value=String(i);}el('pcSeat').onchange=()=>selectSeat(+el('pcSeat').value);
addEventListener('keydown',e=>{if(el('rules').open)return;const bit={ArrowUp:1,ArrowDown:2,ArrowLeft:4,ArrowRight:8,' ':16}[e.key];if(bit){e.preventDefault();localMask|=bit;return;}if(e.repeat)return;if(/^[1-6]$/.test(e.key))selectSeat(+e.key-1);if(e.key.toLowerCase()==='b')action(selectedSeat,'B');if(e.key==='Enter'){e.preventDefault();action(selectedSeat,'START');}if(e.key==='Escape')pause();});addEventListener('keyup',e=>{const bit={ArrowUp:1,ArrowDown:2,ArrowLeft:4,ArrowRight:8,' ':16}[e.key]||0;if(bit===16)releases[selectedSeat]=true;localMask&=~bit;});
function lose(){clear();pointer=null;if(!['lobby','finished'].includes(game.phase))game.paused=true;}addEventListener('blur',lose);document.addEventListener('visibilitychange',()=>{if(document.hidden)lose();else{legacyCursor=touchCursor=null;activate();}});
function exit(){if(!running)return;running=false;clear();native?.stop();timers.forEach(clearInterval);fetch('/arcadium-vibe/activate/'+slug,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({owner,active:false}),keepalive:true}).catch(()=>{});}el('exit').onclick=e=>{e.preventDefault();exit();if(parent!==window)parent.postMessage({type:'ARCADIUM_GAME_EXIT',game:slug},'*');else location.href='/';};addEventListener('pagehide',exit);
window.WORM_WHIPLASH={game,action,mask,clear,surfaces,publish,render,exit,get active(){return active},get displaced(){return displaced},get error(){return error}};
native=ArcadiumInputState.connect({onEvent:e=>{const i=COLORS.indexOf(e.color);if(i<0||displaced||!fresh(e,650))return;const before=readers[i].read(),id=e.button.slice(1,7).toLowerCase();if(sessions[i]!==id){if(retiredSessions[i].includes(id))return;if(sessions[i]){retiredSessions[i].push(sessions[i]);if(retiredSessions[i].length>8)retiredSessions[i].shift();game.cancelPull(i);}sessions[i]=id;}readers[i].receive(e.button);const after=readers[i].read();if((before&16)&&!(after&16))releases[i]=true;blocked[i]&=after;},onReset:clear,onError:e=>{if(e)error=e;}});
await activate();await poll('legacy');await poll('touch');view();timers.push(setInterval(()=>logic(performance.now()),16),setInterval(activate,2200),setInterval(()=>poll('legacy'),45),setInterval(()=>poll('touch'),45),setInterval(publish,100));requestAnimationFrame(frame);
