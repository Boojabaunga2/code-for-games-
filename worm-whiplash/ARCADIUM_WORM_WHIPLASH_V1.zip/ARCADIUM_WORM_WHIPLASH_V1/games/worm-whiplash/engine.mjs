export const COLORS=['red','blue','green','yellow','pink','white'];
export const HEX=['#ef3a36','#29aaf0','#75c435','#ffd43b','#f656b5','#f6ecd9'];
export const ABILITIES=[
 {name:'BLAST',hint:'A tight, powerful explosion',icon:'✹'},
 {name:'SPLIT',hint:'Split into three flying worms',icon:'⋔'},
 {name:'ACID',hint:'Corrode nearby fort blocks',icon:'◉'},
 {name:'RICOCHET',hint:'Boost and bounce through supports',icon:'↯'},
 {name:'GRAPPLE',hint:'Latch onto a beam and yank it loose',icon:'⌁'},
 {name:'SHOCKWAVE',hint:'Two wide structural shockwaves',icon:'◎'}
];
export const GROUND=770,ANCHOR={x:200,y:640},WORLD_W=1500;
export const MATERIALS={wood:{hp:30,points:120,density:.002,friction:.65,restitution:.06},glass:{hp:18,points:100,density:.0015,friction:.4,restitution:.03},stone:{hp:85,points:240,density:.004,friction:.8,restitution:.03},core:{hp:40,points:1500,density:.002,friction:.5,restitution:.05}};
function tower(cx,width,n,post,roof,cores=false){const a=[];for(let k=0;k<n;k++){const base=GROUND-k*110;a.push({kind:post,x:cx-width/2+15,y:base-45,w:post==='stone'?30:23,h:90},{kind:post,x:cx+width/2-15,y:base-45,w:post==='stone'?30:23,h:90},{kind:roof,x:cx,y:base-100,w:width+20,h:20});if(cores&&[0,1,n-1].includes(k))a.push({kind:'core',x:cx,y:base-19,w:38,h:38});}return a;}
export const LEVELS=[
 {name:'WOODWORKS',bodies:[...tower(1010,230,3,'wood','wood',true),...tower(770,100,2,'glass','wood'),...tower(1240,100,2,'wood','wood')]},
 {name:'GLASSHOUSE',bodies:[...tower(1010,240,4,'glass','wood',true),...tower(765,100,2,'glass','glass'),...tower(1250,100,2,'glass','wood')]},
 {name:'GARDEN KEEP',bodies:[...tower(1010,250,3,'stone','wood',true),...tower(760,110,2,'wood','wood'),...tower(1250,110,2,'glass','stone')]}
];
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
export class WhiplashGame{
 constructor(M=globalThis.Matter){if(!M)throw Error('Offline physics library did not load');this.M=M;this.serial=0;this.lobby();}
 setPhase(phase,clock=0){this.phase=phase;this.clock=clock;this.turnId=`${++this.serial}:${phase}`;}
 player(i,human=true,total=0){const p={i,color:COLORS[i],human,total,score:0,targets:0,shots:3,pullX:-105,pullY:75,charging:false,abilityUsed:false,projectiles:[],effects:[],links:[],time:0,cooldown:0,settled:0,done:false,toast:'',toastUntil:0,cpuWait:1+i*.2,cpuPull:0};this.buildFort(p);return p;}
 buildFort(p){const {Engine,Bodies,Composite,Events}=this.M;p.engine=Engine.create({enableSleeping:true,positionIterations:8,velocityIterations:8});p.engine.gravity.y=1;p.blocks=[];p.projectiles=[];p.links=[];p.effects=[];p.targets=0;p.done=false;p.charging=false;p.abilityUsed=false;p.settled=0;p.score=0;p.cooldown=0;
  const ground=Bodies.rectangle(WORLD_W/2,GROUND+40,WORLD_W+400,80,{isStatic:true,friction:.8,label:'ground'});Composite.add(p.engine.world,ground);
  this.level().bodies.forEach((d,index)=>{const m=MATERIALS[d.kind],opts={density:m.density,friction:m.friction,restitution:m.restitution,frictionAir:.003,label:d.kind,render:{visible:false}};const b=d.kind==='core'?Bodies.circle(d.x,d.y,19,opts):Bodies.rectangle(d.x,d.y,d.w,d.h,opts);b._fort={index,kind:d.kind,health:m.hp,max:m.hp,dead:false,acidUntil:0};p.blocks.push(b);Composite.add(p.engine.world,b);});
  for(let n=0;n<120;n++)Engine.update(p.engine,1000/120);
  Events.on(p.engine,'collisionStart',event=>this.collisions(p,event.pairs));
 }
 level(){return LEVELS[Math.max(0,this.round-1)%LEVELS.length];}
 lobby(){this.round=1;this.time=0;this.paused=false;this.winner=null;this.players=COLORS.map((_,i)=>this.player(i));this.setPhase('lobby');}
 reset(phase){const types=this.players.map(p=>p.human);this.round=1;this.time=0;this.paused=false;this.winner=null;this.players=types.map((h,i)=>this.player(i,h));this.setPhase(phase,phase==='countdown'?3:0);}
 practice(){if(this.phase!=='lobby')return false;this.reset('practice');return true;}
 start(){if(!['lobby','practice'].includes(this.phase))return false;this.reset('countdown');return true;}
 canAim(i){const p=this.players[i];return !!p&&!this.paused&&['play','practice'].includes(this.phase)&&!p.done&&p.projectiles.length===0&&p.cooldown===0&&(this.phase==='practice'||p.shots>0);}
 beginPull(i){const p=this.players[i];if(!this.canAim(i)||p.charging)return false;p.charging=true;return true;}
 setPull(i,x,y){const p=this.players[i];if(!p?.charging||!this.canAim(i))return false;x=clamp(Number(x),-155,-25);y=clamp(Number(y),15,115);const r=Math.hypot(x,y);if(r>175){x=x/r*175;y=y/r*175;}p.pullX=x;p.pullY=y;return true;}
 movePull(i,dx,dy,dt){const p=this.players[i];return this.setPull(i,p.pullX+dx*105*dt,p.pullY+dy*105*dt);}
 cancelPull(i){if(this.players[i])this.players[i].charging=false;}
 launch(i){const p=this.players[i];if(!p?.charging||!this.canAim(i))return false;p.charging=false;p.abilityUsed=false;p.settled=0;if(this.phase!=='practice')p.shots--;const x=ANCHOR.x+p.pullX,y=ANCHOR.y+p.pullY;this.spawnWorm(p,x,y,-p.pullX*.12,-p.pullY*.12,22);p.cpuWait=1.2;return true;}
 spawnWorm(p,x,y,vx,vy,r){const {Bodies,Body,Composite}=this.M,b=Bodies.circle(x,y,r,{density:.012,friction:.4,restitution:.25,frictionAir:.0015,label:'worm'});b._worm={born:p.time,r,acid:false,ricochet:0};Body.setVelocity(b,{x:vx,y:vy});p.projectiles.push(b);Composite.add(p.engine.world,b);return b;}
 message(p,text){p.toast=text;p.toastUntil=p.time+2;}
 fx(p,type,x,y,size=100){p.effects.push({type,x,y,size,at:p.time});if(p.effects.length>10)p.effects.shift();}
 damage(p,b,amount){const d=b?._fort;if(!d||d.dead||amount<=0)return;const actual=Math.min(d.health,amount);d.health-=actual;p.score+=Math.round(actual*2);if(d.health<=0){d.dead=true;p.score+=MATERIALS[d.kind].points;if(d.kind==='core'){p.targets++;this.message(p,'FORT CORE SMASHED!');}this.fx(p,d.kind==='glass'?1:d.kind==='core'?2:0,b.position.x,b.position.y,d.kind==='core'?90:45);}}
 collisions(p,pairs){for(const pair of pairs){const a=pair.bodyA,b=pair.bodyB;if(!a._fort&&!b._fort)continue;const speed=Math.hypot(a.velocity.x-b.velocity.x,a.velocity.y-b.velocity.y);if(speed<2.8)continue;for(const [target,source]of[[a,b],[b,a]]){if(!target._fort||target._fort.dead)continue;const mult=source._worm?5.2:1.8;this.damage(p,target,(speed-2)*mult);if(source._worm?.acid)target._fort.acidUntil=p.time+4;if(source._worm?.ricochet>0){this.damage(p,target,16);source._worm.ricochet--;}}}}
 radial(p,x,y,radius,damage,force,type){const {Body}=this.M;for(const b of p.blocks){if(b._fort.dead)continue;const dx=b.position.x-x,dy=b.position.y-y,d=Math.hypot(dx,dy);if(d>radius)continue;const f=1-d/radius;this.damage(p,b,damage*f);this.M.Sleeping.set(b,false);Body.setVelocity(b,{x:b.velocity.x+(dx/(d||1))*force*f,y:b.velocity.y+(dy/(d||1))*force*f-2*f});}this.fx(p,type,x,y,radius);}
 ability(i){const p=this.players[i];if(!p||p.abilityUsed||!p.projectiles.length||this.paused||!['practice','play','settling'].includes(this.phase))return false;const b=p.projectiles[0],x=b.position.x,y=b.position.y,{Body,Composite,Constraint}=this.M;p.abilityUsed=true;this.message(p,ABILITIES[i].name+'!');
  if(i===0){this.radial(p,x,y,225,110,11,3);this.removeWorm(p,b);}
  if(i===1){this.spawnWorm(p,x+15,y-42,b.velocity.x*1.04,b.velocity.y-4.5,15);this.spawnWorm(p,x+15,y+42,b.velocity.x*.95,b.velocity.y+4.5,15);this.fx(p,4,x,y,95);}
  if(i===2){b._worm.acid=true;for(const q of p.blocks)if(!q._fort.dead&&Math.hypot(q.position.x-x,q.position.y-y)<155)q._fort.acidUntil=p.time+4;this.fx(p,5,x,y,155);}
  if(i===3){b.restitution=1.13;b._worm.ricochet=3;Body.setVelocity(b,{x:b.velocity.x*1.28,y:b.velocity.y*1.28-2});this.fx(p,6,x,y,85);}
  if(i===4){const target=p.blocks.filter(q=>!q._fort.dead&&this.level().bodies[q._fort.index].w>this.level().bodies[q._fort.index].h*2).sort((a,c)=>Math.hypot(a.position.x-x,a.position.y-y)-Math.hypot(c.position.x-x,c.position.y-y))[0];if(target){const link=Constraint.create({bodyA:b,bodyB:target,length:55,stiffness:.055,damping:.08});p.links.push({link,until:p.time+2});Composite.add(p.engine.world,link);this.damage(p,target,24);this.M.Sleeping.set(target,false);Body.setAngularVelocity(target,.13);const dx=x-target.position.x,dy=y-target.position.y,d=Math.hypot(dx,dy)||1;Body.setVelocity(target,{x:dx/d*12,y:dy/d*12-4});Body.setVelocity(b,{x:b.velocity.x*.6,y:-5});this.fx(p,7,x,y,90);}}
  if(i===5){this.radial(p,x,y,270,18,9,8);b._worm.shockAt=p.time+.35;}
  return true;
 }
 removeWorm(p,b){const {Composite}=this.M;for(const q of p.links.filter(q=>q.link.bodyA===b||q.link.bodyB===b))Composite.remove(p.engine.world,q.link);p.links=p.links.filter(q=>q.link.bodyA!==b&&q.link.bodyB!==b);Composite.remove(p.engine.world,b);p.projectiles=p.projectiles.filter(q=>q!==b);p.cooldown=.5;}
 action(i,key){const p=this.players[i];if(!p)return false;if(this.phase==='lobby'){if(key==='A'){p.human=true;return true;}if(key==='START')return this.start();return false;}if(key==='START'&&p.human&&this.phase!=='finished'){this.paused=!this.paused;this.players.forEach(q=>q.charging=false);return true;}if(this.paused||!p.human)return false;if(key==='CANCEL'){this.cancelPull(i);return true;}if(/^P[0-9a-f]{2}$/i.test(key)){const n=parseInt(key.slice(1),16);return this.setPull(i,-155+(n>>4)/15*130,15+(n&15)/15*100);}if(key==='A'){return p.charging?this.launch(i):this.beginPull(i);}if(key==='B'){if(p.projectiles.length)return this.ability(i);if(this.phase==='practice'){this.buildFort(p);return true;}}return false;}
 update(dt){if(this.paused||['lobby','finished'].includes(this.phase))return;dt=clamp(dt,0,.1);this.time+=dt;if(this.phase==='countdown'){this.clock=Math.max(0,this.clock-dt);if(this.clock===0)this.setPhase('play',90);return;}if(this.phase==='results'){this.clock=Math.max(0,this.clock-dt);if(this.clock===0){if(this.round===3){this.winner=this.rank()[0].i;this.setPhase('finished');}else{const old=this.players;this.round++;this.players=old.map(p=>this.player(p.i,p.human,p.total));this.setPhase('countdown',3);}}return;}
  for(let left=dt;left>1e-8;){const step=Math.min(left,1/120);for(const p of this.players)this.stepPlayer(p,step);left-=step;}
  if(this.phase==='play'){this.clock=Math.max(0,this.clock-dt);if(this.clock===0||this.players.every(p=>p.done)){this.players.forEach(p=>p.charging=false);this.setPhase('settling',3);}}
  else if(this.phase==='settling'){this.clock=Math.max(0,this.clock-dt);if(this.clock===0){this.players.forEach(p=>p.total+=p.score);this.setPhase('results',4);}}
 }
 stepPlayer(p,dt){const {Engine,Composite,Body}=this.M;p.time+=dt;p.cooldown=Math.max(0,p.cooldown-dt);
  if(!p.human&&['play','practice'].includes(this.phase)&&!p.done){p.cpuWait-=dt;if(this.canAim(p.i)&&p.cpuWait<=0){if(!p.charging){this.beginPull(p.i);const k=3-p.shots;this.setPull(p.i,-(104+k*13+p.i*1.2),72+k*6);p.cpuPull=.65;}else{p.cpuPull-=dt;if(p.cpuPull<=0)this.launch(p.i);}}if(!p.abilityUsed&&p.projectiles[0]?.position.x>730)this.ability(p.i);}
  Engine.update(p.engine,dt*1000);
  for(const b of p.blocks){const d=b._fort;if(d.dead){if(!d.removed){Composite.remove(p.engine.world,b);d.removed=true;for(const q of p.blocks)if(!q._fort.dead)this.M.Sleeping.set(q,false);}continue;}if(d.acidUntil>p.time)this.damage(p,b,24*dt);if(b.position.y>880||b.position.x<0||b.position.x>WORLD_W+100)this.damage(p,b,999);}
  for(const b of [...p.projectiles]){const d=b._worm;if(d.shockAt&&p.time>=d.shockAt){d.shockAt=0;this.radial(p,b.position.x,b.position.y,270,18,9,8);}const speed=Math.hypot(b.velocity.x,b.velocity.y);if(speed>28)Body.setVelocity(b,{x:b.velocity.x/speed*28,y:b.velocity.y/speed*28});if(p.time-d.born>6.5||b.position.x>1600||b.position.x<-100||b.position.y>860||b.position.y< -900||(p.time-d.born>2&&speed<.8))this.removeWorm(p,b);}
  for(const q of [...p.links])if(q.until<p.time){Composite.remove(p.engine.world,q.link);p.links=p.links.filter(v=>v!==q);}
  p.effects=p.effects.filter(q=>p.time-q.at<1.4);
  const moving=p.blocks.some(b=>!b._fort.dead&&!b.isSleeping&&Math.hypot(b.velocity.x,b.velocity.y)>.8);p.settled=moving?0:p.settled+dt;
  if(this.phase!=='practice'&&!p.projectiles.length&&p.settled>1.1&&(p.shots===0||p.targets===3))p.done=true;
 }
 rank(){return [...this.players].sort((a,b)=>{const score=p=>p.total+(['results','finished'].includes(this.phase)?0:p.score);return score(b)-score(a)||b.targets-a.targets||a.i-b.i;});}
 dashboard(i){const p=this.players[i];return{seat:i,color:p.color,phase:this.phase,turnId:this.turnId,paused:this.paused,round:this.round,clock:Math.ceil(this.clock*10)/10,score:p.score,total:p.total,stars:p.targets,ammo:this.phase==='practice'?-1:p.shots,pull:[Math.round(p.pullX),Math.round(p.pullY)],charging:p.charging,ready:this.canAim(i),used:p.abilityUsed,done:p.done,time:Math.round(p.time*100)/100,toast:p.toastUntil>p.time?p.toast:'',b:p.blocks.map(b=>[Math.round(b.position.x),Math.round(b.position.y),Math.round(b.angle*100),b._fort.dead?0:Math.max(1,Math.round(b._fort.health))*(b._fort.acidUntil>p.time?-1:1)]),w:p.projectiles.map(b=>[Math.round(b.position.x),Math.round(b.position.y),Math.round(Math.atan2(b.velocity.y,b.velocity.x)*100),b._worm.r,b._worm.acid?2:b._worm.ricochet?3:0]),e:p.effects.slice(-6).map(e=>[e.type,Math.round(e.x),Math.round(e.y),Math.round((p.time-e.at)*100),e.size]),l:p.links.map(q=>[Math.round(q.link.bodyA.position.x),Math.round(q.link.bodyA.position.y),Math.round(q.link.bodyB.position.x),Math.round(q.link.bodyB.position.y)])};}
}
