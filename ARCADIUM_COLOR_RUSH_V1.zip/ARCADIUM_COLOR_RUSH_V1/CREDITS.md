# Credits

Original Color Rush rules supplied in the user's color-rush.zip: bank colors, roll / double up / steal, first to four of your own color. Rebuilt for the existing Arcadium OS and shared Mini Vibe platform.

Original Paint Crew, arena and cover images generated for this build with OpenAI image generation. Six-character transparent 3-by-2 atlas is used directly at runtime without separate cutout edits. All fonts use local system Arial; no remote assets or third-party SDKs needed. No worms or original embedded dice SDK retained.
