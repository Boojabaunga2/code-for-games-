# Validation

Run `node integrations/color-rush/tests/engine.test.mjs` from the repository.
Build: `python integrations/color-rush/build_package.py`.
Python: `python -m unittest discover -s integrations/color-rush/tests -p 'test_*.py'`.
Exact original receiver harness: `python integrations/color-rush/tests/harness.py --server-reference PATH_TO_ORIGINAL_arcadium_server.py`.
Browser: `NODE_PATH=/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules node integrations/color-rush/tests/browser.cjs`.

Tests cover held direction/release, wrong-seat rejection, fair flip selection, rolling and both double outcomes, target cycling, steals, wins, replay, pause, twelve complete six-CPU matches, six personal routes, stale frames and handoff, touch sequence and color, packaged installs/reinstalls/rollback, preservation of prior games and pairing. Browser tests post through the exact original Python input receiver and unchanged shared raw input wrapper; they are not physical-device tests.

Hardware acceptance still pending: six Mini Vibes on the actual LAN, every D-pad and shoulder button, A/B/START, per-player vaults, pause/reconnect and handoff to earlier games.

## Completed automated results

Engine suite PASS, including 12 complete seeded six-CPU matches. Five Python route/installer tests PASS. Chromium suite PASS with six live personal pages and the exact original PC input receiver, including simultaneous raw state packets and reliable action impulses (no duplicate actions), held/released and expired D-pad input, native shoulders, actual touch stealing, pause/resume, victory/replay, compact setup, no script errors, and Kitty/Final Cut handoff. Screenshots and browser log are in repository review/. Windows CMD test and public-download verification are recorded separately in review/delivery.json when available.
