# Arcadium Color Rush — Paint Crew V1

Extract the whole ZIP. Double-click **START_INSTALL.cmd**. Select the existing **Arcadium_OS_COMPACT** folder. Restart Windows once and open Color Rush in the carousel.

Uses the existing universal Mini Vibe v16 app and pairing. **No APK included or required.** The Windows Shared Mini Vibe Controls platform must already be present. Requires the existing Python Arcadium OS server on port 8787. The launcher finds Python with Tk, or uses official Python 3.12 via winget if absent.

## How to play

2–6 players, any mix of human and CPU. A readies a personal seat; START launches the match. The PC crew setup cycles each seat through HUMAN / CPU / OFF. Fill Empty Seats turns unready seats into CPU; a physical A press reclaims a CPU seat before launch.

Automatic random flip-offs choose an active player fairly. Choose ROLL, DOUBLE UP or STEAL. Every color can be banked, but the first player to bank four of their own color wins.

- ROLL: A rolls a digital color die. An unanswered roll runs automatically after 8 seconds.
- DOUBLE UP: an automatic fair coin flip grants two rolls on a win; on a loss every other player gets one roll.
- STEAL: D-pad or L/R cycles opponents with paint. A locks the target. Aiming resets a 3-second auto-lock; initial targeting waits 8 seconds. Then select an available paint color and A to steal one. B backs up.
- X/Y: cosmetic character taunts, limited to one every 3 seconds. They never change luck, paint or controls.
- START: pause/resume; in results START plays a rematch. Crew Setup on the PC returns to lobby.
- PC preview: arrows navigate, Space/Enter confirms, Q/E are shoulders, Backspace backs up, Escape pauses. Real USB gamepads use standard mapping for seats 1–6.

Choose/roll/target/pick phases have safe automatic timeouts so an idle player cannot stall a match. All timers pause when the PC game becomes hidden; START or the PC Resume button resumes.

## Six personal paint stations

CAPS (red robot), DRIP (blue paint creature), ROLLIE (green raccoon), SPARK (yellow inventor), BRISTLE (pink punk cat), GHOST (white hooded thief). Ghost is a character name, not an elimination mode; this game has no elimination.

Each Mini Vibe shows its own character, six-color vault, own-color progress, current action, targeted warning and touch controls. Characters bounce, shake and taunt in response to play. No motion sensors or physical dice are required.

## Preservation and rollback

Installer validates all package hashes and the existing bridge before writing. It wraps the current shared bridge, adds only this game's files/helper and updates only Color Rush's catalogue entry. Main server, Home, input receiver, pairing, other games and their cards are not replaced. Existing Color Rush is backed up. Reinstall is idempotent.

Use the installer's rollback button and select its color_rush_v1_* backup. Guarded rollback refuses to overwrite later changes. Command-line alternative: `python update_color_rush.py --rollback PATH`.

## Verification limits

See VALIDATION.md. Automated engine, browser, exact-receiver, route and installer tests are provided. Six physical Mini Vibes and venue Wi-Fi still need an on-device acceptance check. Never disable antivirus to install this package.
