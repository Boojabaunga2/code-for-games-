export const COLORS=['#ff4055','#3ba9ff','#5ce786','#ffd04b','#ff6aca','#edf4ff'];
export const NAMES=['RED','BLUE','GREEN','YELLOW','PINK','WHITE'];
export const CREW=['CAPS','DRIP','ROLLIE','SPARK','BRISTLE','GHOST'];
export const ROLES=['SPRAY-CAN ROBOT','PAINT-DROP CREATURE','ROLLER RACCOON','SPLATTER INVENTOR','PUNK PAINT CAT','MASKED PAINT THIEF'];
export function createGame({rng=Math.random}={}){
 const S={phase:'lobby',paused:false,selected:Array(6).fill(true),cpu:Array(6).fill(false),ready:Array(6).fill(false),inv:Array.from({length:6},()=>Array(6).fill(0)),active:-1,target:-1,choice:0,paint:0,timer:0,elapsed:0,round:0,queue:[],die:0,coin:null,winner:null,message:'MEET YOUR PAINT CREW',detail:'Bank any color. Collect four of YOUR color to win.',log:[],reaction:Array(6).fill('idle'),reactUntil:Array(6).fill(0),tauntUntil:Array(6).fill(0),stats:Array.from({length:6},()=>({rolls:0,steals:0,robbed:0})),serial:0};
 const events=[],held=Array(6).fill(0),repeat=Array(6).fill(0);let later='flip',rollSeat=-1,cpuWait=0;
 const rand=n=>Math.min(n-1,Math.max(0,Math.floor(rng()*n))),alive=()=>S.selected.map((v,i)=>v?i:-1).filter(i=>i>=0),total=i=>S.inv[i].reduce((a,b)=>a+b,0),targets=()=>alive().filter(i=>i!==S.active&&total(i)>0),paints=()=>S.target<0?[]:S.inv[S.target].map((v,i)=>v>0?i:-1).filter(i=>i>=0);
 function log(m){S.log.unshift(m);S.log.length=Math.min(S.log.length,5);}
 function react(i,r,seconds=2){if(i<0)return;S.reaction[i]=r;S.reactUntil[i]=S.elapsed+seconds;}
 function enter(p,t,m,d=''){S.phase=p;S.timer=t;S.message=m;S.detail=d;S.serial++;cpuWait=.85;held.fill(0);repeat.fill(0);}
 function flip(){S.active=-1;S.target=-1;S.choice=0;S.coin=null;S.round++;enter('flip',2.5,'FLIP-OFF!','Everyone gets a fair shot. Who gets the next move?');}
 function win(i){S.winner=i;enter('results',0,CREW[i]+' WINS!',NAMES[i]+' collected four of their own color!');react(i,'win',999);events.push({type:'winner',seat:i});}
 function after(){const w=alive().find(i=>S.inv[i][i]>=4);if(w!==undefined)return win(w);flip();}
 function feedback(m,d,next='flip',seconds=2){later=next;enter('feedback',seconds,m,d);}
 function startRoll(queue){S.queue=queue.slice();rollSeat=S.queue[0];S.die=0;enter('roll',8,CREW[rollSeat]+' — ROLL!', 'A to roll the color die. All six colors can be banked.');}
 function roll(){if(S.phase!=='roll')return;enter('rolling',1.3,'MIXING IT UP…',CREW[rollSeat]+' is rolling for paint!');react(rollSeat,'roll');}
 function resolveRoll(){const c=rand(6);S.die=c;S.inv[rollSeat][c]++;S.stats[rollSeat].rolls++;react(rollSeat,c===rollSeat?'happy':'roll',2.6);events.push({type:'paint',seat:rollSeat,color:c});log(CREW[rollSeat]+' banked '+NAMES[c]+' paint');S.queue.shift();if(S.inv[rollSeat][rollSeat]>=4)return win(rollSeat);feedback(NAMES[c]+' PAINT!',CREW[rollSeat]+(c===rollSeat?' got their own color!':' banks it. Steal it back later.'),S.queue.length?'nextRoll':'flip');}
 function choose(n){if(S.phase!=='choose'||!Number.isInteger(n)||n<0||n>2)return;if(n===2&&!targets().length){S.detail='Nobody has paint yet. Roll or Double Up instead!';return;}
 S.choice=n;if(n===0)startRoll([S.active]);else if(n===1){S.coin=null;enter('double',2,'DOUBLE UP!','Win: two rolls. Lose: everyone else rolls.');react(S.active,'taunt',3);}else{S.target=targets()[0];enter('target',8,'PICK YOUR VICTIM','L / R or D-pad to aim. A locks. Last 3 seconds lock automatically.');react(S.target,'panic',8);}}
 function lock(){if(S.phase!=='target'||!targets().includes(S.target))return;S.paint=paints()[0];enter('pick',8,'TAKE ONE PAINT','Choose an available paint. A steals it. B changes your target.');}
 function steal(){if(S.phase!=='pick'||S.inv[S.target]?.[S.paint]<=0)return;const a=S.active,v=S.target,c=S.paint;S.inv[v][c]--;S.inv[a][c]++;S.stats[a].steals++;S.stats[v].robbed++;react(a,'taunt',3);react(v,'tantrum',3);events.push({type:'steal',seat:a,target:v,color:c});log(CREW[a]+' stole '+NAMES[c]+' from '+CREW[v]);if(S.inv[a][a]>=4)return win(a);feedback('PAINT HEIST!',CREW[a]+' stole '+NAMES[c]+' from '+CREW[v]);}
 function move(i,d){if(S.paused)return;if(S.phase==='lobby')return;if(i!==S.active)return;if(S.phase==='choose'){S.choice=(S.choice+d+3)%3;}else if(S.phase==='target'){const list=targets();react(S.target,'idle',0);S.target=list[(list.indexOf(S.target)+d+list.length)%list.length];S.timer=3;react(S.target,'panic',3);}else if(S.phase==='pick'){const list=paints();S.paint=list[(list.indexOf(S.paint)+d+list.length)%list.length];}}
 function button(i,b){if(!Number.isInteger(i)||i<0||i>5||!S.selected[i]&&S.phase!=='lobby')return;
 if(S.phase==='lobby'){if(b==='A'){S.selected[i]=true;S.cpu[i]=false;S.ready[i]=true;}if(b==='B'){S.selected[i]=!S.selected[i];S.ready[i]=false;}if(b==='START')start();return;}
 if(b==='START'){if(S.phase==='results'){start();return;}S.paused=!S.paused;return;}if(S.paused)return;
 if(b==='X'||b==='Y'){if(S.elapsed>=S.tauntUntil[i]){react(i,'taunt',1.4);S.tauntUntil[i]=S.elapsed+3;events.push({type:'taunt',seat:i});}return;}
 if(i!==S.active&&!(S.phase==='roll'&&i===rollSeat))return;
 if(b==='L1')return move(i,-1);if(b==='R1')return move(i,1);
 if(b==='B'){if(S.phase==='pick'){enter('target',8,'PICK YOUR VICTIM','L / R to aim. A locks your target.');}else if(S.phase==='target'){S.target=-1;enter('choose',12,'YOUR MOVE, '+CREW[S.active],'Roll, risk a Double Up, or steal someone’s paint.');}return;}
 if(b==='A'){if(S.phase==='choose')choose(S.choice);else if(S.phase==='target')lock();else if(S.phase==='pick')steal();else if(S.phase==='roll')roll();}}
 function start(){if(alive().length<2)return false;S.inv=Array.from({length:6},()=>Array(6).fill(0));S.stats=Array.from({length:6},()=>({rolls:0,steals:0,robbed:0}));S.reaction.fill('idle');S.reactUntil.fill(0);S.tauntUntil.fill(0);S.winner=null;S.log=[];S.queue=[];S.paused=false;S.round=0;S.elapsed=0;log('First to four of your own color wins!');flip();return true;}
 function update(dt,masks=[]){dt=Math.max(0,Math.min(Number.isFinite(dt)?dt:0,.25));if(S.paused||S.phase==='results')return;S.elapsed+=dt;for(let i=0;i<6;i++){if(S.reactUntil[i]<S.elapsed)S.reaction[i]='idle';const mask=masks[i]||0;const d=mask&5?-1:mask&10?1:0;if(d){repeat[i]-=dt;if(mask!==held[i]||repeat[i]<=0){move(i,d);repeat[i]=mask!==held[i]?.38:.18;}}else repeat[i]=0;held[i]=mask;}
 if(S.phase==='lobby')return;S.timer=Math.max(0,S.timer-dt);cpuWait-=dt;const actor=S.phase==='roll'?rollSeat:S.active;
 if(S.cpu[actor]&&cpuWait<=0){if(S.phase==='choose'){const t=targets();choose(t.length&&rand(3)===0?2:rand(2));}else if(S.phase==='roll')roll();else if(S.phase==='target'){const t=targets();S.target=t[rand(t.length)];lock();}else if(S.phase==='pick'){S.paint=S.inv[S.target][actor]>0?actor:paints()[rand(paints().length)];steal();}cpuWait=.85;}
 if(S.timer>0)return;
 if(S.phase==='flip'){S.active=alive()[rand(alive().length)];S.choice=0;react(S.active,'happy');log(CREW[S.active]+' wins the flip');enter('choose',12,'YOUR MOVE, '+CREW[S.active],'Roll, risk a Double Up, or steal someone’s paint.');events.push({type:'turn',seat:S.active});}
 else if(S.phase==='choose')choose(0);
 else if(S.phase==='double'){S.coin=rand(2)===1;log(CREW[S.active]+(S.coin?' doubled up!':' busted — everyone else rolls!'));react(S.active,S.coin?'happy':'tantrum',3);feedback(S.coin?'DOUBLED UP!':'BUSTED!',S.coin?'Two rolls for '+CREW[S.active]:'Everyone else gets a roll!','doubleRoll');}
 else if(S.phase==='roll')roll();else if(S.phase==='rolling')resolveRoll();else if(S.phase==='target')lock();else if(S.phase==='pick')steal();else if(S.phase==='feedback'){if(later==='nextRoll'){rollSeat=S.queue[0];enter('roll',8,CREW[rollSeat]+' — ROLL!','A to roll for paint.');}else if(later==='doubleRoll')startRoll(S.coin?[S.active,S.active]:alive().filter(i=>i!==S.active));else after();}}
 return{S,start,update,button,move,choose,targets,paints,total,drainEvents:()=>events.splice(0),get rollSeat(){return rollSeat;},lobby(){S.paused=false;S.active=-1;S.target=-1;enter('lobby',0,'MEET YOUR PAINT CREW','Bank any color. Collect four of YOUR color to win.');}};
}
