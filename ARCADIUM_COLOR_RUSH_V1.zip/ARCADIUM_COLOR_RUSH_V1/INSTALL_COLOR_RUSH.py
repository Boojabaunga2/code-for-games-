from pathlib import Path
import json,tkinter as tk
from tkinter import filedialog
from update_color_rush import install,rollback
ui=tk.Tk();ui.title('Arcadium / Color Rush');ui.geometry('750x430')
status=tk.StringVar(value='Install Color Rush into your existing Arcadium_OS_COMPACT folder. Six new characters, personal paint vaults and shared controller input. Keep the universal Mini Vibe app you already use. No new APK. Home, pairing and other games are preserved.')
tk.Label(ui,text='COLOR RUSH / ROLL. RISK. ROB.',font=('Segoe UI',17,'bold')).pack(pady=20)
tk.Label(ui,textvariable=status,wraplength=700,justify='left',font=('Segoe UI',12)).pack(padx=20,pady=20)
def run():
 folder=filedialog.askdirectory(title='Select your existing Arcadium_OS_COMPACT folder')
 if not folder:return
 try:
  backup=install(Path(folder));Path(__file__).with_name('COLOR_RUSH_RECEIPT.json').write_text(json.dumps({'backup':str(backup)},indent=2));status.set('Installed. Backup: '+str(backup)+'\n\nRestart Windows once, then launch Color Rush from Arcadium. Keep your existing Mini Vibe app and pairing. A readies a player; START begins. D-pad or shoulders select; A confirms; B goes back. CPU seats can fill empty places.\n\nInstallation is not a physical-device test.')
 except Exception as e:status.set('Stopped: '+str(e))
def undo():
 folder=filedialog.askdirectory(title='Select the color_rush_v1_* backup')
 if not folder:return
 try:rollback(Path(folder));status.set('Color Rush update restored. Restart Windows once.')
 except Exception as e:status.set('Rollback stopped: '+str(e))
tk.Button(ui,text='INSTALL COLOR RUSH',command=run,padx=20,pady=12).pack(pady=8)
tk.Button(ui,text='Rollback this game update',command=undo).pack();ui.mainloop()
