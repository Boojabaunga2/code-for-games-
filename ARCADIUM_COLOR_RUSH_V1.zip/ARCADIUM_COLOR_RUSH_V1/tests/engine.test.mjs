import assert from'node:assert/strict';import{createGame}from'../games/color-rush/engine.mjs';
const tick=(g,t)=>{for(let k=0;k<Math.ceil(t/.1);k++)g.update(.1);};
function start(rng=()=>0){const g=createGame({rng});g.start();tick(g,2.6);assert.equal(g.S.phase,'choose');assert.equal(g.S.active,0);return g;}
{
 const g=start();g.update(.1,[8]);assert.equal(g.S.choice,1);g.update(.1,[0]);g.update(.1,[8]);assert.equal(g.S.choice,2);g.update(.1,[0]);tick(g,.5);assert.equal(g.S.choice,2,'Release must stop moving immediately');g.button(1,'A');assert.equal(g.S.phase,'choose','Out of turn A cannot act');g.choose(2);assert.equal(g.S.phase,'choose','Cannot steal empty inventory');g.choose(0);g.button(1,'A');assert.equal(g.S.phase,'roll');g.button(0,'A');tick(g,1.4);assert.equal(g.S.inv[0][0],1);assert.equal(g.S.phase,'feedback');
}
{
 const g=start();g.choose(1);tick(g,2.1);assert.equal(g.S.coin,false);tick(g,2.1);assert.equal(g.S.phase,'roll');assert.equal(g.rollSeat,1);assert.deepEqual(g.S.queue,[1,2,3,4,5],'Failed Double Up rewards everyone except owner');
}
{
 let n=0;const g=start(()=>n++===0?0:.99);g.choose(1);tick(g,4.2);assert.equal(g.S.coin,true);assert.deepEqual(g.S.queue,[0,0]);
}
{
 const g=start();g.S.inv[1][0]=2;g.S.inv[2][3]=1;g.S.inv[0][0]=3;g.choose(2);assert.equal(g.S.target,1);g.button(0,'R1');assert.equal(g.S.target,2);assert.equal(g.S.timer,3);g.button(0,'L1');g.button(0,'A');assert.equal(g.S.phase,'pick');g.button(2,'A');assert.equal(g.S.inv[1][0],2);g.button(0,'A');assert.equal(g.S.inv[0][0],4);assert.equal(g.S.inv[1][0],1);assert.equal(g.S.winner,0);assert.equal(g.S.stats[0].steals,1);assert.equal(g.S.phase,'results');g.button(0,'START');assert.equal(g.S.phase,'flip');assert.equal(g.S.inv.flat().reduce((a,b)=>a+b),0,'Replay resets inventory');
}
{
 const g=start();g.button(1,'START');const time=g.S.timer;tick(g,2);assert.equal(g.S.timer,time,'Pause freezes game');g.button(1,'START');g.S.inv[1][2]=1;g.choose(2);g.button(0,'A');g.button(0,'B');assert.equal(g.S.phase,'target');g.button(0,'B');assert.equal(g.S.phase,'choose');
}
{
 const g=createGame();g.S.selected.fill(false);g.S.selected[3]=true;assert.equal(g.start(),false);g.button(4,'A');assert.equal(g.S.selected[4],true);assert.equal(g.S.ready[4],true);g.start();tick(g,2.6);assert.ok([3,4].includes(g.S.active),'Off seats cannot win flip');
}
// Full seeded six-CPU matches must terminate, conserve steals and never produce negative paint.
for(let seed=1;seed<=12;seed++){
 let n=seed;const g=createGame({rng:()=>{n=(n*1664525+1013904223)>>>0;return n/4294967296;}});g.S.cpu.fill(true);g.start();let k=0;for(;k<80000&&g.S.phase!=='results';k++){g.update(.25);if(k%40===0)assert.ok(g.S.inv.flat().every(v=>Number.isInteger(v)&&v>=0));}assert.equal(g.S.phase,'results','Match seed '+seed+' must finish');assert.equal(g.S.inv[g.S.winner][g.S.winner],4);
}
console.log('PASS: hold/release, turn authority, rolls, Double Up, steals, pauses, replay, 12 complete six-CPU championships');
