import sys,unittest,urllib.parse
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]));import final_cut_verify as v
class Verify(unittest.TestCase):
 def page(self,title='Rocky',desc='1976 American sports drama film',extract='Rocky is a 1976 American sports drama film.'):
  return {'query':{'pages':[{'title':title,'pageid':123,'terms':{'description':[desc]},'extract':extract}]}}
 def test_confirmed_real_movie_has_attributed_online_source(self):
  urls=[]
  def get(url):urls.append(url);return self.page()
  r=v.verify_movie('ROCKY',get_json=get);self.assertEqual(r['status'],'verified');self.assertEqual(r['canonicalTitle'],'Rocky');self.assertEqual(r['source'],'Wikipedia');self.assertEqual(r['url'],'https://en.wikipedia.org/wiki/Rocky');self.assertEqual(urllib.parse.urlsplit(urls[0]).hostname,'en.wikipedia.org')
 def test_absence_failure_wrong_title_and_nonfilm_are_inconclusive(self):
  for data in [{'query':{'pages':[]}},self.page('Something Else'),self.page(desc='American film series',extract='Rocky is a film series.'),self.page(desc='1976 novel',extract='Rocky is a novel adapted into a film.')]:
   self.assertEqual(v.verify_movie('Rocky',get_json=lambda url,data=data:data)['status'],'unresolved')
  def fail(url):raise TimeoutError()
  r=v.verify_movie('Rocky',get_json=fail);self.assertEqual(r['status'],'unresolved');self.assertIn('No player',r['reason'])
 def test_film_disambiguation_qualifiers_and_size_bound(self):
  r=v.verify_movie('ALIEN',get_json=lambda url:self.page('Alien (film)','1979 science fiction film','Alien is a film.'));self.assertEqual(r['status'],'verified');self.assertEqual(r['canonicalTitle'],'Alien');self.assertEqual(v.title_key('Rocky (1976)'),'ROCKY')
  for title in ['', 'A'*91]:self.assertRaises(ValueError,v.verify_movie,title,get_json=lambda url:{})
 def test_no_arbitrary_fetch_from_movie_text(self):
  urls=[]
  v.verify_movie('https://127.0.0.1/admin',get_json=lambda url:urls.append(url) or {})
  self.assertEqual(urllib.parse.urlsplit(urls[0]).hostname,'en.wikipedia.org');self.assertIn('gsrsearch=',urls[0])
if __name__=='__main__':unittest.main()
