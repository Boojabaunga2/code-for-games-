import assert from'node:assert/strict';import{createGame}from'../games/final-cut/engine.mjs';
const make=(two=false)=>{const g=createGame(null,{epoch:'votes'});if(two)g.S.selected=[true,true,false,false,false,false];g.start();g.update(2);return g;},submit=(g,title)=>{g.setEntry(g.S.turn,title);g.submit(g.S.turn);},next=g=>{g.update(3);if(g.S.phase==='ready')g.update(2);};
{
 const g=make();g.update(4);submit(g,'Rocky');assert.equal(g.S.phase,'vote');const frozen=g.S.remaining;g.update(2.99);assert.equal(g.S.phase,'vote');assert.equal(g.S.remaining,frozen);g.update(.011);assert.equal(g.S.phase,'feedback');assert.equal(g.S.last.title,'ROCKY');assert.equal(g.S.required,'Y');assert(g.S.votes.every(v=>v!==null));next(g);g.S.required='R';submit(g,'rocky (1976)');assert.equal(g.S.strikes[1],1);assert.match(g.S.feedback.reason,/already/);console.log('PASS Rocky requires no database; exactly three seconds, silence accepts, drafting clock frozen and normalized repeat blocked');
}
{
 const g=make();submit(g,'Any Unknown Movie');assert(!g.vote(0,'challenge'));assert(!g.vote(1,'accept','stale'));g.button(1,'A');assert.equal(g.S.votes[1],'accept');assert(!g.vote(1,'challenge'));for(let i=2;i<6;i++)g.button(i,'A');assert.equal(g.S.phase,'feedback');assert.equal(g.S.history.length,1);console.log('PASS all surviving other players accept via A; first vote final, submitter/old-turn votes blocked and all accepts proceed early');
}
{
 const g=make();submit(g,'Rocky');g.update(1);const clock=g.S.remaining,vote=g.S.voteRemaining;g.button(2,'B');assert.equal(g.S.phase,'challenge');assert.equal(g.S.challenger,2);g.update(999);assert.equal(g.S.remaining,clock);assert.equal(g.S.voteRemaining,vote);assert(!g.vote(3,'challenge'));assert(g.resolveChallenge(true,{source:'test',canonicalTitle:'Rocky'}));assert.equal(g.S.strikes[2],1);assert.equal(g.S.strikes[0],0);assert.equal(g.S.last.title,'ROCKY');assert.equal(g.S.feedback.challengeWrong,2);assert(!g.resolveChallenge(true));console.log('PASS first challenge freezes both clocks, wrong challenger gets exactly one X and real movie joins the chain');
}
{
 const g=make();submit(g,'Made Up Movie');g.vote(4,'challenge');assert(g.S.phase==='challenge');assert(!g.resolveChallenge(false));assert.equal(g.S.strikes[0],1);assert.equal(g.S.strikes[4],0);assert.equal(g.S.history.length,0);assert.equal(g.S.required,'');console.log('PASS upheld challenge gives submitter X; challenger safe and rejected movie never enters repeat ledger');
}
{
 const g=make(true);g.S.strikes[1]=2;submit(g,'Rocky');g.vote(1,'challenge');g.resolveChallenge(true);assert.equal(g.S.strikes[1],3);next(g);assert.equal(g.S.phase,'results');assert.equal(g.S.winner,0);g.start();g.update(2);assert.equal(g.ledger.size,0);assert(g.S.strikes.every(s=>s===0));assert(g.S.votes.every(v=>v===null));assert.equal(g.S.challenger,null);console.log('PASS challenge third-strike elimination, last survivor and full replay reset');
}
{
 const g=make();submit(g,'Rocky');g.togglePause();const before=JSON.stringify(g.S);g.update(100);assert.equal(JSON.stringify(g.S),before);assert(!g.vote(1,'challenge'));g.togglePause();g.update(3);next(g);const i=g.S.turn;g.update(15);assert.equal(g.S.strikes[i],1);g.update(999);assert.equal(g.S.strikes.reduce((a,b)=>a+b),1);console.log('PASS pause freezes voting, ordinary fifteen-second timeout remains exactly one strike');
}
{
 const g=make();g.S.strikes[3]=3;submit(g,'Rocky');assert.equal(g.S.votes[3],'spectator');assert(!g.vote(3,'challenge'));for(let i of[1,2,4,5])g.vote(i,'accept');next(g);g.S.required='R';submit(g,'Rocky II');g.update(3);next(g);g.S.required='R';submit(g,'Rocky 2');assert.equal(g.S.phase,'feedback');assert.match(g.S.feedback.reason,/already/);console.log('PASS eliminated voters excluded and Roman/Arabic sequel repeats blocked');
}
