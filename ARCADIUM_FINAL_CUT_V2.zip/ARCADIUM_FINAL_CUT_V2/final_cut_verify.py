"""Positive-only online film verification. Missing evidence never means 'fake'."""
import json,re,threading,time,unicodedata,urllib.parse,urllib.request
LOCK=threading.RLock();CACHE={}
UA='Arcadium-FinalCut/2.0 (movie challenge verification; https://github.com/Boojabaunga2/code-for-games-)'
def title_key(s):
 s=re.sub(r'\s*\((?:\d{4}\s+)?film\)\s*$','',str(s),flags=re.I)
 s=re.sub(r'\s*[([](?:18|19|20)\d{2}[)\]]\s*$','',s)
 return re.sub('[^A-Z0-9]','',unicodedata.normalize('NFKD',s).upper())
def _get_json(url):
 req=urllib.request.Request(url,headers={'User-Agent':UA,'Accept':'application/json'})
 with urllib.request.urlopen(req,timeout=3.5) as response:
  data=response.read(600001)
  if len(data)>600000:raise ValueError('Response too large')
  return json.loads(data)
def inspect_pages(data,title):
 expected=title_key(title)
 for page in (data.get('query') or {}).get('pages',[]):
  if not isinstance(page,dict) or page.get('missing') or title_key(page.get('title',''))!=expected:continue
  desc=' '.join((page.get('terms') or {}).get('description',[]));intro=str(page.get('extract') or '')[:650];description=desc.lower()
  if re.search(r'\b(novel|book|film series|film franchise|television series|video game|soundtrack|fictional character|upcoming|unreleased|cancelled)\b',description):continue
  positive=bool(re.search(r'\b(film|movie|short film)\b',description)) or bool(re.search(r'\b(?:is|was)\s+(?:an?\s+)?[^.]{0,180}\bfilm\b',intro,re.I))
  if positive:
   canonical=str(page['title']);url='https://en.wikipedia.org/wiki/'+urllib.parse.quote(canonical.replace(' ','_'),safe='()')
   return {'status':'verified','canonicalTitle':re.sub(r'\s*\((?:\d{4}\s+)?film\)$','',canonical,flags=re.I),'source':'Wikipedia','url':url,'description':desc[:250],'reason':'An online film article matches this title.'}
 return None
def verify_movie(title,get_json=None):
 title=str(title).strip()
 if not 1<=len(title)<=90:raise ValueError('Invalid movie title')
 query=title_key(title);now=time.monotonic()
 if get_json is None:
  with LOCK:
   cached=CACHE.get(query)
   if cached and now-cached[0]<86400:return dict(cached[1])
 getter=get_json or _get_json
 search={'action':'query','format':'json','formatversion':'2','generator':'search','gsrnamespace':'0','gsrlimit':'6','gsrsearch':'"'+title.replace('"','')+'" film','prop':'extracts|pageterms','exintro':'1','explaintext':'1','exchars':'650','wbptterms':'description'}
 url='https://en.wikipedia.org/w/api.php?'+urllib.parse.urlencode(search)
 try:
  result=inspect_pages(getter(url),title)
  if result:
   if get_json is None:
    with LOCK:
     if len(CACHE)>=256:CACHE.pop(next(iter(CACHE)))
     CACHE[query]=(now,dict(result))
   return result
  reason='No matching film article was confirmed. This does not prove the movie is fake.'
 except Exception:reason='The online check could not finish. No player has received a strike from this lookup.'
 return {'status':'unresolved','canonicalTitle':None,'source':'Wikipedia search','url':'https://en.wikipedia.org/w/index.php?'+urllib.parse.urlencode({'search':title+' film'}),'reason':reason}
