# ARCADIUM / FINAL CUT V2 — ACCEPT OR CHALLENGE

Six-player movie chain with matching TV/Mini Vibe clapperboards, a fifteen-second typing timer, three-second voting, online challenge checks, three-strike elimination and a match-local repeat ledger. **No movie catalogue or automatic pre-approval is required.** Includes new square Arcadium-logo carousel artwork for Final Cut and the installed Sniper Kitty card.

## Install — PC only, no new APK

Keep the existing universal v16 Mini Vibe app and pairing.

1. Exit the open game and extract the complete ZIP.
2. Double-click **START_INSTALL.cmd** on the PC.
3. Select the existing **Arcadium_OS_COMPACT** folder.
4. Restart Windows once and open Arcadium normally.

The Mini Vibes automatically load this update’s new personal-page address. No Android install, reset or re-pairing is needed. Home, main server, shared native receiver, prior controller repairs and other games are preserved. Sniper Kitty receives only new carousel artwork/its image registration; its game and controls are unchanged. Other game cards are untouched. Both card changes are included in the guarded backup/rollback. Unknown bridge shapes and duplicate card registrations stop before writes.

## Play

Player 1 names any movie. Each following player names a movie starting with the last letter of the last accepted title. Typing takes fifteen seconds. A repeat, wrong starting letter, empty submission or timeout gives the submitter one X and passes the turn; the required letter stays unchanged. Three Xs eliminate that player. Last survivor wins.

Every otherwise valid submission gets a **three-second acceptance/challenge window**:

- Every other surviving player can press **A / ACCEPT** or **B / CHALLENGE**, or tap the big Mini Vibe buttons.
- No response after three seconds counts as acceptance. If everyone accepts early, play continues early.
- The submitter cannot vote on their own movie. Eliminated players spectate. A player’s first vote is final.
- The first challenge immediately freezes both clocks and locks the voting window. It starts an online film lookup.
- If a matching online film article is confirmed, the challenger gets one X and the movie joins the chain. A wrong challenge can eliminate the challenger.
- If the check is inconclusive or unavailable, play stays paused and nobody is penalized automatically. The host opens the linked Wikipedia or IMDb sources and rules on the challenge.
- Verified real/new movie: challenger gets X. Invalid/repeated movie: submitter gets X and the movie is not added to the chain.

There is no mandatory database qualification popup. ROCKY or another unfamiliar title proceeds to voting. Only an actual player challenge triggers online checking. The online check is positive-only: missing search results or a network failure do not prove that a film is fake. No ChatGPT service, API key or subscription is bundled; verification uses public Wikipedia film-source lookup plus linked host source review.

## Repeats and title rules

The used-title ledger exists only for this match and clears on replay. It ignores case, spaces, punctuation, Latin accents and parenthesized release-year qualifiers. Common Roman/Arabic sequel numbering is normalized, so ROCKY II, ROCKYII and ROCKY 2 cannot be reused as separate answers. ROCKY I / ROCKY 1 count as ROCKY; E.T. and its full title share a repeat key. Different translated/alternate names can be challenged and compared against the match history; a verified canonical title that is already in the ledger is rejected as a repeat.

Articles count: THE GODFATHER starts with T. Numbered sequels use their last alphabetic letter: TOY STORY 3 ends with Y. A purely numeric title such as 1917 requires a title starting with 7. A title is usable once, including remakes sharing the same title. No catalogue is consulted to allow an ordinary submission.

## Controls

On your turn, tap the Mini Vibe keyboard, or hold D-pad to select keys and press A to type. B/L1 deletes; X clears; Y toggles letters/numbers; R1 adds a space; START submits. During voting A accepts and B challenges. Release D-pad to stop selection movement.

In the lobby A joins/readies, B leaves and START launches. The PC can select two to six seats. There are no bots. The host’s PC text field and Enter are a typing fallback; the PC can also pause, inspect history and replay. Standard local gamepads are supported. Hiding the PC game pauses play safely.

Physical state uses the unchanged shared I1 channel and reliable discrete action stream. Raw action levels never generate duplicate A/START impulses. Touch voting/typing is PC-served and colour/session/current-turn bound. Old/off-turn messages, excluded voters and late votes cannot alter the next turn. No hardcoded Android game list is added.

## Verification and limits

Engine tests cover exact three-second voting, default acceptance, first/final votes, frozen challenge clocks, both penalty outcomes, elimination, repeats, keyboard controls, timeout and replay. Browser tests use the actual shared receiver with synthetic invitations, real Mini Vibe touch buttons, both input channels, online-response fixtures, six colours, source-review UI and Kitty handoff. Package tests check exact ZIP integrity, targeted install/repeat/rollback, both card replacements and preservation of prior platform/game files.

External online verification is tested with representative API response fixtures; a live Wikipedia request is not claimed from the restricted build environment. The installed PC needs Internet access for challenged-title lookup/source review. Physical six-device controls, venue Wi-Fi, live external-source availability and the exact running Windows installation still require venue testing.

Backups are under arcadium_backups/final_cut_v2_*. Installer rollback refuses to overwrite later conflicting edits. V1’s old catalogue file may remain unused in an upgraded installation; V2 never loads it. No saved match history or other game data is deleted.
