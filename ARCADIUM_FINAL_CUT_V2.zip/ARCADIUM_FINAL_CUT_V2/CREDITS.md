# Credits

Game concept and challenge rules: the user’s Arcadium movie-chain game, approved FINAL CUT clapperboard UI, three-second acceptance/challenge window and penalties.

Rules engine, match-local repeat ledger, UI, digital timers, input adapters, touch voting, positive-only online verification and installer: original implementation. The cinema backdrop and new Final Cut/Sniper Kitty carousel covers are original generated art made for this project using the supplied Arcadium logo/style. No commercial movie posters or licensed film character artwork is used.

V2 has no bundled movie catalogue or mandatory database qualification. Online challenge results are attributed and linked to Wikipedia; inconclusive checks require host source review. IMDb is linked as an additional host search source. No OpenAI/ChatGPT API integration or credentials are bundled.

The universal native-input reader is copied unchanged from the existing platform. No APK, Android source, shared receiver, Kitty gameplay or other game controllers are replaced. Earlier V1 evidence is retained separately in source history/review; current V2 validation identifies test fixtures and venue-only checks explicitly.
