"""Bitron on the existing Arcadium 8787 lease and server; no new listener."""
import base64,binascii,importlib,ipaddress,json,mimetypes,threading,time,secrets
from pathlib import Path
from urllib.parse import urlsplit,parse_qs,unquote
SLUG='bitron-ghost-uprising';COLORS=('red','blue','green','yellow','pink','white')
BASE=Path(__file__).resolve().parent;LOCK=threading.RLock();FRAMES={};OWNER=None;UI_STATE={};TOUCH_SESSIONS={};TOUCH_EVENTS=[];TOUCH_SEQ=0
def wrap_bitron_handler(Parent):
 class BitronHandler(Parent):
  def log_message(self,format,*args):
   path=urlsplit(getattr(self,'path','')).path
   if path.startswith('/arcadium-bitron/bitron-ghost-uprising/') or path=='/arcadium-vibe/activate/bitron-ghost-uprising':return
   if path in ('/api/vibe/events','/api/vibe/native-events') and self._bitron_active():return
   return super().log_message(format,*args)
  def _bitron_shared(self):
   bridge=importlib.import_module('arcadium_game_bridge');return bridge.ACTIVE_WEB_GAME,bridge.ACTIVE_LOCK
  def _bitron_active(self):
   state,lock=self._bitron_shared()
   with lock:return state['game']==SLUG and time.time()<state['until']
  def _bitron_send(self,data,mime='application/json',status=200):
   self.send_response(status);self.send_header('Content-Type',mime);self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
  def _bitron_host(self):
   try:
    peer=ipaddress.ip_address(self.client_address[0]);local=ipaddress.ip_address(self.connection.getsockname()[0])
    peer=getattr(peer,'ipv4_mapped',None) or peer;local=getattr(local,'ipv4_mapped',None) or local
    return peer.is_loopback or peer==local
   except (ValueError,OSError,AttributeError):return False
  def _bitron_touch(self,path,body=None):
   global TOUCH_SEQ
   apppath='/arcadium-bitron/bitron-ghost-uprising/touch/'
   if not path.startswith(apppath):return False
   if not self._bitron_active():self.send_error(409);return True
   route=path[len(apppath):];now=time.monotonic();ip=self.client_address[0]
   if route=='events' and body is None:
    if not self._bitron_host():self.send_error(403);return True
    try:after=max(0,int(parse_qs(urlsplit(self.path).query).get('after',['0'])[0]))
    except (ValueError,TypeError):self.send_error(400);return True
    with LOCK:data={'latest':TOUCH_SEQ,'events':[dict(e) for e in TOUCH_EVENTS if e['seq']>after]}
    self._bitron_send(json.dumps(data).encode());return True
   if route=='session' and body is None:
    color=parse_qs(urlsplit(self.path).query).get('color',[''])[0].lower()
    if color not in COLORS:self.send_error(400);return True
    with LOCK:
     for token in list(TOUCH_SESSIONS):
      if now-TOUCH_SESSIONS[token]['at']>7200:del TOUCH_SESSIONS[token]
     if len(TOUCH_SESSIONS)>=64:del TOUCH_SESSIONS[next(iter(TOUCH_SESSIONS))]
     token=secrets.token_urlsafe(24);TOUCH_SESSIONS[token]={'ip':ip,'color':color,'at':now,'last':0,'owner':OWNER}
     data={'token':token,'color':color,'state':dict(UI_STATE.get('data',{}))}
    self._bitron_send(json.dumps(data).encode());return True
   token=(body.get('token') if isinstance(body,dict) else parse_qs(urlsplit(self.path).query).get('token',[''])[0])
   with LOCK:
    session=TOUCH_SESSIONS.get(token) if isinstance(token,str) else None
    if not session or session['ip']!=ip or session['owner']!=OWNER or now-session['at']>7200:self.send_error(403);return True
    current=UI_STATE.get('data',{});fresh=now-UI_STATE.get('at',-100)>2.5
    if route=='state' and body is None:
     self._bitron_send(json.dumps({'state':current,'stale':fresh}).encode());return True
    if route!='key' or body is None:self.send_error(404);return True
    n=body.get('seq');key=body.get('key');turn=body.get('turnId')
    if type(n) is not int or not 1<=n<=0x7fffffff or not isinstance(key,str) or not (key in ('A','B','X','Y','START','L1','R1') or len(key)==4 and key.startswith('M0') and key[2] in '01' and key[3].lower() in '0123456789abcdef'):
     self.send_error(400);return True
    if n<=session['last']:self._bitron_send(b'{"ok":true,"duplicate":true}');return True
    if fresh or turn!=current.get('turnId'):
     self.send_error(409);return True
    session['last']=n;TOUCH_SEQ+=1;TOUCH_EVENTS.append({'seq':TOUCH_SEQ,'color':session['color'],'key':key,'turnId':turn})
    if len(TOUCH_EVENTS)>400:del TOUCH_EVENTS[:-300]
   self._bitron_send(b'{"ok":true}');return True
  def do_POST(self):
   global OWNER
   path=urlsplit(self.path).path
   if path.startswith('/arcadium-bitron/bitron-ghost-uprising/touch/'):

    try:
     size=int(self.headers.get('Content-Length','0'))
     if not 0<size<=1024:return self.send_error(413)
     body=json.loads(self.rfile.read(size))
     if not isinstance(body,dict):return self.send_error(400)
     self._bitron_touch(path,body);return
    except (ValueError,TypeError,UnicodeError):return self.send_error(400)
   activate=path=='/arcadium-vibe/activate/'+SLUG;frame=path=='/arcadium-bitron/'+SLUG+'/frame'
   if not activate and not frame:return super().do_POST()
   if not self._bitron_host():return self.send_error(403)
   try:
    size=int(self.headers.get('Content-Length','0'))
    if size<0 or size>(1024 if activate else 300000):return self.send_error(413)
    body=json.loads(self.rfile.read(size) or b'{}')
    if not isinstance(body,dict):raise ValueError()
    if activate:
     enabled=body.get('active',True);renew=body.get('renew',False);owner=body.get('owner')
     if owner is not None and (not isinstance(owner,str) or not 1<=len(owner)<=100):raise ValueError()
     if not isinstance(enabled,bool) or not isinstance(renew,bool):raise ValueError()
     state,lock=self._bitron_shared()
     with lock:
      if enabled and renew and (state['game']!=SLUG or (owner is not None and OWNER!=owner)):return self.send_error(409)
      if enabled:
       if state['game']!=SLUG or time.time()>=state['until'] or (owner is not None and OWNER!=owner):
        with LOCK:FRAMES.clear();UI_STATE.clear();TOUCH_SESSIONS.clear();TOUCH_EVENTS.clear()
       state.update(game=SLUG,until=time.time()+7)
       if owner is not None:OWNER=owner
      elif state['game']==SLUG and (owner is None or OWNER==owner):
       state.update(game=None,until=0)
       with LOCK:FRAMES.clear();UI_STATE.clear();TOUCH_SESSIONS.clear();TOUCH_EVENTS.clear()
    else:
     if not self._bitron_active() or (body.get('owner') is not None and body['owner']!=OWNER):return self.send_error(409)
     seat=body['seat'];image=base64.b64decode(body['image'],validate=True)
     if type(seat) is not int or seat not in range(1,7) or len(image)>200000 or not image.startswith(b'\xff\xd8'):raise ValueError()
     state=body.get('state')
     if state is not None:
      if not isinstance(state,dict) or state.get('phase') not in ('splash','howtoAttract','attract','join','howto','countdown','play','victory','gameover','results') or not isinstance(state.get('turnId'),str) or len(state['turnId'])>100 or type(state.get('pause')) is not bool:raise ValueError()
      ready=state.get('ghostReady',[False]*6)
      if not isinstance(ready,list) or len(ready)!=6 or any(type(v) is not bool for v in ready):raise ValueError()
      state={**{k:state[k] for k in ('phase','turnId','pause')},'ghostReady':ready}
     with LOCK:
      FRAMES[seat]=(time.monotonic(),image)
      if state is not None:UI_STATE.update(at=time.monotonic(),data=state)
    return self._bitron_send(b'{"ok":true}')
   except (ValueError,TypeError,KeyError,UnicodeError,binascii.Error):return self.send_error(400)
  def do_GET(self):
   path=urlsplit(self.path).path
   if self._bitron_touch(path):return
   if path in ('/api/vibe/mode','/api/vibe/launch') and self._bitron_active():
    page='/games/'+SLUG+'/personal-v1/vibe.html';return self._bitron_send(json.dumps(dict(mode='web-game',game=SLUG,page=page,url=page,active=True,nativeState=1)).encode())
   prefix='/games/'+SLUG+'/'
   if path.startswith(prefix):
    relative=unquote(path[len(prefix):]);relative='vibe.html' if relative in ('personal/vibe.html','personal-v1/vibe.html') else relative
    folder=(BASE/'games'/SLUG).resolve();file=(folder/relative).resolve()
    if not file.is_relative_to(folder) or not file.is_file():return self.send_error(404)
    return self._bitron_send(file.read_bytes(),('application/javascript' if file.suffix=='.mjs' else mimetypes.guess_type(file.name)[0]) or 'application/octet-stream')
   if path=='/arcadium-bitron/'+SLUG+'/status':
    with LOCK:seats=[COLORS[i-1] for i,p in FRAMES.items() if time.monotonic()-p[0]<2.5]
    return self._bitron_send(json.dumps(dict(build='bitron-v1',game=SLUG,active=self._bitron_active(),liveSeats=seats)).encode())
   if path!='/arcadium-bitron/'+SLUG+'/frame':return super().do_GET()
   color=parse_qs(urlsplit(self.path).query).get('color',[''])[0].lower()
   if color not in COLORS:return self.send_error(400)
   if not self._bitron_active():return self.send_error(503)
   with LOCK:
    packet=FRAMES.get(COLORS.index(color)+1)
    if not packet or time.monotonic()-packet[0]>2.5:return self.send_error(503)
    return self._bitron_send(packet[1],'image/jpeg')
 return BitronHandler
