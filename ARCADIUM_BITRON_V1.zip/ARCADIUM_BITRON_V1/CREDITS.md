# Credits and source preservation

Game source, original sprites, embedded fonts, original enemy/wave/score/ghost systems: user-provided `bitron-ghost-uprising.zip` (592,715 bytes). The embedded local resources were extracted without changing their bytes. Original inline script hashes are recorded in tests/source-contracts.json.

New illustrated Arcadium card/title and reactor sprite: generated for this requested upgrade. Reactor circuits, personal view interface and shared-controller integration: this update. Promotional cover art illustrates the theme; gameplay screenshots in review/ come from the actual browser build.

Shared Native Input V1 reader: copied unchanged from the existing Arcadium integration. Transport and guarded installer adapted from the preceding tested Arcadium integrations. No new Android application, SDK, cloud key or paid runtime service is required.
