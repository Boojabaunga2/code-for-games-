# Validation

Build: `python integrations/bitron-ghost-uprising/build_package.py`.
Installer/transport/contracts: `python -m unittest discover -s integrations/bitron-ghost-uprising/tests -p 'test_*.py'`.
Exact receiver harness: `python integrations/bitron-ghost-uprising/tests/harness.py --server-reference PATH_TO_ORIGINAL_arcadium_server.py`.
Browser: `NODE_PATH=/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules node integrations/bitron-ghost-uprising/tests/browser.cjs`.

Browser fixtures use the unchanged original receiver and genuine I1/reliable-action HTTP paths with synthetic controller packets, six private browser pages and actual pointer-down/up touch controls. Enemy spawning is disabled only inside the movement fixture to isolate steering from random combat contact. Death and final clocks are explicitly accelerated to reach both endings. This is not evidence of physical Mini Vibe hardware acceptance.

Automated checks cover six continuous held D-pads and release stops, native hold fire, exactly one bomb for raw plus reliable B, touch hold/release, pause, real death-to-ghost transition, ghost steering and attacking, each original ghost power and energy cost/restriction, shoulders, Recall shortcut, lost-heartbeat safety, 30-second final configuration, five ghosts versus survivor, victory/results/replay, ghosts-win ending and handoff to six preceding games without script errors. Installer checks verify extracted ZIP, checksums, corruption rejection, repeat install/rollback, later-edit guard, catalogue isolation and preservation of older game files and pairing.

review/ stores actual screenshots, browser log, Windows CI results and delivery hash. Windows Defender runner scan success cannot establish the cause of prior recipient alerts or guarantee acceptance on the recipient PC. No antivirus exclusions or disabled protections are used. Physical six-device controller behavior, Mini Vibe rendering latency, LAN conditions and balance remain pending.
