
/* js/input.js */
/* input.js - six-player keyboard input.
   Pad 1 = untagged numpad. Pads 2-6 = numpad keys preceded by an F13-F17 tag
   (LuaMacros arcadium-keypads-hold.lua tags both key-down and key-up).
   Bots write into the same control structure through setVirtual(). */
var BT = window.BT = window.BT || {};

BT.Input = (function () {
  var K = BT.CONFIG.keys;
  var held = [], latch = [], state = [], virt = [null, null, null, null, null, null];
  var recentTag = { p: -1, t: 0 };
  var fbMap = {};   // fallback code -> {p, a}
  var globalHandlers = [];

  for (var i = 0; i < 6; i++) {
    held.push({}); latch.push({ fire: false, special: false, start: false, dir: false });
    state.push(blank());
    var fb = K.fallback[i] || {};
    Object.keys(fb).forEach(function (act) { fbMap[fb[act]] = { p: i, a: act }; });
  }
  (K.p1Start || []).forEach(function (c) { fbMap[c] = { p: 0, a: 'start' }; });

  function blank() { return { dx: 0, dy: 0, fire: false, special: false, start: false, pFire: false, pSpecial: false, pStart: false, pDir: false, any: false }; }

  function route(code) {
    // which player does this numpad event belong to?
    var now = performance.now();
    if (recentTag.p >= 0 && now - recentTag.t <= K.tagWindowMs) { var p = recentTag.p; recentTag.p = -1; return p; }
    return 0;
  }

  function actionOf(code) {
    var a = K.pad[code];
    if (a === undefined) return null;
    return a;
  }

  function down(e) {
    var code = e.code;
    if (BT.Audio) BT.Audio.init();
    if (K.tags[code] !== undefined) { recentTag.p = K.tags[code]; recentTag.t = performance.now(); e.preventDefault(); return; }
    for (var g = 0; g < globalHandlers.length; g++) if (globalHandlers[g](code, e)) { e.preventDefault(); return; }
    var a = actionOf(code), p;
    if (a !== null) {
      p = route(code);
      e.preventDefault();
      if (e.repeat) return;
      held[p][code] = a;
      latchAct(p, a);
      return;
    }
    var f = fbMap[code];
    if (f) {
      e.preventDefault();
      if (e.repeat) return;
      var fa = f.a;
      if (fa === 'up') a = [0, -1]; else if (fa === 'down') a = [0, 1]; else if (fa === 'left') a = [-1, 0]; else if (fa === 'right') a = [1, 0]; else a = fa;
      held[f.p][code] = a;
      latchAct(f.p, a);
    }
  }
  function latchAct(p, a) {
    if (a === 'fire') latch[p].fire = true;
    else if (a === 'special') latch[p].special = true;
    else if (a === 'start') latch[p].start = true;
    else latch[p].dir = true;
  }
  function up(e) {
    var code = e.code;
    if (K.tags[code] !== undefined) { recentTag.p = K.tags[code]; recentTag.t = performance.now(); return; }
    if (K.pad[code] !== undefined) {
      var p = route(code);
      delete held[p][code];
      return;
    }
    var f = fbMap[code];
    if (f) delete held[f.p][code];
  }
  function clearAll() { for (var i = 0; i < 6; i++) held[i] = {}; }

  /* called once per fixed tick */
  var hstate = [];
  for (var hi = 0; hi < 6; hi++) hstate.push(blank());

  /* called once per fixed tick: human state is always computed; bots override get() */
  function update() {
    for (var i = 0; i < 6; i++) {
      var hs = hstate[i];
      var dx = 0, dy = 0, fire = false, sp = false, st = false, h = held[i];
      for (var c in h) {
        var a = h[c];
        if (a === 'fire') fire = true; else if (a === 'special') sp = true; else if (a === 'start') st = true;
        else { dx += a[0]; dy += a[1]; }
      }
      hs.dx = dx > 0 ? 1 : (dx < 0 ? -1 : 0); hs.dy = dy > 0 ? 1 : (dy < 0 ? -1 : 0);
      var L = latch[i];
      hs.pFire = L.fire; hs.pSpecial = L.special; hs.pStart = L.start; hs.pDir = L.dir;
      hs.fire = fire || L.fire; hs.special = sp || L.special; hs.start = st || L.start;
      hs.any = L.fire || L.special || L.start || L.dir;
      L.fire = L.special = L.start = L.dir = false;

      var s = state[i];
      if (virt[i]) {
        var v = virt[i];
        s.pFire = v.fire && !s.fire; s.pSpecial = v.special && !s.special; s.pStart = v.start && !s.start;
        s.dx = v.dx; s.dy = v.dy; s.fire = v.fire; s.special = v.special; s.start = v.start;
        s.pDir = false; s.any = false;
      } else {
        for (var k in hs) s[k] = hs[k];
      }
    }
  }

  window.addEventListener('keydown', down, true);
  window.addEventListener('keyup', up, true);
  window.addEventListener('blur', clearAll);

  return {
    update: update,
    get: function (i) { return state[i]; },
    human: function (i) { return hstate[i]; },
    setVirtual: function (i, v) { virt[i] = v; },
    clearVirtual: function () { for (var i = 0; i < 6; i++) virt[i] = null; },
    isVirtual: function (i) { return !!virt[i]; },
    onGlobal: function (fn) { globalHandlers.push(fn); },
    // test hooks
    _down: down, _up: up
  };
})();

