
/* js/projectiles.js */
/* projectiles.js - pooled bullets for players and machines */
var BT = window.BT = window.BT || {};

BT.Projectiles = (function () {
  var pool = new BT.Pool(900, function () { return { x: 0, y: 0, vx: 0, vy: 0, life: 0, owner: -1, dmg: 1, kind: 'shot', pierce: 0, color: '#fff', r: 4, hitList: null }; });

  function fire(x, y, ang, speed, owner, kind, color, dmg, life) {
    var b = pool.spawn(); if (!b) return null;
    b.x = x; b.y = y; b.vx = Math.cos(ang) * speed; b.vy = Math.sin(ang) * speed;
    b.owner = owner; b.kind = kind || 'shot'; b.color = color || '#fff'; b.dmg = dmg || 1;
    b.life = life || 0.9; b.pierce = kind === 'laser' ? 4 : 0; b.r = kind === 'enemy' ? 7 : (kind === 'big' ? 12 : 5);
    b.hitList = kind === 'laser' ? [] : null;
    return b;
  }

  function update(dt, game) {
    var it = pool.items;
    for (var i = 0; i < it.length; i++) {
      var b = it[i]; if (!b.alive) continue;
      b.life -= dt; if (b.life <= 0) { b.alive = false; continue; }
      // sub-step fast bullets so they can't tunnel through bits
      var steps = b.owner >= 0 ? 2 : 1;
      for (var s = 0; s < steps && b.alive; s++) {
        b.x += b.vx * dt / steps; b.y += b.vy * dt / steps;
        var wall = BT.Arena.bulletHit(b.x, b.y);
        if (wall) {
          if (wall !== true) BT.Arena.damage(wall, b.dmg, game);
          BT.FX.burst(b.x, b.y, b.owner >= 0 ? b.color : '#ff5040', 4, 160, 0.2, 2);
          b.alive = false; break;
        }
        if (b.owner >= 0) hitHostiles(b, game); else hitPlayersAndBits(b, game);
      }
    }
  }

  function hitHostiles(b, game) {
    var near = game.grid.query(b.x, b.y, 60);
    for (var i = 0; i < near.length; i++) {
      var e = near[i];
      if (!e.alive || e.dead || (e.isBit && e.birth > 0)) continue;
      var rr = e.r + b.r;
      if (BT.U.dist2(b.x, b.y, e.x, e.y) > rr * rr) continue;
      if (b.hitList) { if (b.hitList.indexOf(e) >= 0) continue; b.hitList.push(e); }
      if (e.isBit) game.hitBit(e, b.owner, b.dmg); else game.hitEnemy(e, b.dmg, b.owner, b.vx, b.vy);
      if (b.pierce > 0) { b.pierce--; continue; }
      b.alive = false; return;
    }
  }
  function hitPlayersAndBits(b, game) {
    var ps = game.players;
    for (var i = 0; i < ps.length; i++) {
      var p = ps[i]; if (!p || !p.alive) continue;
      var rr = p.r + b.r;
      if (BT.U.dist2(b.x, b.y, p.x, p.y) < rr * rr) { game.hurtPlayer(p, 1, -1, b.vx, b.vy); b.alive = false; return; }
    }
    var near = game.grid.query(b.x, b.y, 30);
    for (var k = 0; k < near.length; k++) {
      var e = near[k];
      if (!e.isBit || !e.alive) continue;
      if (BT.U.dist2(b.x, b.y, e.x, e.y) < (e.r + b.r) * (e.r + b.r)) { game.hitBit(e, -1, 1); b.alive = false; return; }
    }
  }

  function draw(g) {
    var it = pool.items;
    g.globalCompositeOperation = 'lighter';
    g.lineCap = 'round';
    for (var i = 0; i < it.length; i++) {
      var b = it[i]; if (!b.alive) continue;
      if (b.owner >= 0) {
        var tl = b.kind === 'laser' ? 0.06 : 0.022;
        g.strokeStyle = b.color; g.lineWidth = b.kind === 'laser' ? 9 : 7; g.globalAlpha = 0.55;
        g.beginPath(); g.moveTo(b.x - b.vx * tl, b.y - b.vy * tl); g.lineTo(b.x, b.y); g.stroke();
        g.strokeStyle = '#ffffff'; g.lineWidth = b.kind === 'laser' ? 3 : 2.5; g.globalAlpha = 1;
        g.beginPath(); g.moveTo(b.x - b.vx * tl * 0.6, b.y - b.vy * tl * 0.6); g.lineTo(b.x, b.y); g.stroke();
      } else {
        g.fillStyle = '#ff2030'; g.globalAlpha = 0.5;
        g.beginPath(); g.arc(b.x, b.y, b.r + 4, 0, 6.283); g.fill();
        g.globalAlpha = 1; g.fillStyle = '#ffc0c0';
        g.beginPath(); g.arc(b.x, b.y, b.r * 0.55, 0, 6.283); g.fill();
      }
    }
    g.globalAlpha = 1;
    g.globalCompositeOperation = 'source-over';
  }

  return { fire: fire, update: update, draw: draw, clear: function () { pool.clear(); }, count: function () { return pool.count(); } };
})();

