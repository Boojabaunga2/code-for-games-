
/* js/audio.js */
/* audio.js - every sound is a named hook. Built-in WebAudio synth placeholders;
   map a name to a file in CONFIG.audioFiles to replace it.
   Music is a procedural loop whose layers stack up as players die. */
var BT = window.BT = window.BT || {};

BT.Audio = (function () {
  var ctx = null, master = null, sfxBus = null, musBus = null, muted = false;
  var last = {}, files = {};
  var MINGAP = { playerFire: 0.035, enemyFire: 0.05, bitPop: 0.03, robotExplode: 0.03, bitSwarm: 0.25, playerHit: 0.08 };

  function init() {
    if (ctx) { if (ctx.state === 'suspended') ctx.resume(); return; }
    var AC = window.AudioContext || window.webkitAudioContext; if (!AC) return;
    ctx = new AC();
    master = ctx.createGain(); master.gain.value = 0.7; master.connect(ctx.destination);
    sfxBus = ctx.createGain(); sfxBus.gain.value = 0.55; sfxBus.connect(master);
    musBus = ctx.createGain(); musBus.gain.value = 0.32; musBus.connect(master);
    var map = BT.CONFIG.audioFiles || {};
    Object.keys(map).forEach(function (k) { var a = new Audio(map[k]); a.preload = 'auto'; files[k] = a; });
  }

  function tone(type, f0, f1, dur, vol, delay, bus) {
    var t = ctx.currentTime + (delay || 0);
    var o = ctx.createOscillator(), g = ctx.createGain();
    o.type = type; o.frequency.setValueAtTime(f0, t);
    if (f1) o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
    g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0008, t + dur);
    o.connect(g); g.connect(bus || sfxBus); o.start(t); o.stop(t + dur + 0.02);
  }
  var noiseBuf = null;
  function noise(dur, vol, fc, delay, bus, q) {
    if (!noiseBuf) {
      noiseBuf = ctx.createBuffer(1, ctx.sampleRate, ctx.sampleRate);
      var d = noiseBuf.getChannelData(0); for (var i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    }
    var t = ctx.currentTime + (delay || 0);
    var s = ctx.createBufferSource(), f = ctx.createBiquadFilter(), g = ctx.createGain();
    s.buffer = noiseBuf; f.type = 'lowpass'; f.frequency.value = fc || 2000; f.Q.value = q || 0.7;
    g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0008, t + dur);
    s.connect(f); f.connect(g); g.connect(bus || sfxBus); s.start(t); s.stop(t + dur + 0.02);
  }

  var SFX = {
    playerFire: function () { tone('square', 880, 300, 0.07, 0.07); },
    enemyFire: function () { tone('sawtooth', 300, 140, 0.12, 0.06); },
    robotExplode: function () { noise(0.35, 0.35, 900); tone('square', 160, 40, 0.3, 0.12); },
    bitPop: function () { tone('triangle', 1400, 2400, 0.05, 0.08); },
    playerHit: function () { tone('sawtooth', 220, 80, 0.25, 0.2); noise(0.15, 0.2, 3000); },
    playerDeath: function () { tone('sawtooth', 440, 30, 1.2, 0.3); noise(0.9, 0.4, 600); },
    ghostTransform: function () { for (var i = 0; i < 6; i++) tone('sine', 200 + i * 90, 900 + i * 120, 0.35, 0.09, i * 0.07); tone('triangle', 110, 55, 1.2, 0.2, 0.3); },
    bitSwarm: function () { for (var i = 0; i < 5; i++) tone('square', 600 + Math.random() * 900, 300, 0.08, 0.035, i * 0.03); },
    command: function () { tone('square', 500, 1200, 0.12, 0.08); },
    powerup: function () { tone('square', 523, 0, 0.08, 0.1); tone('square', 784, 0, 0.08, 0.1, 0.07); tone('square', 1046, 0, 0.12, 0.1, 0.14); },
    bomb: function () { noise(0.9, 0.5, 400); tone('sine', 90, 30, 0.9, 0.4); },
    waveStart: function () { tone('sawtooth', 220, 440, 0.4, 0.15); tone('sawtooth', 330, 660, 0.4, 0.1, 0.1); },
    countdown: function () { tone('square', 660, 0, 0.15, 0.15); },
    go: function () { tone('square', 990, 0, 0.4, 0.18); },
    join: function () { tone('square', 660, 1320, 0.15, 0.12); },
    finalAlarm: function () { for (var i = 0; i < 6; i++) tone('sawtooth', i % 2 ? 520 : 780, 0, 0.28, 0.16, i * 0.3); },
    victory: function () { [523, 659, 784, 1046, 784, 1046].forEach(function (f, i) { tone('square', f, 0, 0.22, 0.13, i * 0.14); }); },
    gameOver: function () { [392, 330, 262, 196].forEach(function (f, i) { tone('sawtooth', f, f * 0.98, 0.4, 0.14, i * 0.3); }); },
    tick: function () { tone('square', 1200, 0, 0.04, 0.06); }
  };

  function play(name) {
    if (!ctx || muted) return;
    var now = ctx.currentTime, gap = MINGAP[name] || 0.02;
    if (last[name] && now - last[name] < gap) return;
    last[name] = now;
    if (files[name]) { try { var a = files[name].cloneNode(); a.volume = 0.7; a.play(); } catch (e) {} return; }
    if (SFX[name]) SFX[name]();
  }

  /* -------- adaptive music -------- */
  var mus = { on: false, level: 0, final: false, step: 0, next: 0, timer: null, duck: 0 };
  var BASS = [55, 55, 65.4, 55, 73.4, 55, 65.4, 49];
  function schedule() {
    if (!ctx || !mus.on) return;
    var bpm = mus.final ? 160 : 118 + mus.level * 7;
    var stepDur = 60 / bpm / 4;
    while (mus.next < ctx.currentTime + 0.12) {
      var s = mus.step % 16, t = mus.next - ctx.currentTime;
      if (t < 0) t = 0;
      if (ctx.currentTime > mus.duck) {
        if (s % 4 === 0) tone('sine', 120, 40, 0.18, 0.5, t, musBus);
        if (s % 2 === 0) tone('sawtooth', BASS[(mus.step >> 1) % 8] * (mus.final ? 1.06 : 1), 0, stepDur * 1.8, 0.16, t, musBus);
        if (mus.level >= 1 && s % 2 === 1) noise(0.04, 0.12, 8000, t, musBus);
        if (mus.level >= 2 && (s === 4 || s === 12)) noise(0.14, 0.3, 2500, t, musBus);
        if (mus.level >= 3 && s % 4 === 2) tone('square', BASS[(mus.step >> 2) % 8] * 4, 0, stepDur, 0.06, t, musBus);
        if (mus.level >= 4 && s % 3 === 0) tone('square', BASS[s % 8] * 8, 0, stepDur * 0.7, 0.04, t, musBus);
        if (mus.final && s === 0) tone('sawtooth', 700, 500, 0.5, 0.07, t, musBus);
      }
      mus.step++; mus.next += stepDur;
    }
  }
  function musicStart() { if (!ctx) return; mus.on = true; mus.next = ctx.currentTime + 0.05; if (!mus.timer) mus.timer = setInterval(schedule, 40); }
  function musicStop() { mus.on = false; }
  function musicLevel(n, fin) { mus.level = n; mus.final = !!fin; }
  function musicCut(sec) { if (ctx) mus.duck = ctx.currentTime + sec; }
  function toggleMute() { muted = !muted; if (master) master.gain.value = muted ? 0 : 0.7; return muted; }

  return { init: init, play: play, musicStart: musicStart, musicStop: musicStop, musicLevel: musicLevel, musicCut: musicCut, toggleMute: toggleMute };
})();

