
/* js/enemies.js */
/* enemies.js - the machine army. Every machine attacks living players AND any
   ghost Bits that wander too close. Nine original machine types. */
var BT = window.BT = window.BT || {};

BT.Enemies = (function () {
  var U = BT.U;
  var TYPES = {
    grunt:   { hp: 2,   speed: 110, r: 19, spr: 'en_grunt',   bitAggro: 90 },
    rusher:  { hp: 1,   speed: 330, r: 16, spr: 'en_rusher',  bitAggro: 70 },
    swarmer: { hp: 1,   speed: 190, r: 11, spr: 'en_swarmer', bitAggro: 60 },
    shooter: { hp: 3,   speed: 115, r: 22, spr: 'en_shooter', bitAggro: 180, fire: 1.7 },
    tank:    { hp: 16,  speed: 62,  r: 38, spr: 'en_tank',    bitAggro: 200, bar: true },
    spawner: { hp: 12,  speed: 55,  r: 33, spr: 'en_spawner', bitAggro: 0, bar: true },
    hunter:  { hp: 5,   speed: 185, r: 22, spr: 'en_hunter',  bitAggro: 0 },
    elite:   { hp: 30,  speed: 100, r: 34, spr: 'en_elite',   bitAggro: 220, fire: 1.3, bar: true },
    boss:    { hp: 260, speed: 46,  r: 78, spr: 'en_boss',    bitAggro: 300, fire: 2.2, bar: true }
  };
  var pool = new BT.Pool(160, function () { return { type: 'grunt', x: 0, y: 0, vx: 0, vy: 0, r: 10, hp: 1, maxHp: 1, speed: 100, flash: 0, cd: 0, cd2: 0, crushCD: 0, spawnT: 0, target: null, prey: null, dash: 0, wob: 0, isBit: false, dead: false }; });

  function spawn(type, x, y, mult) {
    var e = pool.spawn(); if (!e) return null;
    var T = TYPES[type];
    e.type = type; e.x = x; e.y = y; e.vx = 0; e.vy = 0; e.r = T.r; e.dead = false;
    var hpm = type === 'boss' ? mult.bossHp : mult.hp;
    e.hp = e.maxHp = Math.ceil(T.hp * hpm); e.speed = T.speed * mult.speed * U.rand(0.9, 1.1);
    e.flash = 0; e.cd = U.rand(0.5, T.fire || 2); e.cd2 = U.rand(1, 3); e.crushCD = 0; e.spawnT = 0.45;
    e.target = null; e.prey = null; e.dash = 0; e.wob = Math.random() * 10;
    return e;
  }

  function nearestPlayer(game, x, y) {
    var best = null, bd = 1e12, ps = game.players;
    for (var i = 0; i < ps.length; i++) { var p = ps[i]; if (!p || !p.alive) continue; var d = U.dist2(x, y, p.x, p.y); if (d < bd) { bd = d; best = p; } }
    return best;
  }

  function update(dt, game) {
    var it = pool.items;
    for (var i = 0; i < it.length; i++) {
      var e = it[i]; if (!e.alive) continue;
      var T = TYPES[e.type];
      if (e.spawnT > 0) e.spawnT -= dt;
      if (e.flash > 0) e.flash -= dt;
      if (e.crushCD > 0) e.crushCD -= dt;
      e.wob += dt;
      // choose target
      var tgt = null;
      if (e.type === 'hunter') {
        if (!e.prey || !e.prey.alive) e.prey = game.randomLivingPlayer();
        tgt = e.prey;
      } else {
        tgt = nearestPlayer(game, e.x, e.y);
        if (T.bitAggro > 0) {
          var b = game.nearestBit(e.x, e.y, T.bitAggro);
          if (b && (!tgt || U.dist2(e.x, e.y, b.x, b.y) < U.dist2(e.x, e.y, tgt.x, tgt.y))) tgt = b;
        }
      }
      e.target = tgt;
      var tx = tgt ? tgt.x : BT.Arena.center.x + Math.cos(e.wob * 0.3 + i) * 500;
      var ty = tgt ? tgt.y : BT.Arena.center.y + Math.sin(e.wob * 0.4 + i) * 300;
      var dx = tx - e.x, dy = ty - e.y, d = Math.sqrt(dx * dx + dy * dy) || 1;
      var mx = dx / d, my = dy / d, spd = e.speed;

      if (e.type === 'shooter') {
        if (d < 300) { mx = -mx; my = -my; } else if (d < 430) { var tmp = mx; mx = -my * 0.8; my = tmp * 0.8; }
        fireLogic(e, T, dt, tx, ty, d, game);
      } else if (e.type === 'rusher') {
        e.cd2 -= dt;
        if (e.cd2 <= 0) { e.dash = 0.45; e.cd2 = U.rand(1.0, 1.8); }
        if (e.dash > 0) { e.dash -= dt; spd *= 1.9; } else spd *= 0.45;
      } else if (e.type === 'swarmer') {
        mx += Math.cos(e.wob * 6 + i) * 0.5; my += Math.sin(e.wob * 6 + i) * 0.5;
      } else if (e.type === 'spawner') {
        mx = Math.cos(e.wob * 0.5 + i); my = Math.sin(e.wob * 0.7 + i);
        e.cd2 -= dt;
        if (e.cd2 <= 0 && game.machineCount() < BT.CONFIG.waves.maxAlive) {
          e.cd2 = 2.6;
          for (var s = 0; s < 3; s++) spawn('swarmer', e.x + U.rand(-20, 20), e.y + U.rand(-20, 20), game.mult());
          BT.FX.ring(e.x, e.y, '#ff3040', 60, 0.3);
        }
      } else if (e.type === 'elite') {
        fireLogic(e, T, dt, tx, ty, d, game);
        e.cd2 -= dt; if (e.cd2 <= 0) { e.dash = 0.5; e.cd2 = U.rand(3, 5); }
        if (e.dash > 0) { e.dash -= dt; spd *= 3.2; }
      } else if (e.type === 'boss') {
        fireLogic(e, T, dt, tx, ty, d, game);
        e.cd2 -= dt;
        if (e.cd2 <= 0 && game.machineCount() < BT.CONFIG.waves.maxAlive) {
          e.cd2 = 4;
          for (var k = 0; k < 4; k++) spawn(k % 2 ? 'grunt' : 'rusher', e.x + U.rand(-60, 60), e.y + U.rand(-60, 60), game.mult());
        }
      }
      var acc = Math.min(1, dt * 6);
      e.vx += (mx * spd - e.vx) * acc; e.vy += (my * spd - e.vy) * acc;
      e.x += e.vx * dt; e.y += e.vy * dt;
      BT.Arena.collide(e, e.r * 0.8);
    }
  }

  function fireLogic(e, T, dt, tx, ty, d, game) {
    e.cd -= dt;
    if (e.cd > 0 || e.spawnT > 0 || d > 900) return;
    e.cd = T.fire * U.rand(0.85, 1.15) / Math.min(1.6, game.mult().speed);
    var a = Math.atan2(ty - e.y, tx - e.x), P = BT.Projectiles;
    if (e.type === 'shooter') P.fire(e.x, e.y, a, 380, -1, 'enemy', '#f22', 1, 2.5);
    else if (e.type === 'elite') { for (var s = -1; s <= 1; s++) P.fire(e.x, e.y, a + s * 0.2, 430, -1, 'enemy', '#f22', 1, 2.5); }
    else if (e.type === 'boss') {
      var n = 18, off = e.wob;
      for (var k = 0; k < n; k++) P.fire(e.x, e.y, off + k * 6.283 / n, 300, -1, 'enemy', '#f22', 1, 3);
      for (var j = -2; j <= 2; j++) P.fire(e.x, e.y, a + j * 0.09, 470, -1, 'enemy', '#f22', 1, 3);
      BT.FX.shake(6);
    }
    BT.Audio.play('enemyFire');
  }

  var shadow = null;
  function draw(g, t) {
    var it = pool.items;
    for (var i = 0; i < it.length; i++) {
      var e = it[i]; if (!e.alive) continue;
      var T = TYPES[e.type];
      if (!shadow) { shadow = BT.Assets.canvas(64, 24); var sg = shadow.getContext('2d'); sg.fillStyle = 'rgba(0,0,0,0.45)'; sg.beginPath(); sg.ellipse(32, 12, 31, 11, 0, 0, 6.283); sg.fill(); }
      g.drawImage(shadow, e.x - e.r * 0.9, e.y + e.r * 0.6, e.r * 1.8, e.r * 0.64);
      if (e.type === 'elite' || e.type === 'boss') {
        g.fillStyle = 'rgba(255,20,40,' + (0.12 + 0.08 * Math.sin(t * 8 + i)) + ')';
        g.beginPath(); g.arc(e.x, e.y, e.r * 1.35, 0, 6.283); g.fill();
      }
      if (e.type === 'hunter' && e.prey && e.prey.alive) {
        g.strokeStyle = U.hexA(e.prey.color, 0.35); g.lineWidth = 2; g.setLineDash([8, 10]);
        g.beginPath(); g.moveTo(e.x, e.y); g.lineTo(e.prey.x, e.prey.y); g.stroke(); g.setLineDash([]);
        g.strokeStyle = e.prey.color; g.lineWidth = 2;
        g.beginPath(); g.arc(e.x, e.y - e.r - 10, 6, 0, 6.283); g.stroke();
      }
      var sc = e.spawnT > 0 ? 1 - e.spawnT / 0.45 : 1;
      var bob = e.type === 'spawner' ? Math.sin(t * 3 + i) * 4 : 0;
      if (sc < 1) {
        var s = BT.Assets.spr[T.spr]; if (s) { g.globalAlpha = sc; g.drawImage(s.c, e.x - s.w * sc / 2, e.y - s.h * sc / 2, s.w * sc, s.h * sc); g.globalAlpha = 1; }
      } else BT.Assets.draw(g, T.spr, e.x, e.y + bob, e.vx < 0, e.flash > 0);
      if (T.bar && e.hp < e.maxHp) {
        var w = e.r * 2;
        g.fillStyle = '#200'; g.fillRect(e.x - w / 2, e.y - e.r - 14, w, 5);
        g.fillStyle = e.type === 'boss' ? '#ff1030' : '#ff5060'; g.fillRect(e.x - w / 2, e.y - e.r - 14, w * e.hp / e.maxHp, 5);
      }
    }
  }

  return {
    TYPES: TYPES, spawn: spawn, update: update, draw: draw,
    items: pool.items, clear: function () { pool.clear(); }, count: function () { return pool.count(); }
  };
})();

