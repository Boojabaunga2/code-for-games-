
/* js/bots.js */
/* bots.js - CPU control for attract mode, test bots and empty seats.
   Bots drive the exact same control structure humans do (8-way + fire + special). */
var BT = window.BT = window.BT || {};

BT.Bots = (function () {
  var U = BT.U;
  var mem = [{}, {}, {}, {}, {}, {}];

  function q8(x, y) {
    if (Math.abs(x) < 0.01 && Math.abs(y) < 0.01) return [0, 0];
    var a = Math.round(Math.atan2(y, x) / (Math.PI / 4)) * (Math.PI / 4);
    return [Math.round(Math.cos(a)), Math.round(Math.sin(a))];
  }

  function living(p, game, m, dt) {
    var ax = 0, ay = 0, closest = null, cd = 1e12, i, e;
    var near = game.grid.query(p.x, p.y, 520);
    for (i = 0; i < near.length; i++) {
      e = near[i]; if (!e.alive) continue;
      var dx = p.x - e.x, dy = p.y - e.y, d2 = dx * dx + dy * dy;
      if (d2 < cd) { cd = d2; closest = e; }
      var danger = e.isBit ? 170 : 170 + e.r * 2;
      if (d2 < danger * danger) { var d = Math.sqrt(d2) || 1, w = (danger - d) / danger; ax += dx / d * w * w * 5; ay += dy / d * w * w * 5; }
    }
    for (i = 0; i < 6; i++) {
      var o = game.players[i]; if (!o || o === p || !o.alive) continue;
      var ox = p.x - o.x, oy = p.y - o.y, od = Math.sqrt(ox * ox + oy * oy) || 1;
      if (od < 260) { ax += ox / od * 0.6; ay += oy / od * 0.6; }
    }
    var c = BT.Arena.center;
    ax += (c.x - p.x) / 2500; ay += (c.y - p.y) / 2500;
    var fleeing = ax * ax + ay * ay > 0.5;
    if (!fleeing && closest) {
      var tx = closest.x - p.x, ty = closest.y - p.y, td = Math.sqrt(tx * tx + ty * ty) || 1;
      var orbit = m.side || 1;
      if (td > 260) { ax += tx / td; ay += ty / td; }
      else { ax += tx / td * 0.6 - ty / td * 0.6 * orbit; ay += ty / td * 0.6 + tx / td * 0.6 * orbit; }
    }
    m.sideT = (m.sideT || 0) - dt; if (m.sideT <= 0) { m.sideT = U.rand(1, 3); m.side = Math.random() < 0.5 ? -1 : 1; }
    var dir = q8(ax, ay);
    return { dx: dir[0], dy: dir[1], fire: !!closest && cd < 600 * 600, special: (p.hearts < 1.5 && cd < 90 * 90 && p.bombs > 0 && Math.random() < 0.05), start: false };
  }

  function ghost(p, game, m, dt) {
    var c = p.gc, best = null, bd = 1e12;
    for (var i = 0; i < 6; i++) { var q = game.players[i]; if (!q || !q.alive) continue; var d = U.dist2(c.x, c.y, q.x, q.y); if (d < bd) { bd = d; best = q; } }
    var army = BT.Ghosts.count(p.idx), tx, ty;
    if (best && (army > 10 || game.finalMode)) { tx = best.x; ty = best.y; }
    else {
      // farm machines to grow the army
      var es = BT.Enemies.items, ed = 1e12, et = null;
      for (var k = 0; k < es.length; k++) { var e = es[k]; if (!e.alive) continue; var d2 = U.dist2(c.x, c.y, e.x, e.y); if (d2 < ed) { ed = d2; et = e; } }
      if (et) { tx = et.x; ty = et.y; } else if (best) { tx = best.x; ty = best.y; } else { tx = BT.Arena.center.x; ty = BT.Arena.center.y; }
    }
    var dx = tx - c.x, dy = ty - c.y, dd = Math.sqrt(dx * dx + dy * dy);
    var dir = dd > 90 ? q8(dx, dy) : [0, 0];
    m.cmdT = (m.cmdT || U.rand(2, 5)) - dt;
    var special = false, start = false;
    if (m.cmdT <= 0 && best && bd < 500 * 500) {
      m.cmdT = U.rand(2.5, 6);
      if (Math.random() < 0.4) start = true; else special = true;
    }
    return { dx: dir[0], dy: dir[1], fire: dd < 340, special: special, start: start };
  }

  function think(game, dt) {
    for (var i = 0; i < 6; i++) {
      var p = game.players[i]; if (!p || !p.isBot) continue;
      var m = mem[i];
      m.t = (m.t || 0) - dt;
      if (m.t > 0 && m.last && !m.last.special && !m.last.start) { BT.Input.setVirtual(i, m.last); continue; }
      m.t = U.rand(0.08, 0.16);
      var v = p.alive ? living(p, game, m, dt + 0.12) : (p.ghost && p.gc ? ghost(p, game, m, dt + 0.12) : { dx: 0, dy: 0, fire: false, special: false, start: false });
      m.last = v;
      BT.Input.setVirtual(i, v);
      if (v.special || v.start) m.last = { dx: v.dx, dy: v.dy, fire: v.fire, special: false, start: false };
    }
  }
  function reset() { mem = [{}, {}, {}, {}, {}, {}]; }
  return { think: think, reset: reset };
})();

