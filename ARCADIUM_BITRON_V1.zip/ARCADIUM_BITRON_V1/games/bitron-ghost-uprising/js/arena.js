
/* js/arena.js */
/* arena.js - the single-screen industrial arena.
   Obstacle kinds:
     reactor   blocks movement + bullets, indestructible
     rack      server rack: blocks movement + bullets, indestructible
     wall      machinery wall: blocks movement + bullets
     generator low unit: blocks movement, bullets fly over it
     crate     destructible cargo: blocks both until destroyed
   Vents are hazard zones (no collision) that erupt from wave 3.
   Bits are digital: they phase through everything. */
var BT = window.BT = window.BT || {};

BT.Arena = (function () {
  var C = BT.CONFIG, A = C.arena, U = BT.U;
  var cx = A.x + A.w / 2, cy = A.y + A.h / 2;
  var obstacles = [], vents = [], gates = [], floor = null;

  function R(kind, x, y, w, h, extra) {
    var o = { kind: kind, x: x, y: y, w: w, h: h, hp: 0, maxHp: 0, alive: true, hit: 0,
      blocksBullets: kind !== 'generator', seed: Math.random() * 10 };
    if (extra) for (var k in extra) o[k] = extra[k];
    return o;
  }

  function build() {
    obstacles = [
      R('reactor', cx - 72, cy - 72, 144, 144),
      R('rack', 400, 290, 58, 136), R('rack', 1462, 290, 58, 136),
      R('rack', 400, 718, 58, 136), R('rack', 1462, 718, 58, 136),
      R('generator', 700, 172, 110, 60), R('generator', 1110, 172, 110, 60),
      R('generator', 700, 912, 110, 60), R('generator', 1110, 912, 110, 60),
      R('wall', 190, 470, 44, 204), R('wall', 1686, 470, 44, 204),
      R('wall', cx - 120, 300, 240, 34), R('wall', cx - 120, 810, 240, 34)
    ];
    var crates = [[640, 545], [1230, 545], [300, 220], [1570, 220], [300, 880], [1570, 880], [cx - 25, 390], [cx - 25, 705]];
    crates.forEach(function (p) { obstacles.push(R('crate', p[0], p[1], 50, 50, { hp: 14, maxHp: 14 })); });
    vents = [];
    [[560, 380], [1270, 380], [560, 690], [1270, 690], [cx - 45, 160], [cx - 45, 900]].forEach(function (p, i) {
      vents.push({ x: p[0], y: p[1], w: 90, h: 90, state: 'idle', t: U.rand(3, 9), order: i });
    });
    gates = [
      { x: cx, y: A.y + 14, dir: [0, 1] }, { x: cx, y: A.y + A.h - 14, dir: [0, -1] },
      { x: A.x + 14, y: cy, dir: [1, 0] }, { x: A.x + A.w - 14, y: cy, dir: [-1, 0] },
      { x: A.x + 90, y: A.y + 70, dir: [1, 1] }, { x: A.x + A.w - 90, y: A.y + 70, dir: [-1, 1] },
      { x: A.x + 90, y: A.y + A.h - 70, dir: [1, -1] }, { x: A.x + A.w - 90, y: A.y + A.h - 70, dir: [-1, -1] }
    ];
    gates.forEach(function (gt) { gt.flash = 0; });
    floor = null;
  }

  function reset() { build(); }

  // push a circle out of all solid obstacles and keep it in the arena
  function collide(e, r) {
    for (var i = 0; i < obstacles.length; i++) {
      var o = obstacles[i]; if (!o.alive) continue;
      var p = U.circleRect(e.x, e.y, r, o);
      if (p) { e.x += p.x; e.y += p.y; if (e.vx !== undefined) { if (p.x) e.vx *= 0.2; if (p.y) e.vy *= 0.2; } e.blocked = true; }
    }
    e.x = U.clamp(e.x, A.x + r, A.x + A.w - r);
    e.y = U.clamp(e.y, A.y + r, A.y + A.h - r);
  }
  function bulletHit(x, y) {
    if (x < A.x || x > A.x + A.w || y < A.y || y > A.y + A.h) return true;
    for (var i = 0; i < obstacles.length; i++) {
      var o = obstacles[i];
      if (o.alive && o.blocksBullets && x > o.x && x < o.x + o.w && y > o.y && y < o.y + o.h) return o;
    }
    return null;
  }
  function damage(o, d, game) {
    o.hit = 0.08;
    if (o.kind !== 'crate') return;
    o.hp -= d;
    if (o.hp <= 0) {
      o.alive = false;
      BT.FX.explode(o.x + o.w / 2, o.y + o.h / 2, '#c8c8d0', 28, 1);
      BT.Audio.play('robotExplode');
      if (Math.random() < 0.6 && game) BT.Powerups.dropRandom(game, o.x + o.w / 2, o.y + o.h / 2, true);
    }
  }
  function isFree(x, y, r) {
    for (var i = 0; i < obstacles.length; i++) { var o = obstacles[i]; if (o.alive && U.circleRect(x, y, r, o)) return false; }
    return x > A.x + r && x < A.x + A.w - r && y > A.y + r && y < A.y + A.h - r;
  }

  function update(dt, game) {
    for (var i = 0; i < obstacles.length; i++) if (obstacles[i].hit > 0) obstacles[i].hit -= dt;
    for (var g = 0; g < gates.length; g++) if (gates[g].flash > 0) gates[g].flash -= dt;
    var active = game && game.wave >= 3 ? Math.min(vents.length, 2 + Math.floor((game.wave - 3) / 2)) : 0;
    if (game && game.finalMode) active = vents.length;
    for (var v = 0; v < vents.length; v++) {
      var vt = vents[v];
      if (vt.order >= active) { vt.state = 'idle'; continue; }
      vt.t -= dt;
      if (vt.state === 'idle' && vt.t <= 0) { vt.state = 'warn'; vt.t = 1.1; }
      else if (vt.state === 'warn' && vt.t <= 0) { vt.state = 'burst'; vt.t = 1.3; BT.Audio.play('enemyFire'); }
      else if (vt.state === 'burst') {
        if (Math.random() < 0.8) BT.FX.spark(vt.x + U.rand(10, 80), vt.y + U.rand(10, 80), U.pick(['#ff3020', '#ff9020', '#ffd040']), U.rand(-60, 60), U.rand(-260, -120), 0.5, 4);
        if (game) game.hazard(vt);
        if (vt.t <= 0) { vt.state = 'idle'; vt.t = U.rand(game && game.finalMode ? 2 : 4, game && game.finalMode ? 5 : 9); }
      }
    }
  }

  /* ---------- drawing ---------- */
  function metal(g, x, y, w, h, light) {
    var gr = g.createLinearGradient(x, y, x, y + h);
    gr.addColorStop(0, light ? '#9a9aa6' : '#5a5a66'); gr.addColorStop(0.5, '#2c2c34'); gr.addColorStop(1, '#16161c');
    g.fillStyle = gr; g.fillRect(x, y, w, h);
    g.strokeStyle = '#000'; g.lineWidth = 2; g.strokeRect(x + 1, y + 1, w - 2, h - 2);
    g.strokeStyle = 'rgba(220,220,235,0.35)'; g.lineWidth = 1; g.strokeRect(x + 3.5, y + 3.5, w - 7, h - 7);
  }
  function buildFloor() {
    floor = BT.Assets.canvas(C.W, C.H);
    var g = floor.getContext('2d');
    g.fillStyle = '#030305'; g.fillRect(0, 0, C.W, C.H);
    // floor plates
    g.fillStyle = '#0b0b10'; g.fillRect(A.x, A.y, A.w, A.h);
    for (var x = A.x; x < A.x + A.w; x += 48) for (var y = A.y; y < A.y + A.h; y += 48) {
      g.fillStyle = ((x / 48 + y / 48) & 1) ? '#0d0d13' : '#0a0a0f'; g.fillRect(x + 1, y + 1, 46, 46);
      g.fillStyle = 'rgba(255,255,255,0.025)'; g.fillRect(x + 3, y + 3, 3, 3); g.fillRect(x + 42, y + 42, 3, 3);
    }
    g.strokeStyle = 'rgba(200,20,35,0.16)'; g.lineWidth = 1;
    for (x = A.x; x <= A.x + A.w; x += 48) { g.beginPath(); g.moveTo(x + 0.5, A.y); g.lineTo(x + 0.5, A.y + A.h); g.stroke(); }
    for (y = A.y; y <= A.y + A.h; y += 48) { g.beginPath(); g.moveTo(A.x, y + 0.5); g.lineTo(A.x + A.w, y + 0.5); g.stroke(); }
    // centre glow
    var rg = g.createRadialGradient(cx, cy, 50, cx, cy, 700);
    rg.addColorStop(0, 'rgba(255,20,40,0.10)'); rg.addColorStop(1, 'rgba(255,20,40,0)');
    g.fillStyle = rg; g.fillRect(A.x, A.y, A.w, A.h);
    // frame
    g.strokeStyle = '#3a0408'; g.lineWidth = 14; g.strokeRect(A.x - 7, A.y - 7, A.w + 14, A.h + 14);
    g.strokeStyle = '#ff1a2e'; g.lineWidth = 3; g.shadowColor = '#ff1a2e'; g.shadowBlur = 16;
    g.strokeRect(A.x - 2, A.y - 2, A.w + 4, A.h + 4); g.shadowBlur = 0;
    // edge machinery strips
    for (x = A.x + 40; x < A.x + A.w - 60; x += 160) { metal(g, x, A.y + 2, 70, 10); metal(g, x + 40, A.y + A.h - 12, 70, 10); }
    // gates (factory doors)
    gates.forEach(function (gt) {
      var horiz = gt.dir[1] !== 0 && gt.dir[0] === 0, s = 70;
      g.save(); g.translate(gt.x, gt.y);
      if (!horiz && gt.dir[0] !== 0 && gt.dir[1] === 0) g.rotate(Math.PI / 2);
      if (gt.dir[0] !== 0 && gt.dir[1] !== 0) g.rotate(Math.atan2(gt.dir[1], gt.dir[0]) + Math.PI / 2);
      g.fillStyle = '#120306'; g.fillRect(-s, -16, s * 2, 32);
      for (var k = -s; k < s; k += 16) { g.fillStyle = (k / 16) & 1 ? '#ffb000' : '#140a00'; g.beginPath(); g.moveTo(k, -16); g.lineTo(k + 8, -16); g.lineTo(k + 16, 16); g.lineTo(k + 8, 16); g.fill(); }
      g.fillStyle = '#1a1a20'; g.fillRect(-s + 10, -8, s * 2 - 20, 16);
      g.restore();
    });
    // vents
    vents.forEach(function (vt) {
      metal(g, vt.x, vt.y, vt.w, vt.h);
      g.fillStyle = '#050507';
      for (var k = 0; k < 6; k++) g.fillRect(vt.x + 12, vt.y + 12 + k * 12, vt.w - 24, 6);
    });
    // static obstacles (crates drawn live because they can be destroyed)
    obstacles.forEach(function (o) {
      if (o.kind === 'crate') return;
      if (o.kind === 'reactor') {
        metal(g, o.x, o.y, o.w, o.h, true);
        g.fillStyle = '#0a0a0e'; g.fillRect(o.x + 18, o.y + 18, o.w - 36, o.h - 36);
        g.strokeStyle = '#555'; g.lineWidth = 3; g.strokeRect(o.x + 18, o.y + 18, o.w - 36, o.h - 36);
        for (var b = 0; b < 4; b++) { g.fillStyle = '#7a7a86'; g.fillRect(o.x + 6 + (b % 2) * (o.w - 22), o.y + 6 + (b >> 1) * (o.h - 22), 10, 10); }
      } else if (o.kind === 'rack') {
        metal(g, o.x, o.y, o.w, o.h, true);
        for (var r = 0; r < 7; r++) { g.fillStyle = '#08080b'; g.fillRect(o.x + 8, o.y + 10 + r * 17, o.w - 16, 11); }
      } else if (o.kind === 'generator') {
        metal(g, o.x, o.y, o.w, o.h);
        g.fillStyle = '#ffb000'; for (var s2 = 0; s2 < o.w; s2 += 14) g.fillRect(o.x + s2, o.y + o.h - 8, 7, 6);
        g.fillStyle = '#0a0a0e'; g.beginPath(); g.arc(o.x + o.w / 2, o.y + o.h / 2 - 4, 18, 0, 7); g.fill();
      } else {
        metal(g, o.x, o.y, o.w, o.h, true);
        g.fillStyle = 'rgba(255,30,45,0.5)';
        if (o.w > o.h) g.fillRect(o.x + 8, o.y + o.h / 2 - 2, o.w - 16, 4); else g.fillRect(o.x + o.w / 2 - 2, o.y + 8, 4, o.h - 16);
      }
    });
  }

  function drawFloor(g) { if (!floor) buildFloor(); g.drawImage(floor, 0, 0); }

  function drawLive(g, t, game) {
    // vents
    for (var v = 0; v < vents.length; v++) {
      var vt = vents[v];
      if (vt.state === 'warn') {
        g.fillStyle = 'rgba(255,40,30,' + (0.25 + 0.25 * Math.sin(t * 30)) + ')'; g.fillRect(vt.x - 6, vt.y - 6, vt.w + 12, vt.h + 12);
      } else if (vt.state === 'burst') {
        g.fillStyle = 'rgba(255,120,30,' + (0.45 + 0.2 * Math.sin(t * 50)) + ')'; g.fillRect(vt.x - 10, vt.y - 10, vt.w + 20, vt.h + 20);
        g.fillStyle = 'rgba(255,240,180,0.5)'; g.fillRect(vt.x + 14, vt.y + 14, vt.w - 28, vt.h - 28);
      }
    }
    // gate warning lights
    for (var k = 0; k < gates.length; k++) {
      var gt = gates[k];
      if (gt.flash > 0) {
        g.fillStyle = 'rgba(255,30,40,' + (0.5 + 0.5 * Math.sin(t * 40)) + ')';
        g.beginPath(); g.arc(gt.x, gt.y, 34, 0, 7); g.fill();
      }
    }
    for (var i = 0; i < obstacles.length; i++) {
      var o = obstacles[i]; if (!o.alive) continue;
      if (o.kind === 'crate') {
        metal(g, o.x, o.y, o.w, o.h, true);
        g.strokeStyle = '#ff2a3a'; g.lineWidth = 3;
        g.beginPath(); g.moveTo(o.x + 8, o.y + 8); g.lineTo(o.x + o.w - 8, o.y + o.h - 8); g.moveTo(o.x + o.w - 8, o.y + 8); g.lineTo(o.x + 8, o.y + o.h - 8); g.stroke();
        var f = o.hp / o.maxHp; if (f < 1) { g.fillStyle = '#300'; g.fillRect(o.x, o.y - 8, o.w, 4); g.fillStyle = '#ff3040'; g.fillRect(o.x, o.y - 8, o.w * f, 4); }
      } else if (o.kind === 'reactor') {
        var p = 0.6 + 0.4 * Math.sin(t * (game && game.finalMode ? 12 : 3));
        g.fillStyle = 'rgba(255,20,40,' + p + ')';
        g.fillRect(o.x + 30, o.y + 30, o.w - 60, o.h - 60);
        g.fillStyle = 'rgba(255,200,200,' + (p * 0.7) + ')'; g.fillRect(o.x + 52, o.y + 40, o.w - 104, o.h - 80);
      } else if (o.kind === 'rack') {
        for (var r = 0; r < 7; r++) {
          var on = Math.sin(t * 4 + r * 1.7 + o.seed) > 0;
          g.fillStyle = on ? '#ff2a3a' : '#3a0a0e'; g.fillRect(o.x + 12, o.y + 13 + r * 17, 5, 5);
          g.fillStyle = Math.sin(t * 7 + r + o.seed) > 0.3 ? '#40ff70' : '#0a2a12'; g.fillRect(o.x + 22, o.y + 13 + r * 17, 5, 5);
        }
      }
      if (o.hit > 0) { g.fillStyle = 'rgba(255,255,255,0.35)'; g.fillRect(o.x, o.y, o.w, o.h); }
    }
  }

  build();
  return {
    reset: reset, collide: collide, bulletHit: bulletHit, damage: damage, isFree: isFree, update: update,
    drawFloor: drawFloor, drawLive: drawLive,
    get obstacles() { return obstacles; }, get vents() { return vents; }, get gates() { return gates; },
    center: { x: cx, y: cy }
  };
})();

