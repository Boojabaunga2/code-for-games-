
/* js/config.js */
/* BITRON: GHOST UPRISING - config.js
   Every tunable number and every key binding lives here.
   Edit this file on the Arcadium case PC; no other file needs changing. */
var BT = window.BT = window.BT || {};

BT.CONFIG = {
  W: 1920, H: 1080,
  arena: { x: 24, y: 104, w: 1872, h: 936 },   // HUD above, status strip below

  players: {
    min: 2,              // players needed to start a real match
    allowSolo: true,     // 1 player may start (game over on death) - handy for testing
    lobbySeconds: 12,    // auto-start countdown once min players have joined
    names: ['P1', 'P2', 'P3', 'P4', 'P5', 'P6'],
    colors: ['#ff405a', '#3ba9ff', '#35ef8b', '#ffd452', '#ff72d1', '#e9f4ff'],
    colorNames: ['RED', 'BLUE', 'GREEN', 'YELLOW', 'PINK', 'WHITE']
  },

  player: {
    speed: 340, radius: 20, hearts: 3, maxHearts: 5,
    invuln: 1.8, knockback: 420, repulse: 150,
    fireRate: 9, bulletSpeed: 1000, bulletLife: 0.9,
    startBombs: 1, bombRadius: 300,
    aimCone: 28,        // degrees either side of facing that aim assist will consider
    aimBias: 0.7,       // 0 = no assist, 1 = full snap (inside the cone only)
    aimRange: 600
  },

  ghost: {
    startBits: 12, maxBits: 40, finalMaxBits: 50,
    cursorSpeed: 470, energyMax: 100, energyRegen: 16,
    bitSpeed: 270, bitAttackSpeed: 380, bitHp: 2, bitRadius: 11,
    biteDamage: 0.25,           // hearts per bite; four bites = one heart
    biteCooldown: 0.7,
    bitBiteRobot: 1,            // damage a bite does to a machine
    passiveBitEvery: 5,         // seconds per free bit while army < max
    respawnDelay: 3, respawnBits: 10,
    finalBonusBits: 10,
    attackRange: 380,           // how far from the commander bits will look for prey when 5 is held
    costs: { SWARM: 35, SPLIT: 35, CHARGE: 40, RECALL: 10, SCATTER: 15 },
    durations: { SWARM: 4, SPLIT: 4, CHARGE: 0.9, RECALL: 1.0, SCATTER: 1.4 }
  },

  final: { timer: 30, lastStandShield: 2.5, lastStandRapid: 8 },

  waves: {
    base: 40, perWave: 12, maxAlive: 110, minAliveBase: 6, minAlivePerWave: 4,
    breakSeconds: 2.6, speedPerWave: 0.045, speedCap: 1.55,
    bossEvery: 5, fragmentChance: 0.45, powerupChance: 0.07
  },

  scoring: {
    robot: { grunt: 100, rusher: 150, swarmer: 50, shooter: 250, tank: 500, spawner: 600, hunter: 400, elite: 1500, boss: 6000 },
    bitKill: 25, waveSurvive: 1000, scoreBonus: 2500,
    ghostHeart: 600, ghostElim: 6000, fragment: 60, armyPerBitPerSec: 4,
    survivorWin: 25000
  },

  fx: { maxParticles: 2600, shake: 1.0 },

  /* ---------------- CONTROLS ----------------
     Pad 1 = plain numpad (untagged).
     Pads 2-6 are tagged by LuaMacros: arcadium-keypads-hold.lua sends F13..F17 right before
     each numpad key-down AND key-up. This game NEEDS the HOLD script (held move/fire).
     Codes are KeyboardEvent.code values. */
  keys: {
    tags: { F13: 1, F14: 2, F15: 3, F16: 4, F17: 5 },   // tag key -> player index (0-based)
    tagWindowMs: 160,
    pad: {
      Numpad7: [-1, -1], Numpad8: [0, -1], Numpad9: [1, -1],
      Numpad4: [-1, 0],                     Numpad6: [1, 0],
      Numpad1: [-1, 1],  Numpad2: [0, 1],  Numpad3: [1, 1],
      Numpad5: 'fire', Numpad0: 'special', NumpadEnter: 'start'
    },
    // Keyboard fallback for testing on one keyboard. Diagonals = press two keys.
    fallback: [
      { },  // P1 uses the numpad directly
      { up: 'KeyW', down: 'KeyS', left: 'KeyA', right: 'KeyD', fire: 'KeyF', special: 'KeyG', start: 'Digit2' },
      { up: 'KeyI', down: 'KeyK', left: 'KeyJ', right: 'KeyL', fire: 'KeyH', special: 'KeyU', start: 'Digit3' },
      { up: 'ArrowUp', down: 'ArrowDown', left: 'ArrowLeft', right: 'ArrowRight', fire: 'ShiftRight', special: 'ControlRight', start: 'Digit4' },
      { start: 'Digit5' },
      { start: 'Digit6' }
    ],
    p1Start: ['Digit1', 'Enter'],
    addBot: 'KeyB',        // join screen: fill the next empty slot with a CPU bot
    fullscreen: 'F11',
    mute: 'KeyM'
  },

  // Optional: point any sound name at a file to replace the built-in synth sound.
  // e.g. audioFiles: { robotExplode: 'sfx/boom.ogg' }
  audioFiles: {}
};

