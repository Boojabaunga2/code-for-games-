
/* js/players.js */
/* players.js - living Arcadium combat robots */
var BT = window.BT = window.BT || {};

BT.Player = function (idx, isBot) {
  var C = BT.CONFIG;
  this.idx = idx; this.isBot = !!isBot;
  this.color = C.players.colors[idx]; this.name = C.players.names[idx];
  this.r = C.player.radius;
  this.score = 0;
  this.stats = { robots: 0, bits: 0, elims: 0, maxArmy: 0, survival: 0, heartsDealt: 0 };
  this.reset();
};
BT.Player.prototype.reset = function () {
  var C = BT.CONFIG.player;
  this.alive = true; this.ghost = false; this.joined = true;
  this.x = 0; this.y = 0; this.vx = 0; this.vy = 0; this.kx = 0; this.ky = 0;
  this.face = -Math.PI / 2; this.hearts = C.hearts; this.invuln = 0; this.hurtFlash = 0;
  this.fireCD = 0; this.bombs = C.startBombs;
  this.pw = { rapid: 0, spread: 0, laser: 0, speed: 0, shield: 0, magnet: 0 };
  this.deathTime = 0; this.biteCD = 0; this.walk = 0;
};

BT.Player.prototype.update = function (dt, ctl, game) {
  var C = BT.CONFIG.player, U = BT.U;
  for (var k in this.pw) if (this.pw[k] > 0) this.pw[k] -= dt;
  if (this.invuln > 0) this.invuln -= dt;
  if (this.hurtFlash > 0) this.hurtFlash -= dt;
  this.stats.survival += dt;

  var dx = ctl.dx, dy = ctl.dy;
  var spd = C.speed * (this.pw.speed > 0 ? 1.4 : 1);
  if (dx || dy) {
    var l = Math.sqrt(dx * dx + dy * dy); dx /= l; dy /= l;
    this.face = Math.atan2(dy, dx);
    this.walk += dt * 12;
  }
  var t = Math.min(1, dt * 22);   // snappy acceleration
  this.vx += (dx * spd - this.vx) * t; this.vy += (dy * spd - this.vy) * t;
  this.x += (this.vx + this.kx) * dt; this.y += (this.vy + this.ky) * dt;
  var kd = Math.pow(0.002, dt); this.kx *= kd; this.ky *= kd;
  BT.Arena.collide(this, this.r);

  if (this.fireCD > 0) this.fireCD -= dt;
  if (ctl.fire && this.fireCD <= 0) this.shoot(game);
  if (ctl.pSpecial) {
    if (this.bombs > 0) { this.bombs--; game.bomb(this.x, this.y, this.idx, BT.CONFIG.player.bombRadius); }
    else BT.FX.text(this.x, this.y - 30, 'NO BOMBS', '#888', 16, 0.5);
  }
};

BT.Player.prototype.aimAngle = function (game) {
  var C = BT.CONFIG.player, U = BT.U;
  var cone = C.aimCone * Math.PI / 180, best = null, bestScore = 1e9;
  var near = game.grid.query(this.x, this.y, C.aimRange);
  for (var i = 0; i < near.length; i++) {
    var e = near[i]; if (!e.alive || e.dead) continue;
    var ex = e.x - this.x, ey = e.y - this.y, d2 = ex * ex + ey * ey;
    if (d2 > C.aimRange * C.aimRange) continue;
    var ad = Math.abs(U.angDiff(this.face, Math.atan2(ey, ex)));
    if (ad > cone) continue;
    var sc = Math.sqrt(d2) * (1 + ad * 2);
    if (sc < bestScore) { bestScore = sc; best = e; }
  }
  if (!best) return this.face;
  return this.face + U.angDiff(this.face, Math.atan2(best.y - this.y, best.x - this.x)) * C.aimBias;
};

BT.Player.prototype.shoot = function (game) {
  var C = BT.CONFIG.player, P = BT.Projectiles;
  var rate = C.fireRate * (this.pw.rapid > 0 ? 2.2 : 1) * (this.pw.laser > 0 ? 0.75 : 1);
  this.fireCD = 1 / rate;
  var a = this.aimAngle(game);
  var mx = this.x + Math.cos(a) * (this.r + 6), my = this.y + Math.sin(a) * (this.r + 6);
  var kind = this.pw.laser > 0 ? 'laser' : 'shot';
  var spd = C.bulletSpeed * (kind === 'laser' ? 1.4 : 1), dmg = kind === 'laser' ? 2 : 1;
  if (this.pw.spread > 0) {
    for (var s = -2; s <= 2; s++) P.fire(mx, my, a + s * 0.17, spd, this.idx, kind, this.color, dmg, C.bulletLife * 0.8);
  } else P.fire(mx, my, a, spd, this.idx, kind, this.color, dmg, C.bulletLife);
  BT.FX.spark(mx, my, '#ffffff', Math.cos(a) * 120, Math.sin(a) * 120, 0.08, 9);
  BT.FX.spark(mx, my, this.color, Math.cos(a) * 200, Math.sin(a) * 200, 0.12, 6);
  BT.Audio.play('playerFire');
};

BT.Player.prototype.draw = function (g, t) {
  if (!this.alive) return;
  var blink = this.invuln > 0 && Math.floor(t * 20) % 2 === 0;
  // floor glow + shadow
  g.fillStyle = BT.U.hexA(this.color, 0.22);
  g.beginPath(); g.ellipse(this.x, this.y + 18, 24, 9, 0, 0, 6.283); g.fill();
  var bob = Math.sin(this.walk) * 1.5;
  if (!blink) BT.Assets.draw(g, 'player' + this.idx, this.x, this.y - 4 + bob, Math.cos(this.face) < -0.1, this.hurtFlash > 0);
  // gun direction indicator
  var gx = this.x + Math.cos(this.face) * (this.r + 12), gy = this.y + Math.sin(this.face) * (this.r + 12);
  g.fillStyle = this.color; g.beginPath(); g.arc(gx, gy, 5, 0, 6.283); g.fill();
  g.fillStyle = '#fff'; g.beginPath(); g.arc(gx, gy, 2.2, 0, 6.283); g.fill();
  // shield bubble
  if (this.pw.shield > 0) {
    g.strokeStyle = 'rgba(80,170,255,' + (0.5 + 0.3 * Math.sin(t * 12)) + ')'; g.lineWidth = 3;
    g.beginPath(); g.arc(this.x, this.y, this.r + 16, 0, 6.283); g.stroke();
    g.fillStyle = 'rgba(80,170,255,0.12)'; g.fill();
  }
  // tag
  g.font = '15px RussoOne, Impact, sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle';
  g.lineWidth = 3; g.strokeStyle = '#000'; g.strokeText(this.name, this.x, this.y - 40);
  g.fillStyle = this.color; g.fillText(this.name, this.x, this.y - 40);
  // active weapon timer ring
  var pw = this.pw, best = Math.max(pw.rapid, pw.spread, pw.laser, pw.speed);
  if (best > 0) {
    g.strokeStyle = BT.U.hexA(this.color, 0.8); g.lineWidth = 3;
    g.beginPath(); g.arc(this.x, this.y, this.r + 9, -Math.PI / 2, -Math.PI / 2 + 6.283 * Math.min(1, best / 10)); g.stroke();
  }
};

