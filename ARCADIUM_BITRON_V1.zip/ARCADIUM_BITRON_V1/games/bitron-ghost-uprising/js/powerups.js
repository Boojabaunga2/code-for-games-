
/* js/powerups.js */
/* powerups.js - floor pickups + BIT fragments.
   who: 'L' = living players only, 'G' = ghosts only, 'B' = both */
var BT = window.BT = window.BT || {};

BT.Powerups = (function () {
  var U = BT.U;
  var TYPES = {
    rapid:    { who: 'L', label: 'RAPID FIRE', w: 10 },
    spread:   { who: 'L', label: 'SPREAD SHOT', w: 9, spr: null },
    laser:    { who: 'L', label: 'LASER', w: 7, spr: 'pu_laser' },
    bomb:     { who: 'L', label: 'BOMB', w: 6, spr: 'pu_bomb' },
    shield:   { who: 'L', label: 'SHIELD', w: 6, spr: 'pu_shield' },
    heart:    { who: 'L', label: 'EXTRA LIFE', w: 5, spr: 'pu_heart' },
    bitbomb:  { who: 'L', label: 'BIT BOMB', w: 6, spr: 'pu_skull' },
    score:    { who: 'B', label: 'SCORE BONUS', w: 6, spr: 'pu_score' },
    speed:    { who: 'B', label: 'SPEED BOOST', w: 6, spr: 'pu_speed' },
    magnet:   { who: 'B', label: 'BIT MAGNET', w: 5, spr: 'pu_magnet' },
    bitcache: { who: 'G', label: '+6 BITS', w: 0 }
  };
  var items = new BT.Pool(24, function () { return { type: 'score', x: 0, y: 0, life: 0, ph: 0 }; });
  var frags = new BT.Pool(260, function () { return { x: 0, y: 0, vx: 0, vy: 0, life: 0, ph: 0 }; });

  function spawn(type, x, y) {
    var p = items.spawn(); if (!p) return;
    p.type = type; p.x = x; p.y = y; p.life = 14; p.ph = Math.random() * 6;
  }
  function dropRandom(game, x, y, bias) {
    var ghosts = game.ghostCount();
    if (ghosts > 0 && Math.random() < 0.28) { spawn('bitcache', x, y); return; }
    var tot = 0, k; for (k in TYPES) tot += TYPES[k].w;
    var r = Math.random() * tot;
    for (k in TYPES) { r -= TYPES[k].w; if (r <= 0) { spawn(k, x, y); return; } }
  }
  function fragment(x, y, n) {
    for (var i = 0; i < n; i++) {
      var f = frags.spawn(); if (!f) return;
      var a = Math.random() * 6.283, s = U.rand(60, 200);
      f.x = x; f.y = y; f.vx = Math.cos(a) * s; f.vy = Math.sin(a) * s; f.life = 9; f.ph = Math.random() * 6;
    }
  }

  function applyLiving(p, type, game) {
    var C = BT.CONFIG;
    switch (type) {
      case 'rapid': p.pw.rapid = 9; break;
      case 'spread': p.pw.spread = 10; break;
      case 'laser': p.pw.laser = 8; break;
      case 'bomb': p.bombs = Math.min(5, p.bombs + 1); break;
      case 'shield': p.pw.shield = 7; break;
      case 'heart': p.hearts = Math.min(C.player.maxHearts, Math.floor(p.hearts + 1)); break;
      case 'bitbomb': game.bitBomb(p.x, p.y, p.idx); break;
      case 'score': game.addScore(p, C.scoring.scoreBonus, p.x, p.y); break;
      case 'speed': p.pw.speed = 8; break;
      case 'magnet': p.pw.magnet = 10; break;
    }
  }
  function applyGhost(p, type, game) {
    switch (type) {
      case 'bitcache': BT.Ghosts.addBits(p, 6); break;
      case 'score': game.addScore(p, BT.CONFIG.scoring.scoreBonus, p.gc.x, p.gc.y); break;
      case 'speed': p.pw.speed = 8; break;
      case 'magnet': p.pw.magnet = 10; break;
    }
  }

  function update(dt, game) {
    var it = items.items, i, k, p, q;
    for (i = 0; i < it.length; i++) {
      q = it[i]; if (!q.alive) continue;
      q.life -= dt; q.ph += dt; if (q.life <= 0) { q.alive = false; continue; }
      var T = TYPES[q.type], got = null, asGhost = false;
      for (k = 0; k < game.players.length && !got; k++) {
        p = game.players[k]; if (!p) continue;
        if (p.alive && T.who !== 'G' && U.dist2(p.x, p.y, q.x, q.y) < 34 * 34) got = p;
        else if (p.ghost && p.gc && T.who !== 'L' && U.dist2(p.gc.x, p.gc.y, q.x, q.y) < 48 * 48) { got = p; asGhost = true; }
      }
      if (!got && T.who !== 'L') {
        var near = game.grid.query(q.x, q.y, 26);
        for (k = 0; k < near.length; k++) { var b = near[k]; if (b.isBit && b.alive && U.dist2(b.x, b.y, q.x, q.y) < 26 * 26) { got = game.players[b.owner]; asGhost = true; break; } }
      }
      if (got) {
        q.alive = false;
        if (asGhost) applyGhost(got, q.type, game); else applyLiving(got, q.type, game);
        BT.Audio.play('powerup');
        BT.FX.text(q.x, q.y - 26, T.label, got.color, 22, 1.1);
        BT.FX.ring(q.x, q.y, got.color, 70, 0.3);
      }
    }
    // fragments
    var ft = frags.items;
    for (i = 0; i < ft.length; i++) {
      var f = ft[i]; if (!f.alive) continue;
      f.life -= dt; f.ph += dt; if (f.life <= 0) { f.alive = false; continue; }
      // magnets
      for (k = 0; k < game.players.length; k++) {
        p = game.players[k]; if (!p || p.pw.magnet <= 0) continue;
        var mx = p.alive ? p.x : (p.gc ? p.gc.x : null), my = p.alive ? p.y : (p.gc ? p.gc.y : null);
        if (mx === null || (!p.alive && !p.ghost)) continue;
        var dx = mx - f.x, dy = my - f.y, d2 = dx * dx + dy * dy;
        if (d2 < 450 * 450) { var d = Math.sqrt(d2) || 1; f.vx += dx / d * 1400 * dt; f.vy += dy / d * 1400 * dt; }
      }
      f.x += f.vx * dt; f.y += f.vy * dt; f.vx *= Math.pow(0.1, dt); f.vy *= Math.pow(0.1, dt);
      collectFragment(f, game);
    }
  }
  function collectFragment(f, game) {
    var S = BT.CONFIG.scoring;
    for (var k = 0; k < game.players.length; k++) {
      var p = game.players[k]; if (!p) continue;
      if (p.alive && U.dist2(p.x, p.y, f.x, f.y) < 30 * 30) { f.alive = false; game.addScore(p, 20, f.x, f.y, true); BT.FX.burst(f.x, f.y, '#dfe8ff', 5, 120, 0.2, 2); return; }
      if (p.ghost && p.gc && U.dist2(p.gc.x, p.gc.y, f.x, f.y) < 44 * 44) { take(p); return; }
    }
    var near = game.grid.query(f.x, f.y, 20);
    for (var i = 0; i < near.length; i++) {
      var b = near[i];
      if (b.isBit && b.alive && U.dist2(b.x, b.y, f.x, f.y) < 20 * 20) { take(game.players[b.owner]); return; }
    }
    function take(p) {
      f.alive = false;
      if (BT.Ghosts.addBits(p, 1, f.x, f.y)) BT.FX.burst(f.x, f.y, p.color, 6, 140, 0.25, 2);
      game.addScore(p, S.fragment, f.x, f.y, true);
    }
  }

  function drawIcon(g, type, x, y, t) {
    var T = TYPES[type];
    if (T.spr) { BT.Assets.draw(g, T.spr, x, y); return; }
    if (type === 'bitcache') { BT.Assets.draw(g, 'fragment', x, y); BT.Assets.draw(g, 'fragment', x - 9, y + 6); BT.Assets.draw(g, 'fragment', x + 9, y + 6); return; }
    g.save(); g.translate(x, y);
    if (type === 'rapid') {
      g.fillStyle = '#ffd21a'; g.shadowColor = '#ffd21a'; g.shadowBlur = 10;
      for (var i = -1; i <= 1; i++) { g.fillRect(i * 9 - 3, -13, 6, 26); g.fillRect(i * 9 - 6, -4, 12, 3); }
    } else if (type === 'spread') {
      g.strokeStyle = '#e8f4ff'; g.shadowColor = '#9cf'; g.shadowBlur = 10; g.lineWidth = 3;
      for (var k = 0; k < 8; k++) { var a = k * Math.PI / 4; g.beginPath(); g.moveTo(Math.cos(a) * 4, Math.sin(a) * 4); g.lineTo(Math.cos(a) * 15, Math.sin(a) * 15); g.stroke(); }
    }
    g.restore();
  }

  function draw(g, t) {
    var ft = frags.items, i;
    for (i = 0; i < ft.length; i++) {
      var f = ft[i]; if (!f.alive) continue;
      if (f.life < 2 && Math.floor(f.life * 10) % 2) continue;
      BT.Assets.draw(g, 'fragment', f.x, f.y + Math.sin(f.ph * 5) * 2);
    }
    var it = items.items;
    for (i = 0; i < it.length; i++) {
      var q = it[i]; if (!q.alive) continue;
      if (q.life < 3 && Math.floor(q.life * 8) % 2) continue;
      var T = TYPES[q.type], col = T.who === 'G' ? '#e8e8ff' : (T.who === 'B' ? '#ffd21a' : '#ff2a3a');
      var pr = 26 + Math.sin(q.ph * 4) * 3;
      g.strokeStyle = col; g.globalAlpha = 0.85; g.lineWidth = 3;
      g.beginPath(); g.arc(q.x, q.y, pr, q.ph * 2, q.ph * 2 + 4.6); g.stroke();
      g.globalAlpha = 0.14; g.fillStyle = col; g.beginPath(); g.arc(q.x, q.y, pr, 0, 6.283); g.fill();
      g.globalAlpha = 1;
      drawIcon(g, q.type, q.x, q.y + Math.sin(q.ph * 3) * 2, t);
    }
  }

  return {
    TYPES: TYPES, spawn: spawn, dropRandom: dropRandom, fragment: fragment, update: update, draw: draw, drawIcon: drawIcon,
    clear: function () { items.clear(); frags.clear(); }, fragCount: function () { return frags.count(); }
  };
})();

