
/* js/main.js */
/* main.js - boot, fixed 60 Hz simulation, scaling to the cabinet screen */
var BT = window.BT = window.BT || {};

(function () {
  var C = BT.CONFIG;
  var cv = document.getElementById('game');
  cv.width = C.W; cv.height = C.H;
  var g = cv.getContext('2d');
  var DT = 1 / 60, acc = 0, last = 0, t = 0, showFps = false, fps = 60, fpsAcc = 0, fpsN = 0;

  function fit() {
    var s = Math.min(window.innerWidth / C.W, (window.innerHeight - 52) / C.H);
    cv.style.width = Math.floor(C.W * s) + 'px'; cv.style.height = Math.floor(C.H * s) + 'px';
  }
  window.addEventListener('resize', fit); fit();

  BT.Input.onGlobal(function (code) {
    if (code === C.keys.fullscreen) {
      if (!document.fullscreenElement) { (document.documentElement.requestFullscreen || function () {}).call(document.documentElement); }
      else document.exitFullscreen();
      return true;
    }
    if (code === C.keys.mute) { BT.Audio.toggleMute(); return true; }
    if (code === 'F9') { showFps = !showFps; return true; }
    return false;
  });

  function frame(now) {
    requestAnimationFrame(frame);
    if (!last) last = now;
    var el = Math.min(0.1, (now - last) / 1000); last = now;
    fpsAcc += el; fpsN++; if (fpsAcc > 0.5) { fps = fpsN / fpsAcc; fpsAcc = 0; fpsN = 0; }
    acc += el;
    var n = 0;
    while (acc >= DT && n < 5) { BT.App.update(DT); t += DT; acc -= DT; n++; }
    if (n === 5) acc = 0;
    render();
  }
  function render() {
    g.setTransform(1, 0, 0, 1, 0, 0);
    BT.App.render(g, t);
    if (showFps) {
      var gm = BT.App.S.game;
      BT.UI.txt(g, Math.round(fps) + ' FPS  machines ' + BT.Enemies.count() + '  bits ' + BT.Ghosts.total() + '  shots ' + BT.Projectiles.count() + '  fx ' + BT.FX.count(), 20, C.H - 60, 20, '#0f0', 'left', true);
    }
  }

  // test / debug hooks (used by the automated playtests)
  BT.debug = {
    sim: function (sec) { var k = Math.round(sec * 60); for (var i = 0; i < k; i++) { BT.App.update(DT); t += DT; } },
    render: render,
    kill: function (i) { var gm = BT.App.S.game; if (gm && gm.players[i] && gm.players[i].alive) gm.killPlayer(gm.players[i], -1); },
    state: function () { return BT.App.S.name; },
    game: function () { return BT.App.S.game; }
  };

  BT.Assets.load(function () {
    document.getElementById('boot').style.display = 'none';
    BT.App.go('splash');
    requestAnimationFrame(frame);
  });
})();

