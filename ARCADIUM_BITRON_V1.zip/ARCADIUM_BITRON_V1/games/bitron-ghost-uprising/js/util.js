
/* js/util.js */
/* util.js - math helpers, object pools, spatial hash */
var BT = window.BT = window.BT || {};

BT.U = {
  clamp: function (v, a, b) { return v < a ? a : (v > b ? b : v); },
  lerp: function (a, b, t) { return a + (b - a) * t; },
  rand: function (a, b) { return a + Math.random() * (b - a); },
  randi: function (a, b) { return Math.floor(a + Math.random() * (b - a + 1)); },
  pick: function (arr) { return arr[Math.floor(Math.random() * arr.length)]; },
  dist2: function (ax, ay, bx, by) { var dx = ax - bx, dy = ay - by; return dx * dx + dy * dy; },
  len: function (x, y) { return Math.sqrt(x * x + y * y); },
  angDiff: function (a, b) { var d = b - a; while (d > Math.PI) d -= 2 * Math.PI; while (d < -Math.PI) d += 2 * Math.PI; return d; },
  fmt: function (n) { n = Math.floor(n); return n.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ','); },
  pad: function (n, w) { var s = String(Math.floor(n)); while (s.length < w) s = '0' + s; return s; },
  hexA: function (hex, a) {
    var r = parseInt(hex.substr(1, 2), 16), g = parseInt(hex.substr(3, 2), 16), b = parseInt(hex.substr(5, 2), 16);
    return 'rgba(' + r + ',' + g + ',' + b + ',' + a + ')';
  },
  // circle vs axis-aligned rect: returns push vector or null
  circleRect: function (cx, cy, r, R) {
    var nx = BT.U.clamp(cx, R.x, R.x + R.w), ny = BT.U.clamp(cy, R.y, R.y + R.h);
    var dx = cx - nx, dy = cy - ny, d2 = dx * dx + dy * dy;
    if (d2 >= r * r) return null;
    if (d2 > 0.0001) { var d = Math.sqrt(d2); return { x: dx / d * (r - d), y: dy / d * (r - d) }; }
    // centre inside rect: push out along shallowest axis
    var l = cx - R.x, rr = R.x + R.w - cx, t = cy - R.y, b = R.y + R.h - cy, m = Math.min(l, rr, t, b);
    if (m === l) return { x: -(l + r), y: 0 };
    if (m === rr) return { x: rr + r, y: 0 };
    if (m === t) return { x: 0, y: -(t + r) };
    return { x: 0, y: b + r };
  }
};

/* Fixed-size pool. Objects carry .alive; spawn() recycles dead ones. */
BT.Pool = function (size, factory) {
  this.items = [];
  for (var i = 0; i < size; i++) { var o = factory(); o.alive = false; this.items.push(o); }
  this.cursor = 0;
};
BT.Pool.prototype.spawn = function () {
  var n = this.items.length;
  for (var i = 0; i < n; i++) {
    var k = (this.cursor + i) % n;
    if (!this.items[k].alive) { this.cursor = (k + 1) % n; this.items[k].alive = true; return this.items[k]; }
  }
  return null;  // pool exhausted - caller simply skips the spawn
};
BT.Pool.prototype.count = function () { var c = 0; for (var i = 0; i < this.items.length; i++) if (this.items[i].alive) c++; return c; };
BT.Pool.prototype.clear = function () { for (var i = 0; i < this.items.length; i++) this.items[i].alive = false; };

/* Uniform-grid spatial hash, rebuilt every frame. */
BT.Grid = function (x, y, w, h, cell) {
  this.x = x; this.y = y; this.cell = cell;
  this.cols = Math.ceil(w / cell) + 1; this.rows = Math.ceil(h / cell) + 1;
  this.cells = [];
  for (var i = 0; i < this.cols * this.rows; i++) this.cells.push([]);
  this.out = [];
};
BT.Grid.prototype.clear = function () { for (var i = 0; i < this.cells.length; i++) this.cells[i].length = 0; };
BT.Grid.prototype.idx = function (px, py) {
  var c = BT.U.clamp(Math.floor((px - this.x) / this.cell), 0, this.cols - 1);
  var r = BT.U.clamp(Math.floor((py - this.y) / this.cell), 0, this.rows - 1);
  return r * this.cols + c;
};
BT.Grid.prototype.insert = function (o) { this.cells[this.idx(o.x, o.y)].push(o); };
BT.Grid.prototype.query = function (px, py, rad) {
  var out = this.out; out.length = 0;
  var c0 = BT.U.clamp(Math.floor((px - rad - this.x) / this.cell), 0, this.cols - 1);
  var c1 = BT.U.clamp(Math.floor((px + rad - this.x) / this.cell), 0, this.cols - 1);
  var r0 = BT.U.clamp(Math.floor((py - rad - this.y) / this.cell), 0, this.rows - 1);
  var r1 = BT.U.clamp(Math.floor((py + rad - this.y) / this.cell), 0, this.rows - 1);
  for (var r = r0; r <= r1; r++) for (var c = c0; c <= c1; c++) {
    var cell = this.cells[r * this.cols + c];
    for (var i = 0; i < cell.length; i++) out.push(cell[i]);
  }
  return out;
};

