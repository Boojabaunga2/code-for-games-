
/* js/assets.js */
/* assets.js - loads the art cut from the BITRON reference sheets and bakes
   scaled / glowing / tinted / flash variants into offscreen canvases.
   To replace any art: drop a new PNG with the same name into assets/. */
var BT = window.BT = window.BT || {};

BT.Assets = (function () {
  var FILES = ['logo', 'arcadium', 'ghost_skull', 'red_skull',
    'pl_blue', 'pl_red', 'pl_green', 'pl_yellow', 'pl_purple', 'pl_cyan',
    'bit_blue', 'bit_red', 'bit_green', 'bit_yellow', 'bit_purple', 'bit_cyan',
    'en_grunt', 'en_rusher', 'en_tank', 'en_shooter', 'en_saucer', 'en_boss',
    'pu_heart', 'pu_shield', 'pu_bomb', 'pu_laser', 'pu_score', 'pu_magnet', 'pu_speed', 'pu_skull',
    'fx_boom_y', 'fx_boom_r', 'fx_boom_b'];
  var PCOL = ['red', 'blue', 'green', 'yellow', 'purple', 'cyan'];
  var img = {}, spr = {};

  function canvas(w, h) { var c = document.createElement('canvas'); c.width = Math.max(1, Math.ceil(w)); c.height = Math.max(1, Math.ceil(h)); return c; }

  // bake: scaled sprite with optional glow, plus a white "hit flash" copy
  function bake(key, srcName, scale, glow, blur, tint) {
    var s = img[srcName]; if (!s) return;
    var w = s.width * scale, h = s.height * scale, pad = glow ? blur + 2 : 2;
    var c = canvas(w + pad * 2, h + pad * 2), g = c.getContext('2d');
    g.imageSmoothingEnabled = true;
    var base = s;
    if (tint) { base = tintCanvas(s, tint); }
    if (glow) { g.shadowColor = glow; g.shadowBlur = blur; }
    g.drawImage(base, pad, pad, w, h);
    g.shadowBlur = 0;
    if (glow) g.drawImage(base, pad, pad, w, h);
    var f = canvas(c.width, c.height), fg = f.getContext('2d');
    fg.drawImage(base, pad, pad, w, h);
    fg.globalCompositeOperation = 'source-atop'; fg.fillStyle = '#ffffff'; fg.fillRect(0, 0, f.width, f.height);
    spr[key] = { c: c, flash: f, cf: mirror(c), ff: mirror(f), w: c.width, h: c.height };
  }
  function mirror(src) { var m = canvas(src.width, src.height), g = m.getContext('2d'); g.translate(src.width, 0); g.scale(-1, 1); g.drawImage(src, 0, 0); return m; }
  // colourise a (mostly grey) image to a hex colour, keeping its alpha + shading
  function tintCanvas(s, hex) {
    var c = canvas(s.width, s.height), g = c.getContext('2d');
    g.filter='grayscale(1)'; g.drawImage(s, 0, 0); g.filter='none';
    g.globalCompositeOperation = 'multiply'; g.fillStyle = hex; g.fillRect(0, 0, c.width, c.height);
    g.globalCompositeOperation = 'lighter'; g.globalAlpha = 0.25; g.drawImage(s, 0, 0); g.globalAlpha = 1;
    g.globalCompositeOperation = 'destination-in'; g.drawImage(s, 0, 0);
    return c;
  }

  function bakeAll() {
    var P = BT.CONFIG.players.colors;
    for (var i = 0; i < 6; i++) {
      bake('player' + i, 'pl_' + PCOL[i], 0.7, P[i], 10, i >= 4 ? P[i] : null);
      bake('card' + i, 'pl_' + PCOL[i], 2.2, P[i], 22, i >= 4 ? P[i] : null);
      bake('bit' + i, 'bit_' + PCOL[i], 0.85, P[i], 7, i >= 4 ? P[i] : null);
      bake('bitbig' + i, 'bit_' + PCOL[i], 1.3, P[i], 10);
      bake('ghost' + i, 'ghost_skull', 0.85, P[i], 22, P[i]);
      bake('ghosthud' + i, 'ghost_skull', 0.5, P[i], 10, P[i]);
      bake('ghostbig' + i, 'ghost_skull', 2.4, P[i], 40, P[i]);
    }
    bake('fragment', 'bit_cyan', 0.42, '#ffffff', 6, '#dfe8ff');
    bake('en_grunt', 'en_grunt', 1.0, null);
    bake('en_hunter', 'en_grunt', 1.18, '#ff2030', 8);
    bake('en_rusher', 'en_rusher', 0.9, null);
    bake('en_swarmer', 'en_rusher', 0.56, '#ff3040', 4);
    bake('en_shooter', 'en_shooter', 1.0, null);
    bake('en_tank', 'en_tank', 1.18, null);
    bake('en_spawner', 'en_saucer', 1.35, '#ff2030', 8);
    bake('en_elite', 'en_boss', 0.78, '#ff1020', 14);
    bake('en_boss', 'en_boss', 1.9, '#ff1020', 22);
    var pus = ['heart', 'shield', 'bomb', 'laser', 'score', 'magnet', 'speed', 'skull'];
    for (var k = 0; k < pus.length; k++) bake('pu_' + pus[k], 'pu_' + pus[k], 0.95, null);
    bake('fx_boom_y', 'fx_boom_y', 1, null); bake('fx_boom_r', 'fx_boom_r', 1, null); bake('fx_boom_b', 'fx_boom_b', 1, null);
    bake('red_skull', 'red_skull', 1, null);
    bake('red_skull_big', 'red_skull', 2.6, '#ff0020', 30);
  }

  function load(done) {
    var left = FILES.length;
    var data = window.BT_ASSET_DATA || {};
    FILES.forEach(function (n) {
      var im = new Image();
      im.onload = function () { img[n] = im; if (--left === 0) finish(); };
      im.onerror = function () { console.warn('missing asset ' + n); if (--left === 0) finish(); };
      im.src = data[n] || ('assets/' + n + '.png');
    });
    function finish() {
      bakeAll();
      var fontsReady = (document.fonts && document.fonts.load) ?
        Promise.all([document.fonts.load('40px RussoOne'), document.fonts.load('700 40px ChakraPetch')]) : Promise.resolve();
      fontsReady.then(done, done);
    }
  }

  // draw centred sprite; mirrored copy if flip (pre-baked, no save/restore)
  function draw(g, key, x, y, flip, flash, alpha) {
    var s = spr[key]; if (!s) return;
    var src = flash ? (flip ? s.ff : s.flash) : (flip ? s.cf : s.c);
    if (alpha !== undefined && alpha < 1) g.globalAlpha = alpha;
    g.drawImage(src, Math.round(x - s.w / 2), Math.round(y - s.h / 2));
    if (alpha !== undefined && alpha < 1) g.globalAlpha = 1;
  }

  return { load: load, img: img, spr: spr, draw: draw, canvas: canvas };
})();

