
/* js/fx.js */
/* fx.js - pooled particles, explosion sprites, rings, floating text, shake, flashes */
var BT = window.BT = window.BT || {};

BT.FX = (function () {
  var U = BT.U;
  var parts = new BT.Pool(BT.CONFIG.fx.maxParticles, function () { return { x: 0, y: 0, vx: 0, vy: 0, life: 0, max: 1, size: 2, color: '#fff', drag: 0.9, kind: 0 }; });
  var booms = new BT.Pool(80, function () { return { x: 0, y: 0, t: 0, max: 0.4, key: '', scale: 1 }; });
  var rings = new BT.Pool(60, function () { return { x: 0, y: 0, t: 0, max: 0.4, r: 100, color: '#fff' }; });
  var texts = new BT.Pool(60, function () { return { x: 0, y: 0, t: 0, max: 1, s: '', color: '#fff', size: 20 }; });
  var shakeAmt = 0, flashC = null, flashA = 0, flashMax = 0.0001;

  function spark(x, y, color, vx, vy, life, size, drag) {
    var p = parts.spawn(); if (!p) return;
    p.x = x; p.y = y; p.vx = vx; p.vy = vy; p.life = p.max = life; p.size = size || 3; p.color = color; p.drag = drag || 0.92; p.kind = 0;
  }
  function debris(x, y, n) {
    for (var i = 0; i < n; i++) {
      var p = parts.spawn(); if (!p) return;
      var a = Math.random() * 6.283, s = U.rand(80, 420);
      p.x = x; p.y = y; p.vx = Math.cos(a) * s; p.vy = Math.sin(a) * s; p.life = p.max = U.rand(0.4, 0.9);
      p.size = U.rand(3, 7); p.color = U.pick(['#8a8a96', '#c0c0cc', '#3a3a44', '#ff2a3a']); p.drag = 0.88; p.kind = 1;
    }
  }
  function burst(x, y, color, n, speed, life, size) {
    for (var i = 0; i < n; i++) {
      var a = Math.random() * 6.283, s = U.rand(speed * 0.3, speed);
      spark(x, y, color, Math.cos(a) * s, Math.sin(a) * s, U.rand(life * 0.5, life), size || 3);
    }
  }
  function boom(x, y, key, scale, dur) {
    var b = booms.spawn(); if (!b) return;
    b.x = x; b.y = y; b.t = 0; b.max = dur || 0.35; b.key = key; b.scale = scale || 1;
  }
  function ring(x, y, color, r, dur) {
    var o = rings.spawn(); if (!o) return;
    o.x = x; o.y = y; o.t = 0; o.max = dur || 0.4; o.r = r; o.color = color;
  }
  function explode(x, y, color, n, scale) {
    burst(x, y, color || '#ff4020', n || 22, 420 * (scale || 1), 0.6, 3);
    burst(x, y, '#ffd060', Math.floor((n || 22) / 2), 260 * (scale || 1), 0.4, 2);
    debris(x, y, Math.floor((n || 22) / 3));
    boom(x, y, U.pick(['fx_boom_y', 'fx_boom_r']), scale || 1, 0.32 + 0.1 * (scale || 1));
    if ((scale || 1) >= 1.5) ring(x, y, '#ff3040', 140 * scale, 0.45);
  }
  function pop(x, y, color) {
    burst(x, y, color, 8, 240, 0.35, 3);
    boom(x, y, 'fx_boom_b', 0.45, 0.18);
  }
  function text(x, y, s, color, size, life) {
    var t = texts.spawn(); if (!t) return;
    t.x = x; t.y = y; t.s = s; t.color = color || '#fff'; t.size = size || 20; t.t = 0; t.max = life || 0.9;
  }
  function shake(a) { shakeAmt = Math.min(28, Math.max(shakeAmt, a * BT.CONFIG.fx.shake)); }
  function flash(color, a, dur) { flashC = color; flashA = a; flashMax = dur || 0.3; flashT = flashMax; }
  var flashT = 0;

  function update(dt) {
    var it = parts.items, i, p;
    for (i = 0; i < it.length; i++) {
      p = it[i]; if (!p.alive) continue;
      p.life -= dt; if (p.life <= 0) { p.alive = false; continue; }
      p.x += p.vx * dt; p.y += p.vy * dt; var d = Math.pow(p.drag, dt * 60); p.vx *= d; p.vy *= d;
    }
    it = booms.items; for (i = 0; i < it.length; i++) if (it[i].alive && (it[i].t += dt) >= it[i].max) it[i].alive = false;
    it = rings.items; for (i = 0; i < it.length; i++) if (it[i].alive && (it[i].t += dt) >= it[i].max) it[i].alive = false;
    it = texts.items; for (i = 0; i < it.length; i++) if (it[i].alive) { it[i].t += dt; it[i].y -= 40 * dt; if (it[i].t >= it[i].max) it[i].alive = false; }
    shakeAmt *= Math.pow(0.0015, dt); if (shakeAmt < 0.3) shakeAmt = 0;
    if (flashT > 0) flashT -= dt;
  }

  function draw(g) {
    var it = rings.items, i;
    g.lineWidth = 4;
    for (i = 0; i < it.length; i++) {
      var r = it[i]; if (!r.alive) continue;
      var f = r.t / r.max; g.globalAlpha = 1 - f; g.strokeStyle = r.color;
      g.beginPath(); g.arc(r.x, r.y, r.r * (0.2 + 0.8 * f), 0, 6.283); g.stroke();
    }
    g.globalAlpha = 1;
    g.globalCompositeOperation = 'lighter';
    it = booms.items;
    for (i = 0; i < it.length; i++) {
      var b = it[i]; if (!b.alive) continue;
      var s = BT.Assets.spr[b.key]; if (!s) continue;
      var k = b.t / b.max, sc = b.scale * (0.6 + 1.1 * k);
      g.globalAlpha = 1 - k;
      g.drawImage(s.c, b.x - s.w * sc / 2, b.y - s.h * sc / 2, s.w * sc, s.h * sc);
    }
    g.globalAlpha = 1;
    it = parts.items;
    for (i = 0; i < it.length; i++) {
      var p = it[i]; if (!p.alive || p.kind) continue;
      g.globalAlpha = p.life / p.max; g.fillStyle = p.color;
      g.fillRect(p.x - p.size / 2, p.y - p.size / 2, p.size, p.size);
    }
    g.globalCompositeOperation = 'source-over';
    for (i = 0; i < it.length; i++) {
      p = it[i]; if (!p.alive || !p.kind) continue;
      g.globalAlpha = Math.min(1, p.life / p.max * 2); g.fillStyle = p.color;
      g.fillRect(p.x - p.size / 2, p.y - p.size / 2, p.size, p.size);
    }
    g.globalAlpha = 1;
    it = texts.items;
    g.textAlign = 'center'; g.textBaseline = 'middle';
    for (i = 0; i < it.length; i++) {
      var t = it[i]; if (!t.alive) continue;
      g.globalAlpha = Math.min(1, (t.max - t.t) * 3);
      g.font = t.size + 'px RussoOne, Impact, sans-serif';
      g.lineWidth = 4; g.strokeStyle = '#000'; g.strokeText(t.s, t.x, t.y);
      g.fillStyle = t.color; g.fillText(t.s, t.x, t.y);
    }
    g.globalAlpha = 1;
  }
  function drawScreen(g, W, H) {
    if (flashT > 0 && flashC) { g.globalAlpha = flashA * (flashT / flashMax); g.fillStyle = flashC; g.fillRect(0, 0, W, H); g.globalAlpha = 1; }
  }
  function clear() { parts.clear(); booms.clear(); rings.clear(); texts.clear(); shakeAmt = 0; flashT = 0; }

  return {
    spark: spark, burst: burst, debris: debris, boom: boom, ring: ring, explode: explode, pop: pop, text: text,
    shake: shake, flash: flash, update: update, draw: draw, drawScreen: drawScreen, clear: clear,
    get shakeAmt() { return shakeAmt; }, count: function () { return parts.count(); }
  };
})();

