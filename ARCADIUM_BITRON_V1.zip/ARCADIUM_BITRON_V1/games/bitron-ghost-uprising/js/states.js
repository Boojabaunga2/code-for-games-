
/* js/states.js */
/* states.js - game-state machine:
   splash -> howtoAttract -> attract -> (loop)   any START -> join
   join -> howto -> countdown -> play -> victory | gameover -> results -> join */
var BT = window.BT = window.BT || {};

BT.App = (function () {
  var C = BT.CONFIG, I = BT.Input;
  var S = { name: 'splash', t: 0, slots: null, lobbyT: null, game: null, idle: 0, cd: 0 };

  function freshSlots(keep) {
    var s = [];
    for (var i = 0; i < 6; i++) s.push({ joined: keep ? keep[i].joined : false, bot: keep ? keep[i].bot : false });
    return s;
  }
  function go(name) {
    S.name = name; S.t = 0;
    if (name === 'splash' || name === 'howtoAttract') { BT.Audio.musicStop(); }
    if (name === 'attract') {
      I.clearVirtual(); BT.Bots.reset();
      S.game = new BT.Game([1, 1, 1, 1, 1, 1], [1, 1, 1, 1, 1, 1], true);
      BT.Waves.start(S.game, 1);
    }
    if (name === 'join') { I.clearVirtual(); BT.Audio.musicStop(); S.lobbyT = null; S.idle = 0; }
    if (name === 'countdown') {
      I.clearVirtual(); BT.Bots.reset();
      var j = [], b = [];
      for (var i = 0; i < 6; i++) { j.push(S.slots[i].joined); b.push(S.slots[i].bot); }
      S.game = new BT.Game(j, b, false);
      S.cd = 3;
    }
    if (name === 'play') { BT.Waves.start(S.game, 1); BT.Audio.musicStart(); }
    if (name === 'results') S.idle = 0;
  }

  function joinedCount() { var n = 0; for (var i = 0; i < 6; i++) if (S.slots[i].joined) n++; return n; }
  function anyStart() { for (var i = 0; i < 6; i++) if (I.get(i).pStart) return i; return -1; }

  function join(i) {
    if (S.slots[i].joined) return;
    S.slots[i].joined = true; S.slots[i].bot = false;
    BT.Audio.play('join');
    var n = joinedCount();
    if (n >= C.players.min) S.lobbyT = S.lobbyT === null ? C.players.lobbySeconds : Math.max(S.lobbyT, 6);
    if (n === 6) S.lobbyT = Math.min(S.lobbyT, 3);
  }
  function addBot() {
    for (var i = 0; i < 6; i++) if (!S.slots[i].joined) { join(i); S.slots[i].bot = true; return; }
  }
  function launch() {
    var n = joinedCount();
    if (n >= C.players.min || (C.players.allowSolo && n >= 1)) go('howto');
  }

  // world step for any state that runs a match
  function stepMatch(dt) {
    var g = S.game;
    BT.Bots.think(g, dt);
    var ctls = [];
    for (var i = 0; i < 6; i++) ctls.push(I.get(i));
    g.step(dt, ctls);
  }

  function update(dt) {
    I.update();
    S.t += dt;
    var st = anyStart(), i;
    switch (S.name) {
      case 'splash':
        if (st >= 0) { S.slots = freshSlots(); go('join'); join(st); return; }
        if (S.t > 7) go('howtoAttract');
        break;
      case 'howtoAttract':
        if (st >= 0) { S.slots = freshSlots(); go('join'); join(st); return; }
        if (S.t > 9) go('attract');
        break;
      case 'attract':
        // humans' START is read before bots overwrite virtual input
        for (i = 0; i < 6; i++) if (I.human(i).pStart) { I.clearVirtual(); S.slots = freshSlots(); go('join'); join(i); return; }
        stepMatch(dt * S.game.timeScaleNow);
        if (S.t > 40 || (S.game.over && S.game.endT <= 0)) { I.clearVirtual(); go('splash'); }
        break;
      case 'join':
        S.idle += dt;
        for (i = 0; i < 6; i++) {
          var c = I.get(i);
          if (c.pStart) { join(i); S.idle = 0; }
          if (c.pSpecial && S.slots[i].joined && !S.slots[i].bot) launch();
          if (c.any) S.idle = 0;
        }
        if (S.lobbyT !== null) { S.lobbyT -= dt; if (S.lobbyT <= 0) { launch(); return; } }
        if (S.idle > 45 && joinedCount() === 0) go('splash');
        break;
      case 'howto':
        for (i = 0; i < 6; i++) if (S.slots[i].joined && I.get(i).pFire && S.t > 0.6) { go('countdown'); return; }
        if (S.t > 7) go('countdown');
        break;
      case 'countdown':
        var before = Math.ceil(S.cd);
        S.cd -= dt;
        if (Math.ceil(S.cd) !== before && S.cd > 0) BT.Audio.play('countdown');
        if (S.cd <= -0.6) go('play');
        else if (S.cd <= 0 && before > 0) BT.Audio.play('go');
        break;
      case 'play':
        stepMatch(dt * S.game.timeScaleNow);
        if (S.game.over && S.game.endT <= 0) go(S.game.over === 'survivor' ? 'victory' : 'gameover');
        break;
      case 'victory': case 'gameover':
        BT.FX.update(dt);
        if (S.t > 6 || (S.t > 2 && st >= 0)) go('results');
        break;
      case 'results':
        S.idle += dt;
        if (st >= 0 && S.t > 1.5) { var keep = S.slots; S.slots = freshSlots(keep); go('join'); S.lobbyT = joinedCount() >= C.players.min ? C.players.lobbySeconds : null; return; }
        if (S.idle > 45) go('splash');
        break;
    }
  }

  function render(g, t) {
    var U = BT.UI, game = S.game;
    switch (S.name) {
      case 'splash': U.splash(g, S.t); break;
      case 'howtoAttract': U.howto(g, S.t); break;
      case 'join': U.join(g, S.slots, S.t, S.lobbyT, joinedCount() >= C.players.min); break;
      case 'howto': U.howto(g, S.t, Math.max(0, 7 - S.t)); break;
      case 'attract': case 'countdown': case 'play':
        var sh = BT.FX.shakeAmt;
        g.save();
        if (sh > 0) g.translate((Math.random() - 0.5) * sh, (Math.random() - 0.5) * sh);
        game.draw(g, t);
        U.arenaOverlays(g, game, t);
        g.restore();
        U.hud(g, game, t);
        BT.FX.drawScreen(g, C.W, C.H);
        if (S.name === 'countdown') { var n = Math.ceil(S.cd); U.countdown(g, n, n > 0 ? S.cd - Math.floor(S.cd) : (0.6 + S.cd) / 0.6); }
        if (S.name === 'attract') U.attract(g, S.t);
        break;
      case 'victory': U.victory(g, game, S.t); break;
      case 'gameover': U.gameover(g, game, S.t); break;
      case 'results': U.results(g, game, S.t); break;
    }
  }

  // ESC on the join screen goes back to the title
  I.onGlobal(function (code) { if (code === 'Escape' && S.name === 'join') { go('splash'); return true; } return false; });
  I.onGlobal(function (code) { if (code === C.keys.addBot && S.name === 'join') { addBot(); return true; } return false; });

  return { update: update, render: render, go: go, S: S, join: function (i) { join(i); }, addBot: addBot, launch: launch,
    freshSlots: freshSlots };
})();

/* real-time slow-motion: consumed by the app each tick */
Object.defineProperty(BT.Game.prototype, 'timeScaleNow', {
  get: function () {
    if (this.slowT > 0) { this.slowT -= 1 / 60; return this.slowScale || 0.3; }
    return 1;
  }
});

