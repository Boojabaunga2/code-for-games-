
/* js/game.js */
/* game.js - one match of BITRON. Owns the rules:
   damage, scoring, elimination -> ghost transformation, final survivor, win conditions. */
var BT = window.BT = window.BT || {};

BT.Game = function (joined, bots, attract) {
  var C = BT.CONFIG;
  this.attract = !!attract;
  this.players = [null, null, null, null, null, null];
  for (var i = 0; i < 6; i++) if (joined[i]) this.players[i] = new BT.Player(i, bots[i]);
  this.grid = new BT.Grid(C.arena.x - 40, C.arena.y - 40, C.arena.w + 80, C.arena.h + 80, 64);
  this.time = 0; this.wave = 0; this.timeScale = 1; this.slowT = 0;
  this.finalMode = false; this.finalIntro = 0; this.finalTimer = C.final.timer;
  this.over = null; this.endT = 0; this.topPlayer = null;
  this.banners = []; this.pending = []; this.puT = 6; this.cacheT = 10;
  this.darken = 0;
  BT.Arena.reset(); BT.Enemies.clear(); BT.Ghosts.clear(); BT.Projectiles.clear(); BT.Powerups.clear(); BT.FX.clear(); BT.Waves.reset();
  this.placePlayers();
};

var GP = BT.Game.prototype;

GP.placePlayers = function () {
  var c = BT.Arena.center, n = 0;
  for (var i = 0; i < 6; i++) {
    var p = this.players[i]; if (!p) continue;
    // ring around the reactor, clear of the long walls, everyone facing outward toward the gates
    var a = -Math.PI / 3 + i * Math.PI / 3;
    p.x = c.x + Math.cos(a) * 330; p.y = c.y + Math.sin(a) * 200; p.face = a; n++;
    BT.Arena.collide(p, p.r);
  }
};

/* ---------- queries ---------- */
GP.joinedCount = function () { var n = 0; for (var i = 0; i < 6; i++) if (this.players[i]) n++; return n; };
GP.livingCount = function () { var n = 0; for (var i = 0; i < 6; i++) if (this.players[i] && this.players[i].alive) n++; return n; };
GP.ghostCount = function () { var n = 0; for (var i = 0; i < 6; i++) if (this.players[i] && this.players[i].ghost) n++; return n; };
GP.machineCount = function () { return BT.Enemies.count(); };
GP.mult = function () { return BT.Waves.mult(); };
GP.randomLivingPlayer = function () {
  var l = []; for (var i = 0; i < 6; i++) if (this.players[i] && this.players[i].alive) l.push(this.players[i]);
  return l.length ? BT.U.pick(l) : null;
};
GP.nearestBit = function (x, y, maxD) {
  var near = this.grid.query(x, y, maxD), best = null, bd = maxD * maxD;
  for (var i = 0; i < near.length; i++) { var b = near[i]; if (!b.isBit || !b.alive) continue; var d = BT.U.dist2(x, y, b.x, b.y); if (d < bd) { bd = d; best = b; } }
  return best;
};

/* ---------- presentation helpers ---------- */
GP.banner = function (lines, color, dur, big) { this.banners.push({ lines: lines, color: color || '#fff', t: 0, dur: dur || 1.6, big: !!big }); };
GP.later = function (sec, fn) { this.pending.push({ t: sec, fn: fn }); };
GP.slowmo = function (sec, scale) { this.slowT = Math.max(this.slowT, sec); this.slowScale = scale || 0.3; };

/* ---------- scoring ---------- */
GP.addScore = function (p, n, x, y, quiet) {
  if (!p || this.attract) { if (p) p.score += n; return; }
  p.score += n;
  if (!quiet && n >= 100 && x !== undefined) BT.FX.text(x, y - 20, '+' + BT.U.fmt(n), p.color, n >= 1000 ? 26 : 18, 0.8);
};

/* ---------- damage ---------- */
GP.hitEnemy = function (e, dmg, owner, vx, vy, byBit) {
  if (!e.alive || (e.spawnT > 0 && !byBit)) return;
  e.hp -= dmg; e.flash = 0.06;
  if (vx !== undefined && e.type !== 'boss' && e.type !== 'tank') { var l = Math.sqrt(vx * vx + vy * vy) || 1; e.x += vx / l * 4; e.y += vy / l * 4; }
  BT.FX.spark(e.x, e.y, '#ffe0a0', BT.U.rand(-150, 150), BT.U.rand(-150, 150), 0.15, 3);
  if (e.hp > 0) return;
  e.alive = false;
  var C = BT.CONFIG, val = C.scoring.robot[e.type] || 100, big = e.r > 30;
  var scale = e.type === 'boss' ? 3 : (big ? 1.6 : (e.type === 'swarmer' ? 0.5 : 1));
  BT.FX.explode(e.x, e.y, '#ff3a20', big ? 40 : 18, scale);
  BT.FX.shake(e.type === 'boss' ? 24 : (big ? 9 : 3));
  BT.Audio.play('robotExplode');
  var p = owner >= 0 ? this.players[owner] : null;
  if (p) {
    p.stats.robots++;
    this.addScore(p, val, e.x, e.y);
    if (p.ghost) BT.Ghosts.addBits(p, e.type === 'boss' ? 6 : (big ? 2 : 1), e.x, e.y);
  }
  if (e.type === 'boss') { this.slowmo(0.8, 0.25); BT.FX.flash('#ffffff', 0.25, 0.3); this.banner(['BOSS UNIT DESTROYED'], p ? p.color : '#fff', 1.6); }
  var nf = e.type === 'boss' ? 12 : (big ? 3 : (Math.random() < C.waves.fragmentChance ? 1 : 0));
  if (nf) BT.Powerups.fragment(e.x, e.y, nf);
  if (Math.random() < (big ? 0.35 : C.waves.powerupChance)) BT.Powerups.dropRandom(this, e.x, e.y);
};

GP.hitBit = function (b, owner, dmg) {
  if (!b.alive || (b.birth > 0 && dmg < 9)) return;
  b.hp -= dmg; if (b.hp > 0) return;
  var ghost = this.players[b.owner];
  BT.Ghosts.kill(b);
  BT.FX.pop(b.x, b.y, ghost ? ghost.color : '#fff');
  BT.Audio.play('bitPop');
  var p = owner >= 0 ? this.players[owner] : null;
  if (p) { p.stats.bits++; this.addScore(p, BT.CONFIG.scoring.bitKill, b.x, b.y, true); if (Math.random() < 0.12) BT.Powerups.fragment(b.x, b.y, 1); }
};

GP.hurtPlayer = function (p, amount, src, vx, vy) {
  if (!p.alive || p.invuln > 0 || this.over) return;
  if (p.pw.shield > 0) { BT.FX.ring(p.x, p.y, '#5af', 50, 0.2); return; }
  p.hearts -= amount; p.invuln = BT.CONFIG.player.invuln; p.hurtFlash = 0.12;
  if (vx !== undefined) { var l = Math.sqrt(vx * vx + vy * vy) || 1, k = BT.CONFIG.player.knockback; p.kx = vx / l * k; p.ky = vy / l * k; }
  BT.FX.burst(p.x, p.y, p.color, 14, 300, 0.4, 3); BT.FX.shake(7); BT.Audio.play('playerHit');
  this.repulse(p.x, p.y, BT.CONFIG.player.repulse);
  if (p.hearts <= 0.02) this.killPlayer(p, src);
};

// shove machines away from a freshly-hit survivor so one mistake isn't a chain of hits
GP.repulse = function (x, y, r) {
  var es = BT.Enemies.items;
  for (var i = 0; i < es.length; i++) {
    var e = es[i]; if (!e.alive || e.type === 'boss') continue;
    var dx = e.x - x, dy = e.y - y, d2 = dx * dx + dy * dy;
    if (d2 < r * r) { var d = Math.sqrt(d2) || 1; e.x += dx / d * (r - d) * 0.8; e.y += dy / d * (r - d) * 0.8; e.vx = dx / d * 300; e.vy = dy / d * 300; BT.Arena.collide(e, e.r * 0.8); }
  }
  BT.FX.ring(x, y, '#ffffff', r, 0.25);
};

GP.biteplayer = function (p, b) {
  if (!p.alive || p.invuln > 0 || this.over) return;
  var G = BT.CONFIG.ghost, ghost = this.players[b.owner];
  var before = Math.ceil(p.hearts - 0.001);
  p.hearts -= G.biteDamage; p.hurtFlash = 0.08;
  BT.FX.burst(b.x, b.y, ghost.color, 6, 180, 0.25, 3);
  BT.Audio.play('playerHit');
  ghost.stats.heartsDealt += G.biteDamage;
  if (p.hearts <= 0.02) { this.killPlayer(p, b.owner); return; }
  if (Math.ceil(p.hearts - 0.001) < before) {
    // a whole heart chewed away
    p.invuln = 1.0;
    this.addScore(ghost, BT.CONFIG.scoring.ghostHeart, p.x, p.y);
    BT.Ghosts.addBits(ghost, 2, p.x, p.y);
    BT.FX.shake(6);
  }
};

GP.bomb = function (x, y, owner, r) {
  BT.Audio.play('bomb'); BT.FX.shake(18); BT.FX.flash('#ffffff', 0.18, 0.2);
  var p = this.players[owner], col = p ? p.color : '#fff';
  BT.FX.ring(x, y, col, r, 0.45); BT.FX.ring(x, y, '#ffffff', r * 0.7, 0.35);
  BT.FX.burst(x, y, col, 60, 700, 0.6, 4);
  var es = BT.Enemies.items, i;
  for (i = 0; i < es.length; i++) { var e = es[i]; if (e.alive && BT.U.dist2(x, y, e.x, e.y) < r * r) this.hitEnemy(e, e.type === 'boss' ? 40 : 30, owner, e.x - x, e.y - y, true); }
  var bs = BT.Ghosts.items;
  for (i = 0; i < bs.length; i++) { var b = bs[i]; if (b.alive && BT.U.dist2(x, y, b.x, b.y) < r * r) this.hitBit(b, owner, 9); }
};

GP.bitBomb = function (x, y, owner) {
  var p = this.players[owner];
  BT.Audio.play('bomb'); BT.FX.shake(12);
  BT.FX.ring(x, y, '#ffffff', 340, 0.4); BT.FX.ring(x, y, p.color, 600, 0.6);
  var bs = BT.Ghosts.items;
  for (var i = 0; i < bs.length; i++) {
    var b = bs[i]; if (!b.alive) continue;
    var d2 = BT.U.dist2(x, y, b.x, b.y);
    if (d2 < 340 * 340) this.hitBit(b, owner, 9);
    else if (d2 < 650 * 650) { var d = Math.sqrt(d2); b.vx = (b.x - x) / d * 700; b.vy = (b.y - y) / d * 700; b.stun = 0.6; }
  }
};

GP.hazard = function (v) {
  var cx = v.x + v.w / 2, cy = v.y + v.h / 2, i;
  for (i = 0; i < 6; i++) {
    var p = this.players[i];
    if (p && p.alive && Math.abs(p.x - cx) < v.w / 2 + 6 && Math.abs(p.y - cy) < v.h / 2 + 6) this.hurtPlayer(p, 1, -1, p.x - cx, p.y - cy);
  }
  var bs = BT.Ghosts.items;
  for (i = 0; i < bs.length; i++) { var b = bs[i]; if (b.alive && Math.abs(b.x - cx) < v.w / 2 && Math.abs(b.y - cy) < v.h / 2) this.hitBit(b, -1, 9); }
};

GP.waveCleared = function (n) {
  for (var i = 0; i < 6; i++) { var p = this.players[i]; if (p && p.alive) this.addScore(p, BT.CONFIG.scoring.waveSurvive, p.x, p.y); }
  this.banner(['WAVE ' + n + ' CLEAR'], '#ffffff', 1.6);
};

/* ---------- elimination -> ghost ---------- */
GP.killPlayer = function (p, killer) {
  if (!p.alive) return;
  var self = this;
  p.alive = false; p.hearts = 0; p.deathTime = this.time;
  BT.FX.explode(p.x, p.y, p.color, 60, 2.2); BT.FX.burst(p.x, p.y, '#ffffff', 30, 600, 0.5, 4);
  BT.FX.shake(22); BT.FX.flash(p.color, 0.14, 0.25);
  BT.Audio.play('playerDeath');
  this.slowmo(1.1, 0.22);
  var k = killer >= 0 ? this.players[killer] : null;
  if (k && k !== p) { k.stats.elims++; this.addScore(k, BT.CONFIG.scoring.ghostElim, p.x, p.y); }
  var living = this.livingCount(), joined = this.joinedCount();
  if (joined === 1) { this.banner([p.name + ' HAS BEEN ELIMINATED'], p.color, 2); this.finish('gameover'); return; }
  this.banner([p.name + ' HAS BEEN ELIMINATED', k && k !== p ? 'EATEN BY ' + k.name + "'S BITS" : 'THE MACHINE GOT YOU'], p.color, 1.4, true);
  this.banner(['YOU ARE NOW THE GHOST', 'COMMAND AN ARMY OF BITS'], p.color, 1.6, true);
  if (living === 0) { this.finish('ghosts'); return; }
  var px = p.x, py = p.y;
  this.later(0.9, function () { self.becomeGhost(p, px, py); });
  if (living === 1 && !this.finalMode) this.later(0.4, function () { self.startFinal(); });
};

GP.becomeGhost = function (p, x, y) {
  if (this.over) return;
  p.ghost = true;
  p.pw = { rapid: 0, spread: 0, laser: 0, speed: 0, shield: 0, magnet: 0 };
  BT.Ghosts.makeCommander(p, x, y);
  var start = BT.CONFIG.ghost.startBits;
  if (this.finalMode) { p.gc.maxBits = BT.CONFIG.ghost.finalMaxBits; start += BT.CONFIG.ghost.finalBonusBits; p.gc.energy = BT.CONFIG.ghost.energyMax; }
  BT.Ghosts.addBits(p, start, x, y, 1.2);
  BT.Audio.play('ghostTransform');
  // GHOST BURST: the rising ghost shoves nearby survivors away so the new army can form
  for (var i = 0; i < 6; i++) {
    var q = this.players[i]; if (!q || !q.alive) continue;
    var dx = q.x - x, dy = q.y - y, d = Math.sqrt(dx * dx + dy * dy) || 1;
    if (d < 260) { q.kx = dx / d * 900; q.ky = dy / d * 900; }
  }
  BT.FX.shake(14);
  BT.FX.ring(x, y, p.color, 220, 0.6); BT.FX.burst(x, y, p.color, 50, 500, 0.7, 4);
};

GP.startFinal = function () {
  if (this.over || this.finalMode || this.livingCount() !== 1) return;
  var G = BT.CONFIG.ghost, self = this;
  this.finalMode = true; this.finalIntro = 2.6; this.finalTimer = BT.CONFIG.final.timer;
  BT.Audio.musicCut(2.2); BT.Audio.play('finalAlarm');
  BT.FX.flash('#ff0010', 0.22, 0.5); BT.FX.shake(16);
  var surv = this.randomLivingPlayer(), F = BT.CONFIG.final;
  // LAST STAND: the survivor gets a fighting chance before five swarms arrive
  surv.hearts = Math.max(surv.hearts, BT.CONFIG.player.hearts);
  surv.pw.shield = this.finalIntro + F.lastStandShield; surv.pw.rapid = this.finalIntro + F.lastStandRapid;
  surv.bombs = Math.min(5, surv.bombs + 1); surv.invuln = 0;
  this.banners.length = 0;
  this.banner(['FINAL SURVIVOR', 'ONE PLAYER REMAINS'], surv.color, 1.5, true);
  this.banner(['SURVIVE THE UPRISING', 'LAST STAND: FULL HEARTS + SHIELD + BOMB'], '#ff2030', 1.3, true);
  for (var i = 0; i < 6; i++) {
    var p = this.players[i];
    if (p && p.ghost && p.gc) { p.gc.maxBits = G.finalMaxBits; BT.Ghosts.addBits(p, G.finalBonusBits); p.gc.energy = G.energyMax; }
  }
};

GP.finish = function (kind) {
  if (this.over) return;
  this.over = kind; this.endT = 2.4;
  var best = null;
  for (var i = 0; i < 6; i++) { var p = this.players[i]; if (p && (!best || p.score > best.score)) best = p; }
  this.topPlayer = best;
  if (kind === 'survivor') {
    var s = this.randomLivingPlayer();
    if (s) { this.addScore(s, BT.CONFIG.scoring.survivorWin, s.x, s.y); this.survivor = s; }
    this.banner(['SURVIVOR WINS!'], s ? s.color : '#fff', 2.4, true);
    BT.Audio.play('victory');
    // recompute top after bonus
    best = null; for (i = 0; i < 6; i++) { p = this.players[i]; if (p && (!best || p.score > best.score)) best = p; } this.topPlayer = best;
  } else if (kind === 'ghosts') {
    this.banner(['GHOST UPRISING WINS!'], '#ff2030', 2.4, true);
    BT.Audio.play('gameOver');
  } else {
    BT.Audio.play('gameOver');
  }
};

/* ---------- simulation ---------- */
GP.step = function (dt, ctls) {
  var i, p;
  this.time += dt;
  for (i = this.pending.length - 1; i >= 0; i--) { var pe = this.pending[i]; pe.t -= dt; if (pe.t <= 0) { this.pending.splice(i, 1); pe.fn(); } }
  if (this.banners.length) { var bn = this.banners[0]; bn.t += dt; if (bn.t >= bn.dur * (this.banners.length > 2 ? 0.6 : 1)) this.banners.shift(); }

  // players & commanders
  this.rebuildGrid();
  for (i = 0; i < 6; i++) {
    p = this.players[i]; if (!p) continue;
    if (p.alive) p.update(dt, ctls[i], this);
    else if (p.ghost && p.gc) { BT.Ghosts.updateCommander(p, ctls[i], dt, this); for (var k in p.pw) if (p.pw[k] > 0) p.pw[k] -= dt; }
  }
  if (!this.over) BT.Waves.update(dt, this);
  BT.Enemies.update(dt, this);
  this.rebuildGrid();
  this.separateEnemies();
  BT.Ghosts.update(dt, this);
  this.rebuildGrid();
  BT.Projectiles.update(dt, this);
  this.enemyContacts();
  BT.Powerups.update(dt, this);
  BT.Arena.update(dt, this);
  BT.FX.update(dt);

  // floor pickups on a timer
  this.puT -= dt;
  if (this.puT <= 0) { this.puT = BT.U.rand(7, 11); this.dropAtRandom(false); }
  if (this.ghostCount() > 0) { this.cacheT -= dt; if (this.cacheT <= 0) { this.cacheT = BT.U.rand(9, 14); this.dropAtRandom(true); } }

  // final survivor clock
  if (this.finalMode && !this.over) {
    if (this.finalIntro > 0) { this.finalIntro -= dt; }
    else {
      var before = Math.ceil(this.finalTimer);
      this.finalTimer -= dt;
      if (Math.ceil(this.finalTimer) !== before && this.finalTimer <= 10) BT.Audio.play('tick');
      if (this.finalTimer <= 0) { this.finalTimer = 0; this.finish('survivor'); }
    }
  }
  if (this.over) this.endT -= dt;
  this.darken += ((this.finalMode ? 0.45 : 0) - this.darken) * Math.min(1, dt * 2);
  // music: one layer per ghost
  BT.Audio.musicLevel(Math.min(4, this.ghostCount()), this.finalMode && this.finalIntro <= 0);
};

GP.dropAtRandom = function (cache) {
  var A = BT.CONFIG.arena;
  for (var t = 0; t < 12; t++) {
    var x = BT.U.rand(A.x + 80, A.x + A.w - 80), y = BT.U.rand(A.y + 80, A.y + A.h - 80);
    if (BT.Arena.isFree(x, y, 30)) {
      if (cache) BT.Powerups.spawn('bitcache', x, y); else BT.Powerups.dropRandom(this, x, y);
      return;
    }
  }
};

GP.rebuildGrid = function () {
  var g = this.grid, i; g.clear();
  var es = BT.Enemies.items; for (i = 0; i < es.length; i++) if (es[i].alive) g.insert(es[i]);
  var bs = BT.Ghosts.items; for (i = 0; i < bs.length; i++) if (bs[i].alive) g.insert(bs[i]);
};

GP.separateEnemies = function () {
  var es = BT.Enemies.items;
  for (var i = 0; i < es.length; i++) {
    var e = es[i]; if (!e.alive) continue;
    var near = this.grid.query(e.x, e.y, e.r * 2);
    for (var j = 0; j < near.length; j++) {
      var o = near[j]; if (o === e || o.isBit || !o.alive) continue;
      var dx = e.x - o.x, dy = e.y - o.y, rr = (e.r + o.r) * 0.85, d2 = dx * dx + dy * dy;
      if (d2 < rr * rr && d2 > 0.01) { var d = Math.sqrt(d2), f = (rr - d) * 0.3 * (o.r / (e.r + o.r)) * 2; e.x += dx / d * f; e.y += dy / d * f; }
    }
  }
};

GP.enemyContacts = function () {
  var es = BT.Enemies.items;
  for (var k = 0; k < 6; k++) {
    var p = this.players[k]; if (!p || !p.alive) continue;
    for (var i = 0; i < es.length; i++) {
      var e = es[i]; if (!e.alive || e.spawnT > 0) continue;
      var rr = p.r + e.r * 0.8;
      if (BT.U.dist2(p.x, p.y, e.x, e.y) < rr * rr) {
        if (p.pw.shield > 0) { this.hitEnemy(e, 3, p.idx, e.x - p.x, e.y - p.y); continue; }
        this.hurtPlayer(p, 1, -1, p.x - e.x, p.y - e.y);
      }
    }
  }
};

/* ---------- drawing (world only; HUD is in ui.js) ---------- */
GP.draw = function (g, t) {
  BT.Arena.drawFloor(g);
  BT.Arena.drawLive(g, t, this);
  BT.Powerups.draw(g, t);
  BT.Enemies.draw(g, t);
  BT.Ghosts.draw(g, t, this.players);
  for (var i = 0; i < 6; i++) if (this.players[i]) this.players[i].draw(g, t);
  BT.Projectiles.draw(g);
  BT.FX.draw(g);
};

