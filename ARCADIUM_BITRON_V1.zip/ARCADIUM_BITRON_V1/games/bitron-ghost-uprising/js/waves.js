
/* js/waves.js */
/* waves.js - continuous machine spawning with escalating waves.
   (Ghost players are the real difficulty escalator - waves just keep the pressure on.) */
var BT = window.BT = window.BT || {};

BT.Waves = (function () {
  var U = BT.U, W = BT.CONFIG.waves;
  var UNLOCK = { grunt: 1, swarmer: 1, rusher: 2, shooter: 3, tank: 4, spawner: 4, hunter: 5, elite: 6 };
  var WEIGHT = { grunt: 10, swarmer: 4, rusher: 6, shooter: 5, tank: 2, spawner: 1.2, hunter: 3, elite: 1 };
  var COST = { grunt: 1, swarmer: 3, rusher: 1, shooter: 2, tank: 4, spawner: 4, hunter: 2, elite: 7 };

  var st = { n: 0, queue: [], spawnT: 0, breakT: 0, banner: 0 };

  function compose(n, nPlayers) {
    var budget = (W.base + W.perWave * (n - 1)) * (0.6 + 0.1 * nPlayers);
    var q = [], pool = [], tot = 0, k;
    for (k in UNLOCK) if (n >= UNLOCK[k]) { pool.push(k); tot += WEIGHT[k]; }
    if (n % W.bossEvery === 0) { q.push('boss'); budget -= 10; }
    var guard = 0;
    while (budget > 0 && guard++ < 400) {
      var r = Math.random() * tot, pick = pool[0];
      for (var i = 0; i < pool.length; i++) { r -= WEIGHT[pool[i]]; if (r <= 0) { pick = pool[i]; break; } }
      q.push(pick);
      budget -= COST[pick];
    }
    // shuffle, keep the boss near the middle so it arrives mid-wave
    for (var j = q.length - 1; j > 0; j--) { var x = Math.floor(Math.random() * (j + 1)); var t = q[j]; q[j] = q[x]; q[x] = t; }
    return q;
  }

  function start(game, n) {
    st.n = n; game.wave = n;
    st.queue = compose(n, game.joinedCount());
    st.spawnT = 0.6; st.breakT = 0; st.banner = 2.2;
    BT.Audio.play('waveStart');
  }

  function mult(n) {
    return {
      speed: Math.min(W.speedCap, 1 + W.speedPerWave * (n - 1)),
      hp: 1 + 0.07 * (n - 1),
      bossHp: 0.7 + 0.15 * (n / W.bossEvery)
    };
  }

  function update(dt, game) {
    if (st.banner > 0) st.banner -= dt;
    if (st.breakT > 0) {
      st.breakT -= dt;
      if (st.breakT <= 0) start(game, st.n + 1);
      return;
    }
    var alive = game.machineCount();
    if (st.queue.length === 0 && alive === 0) {
      // wave survived
      game.waveCleared(st.n);
      st.breakT = W.breakSeconds;
      return;
    }
    st.spawnT -= dt;
    var minAlive = Math.min(W.maxAlive, W.minAliveBase + W.minAlivePerWave * (st.n - 1) + 2 * game.livingCount());
    if (st.spawnT <= 0 && st.queue.length && alive < W.maxAlive) {
      st.spawnT = alive < minAlive ? 0.12 : Math.max(0.14, 0.7 - 0.05 * st.n) * U.rand(0.6, 1.3) * (game.finalMode ? 0.7 : 1);
      var gates = BT.Arena.gates, gt = U.pick(gates), burst = U.randi(1, Math.min(4, 1 + Math.floor(st.n / 2)));
      // never spawn right on top of a survivor
      for (var tries = 0; tries < 4; tries++) {
        var close = false;
        for (var i = 0; i < game.players.length; i++) { var p = game.players[i]; if (p && p.alive && U.dist2(p.x, p.y, gt.x, gt.y) < 200 * 200) close = true; }
        if (!close) break; gt = U.pick(gates);
      }
      gt.flash = 0.6;
      var m = mult(st.n);
      for (var b = 0; b < burst && st.queue.length; b++) {
        var type = st.queue.shift();
        if (type === 'swarmer') { for (var z = 0; z < 6; z++) BT.Enemies.spawn('swarmer', gt.x + gt.dir[0] * 40 + U.rand(-30, 30), gt.y + gt.dir[1] * 40 + U.rand(-30, 30), m); }
        else BT.Enemies.spawn(type, gt.x + gt.dir[0] * 50 + U.rand(-20, 20), gt.y + gt.dir[1] * 50 + U.rand(-20, 20), m);
        if (type === 'boss') { BT.FX.shake(14); BT.FX.text(gt.x + gt.dir[0] * 140, gt.y + gt.dir[1] * 140, 'BOSS UNIT!', '#ff2030', 40, 1.8); }
      }
    }
  }

  return {
    start: start, update: update, mult: function () { return mult(Math.max(1, st.n)); },
    remaining: function (game) { return st.queue.length + game.machineCount(); },
    get banner() { return st.banner; }, get n() { return st.n; }, get onBreak() { return st.breakT > 0; },
    reset: function () { st.n = 0; st.queue = []; st.spawnT = 0; st.breakT = 0; st.banner = 0; }
  };
})();

