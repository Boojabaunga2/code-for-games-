
/* js/bits.js */
/* bits.js - GHOST COMMANDERS and their BIT ARMIES.
   A dead player steers a commander cursor; the army flocks around it.
     dirs   move the commander (bits follow like a school of fish)
     5      hold = ATTACK: bits dive on the nearest prey (survivor OR machine) near the commander
     ENTER  cycle special command
     0      fire special command (costs ghost energy)
   Bits phase through machinery. Pooled for 300+ simultaneous bits. */
var BT = window.BT = window.BT || {};

BT.Ghosts = (function () {
  var U = BT.U, G = BT.CONFIG.ghost;
  var CMDS = ['SWARM', 'SPLIT', 'CHARGE', 'RECALL', 'SCATTER'];
  var pool = new BT.Pool(6 * 56, function () { return { owner: 0, x: 0, y: 0, vx: 0, vy: 0, r: G.bitRadius, hp: 1, biteCD: 0, stun: 0, ph: 0, slot: 0, grp: 0, isBit: true, birth: 0 }; });
  var counts = [0, 0, 0, 0, 0, 0];
  var GOLD = 2.39996;

  function makeCommander(p, x, y) {
    p.gc = { x: x, y: y, vx: 0, vy: 0, fx: 0, fy: -1, energy: 50, cmd: 0, active: null, activeT: 0, target: null,
      passiveT: G.passiveBitEvery, respawnT: 0, appearT: 1.6, slotN: 0, attack: false, maxBits: G.maxBits, pulse: 0 };
  }

  function addBits(p, n, x, y, protect) {
    if (!p.gc) return 0;
    var made = 0;
    for (var i = 0; i < n; i++) {
      if (counts[p.idx] >= p.gc.maxBits) break;
      var b = pool.spawn(); if (!b) break;
      b.owner = p.idx; b.hp = G.bitHp; b.r = G.bitRadius; b.biteCD = 0.3; b.stun = 0;
      var a = Math.random() * 6.283, s = U.rand(60, 260);
      b.x = (x !== undefined ? x : p.gc.x) + Math.cos(a) * 6; b.y = (y !== undefined ? y : p.gc.y) + Math.sin(a) * 6;
      b.vx = Math.cos(a) * s; b.vy = Math.sin(a) * s; b.ph = Math.random() * 6.283; b.slot = p.gc.slotN++; b.grp = b.slot & 1; b.birth = protect || 0.25; b.birthMax = b.birth;
      counts[p.idx]++; made++;
    }
    if (counts[p.idx] > p.stats.maxArmy) p.stats.maxArmy = counts[p.idx];
    return made;
  }

  function nearestLiving(game, x, y, maxD) {
    var best = null, bd = maxD ? maxD * maxD : 1e12;
    for (var i = 0; i < game.players.length; i++) { var q = game.players[i]; if (!q || !q.alive) continue; var d = U.dist2(x, y, q.x, q.y); if (d < bd) { bd = d; best = q; } }
    return best;
  }
  function nearestPrey(game, x, y, maxD) {
    var best = nearestLiving(game, x, y, maxD), bd = best ? U.dist2(x, y, best.x, best.y) : maxD * maxD;
    var es = BT.Enemies.items;
    for (var i = 0; i < es.length; i++) { var e = es[i]; if (!e.alive) continue; var d = U.dist2(x, y, e.x, e.y); if (d < bd) { bd = d; best = e; } }
    return best;
  }

  function updateCommander(p, ctl, dt, game) {
    var c = p.gc;
    if (c.appearT > 0) c.appearT -= dt;
    c.pulse += dt;
    // movement
    var dx = ctl.dx, dy = ctl.dy;
    if (dx || dy) { var l = Math.sqrt(dx * dx + dy * dy); dx /= l; dy /= l; c.fx = dx; c.fy = dy; }
    var t = Math.min(1, dt * 14);
    c.vx += (dx * G.cursorSpeed - c.vx) * t; c.vy += (dy * G.cursorSpeed - c.vy) * t;
    c.x += c.vx * dt; c.y += c.vy * dt;
    var A = BT.CONFIG.arena;
    c.x = U.clamp(c.x, A.x + 10, A.x + A.w - 10); c.y = U.clamp(c.y, A.y + 10, A.y + A.h - 10);
    c.energy = Math.min(G.energyMax, c.energy + G.energyRegen * dt);
    c.attack = ctl.fire;
    if (ctl.pFire) BT.Audio.play('bitSwarm');
    // command select / execute
    if (ctl.pStart) { c.cmd = (c.cmd + 1) % CMDS.length; BT.Audio.play('tick'); }
    if (ctl.pSpecial) {
      var name = CMDS[c.cmd], cost = G.costs[name];
      if (c.energy >= cost && counts[p.idx] > 0) {
        c.energy -= cost; c.active = name; c.activeT = G.durations[name];
        c.target = nearestLiving(game, c.x, c.y);
        BT.Audio.play('command');
        BT.FX.text(c.x, c.y - 50, name + '!', p.color, 26, 0.9);
        BT.FX.ring(c.x, c.y, p.color, 120, 0.35);
        if (name === 'CHARGE') {
          var tg = c.target, ax = c.fx, ay = c.fy;
          launchCharge(p, tg, ax, ay);
        }
      } else BT.FX.text(c.x, c.y - 50, 'LOW ENERGY', '#888', 18, 0.6);
    }
    if (c.active) { c.activeT -= dt; if (c.activeT <= 0) c.active = null; if (c.target && !c.target.alive) c.target = nearestLiving(game, c.x, c.y); }
    // growth / respawn
    if (counts[p.idx] === 0) {
      if (c.respawnT <= 0) c.respawnT = G.respawnDelay;
      c.respawnT -= dt;
      if (c.respawnT <= 0) { addBits(p, G.respawnBits); BT.FX.ring(c.x, c.y, p.color, 90, 0.4); BT.Audio.play('ghostTransform'); }
    } else {
      c.respawnT = 0;
      c.passiveT -= dt;
      if (c.passiveT <= 0) { c.passiveT = G.passiveBitEvery; addBits(p, 1); }
      p.score += counts[p.idx] * BT.CONFIG.scoring.armyPerBitPerSec * dt;
    }
  }

  function launchCharge(p, tg, ax, ay) {
    var it = pool.items;
    for (var i = 0; i < it.length; i++) {
      var b = it[i]; if (!b.alive || b.owner !== p.idx) continue;
      var dx = ax, dy = ay;
      if (tg) { dx = tg.x - b.x; dy = tg.y - b.y; var l = Math.sqrt(dx * dx + dy * dy) || 1; dx /= l; dy /= l; }
      b.vx = dx * 780 + U.rand(-60, 60); b.vy = dy * 780 + U.rand(-60, 60);
    }
  }

  function update(dt, game) {
    var players = game.players, it = pool.items, i, b, p, c;
    // per-ghost frame data
    var prey = [null, null, null, null, null, null];
    for (i = 0; i < 6; i++) {
      p = players[i]; if (!p || !p.ghost || !p.gc) continue;
      c = p.gc;
      if (c.attack) prey[i] = nearestPrey(game, c.x, c.y, G.attackRange);
    }
    for (i = 0; i < it.length; i++) {
      b = it[i]; if (!b.alive) continue;
      p = players[b.owner];
      if (!p || !p.gc) { b.alive = false; continue; }
      c = p.gc;
      if (b.biteCD > 0) b.biteCD -= dt;
      if (b.birth > 0) b.birth -= dt;
      b.ph += dt;
      if (b.stun > 0) { b.stun -= dt; b.x += b.vx * dt; b.y += b.vy * dt; b.vx *= 0.9; b.vy *= 0.9; clampBit(b); continue; }

      var n = Math.max(1, counts[b.owner]);
      var spd = G.bitSpeed * (p.pw && p.pw.speed > 0 ? 1.35 : 1), gx, gy, tight = false;
      var ang = b.slot * GOLD + c.pulse * 0.8, rad = 18 + Math.sqrt((b.slot % n) + 1) * 11;
      var act = c.active;
      if (act === 'CHARGE') {
        b.x += b.vx * dt; b.y += b.vy * dt; clampBit(b); continue;
      } else if (act === 'SWARM' && c.target && c.target.alive) {
        gx = c.target.x + Math.cos(ang) * 14; gy = c.target.y + Math.sin(ang) * 14; spd = G.bitAttackSpeed * 1.25;
      } else if (act === 'SPLIT' && c.target && c.target.alive) {
        var tx = c.target.x - c.x, ty = c.target.y - c.y, tl = Math.sqrt(tx * tx + ty * ty) || 1;
        var px = -ty / tl, py = tx / tl, k = Math.max(0, c.activeT - 1.2) / 2.8 * 170, sgn = b.grp ? 1 : -1;
        gx = c.target.x + px * sgn * k + Math.cos(ang) * 10; gy = c.target.y + py * sgn * k + Math.sin(ang) * 10; spd = G.bitAttackSpeed * 1.15;
      } else if (act === 'RECALL') {
        gx = c.x + Math.cos(ang) * 14; gy = c.y + Math.sin(ang) * 14; spd = G.bitSpeed * 2.6; tight = true;
      } else if (act === 'SCATTER') {
        var sa = b.slot * GOLD; gx = c.x + Math.cos(sa) * 300; gy = c.y + Math.sin(sa) * 300; spd = G.bitAttackSpeed * 1.2;
      } else if (c.attack) {
        var pr = prey[b.owner];
        if (pr && pr.alive) { gx = pr.x + Math.cos(ang) * 10; gy = pr.y + Math.sin(ang) * 10; spd = G.bitAttackSpeed; }
        else { gx = c.x + c.fx * 90 + Math.cos(ang) * rad * 0.5; gy = c.y + c.fy * 90 + Math.sin(ang) * rad * 0.5; spd = G.bitAttackSpeed; }
      } else {
        gx = c.x + Math.cos(ang) * rad; gy = c.y + Math.sin(ang) * rad;
      }
      var dx = gx - b.x, dy = gy - b.y, d = Math.sqrt(dx * dx + dy * dy) || 1;
      var arrive = tight ? 1 : Math.min(1, d / 40);
      var wob = 0.35;
      var dvx = dx / d * spd * arrive + Math.cos(b.ph * 7 + b.slot) * spd * wob;
      var dvy = dy / d * spd * arrive + Math.sin(b.ph * 6 + b.slot * 1.3) * spd * wob;
      var k2 = Math.min(1, dt * 7);
      b.vx += (dvx - b.vx) * k2; b.vy += (dvy - b.vy) * k2;
      b.x += b.vx * dt; b.y += b.vy * dt;
      clampBit(b);
    }
    // separation within an army (cheap, grid based)
    for (i = 0; i < it.length; i++) {
      b = it[i]; if (!b.alive) continue;
      var near = game.grid.query(b.x, b.y, 16);
      for (var j = 0; j < near.length; j++) {
        var o = near[j]; if (o === b || !o.isBit || !o.alive) continue;
        var ox = b.x - o.x, oy = b.y - o.y, od = ox * ox + oy * oy;
        if (od < 196 && od > 0.01) { var f = (14 - Math.sqrt(od)) * 0.25; od = Math.sqrt(od); b.x += ox / od * f; b.y += oy / od * f; }
      }
    }
    contacts(dt, game);
  }

  function clampBit(b) {
    var A = BT.CONFIG.arena;
    if (b.x < A.x + 6) { b.x = A.x + 6; b.vx = Math.abs(b.vx); }
    if (b.x > A.x + A.w - 6) { b.x = A.x + A.w - 6; b.vx = -Math.abs(b.vx); }
    if (b.y < A.y + 6) { b.y = A.y + 6; b.vy = Math.abs(b.vy); }
    if (b.y > A.y + A.h - 6) { b.y = A.y + A.h - 6; b.vy = -Math.abs(b.vy); }
  }

  function contacts(dt, game) {
    var it = pool.items, players = game.players;
    for (var i = 0; i < it.length; i++) {
      var b = it[i]; if (!b.alive || b.birth > 0) continue;
      // bite survivors
      for (var k = 0; k < players.length; k++) {
        var p = players[k]; if (!p || !p.alive) continue;
        var rr = b.r + p.r;
        if (U.dist2(b.x, b.y, p.x, p.y) > rr * rr) continue;
        if (p.pw.shield > 0) {
          // shields repel bits rather than deleting whole armies
          var sx = b.x - p.x, sy = b.y - p.y, sl = Math.sqrt(sx * sx + sy * sy) || 1;
          b.x = p.x + sx / sl * (rr + 14); b.y = p.y + sy / sl * (rr + 14);
          b.vx = sx / sl * 420; b.vy = sy / sl * 420; b.stun = 0.35;
          break;
        }
        if (b.biteCD <= 0) {
          b.biteCD = G.biteCooldown;
          game.biteplayer(p, b);
          var ax = b.x - p.x, ay = b.y - p.y, al = Math.sqrt(ax * ax + ay * ay) || 1;
          b.vx = ax / al * 300; b.vy = ay / al * 300; b.stun = 0.18;
        }
        break;
      }
      if (!b.alive) continue;
      // fight machines
      var near = game.grid.query(b.x, b.y, 70);
      for (var j = 0; j < near.length; j++) {
        var e = near[j]; if (e.isBit || !e.alive) continue;
        var r2 = b.r + e.r;
        if (U.dist2(b.x, b.y, e.x, e.y) > r2 * r2) continue;
        if (b.biteCD <= 0 && e.spawnT <= 0) { b.biteCD = 0.4; game.hitEnemy(e, G.bitBiteRobot, b.owner, b.vx, b.vy, true); }
        if (e.alive && e.crushCD <= 0) {
          var heavy = e.type === 'tank' || e.type === 'boss' || e.type === 'elite';
          e.crushCD = heavy ? 0.5 : 1.4;
          game.hitBit(b, -1, heavy ? 2 : 1);
        }
        break;
      }
    }
  }

  function kill(b) {
    if (!b.alive) return;
    b.alive = false; counts[b.owner] = Math.max(0, counts[b.owner] - 1);
  }
  function killAllOf(idx) { var it = pool.items; for (var i = 0; i < it.length; i++) if (it[i].alive && it[i].owner === idx) kill(it[i]); }
  function recount() { counts = [0, 0, 0, 0, 0, 0]; var it = pool.items; for (var i = 0; i < it.length; i++) if (it[i].alive) counts[it[i].owner]++; }

  function draw(g, t, players) {
    var it = pool.items;
    for (var i = 0; i < it.length; i++) {
      var b = it[i]; if (!b.alive) continue;
      var s = BT.Assets.spr['bit' + b.owner]; if (!s) continue;
      var sc = b.birth > 0 ? 1 - Math.min(1, b.birth / 0.25) * 0.6 : 1;
      if (b.birth > 0.25) { g.globalAlpha = 0.5 + 0.5 * Math.sin(b.ph * 30); }
      var bob = Math.sin(b.ph * 14) * 1.5;
      var img = b.vx < 0 ? s.cf : s.c;
      if (sc === 1) g.drawImage(img, (b.x - s.w / 2) | 0, (b.y + bob - s.h / 2) | 0);
      else g.drawImage(img, b.x - s.w * sc / 2, b.y + bob - s.h * sc / 2, s.w * sc, s.h * sc);
      g.globalAlpha = 1;
    }
    // commanders
    for (var k = 0; k < players.length; k++) {
      var p = players[k]; if (!p || !p.ghost || !p.gc) continue;
      var c = p.gc;
      if (c.appearT > 0) {
        var f = c.appearT / 1.6;
        BT.Assets.draw(g, 'ghostbig' + k, c.x, c.y - 20 - (1 - f) * 30, false, false, Math.min(1, f * 1.6) * 0.75);
      }
      var a = 0.55 + 0.15 * Math.sin(c.pulse * 4);
      BT.Assets.draw(g, 'ghost' + k, c.x, c.y + Math.sin(c.pulse * 3) * 4, false, false, a);
      g.font = '15px RussoOne, Impact, sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle';
      g.lineWidth = 3; g.strokeStyle = '#000';
      var label = p.name + ' GHOST';
      g.strokeText(label, c.x, c.y - 52); g.fillStyle = p.color; g.fillText(label, c.x, c.y - 52);
      // energy arc
      g.strokeStyle = U.hexA(p.color, 0.25); g.lineWidth = 4;
      g.beginPath(); g.arc(c.x, c.y, 46, 0, 6.283); g.stroke();
      g.strokeStyle = p.color;
      g.beginPath(); g.arc(c.x, c.y, 46, -Math.PI / 2, -Math.PI / 2 + 6.283 * c.energy / G.energyMax); g.stroke();
      var cmd = CMDS[c.cmd], ok = c.energy >= G.costs[cmd];
      g.font = '13px ChakraPetch, sans-serif';
      g.strokeText('[B] ' + cmd, c.x, c.y + 60); g.fillStyle = ok ? '#fff' : '#777'; g.fillText('[B] ' + cmd, c.x, c.y + 60);
      if (counts[k] === 0 && c.respawnT > 0) {
        g.font = '16px RussoOne, sans-serif'; g.fillStyle = p.color;
        g.fillText('REBOOTING ' + Math.ceil(c.respawnT), c.x, c.y + 80);
      }
      if (c.attack) {
        g.strokeStyle = U.hexA(p.color, 0.16); g.lineWidth = 2; g.setLineDash([4, 14]);
        g.beginPath(); g.arc(c.x, c.y, G.attackRange, 0, 6.283); g.stroke(); g.setLineDash([]);
      }
    }
  }

  return {
    CMDS: CMDS, makeCommander: makeCommander, addBits: addBits, updateCommander: updateCommander, update: update,
    draw: draw, kill: kill, killAllOf: killAllOf, recount: recount, items: pool.items,
    count: function (i) { return counts[i]; }, total: function () { return counts.reduce(function (a, b) { return a + b; }, 0); },
    clear: function () { pool.clear(); counts = [0, 0, 0, 0, 0, 0]; }
  };
})();

