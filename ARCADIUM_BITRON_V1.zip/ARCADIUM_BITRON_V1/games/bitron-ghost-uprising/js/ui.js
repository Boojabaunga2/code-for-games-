
/* js/ui.js */
/* ui.js - HUD and every full-screen panel, styled after the BITRON reference sheets */
var BT = window.BT = window.BT || {};

BT.UI = (function () {
  var C = BT.CONFIG, U = BT.U, A = C.arena;
  var RED = '#ff1a2e', COL = C.players.colors;

  function F(size, body) { return (body ? '700 ' : '') + size + 'px ' + (body ? 'ChakraPetch, Arial Narrow, sans-serif' : 'RussoOne, Impact, sans-serif'); }
  function txt(g, s, x, y, size, color, align, body, glow) {
    g.font = F(size, body); g.textAlign = align || 'center'; g.textBaseline = 'middle';
    if (glow) { g.shadowColor = glow; g.shadowBlur = size * 0.45; }
    g.lineWidth = Math.max(3, size * 0.12); g.strokeStyle = '#000'; g.strokeText(s, x, y);
    g.fillStyle = color || '#fff'; g.fillText(s, x, y);
    g.shadowBlur = 0;
  }
  // chamfered neon panel like the reference
  function panel(g, x, y, w, h, color, fill, cut) {
    cut = cut === undefined ? 14 : cut;
    g.beginPath();
    g.moveTo(x + cut, y); g.lineTo(x + w - cut, y); g.lineTo(x + w, y + cut); g.lineTo(x + w, y + h - cut);
    g.lineTo(x + w - cut, y + h); g.lineTo(x + cut, y + h); g.lineTo(x, y + h - cut); g.lineTo(x, y + cut); g.closePath();
    g.fillStyle = fill || 'rgba(6,4,8,0.92)'; g.fill();
    g.shadowColor = color; g.shadowBlur = 14; g.strokeStyle = color; g.lineWidth = 3; g.stroke(); g.shadowBlur = 0;
    g.strokeStyle = U.hexA('#ffffff', 0.08); g.lineWidth = 1; g.stroke();
  }
  // static panels are baked once: shadowBlur is far too slow to redo every frame
  var pcache = {};
  function cpanel(g, x, y, w, h, color, fill, cut) {
    var key = w + 'x' + h + color + fill + cut, c = pcache[key];
    if (!c) {
      c = BT.Assets.canvas(w + 40, h + 40);
      panel(c.getContext('2d'), 20, 20, w, h, color, fill, cut);
      pcache[key] = c;
    }
    g.drawImage(c, x - 20, y - 20);
  }
  function bg(g, t, dark) {
    g.fillStyle = '#020203'; g.fillRect(0, 0, C.W, C.H);
    var rg = g.createRadialGradient(C.W / 2, C.H * 0.45, 80, C.W / 2, C.H * 0.45, 1100);
    rg.addColorStop(0, 'rgba(120,0,12,' + (dark ? 0.35 : 0.55) + ')'); rg.addColorStop(1, 'rgba(0,0,0,0)');
    g.fillStyle = rg; g.fillRect(0, 0, C.W, C.H);
    g.strokeStyle = 'rgba(255,30,45,0.07)'; g.lineWidth = 1;
    for (var x = 0; x < C.W; x += 48) { g.beginPath(); g.moveTo(x + 0.5, 0); g.lineTo(x + 0.5, C.H); g.stroke(); }
    for (var y = 0; y < C.H; y += 48) { g.beginPath(); g.moveTo(0, y + 0.5); g.lineTo(C.W, y + 0.5); g.stroke(); }
  }
  function frame(g) {
    g.strokeStyle = RED; g.lineWidth = 4; g.shadowColor = RED; g.shadowBlur = 20;
    g.strokeRect(10, 10, C.W - 20, C.H - 20); g.shadowBlur = 0;
  }
  function logo(g, cx, cy, w) {
    var im = BT.Assets.img.logo; if (!im) { txt(g, 'BITRON', cx, cy, 120, '#eee', 'center', false, RED); return; }
    var h = w * im.height / im.width; g.drawImage(im, cx - w / 2, cy - h / 2, w, h);
  }
  function arcadium(g, cx, cy, w) {
    var im = BT.Assets.img.arcadium; if (!im) return;
    var h = w * im.height / im.width; g.drawImage(im, cx - w / 2, cy - h / 2, w, h);
  }
  function heart(g, x, y, s, fill, color) {
    g.save(); g.translate(x, y); g.scale(s / 20, s / 20);
    g.beginPath(); g.moveTo(0, 7); g.bezierCurveTo(-14, -3, -9, -15, 0, -7); g.bezierCurveTo(9, -15, 14, -3, 0, 7); g.closePath();
    g.fillStyle = 'rgba(255,255,255,0.12)'; g.fill();
    if (fill > 0) {
      g.save(); g.clip(); g.fillStyle = color; g.fillRect(-12, 9 - 22 * fill, 24, 22 * fill); g.restore();
    }
    g.strokeStyle = color; g.lineWidth = 1.6; g.stroke();
    g.restore();
  }

  /* ---------------- HUD ---------------- */
  // HUD is redrawn into a cache at 20 Hz and blitted every frame (text strokes are costly)
  var hudC = null, hudN = 0, hudGame = null;
  function hud(g, game, t) {
    if (!hudC) hudC = BT.Assets.canvas(C.W, C.H);
    if (hudN++ % 3 === 0 || hudGame !== game) {
      hudGame = game;
      var hg = hudC.getContext('2d');
      hg.clearRect(0, 0, C.W, A.y); hg.clearRect(0, A.y + A.h, C.W, C.H - A.y - A.h);
      hudDraw(hg, game, t);
    }
    g.drawImage(hudC, 0, 0, C.W, A.y, 0, 0, C.W, A.y);
    g.drawImage(hudC, 0, A.y + A.h, C.W, C.H - A.y - A.h, 0, A.y + A.h, C.W, C.H - A.y - A.h);
  }
  function hudDraw(g, game, t) {
    var w = 306, gap = 8, x0 = 24;
    for (var i = 0; i < 6; i++) {
      var x = x0 + i * (w + gap), y = 8, h = 88, p = game.players[i], col = COL[i];
      if (!p) {
        cpanel(g, x, y, w, h, '#2a2a30', 'rgba(5,5,7,0.85)', 10);
        txt(g, C.players.names[i], x + 34, y + 30, 30, '#3a3a44', 'center');
        txt(g, 'EMPTY', x + w / 2 + 30, y + 46, 22, '#33333a', 'center', true);
        continue;
      }
      var hot = p.alive && p.hurtFlash > 0;
      cpanel(g, x, y, w, h, col, hot ? U.hexA(col, 0.35) : 'rgba(5,4,8,0.9)', 10);
      BT.Assets.draw(g, p.ghost ? 'ghosthud' + i : 'player' + i, x + 32, y + 46, false, false, 1);
      if (p.alive) {
        txt(g, p.name, x + 78, y + 26, 30, col, 'left', false);
        txt(g, U.fmt(p.score), x + w - 14, y + 26, 28, '#fff', 'right', true);
        var full = p.hearts;
        for (var hI = 0; hI < Math.max(3, Math.ceil(full)); hI++) heart(g, x + 92 + hI * 30, y + 62, 24, U.clamp(full - hI, 0, 1), col);
        // bombs + active powerups
        var ix = x + w - 22;
        for (var bI = 0; bI < p.bombs; bI++) { BT.Assets.draw(g, 'pu_bomb', ix, y + 62); ix -= 26; if (bI > 2) break; }
        var pws = ['rapid', 'spread', 'laser', 'speed', 'shield', 'magnet'];
        for (var k = 0; k < pws.length; k++) if (p.pw[pws[k]] > 0) {
          g.globalAlpha = p.pw[pws[k]] < 2 && Math.floor(t * 8) % 2 ? 0.3 : 1;
          g.save(); g.translate(ix, y + 62); g.scale(0.7, 0.7); BT.Powerups.drawIcon(g, pws[k], 0, 0, t); g.restore();
          g.globalAlpha = 1; ix -= 28;
        }
      } else if (p.ghost) {
        var n = BT.Ghosts.count(i), cmd = BT.Ghosts.CMDS[p.gc.cmd], ok = p.gc.energy >= C.ghost.costs[cmd];
        txt(g, p.name + ' \u2014 GHOST', x + 66, y + 22, 22, col, 'left', false);
        txt(g, cmd, x + w - 14, y + 22, 16, ok ? '#fff' : '#666', 'right', true);
        txt(g, U.fmt(p.score), x + 66, y + 50, 24, '#fff', 'left', true);
        txt(g, 'BITS \u00d7 ' + n, x + w - 14, y + 50, 22, n ? col : '#ff5060', 'right', true);
        g.fillStyle = '#18181e'; g.fillRect(x + 66, y + 70, w - 82, 7);
        g.fillStyle = col; g.fillRect(x + 66, y + 70, (w - 82) * p.gc.energy / C.ghost.energyMax, 7);
      } else {
        txt(g, p.name, x + 78, y + 26, 30, col, 'left');
        txt(g, 'ELIMINATED', x + 78, y + 60, 22, '#ff4050', 'left', true);
      }
    }
    // bottom strip
    var by = A.y + A.h + 4;
    cpanel(g, 30, by + 2, 210, 32, RED, 'rgba(10,0,2,0.95)', 8);
    txt(g, 'WAVE  ' + Math.max(1, game.wave), 135, by + 18, 22, '#fff');
    cpanel(g, C.W / 2 - 190, by + 2, 380, 32, RED, 'rgba(10,0,2,0.95)', 8);
    txt(g, 'ROBOTS REMAINING', C.W / 2 - 40, by + 18, 18, '#ddd', 'center', true);
    txt(g, String(BT.Waves.remaining(game)), C.W / 2 + 140, by + 18, 22, RED);
    var gc = game.ghostCount();
    if (gc) txt(g, 'GHOSTS ' + gc + '   BITS ' + BT.Ghosts.total(), 520, by + 18, 18, '#cfcfe0', 'center', true);
    arcadium(g, C.W - 140, by + 18, 190);
  }

  var vignette = null;
  function arenaOverlays(g, game, t) {
    // darken + red pulse during final survivor
    if (game.darken > 0.01) {
      g.fillStyle = 'rgba(0,0,0,' + game.darken * 0.55 + ')'; g.fillRect(A.x, A.y, A.w, A.h);
      var pulse = 0.25 + 0.25 * Math.sin(t * 6);
      if (!vignette) {
        vignette = BT.Assets.canvas(A.w / 4, A.h / 4);
        var vgc = vignette.getContext('2d'), vg = vgc.createRadialGradient(A.w / 8, A.h / 8, 75, A.w / 8, A.h / 8, 280);
        vg.addColorStop(0, 'rgba(255,0,20,0)'); vg.addColorStop(1, 'rgba(255,0,20,1)');
        vgc.fillStyle = vg; vgc.fillRect(0, 0, A.w / 4, A.h / 4);
      }
      g.globalAlpha = Math.min(1, pulse * game.darken * 1.6); g.drawImage(vignette, A.x, A.y, A.w, A.h); g.globalAlpha = 1;
      // re-draw living survivor on top so they never get lost
      for (var i = 0; i < 6; i++) { var p = game.players[i]; if (p && p.alive) { g.strokeStyle = p.color; g.lineWidth = 3; g.beginPath(); g.arc(p.x, p.y, 34 + 4 * Math.sin(t * 10), 0, 6.283); g.stroke(); p.draw(g, t); } }
    }
    if (game.finalMode && !game.over && game.finalIntro <= 0) {
      var s = Math.ceil(game.finalTimer), urgent = game.finalTimer <= 10;
      panel(g, C.W / 2 - 170, A.y + 10, 340, 70, urgent ? '#ffffff' : RED, 'rgba(20,0,4,0.82)', 12);
      txt(g, 'FINAL SURVIVOR', C.W / 2, A.y + 28, 18, '#ffb0b8', 'center', true);
      txt(g, '0:' + U.pad(s, 2), C.W / 2, A.y + 58, urgent ? 40 + 4 * Math.sin(t * 20) : 36, urgent ? '#ffffff' : RED, 'center', false, RED);
    }
    var wb = BT.Waves.banner;
    if (wb > 0 && !game.finalMode) {
      g.globalAlpha = Math.min(1, wb * 2);
      txt(g, 'WAVE ' + BT.Waves.n, C.W / 2, A.y + 150, 78, '#ffffff', 'center', false, RED);
      g.globalAlpha = 1;
    }
    banners(g, game, t);
  }

  function banners(g, game, t) {
    var b = game.banners[0]; if (!b) return;
    var k = b.t / b.dur, a = Math.min(1, b.t * 6, (b.dur - b.t) * 5);
    if (a <= 0) return;
    var cy = C.H / 2, h = b.big ? 190 : 120;
    g.globalAlpha = a * 0.8; g.fillStyle = '#000'; g.fillRect(A.x, cy - h / 2, A.w, h);
    g.globalAlpha = a;
    g.fillStyle = b.color; g.fillRect(A.x, cy - h / 2, A.w, 3); g.fillRect(A.x, cy + h / 2 - 3, A.w, 3);
    var sc = 1 + Math.max(0, 0.25 - b.t) * 1.2;
    g.save(); g.translate(C.W / 2, cy); g.scale(sc, sc);
    if (b.lines.length === 1) txt(g, b.lines[0], 0, 0, b.big ? 84 : 60, b.color, 'center', false, b.color);
    else { txt(g, b.lines[0], 0, -32, b.big ? 66 : 50, b.color, 'center', false, b.color); txt(g, b.lines[1], 0, 42, 34, '#ffffff', 'center', true); }
    g.restore(); g.globalAlpha = 1;
  }

  /* ---------------- screens ---------------- */
  function splash(g, t) {
    bg(g, t);
    logo(g, C.W / 2, 300, 1150);
    BT.Assets.draw(g, 'red_skull_big', C.W / 2, 650, false, false, 0.55);
    for (var i = 0; i < 6; i++) BT.Assets.draw(g, 'card' + i, C.W / 2 - 650 + i * 260, 700 + Math.sin(t * 3 + i) * 8);
    // bit swarm decoration
    for (var b = 0; b < 40; b++) { var a = t * 0.6 + b * 0.7; BT.Assets.draw(g, 'bit' + (b % 6), C.W / 2 + Math.cos(a) * (820 + (b % 5) * 22), 690 + Math.sin(a * 1.3) * 120, b % 2, false, 0.6); }
    txt(g, '6 PLAYERS.  ONE ARENA.  SURVIVE THE MACHINE.', C.W / 2, 900, 40, '#ffffff', 'center', true);
    txt(g, 'DEATH MAKES IT HARDER.', C.W / 2, 950, 40, RED, 'center', true, RED);
    if (Math.floor(t * 2) % 2 === 0) txt(g, 'PRESS START', C.W / 2, 1020, 34, '#ffd21a', 'center', false, '#ff8000');
    frame(g);
  }

  function join(g, slots, t, lobbyT, minOk) {
    bg(g, t);
    logo(g, C.W / 2, 96, 440);
    txt(g, 'PLAYER SELECT', C.W / 2, 240, 58, '#ffffff', 'center', false, RED);
    var w = 270, h = 560, gap = 22, x0 = (C.W - (6 * w + 5 * gap)) / 2, y = 290;
    for (var i = 0; i < 6; i++) {
      var x = x0 + i * (w + gap), col = COL[i], on = slots[i].joined;
      panel(g, x, y, w, h, on ? col : U.hexA(col, 0.45), on ? U.hexA(col, 0.12) : 'rgba(5,5,8,0.9)', 18);
      txt(g, C.players.names[i], x + w / 2, y + 52, 64, col, 'center', false, col);
      g.globalAlpha = on ? 1 : 0.45;
      BT.Assets.draw(g, 'card' + i, x + w / 2, y + 240 + (on ? Math.sin(t * 5 + i) * 6 : 0));
      g.globalAlpha = 1;
      if (on) {
        txt(g, 'READY', x + w / 2, y + 430, 54, '#ffffff', 'center', false, col);
        txt(g, slots[i].bot ? 'CPU' : C.players.colorNames[i], x + w / 2, y + 490, 26, col, 'center', true);
      } else {
        txt(g, 'PRESS', x + w / 2, y + 410, 30, '#ddd', 'center', true);
        txt(g, 'START', x + w / 2, y + 446, 30, '#ddd', 'center', true);
        g.strokeStyle = '#fff'; g.lineWidth = 3; g.strokeRect(x + w / 2 - 30, y + 478, 60, 60);
        txt(g, 'A', x + w / 2, y + 508, 15, '#fff', 'center', true);
      }
    }
    var msg;
    if (lobbyT !== null && minOk) msg = 'LAUNCHING IN ' + Math.ceil(lobbyT) + '   \u2022   ANY READY PLAYER PRESS B TO LAUNCH NOW';
    else msg = 'PRESS A / START ON YOUR MINI VIBE TO JOIN   \u2022   2\u20136 PLAYERS';
    txt(g, msg, C.W / 2, 905, 30, '#ffffff', 'center', true);
    txt(g, 'PC: ADD CPU BUTTON   \u2022   ESC = BACK', C.W / 2, 950, 22, '#888', 'center', true);
    arcadium(g, C.W / 2, 1015, 300);
    frame(g);
  }

  function keypad(g, x, y, s, hi) {
    var keys = [['7', '8', '9'], ['4', '5', '6'], ['1', '2', '3']], arrows = { '7': '\u2196', '8': '\u2191', '9': '\u2197', '4': '\u2190', '6': '\u2192', '1': '\u2199', '2': '\u2193', '3': '\u2198', '5': '5' };
    for (var r = 0; r < 3; r++) for (var c = 0; c < 3; c++) {
      var k = keys[r][c], kx = x + c * (s + 6), ky = y + r * (s + 6), isFire = k === '5';
      g.fillStyle = isFire ? 'rgba(255,30,45,0.35)' : 'rgba(255,255,255,0.06)'; g.fillRect(kx, ky, s, s);
      g.strokeStyle = isFire ? RED : '#cfd8ff'; g.lineWidth = 2; g.strokeRect(kx, ky, s, s);
      txt(g, arrows[k], kx + s / 2, ky + s / 2 + 2, isFire ? s * 0.5 : s * 0.55, isFire ? '#fff' : '#cfd8ff', 'center', true);
    }
    var zy = y + 3 * (s + 6);
    g.fillStyle = 'rgba(255,210,26,0.25)'; g.fillRect(x, zy, s * 2 + 6, s); g.strokeStyle = '#ffd21a'; g.strokeRect(x, zy, s * 2 + 6, s);
    txt(g, '0', x + s + 3, zy + s / 2 + 2, s * 0.5, '#fff', 'center', true);
    var ex = x + 3 * (s + 6), ey = y + 2 * (s + 6);
    g.fillStyle = 'rgba(80,200,255,0.2)'; g.fillRect(ex, ey, s * 0.8, s * 2 + 6); g.strokeStyle = '#5ad'; g.lineWidth = 2; g.strokeRect(ex, ey, s * 0.8, s * 2 + 6);
    g.save(); g.translate(ex + s * 0.4, ey + s + 3); g.rotate(-Math.PI / 2); txt(g, 'ENTER', 0, 0, 16, '#5ad', 'center', true); g.restore();
  }

  function howto(g, t, remaining) {
    bg(g, t, true);
    txt(g, 'HOW TO PLAY', C.W / 2, 70, 64, '#ffffff', 'center', false, RED);
    // living
    panel(g, 60, 130, 880, 800, RED);
    txt(g, 'ALIVE: SURVIVE THE MACHINE', 500, 175, 36, RED, 'center');
    keypad(g, 110, 230, 74, false);
    txt(g, 'MOVE', 440, 250, 34, '#fff', 'left'); txt(g, '8 directions on the 10-key', 440, 290, 24, '#bbb', 'left', true);
    txt(g, '5  FIRE', 440, 350, 34, RED, 'left'); txt(g, 'hold to auto-fire, shots lean onto targets', 440, 390, 24, '#bbb', 'left', true);
    txt(g, '0  BOMB', 440, 450, 34, '#ffd21a', 'left'); txt(g, 'clears everything around you', 440, 490, 24, '#bbb', 'left', true);
    var rows = [['en_grunt', 'DESTROY ROBOTS', 'every machine is points'], ['pu_score', 'COLLECT POWER UPS', 'weapons, shields, hearts, bombs'], ['pu_heart', 'STAY ALIVE', '3 hearts, each bit bite takes a quarter'], ['red_skull', 'DIE...', 'and come back as a GHOST']];
    for (var i = 0; i < rows.length; i++) {
      var y = 610 + i * 78;
      g.save(); g.translate(150, y); var sc = rows[i][0] === 'red_skull' ? 0.55 : 1; g.scale(sc, sc); BT.Assets.draw(g, rows[i][0], 0, 0); g.restore();
      txt(g, rows[i][1], 220, y - 14, 30, i === 3 ? RED : '#fff', 'left'); txt(g, rows[i][2], 220, y + 20, 22, '#aaa', 'left', true);
    }
    // ghost
    panel(g, 980, 130, 880, 800, '#b84dff');
    txt(g, 'DEAD: COMMAND THE BITS', 1420, 175, 36, '#d48cff', 'center');
    BT.Assets.draw(g, 'ghostbig4', 1150, 360, false, false, 0.85);
    for (var b = 0; b < 18; b++) { var a = b * 0.8 + t * 1.5; BT.Assets.draw(g, 'bit4', 1150 + Math.cos(a) * (120 + (b % 3) * 18), 380 + Math.sin(a) * (80 + (b % 3) * 12), Math.cos(a) < 0); }
    var gl = [['D-PAD', 'steer your swarm'], ['A', 'hold: bits attack whatever is near'], ['L / R', 'pick a command'], ['B', 'launch it (uses energy)']];
    for (i = 0; i < gl.length; i++) { txt(g, gl[i][0], 1340, 250 + i * 62, 30, '#ffd21a', 'left'); txt(g, gl[i][1], 1470, 250 + i * 62, 24, '#ddd', 'left', true); }
    var cm = [['SWARM', 'all bits hunt the nearest survivor'], ['SPLIT', 'two groups flank and surround'], ['CHARGE', 'the whole army launches forward'], ['RECALL', 'regroup on your skull'], ['SCATTER', 'spread out to dodge bombs']];
    for (i = 0; i < cm.length; i++) { txt(g, cm[i][0], 1030, 560 + i * 48, 28, '#d48cff', 'left'); txt(g, cm[i][1], 1220, 560 + i * 48, 24, '#ddd', 'left', true); }
    txt(g, 'Grow the army: eat robots, grab BIT fragments, bite survivors.', 1420, 820, 22, '#fff', 'center', true);
    txt(g, 'Machines fight everybody. Bits can farm them or hunt players.', 1420, 856, 22, '#fff', 'center', true);
    txt(g, 'THE MORE PLAYERS THAT DIE, THE HARDER IT GETS!', C.W / 2, 980, 34, RED, 'center', false, RED);
    if (remaining !== undefined) txt(g, 'PRESS 5 TO SKIP  ' + Math.ceil(remaining), C.W / 2, 1035, 22, '#888', 'center', true);
    frame(g);
  }

  function countdown(g, n, f) {
    var s = n > 0 ? String(n) : 'SURVIVE!';
    var sc = 1 + (1 - f) * 0.6;
    g.save(); g.translate(C.W / 2, C.H / 2); g.scale(sc, sc); g.globalAlpha = Math.min(1, f * 2);
    txt(g, s, 0, 0, n > 0 ? 220 : 150, n > 0 ? '#ffffff' : RED, 'center', false, RED);
    g.restore(); g.globalAlpha = 1;
  }

  function verdictText(game) {
    if (game.over === 'survivor') return { t: 'SURVIVOR VICTORY', c: game.survivor ? game.survivor.color : '#fff' };
    if (game.over === 'ghosts') return { t: 'GHOST UPRISING WINS', c: RED };
    return { t: 'GAME OVER', c: RED };
  }

  function results(g, game, t) {
    bg(g, t);
    var v = verdictText(game);
    txt(g, 'SCOREBOARD', C.W / 2, 64, 60, '#ffffff', 'center', false, RED);
    txt(g, v.t, C.W / 2, 132, 46, v.c, 'center', false, v.c);
    var rows = [];
    for (var i = 0; i < 6; i++) if (game.players[i]) rows.push(game.players[i]);
    rows.sort(function (a, b) { return b.score - a.score; });
    var cols = [['RANK', 120], ['PLAYER', 250], ['SCORE', 470], ['STATUS', 660], ['ROBOTS', 850], ['BITS', 1010], ['ELIMS', 1160], ['MAX ARMY', 1310], ['SURVIVAL', 1460]];
    var x0 = 70, y0 = 190;
    panel(g, x0, y0, C.W - 140, 110 + rows.length * 92, RED);
    for (var c = 0; c < cols.length; c++) txt(g, cols[c][0], x0 + cols[c][1], y0 + 40, 24, '#ffb0b8', 'center', true);
    for (var r = 0; r < rows.length; r++) {
      var p = rows[r], y = y0 + 110 + r * 92, top = r === 0;
      if (top) { g.fillStyle = U.hexA(p.color, 0.18 + 0.08 * Math.sin(t * 5)); g.fillRect(x0 + 8, y - 40, C.W - 156, 80); g.strokeStyle = p.color; g.lineWidth = 2; g.strokeRect(x0 + 8, y - 40, C.W - 156, 80); }
      var status = p.alive ? 'ALIVE' : (p.ghost ? 'GHOST' : 'FALLEN');
      var vals = [String(r + 1), p.name, U.fmt(p.score), status, String(p.stats.robots), String(p.stats.bits), String(p.stats.elims), String(p.stats.maxArmy), Math.floor(p.stats.survival / 60) + ':' + U.pad(p.stats.survival % 60, 2)];
      BT.Assets.draw(g, p.ghost ? 'ghosthud' + p.idx : 'player' + p.idx, x0 + 190, y, false, false, 1);
      for (c = 0; c < cols.length; c++) {
        var col = c === 1 ? p.color : (c === 3 ? (p.alive ? '#3dff6a' : '#ff3040') : '#fff');
        txt(g, vals[c], x0 + cols[c][1] + (c === 1 ? 20 : 0), y, c === 2 ? 36 : 30, col, 'center', c !== 1 && c !== 2);
      }
      if (top) txt(g, '\u2605 TOP', x0 + C.W - 230, y, 26, p.color, 'center');
    }
    var tp = game.topPlayer;
    if (tp) txt(g, 'TOP PLAYER:  ' + tp.name + ' \u2014 ' + U.fmt(tp.score), C.W / 2, 880, 40, tp.color, 'center', false, tp.color);
    txt(g, 'GHOSTS STILL PLAY. THEY JUST PLAY DIFFERENT.', C.W / 2, 940, 24, '#aaa', 'center', true);
    if (Math.floor(t * 2) % 2 === 0) txt(g, 'PRESS START TO PLAY AGAIN', C.W / 2, 1010, 32, '#ffd21a', 'center', false, '#ff8000');
    frame(g);
  }

  function victory(g, game, t) {
    bg(g, t);
    var s = game.survivor || game.topPlayer;
    txt(g, 'VICTORY', C.W / 2, 140, 130, '#ffd21a', 'center', false, '#ff8000');
    for (var k = 0; k < 8; k++) {
      var a = k * 0.785 + t; BT.Assets.draw(g, k % 2 ? 'fx_boom_y' : 'fx_boom_b', C.W / 2 + Math.cos(a) * 330, 520 + Math.sin(a) * 200, false, false, 0.5 + 0.5 * Math.sin(t * 6 + k));
    }
    if (s) {
      g.save(); g.translate(C.W / 2, 520); var sc = 1.35 + Math.sin(t * 4) * 0.05; g.scale(sc, sc); BT.Assets.draw(g, 'card' + s.idx, 0, 0); g.restore();
      txt(g, 'LAST PLAYER STANDING!', C.W / 2, 800, 64, '#ffffff', 'center', false, s.color);
      txt(g, s.name + ' SURVIVED THE UPRISING', C.W / 2, 870, 36, s.color, 'center', true);
    }
    var tp = game.topPlayer;
    if (tp) txt(g, 'TOP PLAYER:  ' + tp.name + ' \u2014 ' + U.fmt(tp.score), C.W / 2, 950, 34, tp.color, 'center', false);
    arcadium(g, C.W / 2, 1025, 300);
    frame(g);
  }

  function gameover(g, game, t) {
    bg(g, t);
    BT.Assets.draw(g, 'red_skull_big', C.W / 2, 330 + Math.sin(t * 2) * 6);
    for (var b = 0; b < 60; b++) { var a = b * 0.37 + t * 0.3, r = 420 + (b % 7) * 30; BT.Assets.draw(g, 'bit' + (b % 6), C.W / 2 + Math.cos(a) * r, 360 + Math.sin(a) * r * 0.45, Math.cos(a) < 0, false, 0.55); }
    txt(g, 'GAME OVER', C.W / 2, 640, 120, '#ffffff', 'center', false, RED);
    var v = verdictText(game);
    if (game.over === 'ghosts') txt(g, v.t, C.W / 2, 740, 54, RED, 'center', false, RED);
    txt(g, 'YOU DIED...  BUT THE BITS LIVE ON.', C.W / 2, 820, 34, '#ffffff', 'center', true);
    var tp = game.topPlayer;
    if (tp) txt(g, 'TOP PLAYER:  ' + tp.name + ' \u2014 ' + U.fmt(tp.score), C.W / 2, 910, 40, tp.color, 'center', false, tp.color);
    arcadium(g, C.W / 2, 1015, 300);
    frame(g);
  }

  var ATTRACT_MSGS = [['6 PLAYERS.', 'ONE ARENA.'], ['SURVIVE THE MACHINE.'], ['WHEN YOU DIE...'], ['YOU KEEP PLAYING.'], ['COMMAND AN ARMY OF BITS.'], ['DEATH MAKES IT HARDER.'], ['BITRON:', 'GHOST UPRISING'], ['PRESS START']];
  function attract(g, t) {
    g.fillStyle = 'rgba(0,0,0,0.35)'; g.fillRect(0, 0, C.W, C.H);
    var i = Math.floor(t / 2.2) % ATTRACT_MSGS.length, f = (t % 2.2) / 2.2, m = ATTRACT_MSGS[i];
    var a = Math.min(1, f * 6, (1 - f) * 6);
    g.globalAlpha = a;
    g.fillStyle = 'rgba(0,0,0,0.7)'; g.fillRect(0, C.H / 2 - 120, C.W, 240);
    if (m.length === 1) txt(g, m[0], C.W / 2, C.H / 2, 96, i === 7 ? '#ffd21a' : '#ffffff', 'center', false, RED);
    else { txt(g, m[0], C.W / 2, C.H / 2 - 50, 84, '#ffffff', 'center', false, RED); txt(g, m[1], C.W / 2, C.H / 2 + 50, 84, RED, 'center', false, RED); }
    g.globalAlpha = 1;
    if (Math.floor(t * 2) % 2 === 0) txt(g, 'PRESS START', C.W / 2, A.y + 60, 40, '#ffd21a', 'center', false, '#ff8000');
  }

  return { _hudDraw: function (g, game, t) { hudDraw(g, game, t); }, hud: hud, arenaOverlays: arenaOverlays, splash: splash, join: join, howto: howto, countdown: countdown,
    results: results, victory: victory, gameover: gameover, attract: attract, txt: txt, panel: panel };
})();

