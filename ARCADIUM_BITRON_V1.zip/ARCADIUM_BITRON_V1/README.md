# Bitron: Ghost Uprising — six personal Mini Vibes

Extract the whole ZIP, double-click **START_INSTALL.cmd**, select your existing **Arcadium_OS_COMPACT**, then restart Windows once. Launch Bitron from its carousel card. Keep the existing universal Mini Vibe app and pairing. **No new APK. No GoDice.** Existing Python/Tk and the Shared Mini Vibe Controls PC platform are required. Setup downloads no software and changes no Windows security settings.

## Play

A / START joins from the title and lobby. B launches the lobby, or use the PC LAUNCH MATCH button. A skips the instructions. One player can practice solo; the full game supports six. PC ADD CPU fills an unjoined seat. A physical action or movement can take over a CPU seat outside attract mode.

Hold the D-pad to move continuously, including diagonals. Release stops steering immediately; genuine combat knockback remains. Hold A to shoot with the original facing/aim assist. B deploys a bomb. START pauses/resumes during combat. Movement and firing expire if the controller stops sending fresh state; there is no tap-to-run latch. Touch controls use the same hold/release behavior with heartbeats, and release on cancel/blur. USB gamepads and the original keyboard/numpad fallbacks remain available. Brackets select P1 ghost powers on a PC keyboard.

## Your screen changes when you die

While alive, your Mini Vibe shows a camera following your own robot, hearts, score, active weapon upgrades, bombs and wave. On death it displays signal fracture and then becomes a ghost command console following your own skull and bit army. It shows army size, actual energy, selected power, cost and availability.

- Hold A: send bits to attack nearby survivors or machines.
- L / R shoulders: previous/next power, wrapping through all five.
- B: spend the displayed energy to deploy the selected power.
- X: select and deploy Recall. Y: select and deploy Scatter.
- D-pad: steer your commander and army. START pauses the table.

The original five powers are retained: **Swarm** hunts a survivor, **Split** flanks the target, **Charge** launches the army, **Recall** regroups and **Scatter** spreads out. Energy regenerates; insufficient energy or no bits blocks deployment. Lost armies reboot according to the original rules. The last living player receives the original last-stand assistance and must survive **30 seconds** against the uprising. Mini Vibes display that clock. Scores, wave progression, original enemies, drops, victory/results and replay are retained. Solo death remains solo game-over as in the source.

## Artwork and integration

New Arcadium-branded illustrated carousel/title artwork, a detailed reactor, animated energy rings, illuminated industrial circuits, modern shared-controller instructions and standard red/blue/green/yellow/pink/white seat colors. Original sprites/fonts are extracted into local files; the game needs no external font, asset or AI service during play. The PC draws the world once and reuses it for six personal cameras, rather than simulating six separate matches.

Installer targets only this game's directory, its helper, a wrapper added around the existing recognized game bridge and this game's catalogue entry. It replaces **Bitron's own** carousel image. Home, main server, shared physical input receiver, pairing, other games and their cards are preserved. Automatic backup is created under `arcadium_backups/bitron_v1_*`; rollback in the installer refuses to overwrite later unrelated edits. Repeated installation is supported.

## Validation limits

Automated tests exercise the original shared controller receiver with browser/device-event fixtures, six separate private pages, controller/touch hold and release, all five ghost powers, energy restrictions, survivor/ghost endings, replay and previous-game handoff. Windows launcher and Microsoft Defender archive/extracted-file scans are run before delivery. These checks do not guarantee another machine's antivirus acceptance. Keep Defender enabled and do not allow a blocked file. Real Mini Vibe physical controls, Bluetooth/network conditions, six-device frame latency and venue play balance still need testing on your hardware.
