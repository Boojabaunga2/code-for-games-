from pathlib import Path
import json,tkinter as tk
from tkinter import filedialog
from update_bitron import install,rollback
ui=tk.Tk();ui.title('Arcadium / Bitron: Ghost Uprising');ui.geometry('750x430');status=tk.StringVar(value='Six-player Bitron with personal Mini Vibe combat cameras and ghost army consoles. Uses your existing shared controller app. No new APK. Select your existing Arcadium_OS_COMPACT folder.')
tk.Label(ui,text='BITRON GHOST UPRISING / REAL GODICE. PRIVATE DECISIONS.',font=('Segoe UI',15,'bold')).pack(pady=20);tk.Label(ui,textvariable=status,wraplength=700,justify='left',font=('Segoe UI',12)).pack(padx=20,pady=20)
def run():
 folder=filedialog.askdirectory(title='Select your existing Arcadium_OS_COMPACT folder')
 if not folder:return
 try:
  backup=install(Path(folder));Path(__file__).with_name('BITRON_RECEIPT.json').write_text(json.dumps({'backup':str(backup)},indent=2));status.set('Installed. Backup: '+str(backup)+'\n\nRestart Windows once, then launch Bitron. A / START joins; B launches from the lobby. D-pad moves while held and stops on release. Hold A to fire or attack, B bombs or deploys. Ghosts use shoulders to select powers; X recalls, Y scatters. START pauses/resumes. No APK or GoDice required.\n\nPhysical Mini Vibe and LAN acceptance still needed.')
 except Exception as e:status.set('Stopped: '+str(e))
def undo():
 folder=filedialog.askdirectory(title='Select the bitron_v1_* backup')
 if not folder:return
 try:rollback(Path(folder));status.set('Previous Bitron: Ghost Uprising restored. Restart Windows once.')
 except Exception as e:status.set('Rollback stopped: '+str(e))
tk.Button(ui,text='INSTALL BITRON GHOST UPRISING',command=run,padx=20,pady=12).pack(pady=8);tk.Button(ui,text='Rollback this update',command=undo).pack();ui.mainloop()
