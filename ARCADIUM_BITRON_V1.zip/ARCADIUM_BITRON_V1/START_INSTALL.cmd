@echo off
setlocal EnableExtensions DisableDelayedExpansion
title Arcadium Bitron: Ghost Uprising Setup
cd /d "%~dp0"
if not exist "%~dp0INSTALL_BITRON.py" goto incomplete
if not exist "%~dp0CHECKSUMS.json" goto incomplete
if not exist "%~dp0games\bitron-ghost-uprising\index.html" goto incomplete

echo Arcadium Bitron: Ghost Uprising - Windows setup
echo Finding an existing Python installation with its standard window toolkit...
call :find_python
if defined ARCADIUM_RC_PY_EXE goto launch
if defined ARCADIUM_RC_USE_PY goto launch

echo.
echo STOP: Python with Tkinter was not found. No software will be downloaded.
echo This installer only uses your existing Python installation.
echo Install Python from https://www.python.org/downloads/windows/ if needed.
echo No Arcadium files were changed.
pause
exit /b 1

:launch
echo Opening the Arcadium installer. Select your existing Arcadium_OS_COMPACT folder.
if defined ARCADIUM_RC_USE_PY (
  py -3 "%~dp0INSTALL_BITRON.py"
) else (
  "%ARCADIUM_RC_PY_EXE%" "%~dp0INSTALL_BITRON.py"
)
if errorlevel 1 goto installer_failed
exit /b 0

:find_python
set "ARCADIUM_RC_PY_EXE="
set "ARCADIUM_RC_USE_PY="
for /d %%D in ("%LOCALAPPDATA%\Programs\Python\Python3*") do call :probe "%%~fD\python.exe"
for /d %%D in ("%LOCALAPPDATA%\Python\pythoncore-*") do call :probe "%%~fD\python.exe"
for /d %%D in ("%ProgramFiles%\Python3*") do call :probe "%%~fD\python.exe"
for /d %%D in ("%SystemDrive%\Python3*") do call :probe "%%~fD\python.exe"
for /f "delims=" %%P in ('where python.exe 2^>nul') do call :probe "%%P"
if defined ARCADIUM_RC_PY_EXE exit /b 0
where py.exe >nul 2>&1
if errorlevel 1 exit /b 0
py -3 -c "import sys, tkinter; assert sys.version_info >= (3,9)" >nul 2>&1
if not errorlevel 1 set "ARCADIUM_RC_USE_PY=1"
exit /b 0

:probe
if defined ARCADIUM_RC_PY_EXE exit /b 0
if not exist "%~1" exit /b 0
rem Skip the Windows Store placeholder, which can open a store instead of Python.
if /i "%~1"=="%LOCALAPPDATA%\Microsoft\WindowsApps\python.exe" exit /b 0
"%~1" -c "import sys, tkinter; assert sys.version_info >= (3,9)" >nul 2>&1
if errorlevel 1 exit /b 0
set "ARCADIUM_RC_PY_EXE=%~f1"
exit /b 0

:incomplete
echo.
echo STOP: Extract the WHOLE ZIP first, then double-click START_INSTALL.cmd.
echo Keep the games folder, CHECKSUMS.json and Python files beside this launcher.
pause
exit /b 1

:installer_failed
echo.
echo STOP: The Python installer exited with an error. Keep this window open.
pause
exit /b 1
