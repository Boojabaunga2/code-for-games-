BARREL BASH - GAME FILES ONLY

No Windows installer, Python script, server patch or APK is included.

1. Return to Arcadium on the PC. Wait 10 seconds for the Mini Vibes to return to Command Deck.
2. Extract this ZIP.
3. Copy its games folder into your existing Arcadium_OS_COMPACT folder. Allow replacement of the Barrel Bash game files.
4. Refresh Arcadium with Ctrl+F5, then launch Barrel Bash.

Do not use Import Game: that feature creates a duplicate entry. This update uses the existing Barrel Bash entry and relay. It changes only games/barrel-bash. Back up that one folder first if you want to keep the old files. All other games, server files, startup and pairing remain untouched.

A: join / timed throw. START: launch / pause / resume. B: personal rules.
The existing Barrel Bash state relay or newer Barrel Bash frame relay is required. The earlier supplied OS includes the original relay. If the current OS no longer has it, the PC link panel will report that and this files-only update cannot add a server module.

Keep Windows Security enabled. Previous installer packages V1/V2 were withdrawn after antivirus alerts. Removing those installers does not establish the cause or guarantee antivirus acceptance. Leave this download blocked if it is flagged.
