
'use strict';
// ARCADIUM: BARREL BASH — six-lane knife-thrower. All six score every round.
var ASSETS = {"wheel": "assets/wheel.png", "stand": "assets/stand.png", "_standOff": [-278.4, 180.0], "_wheelK": 0.562390158172232, "bg": "assets/bg.jpg", "co_hit": "assets/co_hit.png", "co_miss": "assets/co_miss.png", "co_perfect": "assets/co_perfect.png", "co_combo": "assets/co_combo.png", "co_round_win": "assets/co_round_win.png", "co_game_over": "assets/co_game_over.png", "impact": "assets/impact.png", "crown": "assets/crown.png", "bull": "assets/bull.png", "splash": "assets/splash.jpg"};
var MAPS = {"N": 1138, "G": 8, "n": 143, "mask": "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPgAAAAAAAAAAAAAAAAAAAAAD/wAAAAAAAAAAAAAAAAAAAAAP/wAAAAAAAAAAAAAAAAAAAAA//wAAAAAAAAAAAAAAAAAAAAD//wAAAAAAAAAAAAAAAAAAAAH//wAAAAAAAAAAAAAAAAAAAAf//gAAAAAAAAAAAAAAAAAAAA///AAAAAAAAAAAAAAAAAAAAB//+AAAAAAAAAAAAAAAAAAAAD//+AAAAAAAAAAAAAAAAAAAAH//8AAAAAAAAAAAAAAAAAAAAP//4AAAAAAAAAAAAAAAAAAAAP//gAAAAAAAAAAAAAAAAAAAAf/+AAAAAAAAAAAAAAAAAAAAB//8AAAAAAAAAAAAAAAAAAAAD//wAAAAAAAAAAAAAAAAAAAAH/+A/AAAAAAAAAAAAAAAAAAAf/wD/AAAAAAAAAAAAAAAAAAB/4AH/AAAAAAAAAAAAAAAAAAD/gAP/AAAAAAAAAAAAAAAAAAP/AAf+AAAAAAAAAAAAAAAAAAf+AB/8AAAAAAAAAAAAAAAAAB/4Af/8AAAAAAAAAAAAAAAAAD/wH///gAAAAAAAAAAAAAAAAH/g////AAAAAAAAAAAAAAAAAf+D////AAAAAAAAAAAAAAAAA/8H///8AAAAAAAAAAAAAAAAB/4P///4AAAAAAAAAAAAAAAAH//////wAAAAAAAAAAAAAAAAP//////wAAAAAAAAAAAAAAAAf//////+AAAAAAAAAAAAAAAA////////AAAAAAAAAAAAAAAD////////gAAAAAAAAAAAAAAH////////AAAAAAAAAAAAAAAP////////AAAAAAAAAAAAAAAf///////+AAAAAAAAAAAAAAA////////8AAAAAAAAAAAAAAB////////wAAAAAAAAAAAAAAH////////gAAAAAAAAAAAAAAP///////+AAAAAAAAAAAAAAAf///////AAAAAAAAAAAAAAAA///////8AAAAAAAAAAAAAAAB/P/////wAAAAAAAAAAAAAAAD8P/////gAAAAAAAAIAAAAAAHwf/////gAAAAAAAA4AAAAAA/Af/////wAAAAAAAD8AAAAAH8Af/////wAAAAAAAP+AAAAAPwA//////gAAAAAAA//4AAAB/gA/////+AAAAAAAB//wAAAH8AA/////8AAAAAAAH//wAAAfwAA/////4AAAAAAAP//gAAB/gAA/////wAAAAAAAf//wAAH/AAB/////gAAAAAAB///8AAP+AAB/////AAAAAAAD///9+Af+BgD////8AAAAAAAH/////h/+PgD////wAAAAAAAP/////3///gA////AAAAAAAAf/////////gAH//+AAAAAAAA//////////gAD//AAAAAAAAB//////////wAAH8ABgAAAAAB//////////4AAHgAPwAAAAAD//////////wAB/AA/8AAAAAH//////////gA//wD/8AAAAAH/////////+AB///P/8AAAAAP/////////8AH/////4AAAAAP/////////wAf/////wAAAAAP/////////wA//////gAAAAAP+f///////gR/////+AAAAAAP5////////hgf////8AAAAAAAD////////+AH////4AAAAAAAD3///////8AAAB//wAAAAAAAAA//////8AAAAB//AAAAAAAAAAH/////wAAAAD/8AAAAAAAAAAB/////AAAAAD/4AAAAAAAAAAA////8AAAAAB/gAAAAAAAAAAA////wAAAAAA+AAAAAAAAAAAA////gAAAAAAAAAAAAAAAAAAA////gAAAAAAAAAAAAAAAAAAA////AAAAAAAAAAAAAAAAAAAB////AAAAAAAAAAAAAAAAAAAD//+AAAAAAAAAAAAAAAAAAAAH//gAAAAAAAAAAAAAAAAAAAAP/8AAAAAAAAAAAAAAAAAAAAA//wAAAAAAAAAAAAAAAAAAAAB//AAAAAAAAAAAAAAAAAAAAAD/8AAAAAAAAAAAAAAAAAAAAAH/wAAAAAAAAAAAAAAAAAAAAAP/AAAAAAAAAAAAAAAAAAAAAA/+AAAAAAAAAAAAAAAAAAAAAB/4AAAAAAAAAAAAAAAAAAAAAH/wAAAAAAAAAAAAAAAAAAAAAP/gAAAAAAAAAAAAAAAAAAAAA/+AAAAAAAAAAAAAAAAAAAAAB/8AAAAAAAAAAAAAAAAAAAAAD/4AAAAAAAAAAAAAAAAAAAAAH/gAAAAAAAAAAAAAAAAAAAAAf/gAAAAAAAAAAAAAAAAAAAAA//AAAAAAAAAAAAAAAAAAAAAA//AAAAAAAAAAAAAAAAAAAAAA/+AAAAAAAAAAAAAAAAAAAAAAf/AAAAAAAAAAAAAAAAAAAAAB//AAAAAAAAAAAAAAAAAAAAAB/+AAAAAAAAAAAAAAAAAAAAAD/+AAAAAAAAAAAAAAAAAAAAAH/+AAAAAAAAAAAAAAAAAAAAAP//AAAAAAAAAAAAAAAAAAAAAf//gAAAAAAAAAAAAAAAAAAAA///gAAAAAAAAAAAAAAAAAAAB///AAAAAAAAAAAAAAAAAAAAD//+AAAAAAAAAAAAAAAAAAAAH//8AAAAAAAAAAAAAAAAAAAAP//wAAAAAAAAAAAAAAAAAAAA///gAAAAAAAAAAAAAAAAAAAB//+AAAAAAAAAAAAAAAAAAAAH//8AAAAAAAAAAAAAAAAAAAAf//wAAAAAAAAAAAAAAAAAAAAf//AAAAAAAAAAAAAAAAAAAAAP/4AAAAAAAAAAAAAAAAAAAAAD+AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==", "targets": [[-90.0, -386.0, 117], [-284.0, -229.0, 118], [-348.0, 170.0, 113], [301.0, 200.0, 118], [61.0, 257.0, 107], [-226.0, 358.0, 108]]};

var CFG = {
  rounds: 5,
  darts: 0, // UNLIMITED throws: clock ends the round
  roundTime: 30,
  targetPts: 100,
  bullPts: 500,
  bearPts: -300,
  perfectBonus: 1000,
  maxMult: 3,
  speeds: [70, 95, 120, 150, 180],
  reverse: [false, false, true, true, true],
  sweep: [2.6, 2.3, 2.0, 1.8, 1.6],
  flight: 0.14,
  bullR: 34,
  lobbyWait: 12,
  resultsTime: 8,
  finalTime: 20
};

// ---------- layout: fills the whole window (design base 1920x1080) ----------
// The canvas takes the window's shape; lanes stretch to fill it. Title and
// results screens are drawn on a 1920x1080 stage centred at (OX, OY).
var W = 1920, H = 1080, OX = 0, OY = 0;
var MAST, FOOT, SIDE, LANES_X = 24, LANES_Y = 146, LANE_W, LANE_H, LANE_GAP = 15, ROW_GAP = 14;
var HEAD_H = 40;
var WHEEL_S, SC, AIM_MIN, AIM_MAX;
var WHEEL_UP = 310, WHEEL_DOWN = 368, WHEEL_WIDE = 630; // wheel+stand extent, wheel-image px
function computeLayout() {
  var vw = window.innerWidth || 1920, vh = (window.innerHeight-30) || 1080, asp = vw / vh;
  H = 1080; W = Math.round(H * asp);
  if (W < 1500) { W = 1500; H = Math.round(W / asp); }
  OX = (W - 1920) / 2; OY = (H - 1080) / 2;
  MAST = { x: 24, y: 18, w: W - 48, h: 110 };
  FOOT = { x: 24, y: H - 70, w: W - 48, h: 52 };
  SIDE = { x: W - 24 - 290, y: LANES_Y, w: 290, h: FOOT.y - 14 - LANES_Y };
  var aw = SIDE.x - 16 - LANES_X, ah = FOOT.y - 14 - LANES_Y;
  LANE_W = (aw - 2 * LANE_GAP) / 3; LANE_H = (ah - ROW_GAP) / 2;
  WHEEL_S = Math.min((LANE_H - HEAD_H - 60) / (WHEEL_UP + WHEEL_DOWN), (LANE_W - 50) / WHEEL_WIDE);
  SC = ASSETS._wheelK * WHEEL_S;
  AIM_MIN = 20 * SC; AIM_MAX = 515 * SC;
}
computeLayout();
var FONT = '"Segoe UI", system-ui, -apple-system, Roboto, "Helvetica Neue", Arial, sans-serif';
var SEATS = [
  { name: 'RED',    col: '#ff3446', key: '1' },
  { name: 'BLUE',   col: '#278cff', key: '2' },
  { name: 'GREEN',  col: '#27dc63', key: '3' },
  { name: 'YELLOW', col: '#ffd51d', key: '4' },
  { name: 'PINK',   col: '#ff46b7', key: '5' },
  { name: 'WHITE',  col: '#dcecff', key: '6' }
];
function laneRect(i) {
  var col = i % 3, row = Math.floor(i / 3);
  return { x: LANES_X + col * (LANE_W + LANE_GAP), y: LANES_Y + row * (LANE_H + ROW_GAP), w: LANE_W, h: LANE_H };
}
function placeLane(L) {
  var r = laneRect(L.i), used = HEAD_H + 10 + (WHEEL_UP + WHEEL_DOWN) * WHEEL_S;
  L.x0 = r.x; L.y0 = r.y; L.px = r.x + r.w / 2;
  L.py = r.y + HEAD_H + 10 + (r.h - 50 - used) / 2 + WHEEL_UP * WHEEL_S;
}

var cv = document.getElementById('game');
var ctx = cv.getContext('2d');
var IMG = {};
var CHROME = null; // pre-rendered static frame for gameplay screens

// ---------- bear hit mask ----------
var MASK = (function () {
  var raw = atob(MAPS.mask), bits = new Uint8Array(raw.length);
  for (var i = 0; i < raw.length; i++) bits[i] = raw.charCodeAt(i);
  return bits;
})();
function onBear(lx, ly) {
  var half = MAPS.N / 2;
  var i = Math.floor((lx + half) / MAPS.G), j = Math.floor((ly + half) / MAPS.G);
  if (i < 0 || j < 0 || i >= MAPS.n || j >= MAPS.n) return false;
  var idx = j * MAPS.n + i;
  return (MASK[idx >> 3] >> (7 - (idx & 7))) & 1;
}

// ---------- audio ----------
var AC = null;
var muted=false;
function beep(freq, dur, type, vol, slide) {
  if(muted)return;
  try {
    if (!AC) AC = new (window.AudioContext || window.webkitAudioContext)();
    if(AC.state==='suspended')AC.resume();
    var o = AC.createOscillator(), g = AC.createGain(), t = AC.currentTime;
    o.type = type || 'square';
    o.frequency.setValueAtTime(freq, t);
    if (slide) o.frequency.exponentialRampToValueAtTime(slide, t + dur);
    g.gain.setValueAtTime(vol || 0.08, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(AC.destination); o.start(t); o.stop(t + dur);
  } catch (e) {}
}
var SFX = {
  throwIt: function () { beep(900, 0.08, 'triangle', 0.05, 400); },
  thunk:   function () { beep(140, 0.12, 'square', 0.08, 70); },
  hit:     function () { beep(660, 0.1, 'square', 0.07); setTimeout(function () { beep(990, 0.12, 'square', 0.07); }, 70); },
  bull:    function () { [660, 880, 1320, 1760].forEach(function (f, i) { setTimeout(function () { beep(f, 0.12, 'square', 0.07); }, i * 60); }); },
  bear:    function () { beep(220, 0.35, 'sawtooth', 0.09, 70); },
  tick:    function () { beep(520, 0.07, 'square', 0.06); },
  go:      function () { beep(1040, 0.3, 'square', 0.08); },
  join:    function () { beep(780, 0.1, 'triangle', 0.08, 1170); },
  fanfare: function () { [523, 659, 784, 1047, 784, 1047].forEach(function (f, i) { setTimeout(function () { beep(f, 0.18, 'square', 0.07); }, i * 140); }); }
};

// ---------- state ----------
var G = {
  scene: 'loading', t: 0, sceneT: 0, round: 0, paused: false,
  joined: [false, false, false, false, false, false],
  lobbyStart: -1, lanes: [], fx: [], timer: 0, countdown: 0, results: null
};

function newLane(i) {
  return {
    i: i, x0: 0, y0: 0, px: 0, py: 0,
    cpu: !G.joined[i], total: 0, roundPts: 0, darts: 0, throws: 0,
    angle: 0, speed: 0, dir: 1, aimPhase: 0, aimU: 0.5,
    stuck: [], used: [false, false, false, false, false, false],
    flying: null, streak: 0, hitsThisRound: 0, shake: 0, flash: 0,
    cpuNext: 0, flipAt: 0
  };
}
function setScene(s) { G.scene = s; G.sceneT = 0; }

// ---------- input ----------
// Single entry point for every input source (keys, touch, Mini Vibe). seat = 0..5
function press(seat) {
  if (seat < 0 || seat > 5) return;
  if (G.scene === 'title') {
    if (!G.joined[seat]) {
      G.joined[seat] = true; SFX.join();
      if (G.lobbyStart < 0) G.lobbyStart = G.t;
    }
    return;
  }
  if (G.scene === 'playing' && !G.paused) {
    var L = G.lanes[seat];
    if (L && !L.cpu) throwDart(L);
  }
}
window.BarrelBash = { press: press };

if(!window.BB_COMPANION){
document.addEventListener('keydown', function (e) {
  if(e.repeat)return;
  for (var i = 0; i < 6; i++) if (e.key === SEATS[i].key) { press(i); return; }
  if (e.code === 'Space') { e.preventDefault(); hostStart(); }
  if (e.key === 'p' || e.key === 'P' || e.key === 'Escape') togglePause();
});
cv.addEventListener('pointerdown', function (e) {
  var r = cv.getBoundingClientRect();
  var x = (e.clientX - r.left) * W / r.width, y = (e.clientY - r.top) * H / r.height;
  if (G.scene === 'title') {
    if (inRect(x - OX, y - OY, START_BTN)) { hostStart(); return; }
    var s = seatChipAt(x - OX, y - OY); if (s >= 0) press(s);
    return;
  }
  if (G.scene === 'final' && G.sceneT > 3) { toTitle(); return; }
  if (G.scene === 'playing' || G.scene === 'countdown') {
    if (inRect(x, y, MAST)) { togglePause(); return; }
    for (var i = 0; i < 6; i++) if (inRect(x, y, laneRect(i))) { press(i); return; }
  }
});
}
function inRect(x, y, r) { return x > r.x && x < r.x + r.w && y > r.y && y < r.y + r.h; }
function togglePause() { if (G.scene === 'playing' || G.scene === 'countdown') G.paused = !G.paused; }
function hostStart() { if (G.scene === 'title') startMatch(); else if (G.scene === 'final' && G.sceneT > 3) toTitle(); }

// ---------- flow ----------
function toTitle() {
  G.paused=false;
  G.joined = [false, false, false, false, false, false];
  G.lobbyStart = -1; G.fx = []; G.lanes=[]; setScene('title');
}
function startMatch() {
  if(!G.joined.some(Boolean))G.joined[0]=true;
  G.lanes = []; for (var i = 0; i < 6; i++) { G.lanes.push(newLane(i)); placeLane(G.lanes[i]); }
  G.round = 0; startRound();
}
function startRound() {
  var r = G.round;
  G.lanes.forEach(function (L) {
    L.darts = 0; L.throws = 0; L.roundPts = 0; L.stuck = []; L.used = [false, false, false, false, false, false];
    L.flying = null; L.streak = 0; L.hitsThisRound = 0;
    L.angle = Math.random() * Math.PI * 2;
    L.speed = CFG.speeds[r] * Math.PI / 180; L.dir = Math.random() < 0.5 ? 1 : -1;
    L.aimPhase = Math.random() * Math.PI * 2;
    L.flipAt = CFG.reverse[r] ? 3 + Math.random() * 5 : 1e9;
    L.cpuNext = 1 + Math.random() * 2;
  });
  G.fx = []; G.timer = CFG.roundTime; G.countdown = 3.999;
  setScene('countdown');
}
function endRound() {
  G.results = G.lanes.map(function (L) { return { i: L.i, round: L.roundPts, total: L.total }; });
  G.round++;
  if (G.round >= CFG.rounds) { setScene('final'); SFX.fanfare(); }
  else setScene('results');
}
function sortedBy(key) {
  var rows = G.results.slice();
  rows.sort(function (a, b) { return b[key] - a[key] || a.i - b.i; });
  return rows;
}
function ranks(rows, key) { // shared place on ties
  var out = [], place = 0;
  for (var k = 0; k < rows.length; k++) {
    if (k === 0 || rows[k][key] !== rows[k - 1][key]) place = k + 1;
    out.push(place);
  }
  return out;
}

// ---------- gameplay ----------
function aimY(L) { return L.py - (AIM_MIN + L.aimU * (AIM_MAX - AIM_MIN)); }

function throwDart(L) {
  if (G.scene !== 'playing' || G.timer <= 0 || L.flying) return;
  L.throws++;
  L.flying = { t: 0, tx: L.px, ty: aimY(L) };
  SFX.throwIt();
}
function toLocal(L, sx, sy) {
  var dx = (sx - L.px) / SC, dy = (sy - L.py) / SC, a = L.angle;
  return { x: dx * Math.cos(a) + dy * Math.sin(a), y: -dx * Math.sin(a) + dy * Math.cos(a) };
}
function judge(L, sx, sy) {
  var p = toLocal(L, sx, sy), k;
  for (k = 0; k < L.stuck.length; k++) {
    var d = L.stuck[k];
    if (Math.hypot(d.x - p.x, d.y - p.y) < 26) return { kind: 'bounce', p: p };
  }
  var best = -1, bestD = 1e9;
  for (k = 0; k < MAPS.targets.length; k++) {
    var T = MAPS.targets[k], dd = Math.hypot(T[0] - p.x, T[1] - p.y);
    if (dd < T[2] && dd < bestD) { best = k; bestD = dd; }
  }
  if (best >= 0) {
    if (L.used[best]) return { kind: 'used', p: p, t: best };
    return { kind: bestD < CFG.bullR ? 'bull' : 'hit', p: p, t: best };
  }
  if (onBear(p.x, p.y)) return { kind: 'bear', p: p };
  return { kind: 'wood', p: p };
}
function land(L) {
  var f = L.flying; L.flying = null;
  var j = judge(L, f.tx, f.ty), pts = 0, txt = '', callout = null;
  if (j.kind === 'hit' || j.kind === 'bull') {
    L.used[j.t] = true; L.streak++; L.hitsThisRound++;
    var mult = Math.min(CFG.maxMult, L.streak);
    pts = (j.kind === 'bull' ? CFG.bullPts : CFG.targetPts) * mult;
    txt = (j.kind === 'bull' ? 'BULLSEYE!! ' : '') + '+' + pts + (mult > 1 ? '  x' + mult : '');
    callout = j.kind === 'bull' ? 'perfect' : (mult > 1 ? 'combo' : 'hit');
    if (j.kind === 'bull') SFX.bull(); else SFX.hit();
    addFx({ type: 'impact', x: f.tx, y: f.ty, lane: L.i });
  } else if (j.kind === 'bear') {
    L.streak = 0; pts = CFG.bearPts; txt = 'OUCH! ' + pts; callout = 'miss';
    L.shake = 0.35; L.flash = 0.35; SFX.bear();
  } else {
    L.streak = 0; callout = 'miss';
    txt = j.kind === 'used' ? 'ALREADY HIT' : (j.kind === 'bounce' ? 'BOUNCED!' : 'MISS');
    SFX.thunk();
  }
  if (j.kind !== 'bounce' && j.kind !== 'used') L.stuck.push({ x: j.p.x, y: j.p.y, a: -L.angle });
  else addFx({ type: 'bounce', x: f.tx, y: f.ty, lane: L.i, col: SEATS[L.i].col });
  L.roundPts += pts; L.total += pts;
  addFx({ type: 'text', x: L.px, y: L.py - 40, txt: txt, col: pts < 0 ? '#ff4d4d' : (pts > 0 ? '#ffd23c' : '#cfe3f7'), lane: L.i });
  if (callout) addFx({ type: 'callout', img: callout, x: L.px + 175, y: L.py + 110, lane: L.i });

}
function addFx(f) { f.t = 0; G.fx.push(f); }

function cpuThink(L, dt) {
  L.cpuNext -= dt;
  if (L.cpuNext > 0 || L.flying) return;
  // dart lands where the crosshair is NOW, on the wheel as it will be after the flight
  var err = 0.04 + Math.random() * 0.1;
  var ahead = CFG.flight + (Math.random() - 0.5) * err;
  var saveA = L.angle;
  L.angle = L.angle + L.speed * L.dir * ahead;
  var j = judge(L, L.px, aimY(L));
  L.angle = saveA;
  var hurry = G.timer < 6;
  if (j.kind === 'hit' || j.kind === 'bull' || (hurry && j.kind === 'wood') || (G.timer < 2)) {
    throwDart(L); L.cpuNext = 0.5 + Math.random() * 1.2;
  } else L.cpuNext = 0.03;
}

// ---------- update ----------
function update(dt) {
  if (G.paused) return;
  G.t += dt;
  G.sceneT += dt;
  var i, L;
  if (G.scene === 'boot') { if (G.sceneT > 2.6) toTitle(); }
  else if (G.scene === 'title') {
    var n = G.joined.filter(Boolean).length;
    if (n === 6 && G.sceneT > 0.5 && (G.t - G.lobbyStart) > 1.5) startMatch();
    // Host START launches short-handed games; no silent countdown forcing CPUs.
  }
  else if (G.scene === 'countdown') {
    var before = Math.ceil(G.countdown);
    G.countdown -= dt;
    var after = Math.ceil(G.countdown);
    if (after !== before) { if (after > 0) SFX.tick(); else SFX.go(); }
    spinLanes(dt);
    if (G.countdown <= 0) setScene('playing');
  }
  else if (G.scene === 'playing') {
    G.timer -= dt;
    spinLanes(dt);
    for (i = 0; i < 6; i++) {
      L = G.lanes[i];
      if (L.flying) { L.flying.t += dt; if (L.flying.t >= CFG.flight) land(L); }
      if (L.cpu) cpuThink(L, dt);
    }
    // Unlimited darts: NEVER end a round early based on throws. The timer is authoritative.
    if (G.timer <= 0) {
      G.lanes.forEach(function (l) { if (l.flying) land(l); });
      G.allDoneAt = undefined; endRound();
    }
  }
  else if (G.scene === 'results') { spinLanes(dt); if (G.sceneT > CFG.resultsTime) startRound(); }
  else if (G.scene === 'final') { spinLanes(dt); if (G.sceneT > CFG.finalTime) toTitle(); }

  for (i = G.fx.length - 1; i >= 0; i--) { G.fx[i].t += dt; if (G.fx[i].t > 1.1) G.fx.splice(i, 1); }
}
function spinLanes(dt) {
  G.lanes.forEach(function (L) {
    L.angle += L.speed * L.dir * dt;
    if (G.scene === 'playing' && G.sceneT > L.flipAt) { L.dir = -L.dir; L.flipAt = G.sceneT + 3 + Math.random() * 5; }
    L.aimU = 0.5 - 0.5 * Math.cos(2 * Math.PI * G.sceneT / CFG.sweep[Math.min(G.round, CFG.rounds - 1)] + L.aimPhase);
    if (L.shake > 0) L.shake -= dt;
    if (L.flash > 0) L.flash -= dt;
  });
}

// ---------- drawing primitives ----------
function rr(c, x, y, w, h, r) {
  c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r);
  c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath();
}
// o: { align, weight, italic, shadow, sx, sy, glow, spacing, c }
function txt(s, x, y, size, col, o) {
  o = o || {};
  var c = o.c || ctx;
  c.save();
  c.font = (o.italic ? 'italic ' : '') + (o.weight || 900) + ' ' + size + 'px ' + FONT;
  c.textAlign = o.align || 'center'; c.textBaseline = 'middle';
  if ('letterSpacing' in c) c.letterSpacing = (o.spacing || 0) + 'px';
  if (o.shadow) { c.fillStyle = o.shadow; c.fillText(s, x + (o.sx === undefined ? 3 : o.sx), y + (o.sy === undefined ? 4 : o.sy)); }
  if (o.glow) { c.shadowColor = o.glow; c.shadowBlur = o.glowBlur || 22; }
  else { c.shadowColor = 'rgba(0,0,0,0.75)'; c.shadowBlur = 0; c.shadowOffsetY = o.drop === false ? 0 : 2; c.shadowBlur = o.drop === false ? 0 : 3; }
  c.fillStyle = col; c.fillText(s, x, y);
  c.restore();
}
// glowing bordered panel in the masthead/sidebar style
function panel(c, x, y, w, h, r, border, glow, fill) {
  c.save();
  rr(c, x, y, w, h, r);
  if (fill) { c.fillStyle = fill; c.fill(); }
  if (glow) { c.shadowColor = glow; c.shadowBlur = 26; }
  c.lineWidth = 2; c.strokeStyle = border; c.stroke();
  c.restore();
}
function mastFill(c, x, y, w, h) {
  var g = c.createLinearGradient(x, y, x + w, y + h * 0.4);
  g.addColorStop(0, '#080c17'); g.addColorStop(0.5, '#12213b'); g.addColorStop(1, '#080b16');
  return g;
}
function brand(c, x, y, size) { // Ⓐ ARCADIUM
  c.save();
  c.lineWidth = Math.max(3, size * 0.11); c.strokeStyle = '#f12d37';
  c.beginPath(); c.arc(x + size * 0.62, y, size * 0.62, 0, Math.PI * 2); c.stroke();
  c.restore();
  txt('A', x + size * 0.62, y + size * 0.03, size * 0.8, '#f12d37', { c: c, drop: false });
  txt('ARCADIUM', x + size * 1.55, y + 2, size, '#ffffff', { c: c, align: 'left', spacing: size * 0.12 });
}
function targetIcon(c, x, y, r) {
  var cols = ['#e8202e', '#ffffff', '#e8202e', '#ffffff', '#1a8cff'];
  for (var k = 0; k < cols.length; k++) { c.fillStyle = cols[k]; c.beginPath(); c.arc(x, y, r * (1 - k * 0.19), 0, Math.PI * 2); c.fill(); }
  c.save(); c.translate(x + r * 0.15, y - r * 0.15); c.rotate(-0.75);
  c.fillStyle = '#1b1f2a'; c.fillRect(-2, -r * 1.05, 4, r * 0.9);
  c.fillStyle = '#29a4ff'; c.beginPath(); c.moveTo(0, -r * 1.05); c.lineTo(-7, -r * 1.3); c.lineTo(7, -r * 1.3); c.closePath(); c.fill();
  c.restore();
}
function crown(x, y, w) { // gold crown, top-left at x,y
  var h = w * 0.78;
  ctx.save();
  var g = ctx.createLinearGradient(0, y, 0, y + h); g.addColorStop(0, '#ffe67a'); g.addColorStop(1, '#e09a00');
  ctx.fillStyle = g; ctx.strokeStyle = '#5a2a00'; ctx.lineWidth = Math.max(1.5, w * 0.06); ctx.lineJoin = 'round';
  ctx.beginPath();
  ctx.moveTo(x, y + h * 0.3); ctx.lineTo(x + w * 0.27, y + h * 0.58); ctx.lineTo(x + w * 0.5, y);
  ctx.lineTo(x + w * 0.73, y + h * 0.58); ctx.lineTo(x + w, y + h * 0.3); ctx.lineTo(x + w * 0.88, y + h);
  ctx.lineTo(x + w * 0.12, y + h); ctx.closePath(); ctx.fill(); ctx.stroke();
  ctx.fillStyle = '#ff3446'; ctx.beginPath(); ctx.arc(x + w * 0.5, y + h * 0.72, w * 0.08, 0, Math.PI * 2); ctx.fill();
  ctx.restore();
}
function titleText(c, s, x, y, size) { // italic BARREL BASH with red offset shadow + glow
  txt(s, x, y, size, '#ffffff', { c: c, italic: true, weight: 900, spacing: -size * 0.055, shadow: '#b01122', sx: size * 0.055, sy: size * 0.07, glow: '#de3b4c', glowBlur: size * 0.3 });
}
function drawDart(c, col) { // pointing up, tip at 0,0
  c.fillStyle = '#2a2e38'; c.fillRect(-2, -2, 4, 30);
  c.fillStyle = '#c9d1de'; c.fillRect(-4, 4, 8, 12);
  c.fillStyle = col; c.strokeStyle = '#05070d'; c.lineWidth = 1.5;
  c.beginPath(); c.moveTo(0, 18); c.lineTo(-9, 32); c.lineTo(0, 28); c.lineTo(9, 32); c.closePath(); c.fill(); c.stroke();
}
function drawWheel(c, px, py, angle, scale, L) {
  var st = IMG.stand;
  c.drawImage(st, px + ASSETS._standOff[0] * scale, py + ASSETS._standOff[1] * scale, st.width * scale, st.height * scale);
  c.save(); c.translate(px, py); c.rotate(angle);
  c.shadowColor = 'rgba(0,0,0,0.7)'; c.shadowBlur = 18; c.shadowOffsetY = 8;
  var w = IMG.wheel.width * scale; c.drawImage(IMG.wheel, -w / 2, -w / 2, w, w);
  c.shadowColor = 'transparent';
  if (L) {
    var sc = ASSETS._wheelK * scale;
    for (var k = 0; k < 6; k++) if (L.used[k]) {
      var T = MAPS.targets[k];
      c.fillStyle = 'rgba(10,14,24,0.55)'; c.beginPath(); c.arc(T[0] * sc, T[1] * sc, T[2] * sc * 0.92, 0, Math.PI * 2); c.fill();
    }
    L.stuck.forEach(function (d) {
      c.save(); c.translate(d.x * sc, d.y * sc); c.rotate(d.a); c.scale(1.2, 1.2); drawDart(c, SEATS[L.i].col); c.restore();
    });
  }
  c.restore();
}
function backdrop(c) {
  var g = c.createRadialGradient(W / 2, 0, 40, W / 2, 0, Math.max(1300, H * 1.2));
  g.addColorStop(0, '#193960'); g.addColorStop(0.45, '#060b1a'); g.addColorStop(1, '#02040a');
  c.fillStyle = g; c.fillRect(0, 0, W, H);
}
function hexA(col, a) { // #rrggbb -> rgba
  var n = parseInt(col.slice(1), 16);
  return 'rgba(' + (n >> 16) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')';
}

// ---------- static chrome for gameplay screens ----------
function buildChrome() {
  var c = document.createElement('canvas'); c.width = W; c.height = H;
  var x = c.getContext('2d');
  backdrop(x);
  // masthead
  rr(x, MAST.x, MAST.y, MAST.w, MAST.h, 18); x.fillStyle = mastFill(x, MAST.x, MAST.y, MAST.w, MAST.h); x.fill();
  panel(x, MAST.x, MAST.y, MAST.w, MAST.h, 18, '#2687db', 'rgba(18,105,185,0.6)');
  brand(x, 54, MAST.y + 56, 38);
  titleText(x, 'BARREL BASH', W / 2, MAST.y + 50, 74);
  txt('SIX PLAYER TARGET SHOWDOWN', W / 2, MAST.y + 96, 15, '#71dbff', { c: x, spacing: 4, weight: 800 });
  targetIcon(x, MAST.x + MAST.w - 60, MAST.y + 58, 26);
  // lanes
  for (var i = 0; i < 6; i++) {
    var r = laneRect(i), col = SEATS[i].col;
    x.save(); rr(x, r.x, r.y, r.w, r.h, 16); x.clip();
    var bg = IMG.bg, sw = bg.width * 0.42, sh = sw * r.h / r.w;
    x.drawImage(bg, (bg.width - sw) / 2 + (i % 3 - 1) * 300, 0, sw, sh, r.x, r.y, r.w, r.h);
    var dg = x.createLinearGradient(0, r.y, 0, r.y + r.h);
    dg.addColorStop(0, 'rgba(4,8,19,0.30)'); dg.addColorStop(1, 'rgba(4,8,19,0.65)');
    x.fillStyle = dg; x.fillRect(r.x, r.y, r.w, r.h);
    var ig = x.createRadialGradient(r.x + r.w / 2, r.y + r.h / 2, r.h * 0.3, r.x + r.w / 2, r.y + r.h / 2, r.w * 0.75);
    ig.addColorStop(0, 'rgba(0,0,0,0)'); ig.addColorStop(1, 'rgba(0,0,0,0.6)');
    x.fillStyle = ig; x.fillRect(r.x, r.y, r.w, r.h);
    var hg = x.createLinearGradient(r.x, 0, r.x + r.w, 0);
    hg.addColorStop(0, col); hg.addColorStop(1, '#050a17');
    x.fillStyle = hg; x.fillRect(r.x, r.y, r.w, HEAD_H);
    x.restore();
    x.save(); rr(x, r.x, r.y, r.w, r.h, 16);
    x.shadowColor = hexA(col, 0.6); x.shadowBlur = 20; x.lineWidth = 3; x.strokeStyle = col; x.stroke(); x.restore();
  }
  // sidebar
  rr(x, SIDE.x, SIDE.y, SIDE.w, SIDE.h, 16);
  var sg = x.createLinearGradient(SIDE.x, SIDE.y, SIDE.x + SIDE.w, SIDE.y + SIDE.h);
  sg.addColorStop(0, '#0c1930'); sg.addColorStop(1, '#02040c'); x.fillStyle = sg; x.fill();
  panel(x, SIDE.x, SIDE.y, SIDE.w, SIDE.h, 16, '#5ab8fa', 'rgba(32,118,212,0.5)');
  [[162, 112, 'ROUND'], [288, 112, 'TIME LEFT'], [414, 566, 'LEADERBOARD']].forEach(function (p) {
    rr(x, SIDE.x + 16, p[0], SIDE.w - 32, p[1], 12); x.fillStyle = '#060d1d'; x.fill();
    x.lineWidth = 1; x.strokeStyle = '#2c6798'; x.stroke();
    txt(p[2], SIDE.x + SIDE.w / 2, p[0] + 24, 15, '#b2d7fa', { c: x, spacing: 2.5 });
  });
  // footer ticker
  rr(x, FOOT.x, FOOT.y, FOOT.w, FOOT.h, 14);
  var fg = x.createLinearGradient(FOOT.x, 0, FOOT.x + FOOT.w, 0);
  fg.addColorStop(0, '#0a1931'); fg.addColorStop(0.5, '#152f4d'); fg.addColorStop(1, '#0a1931');
  x.fillStyle = fg; x.fill(); x.lineWidth = 1.5; x.strokeStyle = '#176aab'; x.stroke();
  var tick = 'HIT THE TARGETS   ◆   STACK MULTIPLIERS   ◆   OWN THE LEADERBOARD';
  x.save(); x.font = '900 22px ' + FONT; if ('letterSpacing' in x) x.letterSpacing = '2.6px'; var tw = x.measureText(tick).width; x.restore();
  targetIcon(x, W / 2 + 20 - tw / 2 - 30, FOOT.y + 28, 13);
  txt(tick, W / 2 + 20, FOOT.y + 27, 22, '#e5f6ff', { c: x, spacing: 2.6 });
  CHROME = c;
}

// ---------- boot / loading ----------
function drawSplash(alpha) {
  ctx.fillStyle = '#000'; ctx.fillRect(0, 0, W, H);
  if (IMG.splash && IMG.splash.complete) {
    ctx.globalAlpha = alpha; var s = 1000; ctx.drawImage(IMG.splash, (W - s) / 2, (H - s) / 2, s, s); ctx.globalAlpha = 1;
  }
}
function drawBoot() {
  var a = Math.min(1, G.sceneT / 0.4) * Math.min(1, (2.6 - G.sceneT) / 0.4);
  drawSplash(Math.max(0, a));
}

// ---------- title ----------
var START_BTN = { x: 770, y: 948, w: 380, h: 76 };
function seatChipRect(i) { return { x: 50 + i * 306, y: 812, w: 290, h: 112 }; }
function seatChipAt(x, y) { for (var i = 0; i < 6; i++) if (inRect(x, y, seatChipRect(i))) return i; return -1; }

function goldButton(r, label) {
  ctx.save();
  rr(ctx, r.x, r.y + 6, r.w, r.h, 12); ctx.fillStyle = '#a65400'; ctx.fill();
  rr(ctx, r.x, r.y, r.w, r.h, 12);
  var g = ctx.createLinearGradient(0, r.y, 0, r.y + r.h); g.addColorStop(0, '#ffe67a'); g.addColorStop(1, '#ff9d00');
  ctx.fillStyle = g; ctx.shadowColor = 'rgba(255,190,60,0.55)'; ctx.shadowBlur = 24; ctx.fill();
  ctx.shadowBlur = 0; ctx.lineWidth = 3; ctx.strokeStyle = '#fff4a9'; ctx.stroke();
  ctx.restore();
  txt(label, r.x + r.w / 2, r.y + r.h / 2 + 2, 40, '#1d1300', { drop: false, spacing: 3 });
}
function infoPanel(x, y, w, h, title, lines) {
  rr(ctx, x, y, w, h, 16);
  var g = ctx.createLinearGradient(x, y, x + w, y + h); g.addColorStop(0, '#0c1930'); g.addColorStop(1, '#02040c');
  ctx.fillStyle = g; ctx.fill();
  panel(ctx, x, y, w, h, 16, '#5ab8fa', 'rgba(32,118,212,0.5)');
  txt(title, x + w / 2, y + 44, 22, '#b2d7fa', { spacing: 4 });
  lines.forEach(function (l, k) {
    var ly = y + 100 + k * 58;
    rr(ctx, x + 22, ly - 24, w - 44, 48, 8); ctx.fillStyle = '#142036'; ctx.fill();
    ctx.fillStyle = l[2] || '#278cff'; ctx.fillRect(x + 22, ly - 24, 5, 48);
    txt(l[0], x + 42, ly, 22, '#ffffff', { align: 'left' });
    if (l[1]) txt(l[1], x + w - 40, ly, 24, l[3] || '#ffd23c', { align: 'right' });
  });
}
function drawTitle() {
  backdrop(ctx);
  ctx.save(); ctx.translate(OX, OY);
  var W0 = W; W = 1920;
  try { drawTitleStage(); } finally { W = W0; ctx.restore(); }
}
function drawTitleStage() {
  brand(ctx, 54, 62, 40);
  txt('2026', W - 60, 62, 22, '#71dbff', { align: 'right', spacing: 5 });
  titleText(ctx, 'BARREL BASH', W / 2, 190, 170);
  txt('SIX PLAYER TARGET SHOWDOWN', W / 2, 290, 24, '#71dbff', { spacing: 7, weight: 800 });
  drawWheel(ctx, W / 2, 540, G.t * 1.1, 0.6, null);
  infoPanel(50, 340, 560, 440, 'HOW TO PLAY', [
    ['Press when the crosshair', '', '#ffd23c'],
    ['is over a target', '', '#ffd23c'],
    ['Target', '+' + CFG.targetPts],
    ['Bullseye', '+' + CFG.bullPts],
    ['Hit streak', 'x2  x3'],
    ['Hit the bear', String(CFG.bearPts), '#ff3446', '#ff4d4d']
  ]);
  infoPanel(W - 610, 340, 560, 440, 'EVERY ROUND', [
    ['Darts', 'UNLIMITED'],
    ['Rounds', String(CFG.rounds)],
    ['Time per round', CFG.roundTime + 's'],
    ['Each target scores once', '', '#41dcff'],
    ['Keep throwing until TIME!', '', '#41dcff'],
    ['Round 3+ wheel reverses', '', '#ff3446']
  ]);
  for (var i = 0; i < 6; i++) {
    var r = seatChipRect(i), on = G.joined[i], col = SEATS[i].col;
    ctx.save(); rr(ctx, r.x, r.y, r.w, r.h, 14); ctx.clip();
    ctx.fillStyle = '#0d1b31'; ctx.fillRect(r.x, r.y, r.w, r.h);
    var hg = ctx.createLinearGradient(r.x, 0, r.x + r.w, 0);
    hg.addColorStop(0, on ? col : hexA(col, 0.35)); hg.addColorStop(1, '#050a17');
    ctx.fillStyle = hg; ctx.fillRect(r.x, r.y, r.w, 44);
    ctx.restore();
    ctx.save(); rr(ctx, r.x, r.y, r.w, r.h, 14);
    if (on) { ctx.shadowColor = hexA(col, 0.8); ctx.shadowBlur = 22 + 6 * Math.sin(G.t * 5); }
    ctx.lineWidth = on ? 3 : 2; ctx.strokeStyle = on ? col : hexA(col, 0.45); ctx.stroke(); ctx.restore();
    txt('●  P' + (i + 1) + ' ' + SEATS[i].name, r.x + 16, r.y + 23, 22, '#ffffff', { align: 'left' });
    txt(on ? 'READY!' : 'PRESS TO JOIN', r.x + r.w / 2, r.y + 80, on ? 34 : 20, on ? col : '#8ab6d5', { spacing: on ? 2 : 2.5 });
  }
  goldButton(START_BTN, 'START');
  var msg = 'EMPTY SEATS ARE PLAYED BY CPU';
  if (G.lobbyStart >= 0) msg = 'START TO LAUNCH  ◆  ' + msg;
  txt(msg, W / 2, 1056, 20, '#8ab6d5', { spacing: 3, weight: 800 });
}

// ---------- gameplay screen ----------
function crosshair(x, y) {
  ctx.beginPath(); ctx.arc(x, y, 14, 0, Math.PI * 2);
  ctx.moveTo(x - 24, y); ctx.lineTo(x - 8, y); ctx.moveTo(x + 8, y); ctx.lineTo(x + 24, y);
  ctx.moveTo(x, y - 24); ctx.lineTo(x, y - 8); ctx.moveTo(x, y + 8); ctx.lineTo(x, y + 24); ctx.stroke();
}
function drawLane(L) {
  var r = laneRect(L.i), c = SEATS[L.i].col, sx = 0, sy = 0;
  // header text (frame is in CHROME)
  txt('●  P' + (L.i + 1) + ' ' + SEATS[L.i].name + (L.cpu ? '  · CPU' : ''), r.x + 16, r.y + HEAD_H / 2 + 1, 21, '#ffffff', { align: 'left' });
  txt(L.total.toLocaleString('en-US'), r.x + r.w - 16, r.y + HEAD_H / 2 + 1, 28, '#ffffff', { align: 'right' });
  ctx.save(); rr(ctx, r.x, r.y + HEAD_H, r.w, r.h - HEAD_H, 0); ctx.clip();
  if (L.shake > 0) { sx = (Math.random() - 0.5) * 14; sy = (Math.random() - 0.5) * 14; }
  ctx.translate(sx, sy);
  drawWheel(ctx, L.px, L.py, L.angle, WHEEL_S, L);
  if (G.scene === 'playing' || G.scene === 'countdown') {
    var ay = aimY(L);
    ctx.strokeStyle = 'rgba(255,255,255,0.18)'; ctx.lineWidth = 2; ctx.setLineDash([6, 8]);
    ctx.beginPath(); ctx.moveTo(L.px, L.py - AIM_MIN); ctx.lineTo(L.px, L.py - AIM_MAX); ctx.stroke(); ctx.setLineDash([]);
    if (G.scene === 'playing' || L.flying) {
      ctx.strokeStyle = '#05070d'; ctx.lineWidth = 7; crosshair(L.px, ay);
      ctx.strokeStyle = c; ctx.lineWidth = 3.5; crosshair(L.px, ay);
    }
  }
  if (L.flying) {
    var u = L.flying.t / CFG.flight, start = r.y + r.h + 20, fy = start + (L.flying.ty - start) * u;
    ctx.save(); ctx.translate(L.px, fy); var s = 1.8 - 0.8 * u; ctx.scale(s, s); drawDart(ctx, c); ctx.restore();
  }
  ctx.restore();
  // Time-attack HUD: unlimited darts; only the clock ends play.
  txt('THROWS ' + (L.throws || 0) + '  ·  UNLIMITED', r.x + 18, r.y + r.h - 25, 19, '#ffdc8b', {align:'left'});
  var mult = Math.min(CFG.maxMult, L.streak + 1);
  if (L.streak > 0 && mult > 1) txt('NEXT x' + mult, r.x + r.w - 18, r.y + r.h - 24, 24, '#41dcff', { align: 'right', glow: '#1aa6ff', glowBlur: 12 });
  else if (G.scene === 'playing') txt(Math.max(0,Math.ceil(G.timer)) + 's', r.x + r.w - 18, r.y + r.h - 24, 22, '#cfe3f7', { align: 'right' });
  if (L.flash > 0) {
    ctx.save(); rr(ctx, r.x, r.y, r.w, r.h, 16); ctx.fillStyle = 'rgba(255,40,40,' + (L.flash * 0.8) + ')'; ctx.fill(); ctx.restore();
  }
}
function drawFx(seat) {
  G.fx.forEach(function (f) {
    if(seat!==undefined && f.lane!==seat)return;
    var u = f.t;
    if (f.type === 'impact') {
      var fr = Math.min(11, Math.floor(u / 0.03));
      if (u < 0.36) ctx.drawImage(IMG.impact, fr * 128, 0, 128, 128, f.x - 56, f.y - 56, 112, 112);
    } else if (f.type === 'text') {
      ctx.globalAlpha = Math.max(0, 1 - u / 1.1);
      txt(f.txt, f.x, f.y - u * 60, f.big ? 34 : 30, f.col, { shadow: '#05070d', sx: 2, sy: 3 }); ctx.globalAlpha = 1;
    } else if (f.type === 'callout') {
      var s = (f.big ? 1.1 : 0.7) * Math.min(1, u / 0.12) * (u > 0.12 ? 1 + 0.06 * Math.sin(u * 20) : 1);
      ctx.globalAlpha = Math.max(0, Math.min(1, (1.1 - u) / 0.3));
      var im = IMG['co_' + f.img], d = 200 * s; ctx.drawImage(im, f.x - d / 2, f.y - d / 2, d, d); ctx.globalAlpha = 1;
    } else if (f.type === 'bounce') {
      ctx.save(); ctx.globalAlpha = Math.max(0, 1 - u / 0.6);
      ctx.translate(f.x + u * 160, f.y + u * u * 600); ctx.rotate(u * 14); drawDart(ctx, f.col); ctx.restore();
    }
  });
}
function drawSidebar() {
  var cx = SIDE.x + SIDE.w / 2;
  var rn = Math.min(G.round + 1, CFG.rounds);
  if (G.scene === 'final') rn = CFG.rounds;
  if (G.scene === 'results') rn=G.round;
  ctx.save(); ctx.font = '900 54px ' + FONT; var wN = ctx.measureText(String(rn)).width; ctx.restore();
  txt(String(rn), cx - 22, 228, 54, '#ffd23c', { shadow: '#7a3d00', sx: 0, sy: 3, drop: false });
  txt('/ ' + CFG.rounds, cx - 22 + wN / 2 + 8, 236, 24, '#ffffff', { align: 'left' });
  var t = Math.max(0, Math.ceil(G.timer));
  if (G.scene === 'countdown') t = CFG.roundTime;
  if (G.scene === 'results' || G.scene === 'final') t = 0;
  var tc = t <= 5 && G.scene === 'playing' ? '#ff4d4d' : '#41dcff';
  txt('0:' + (t < 10 ? '0' : '') + t, cx, 354, 54, tc, { shadow: '#063a59', sx: 0, sy: 3, drop: false, glow: G.scene === 'playing' && t <= 5 ? '#ff2a3c' : null });
  var rows = G.lanes.map(function (L) { return { i: L.i, total: L.total }; });
  rows.sort(function (a, b) { return b.total - a.total || a.i - b.i; });
  var rk = ranks(rows, 'total');
  rows.forEach(function (r, k) {
    var y = 464 + k * 84, x = SIDE.x + 28, w = SIDE.w - 56;
    rr(ctx, x, y, w, 70, 8); ctx.fillStyle = '#142036'; ctx.fill();
    ctx.fillStyle = SEATS[r.i].col; ctx.fillRect(x, y, 6, 70);
    if (rk[k] === 1) crown(x + 14, y + 10, 26);
    else txt(String(rk[k]), x + 27, y + 22, 20, '#8ab6d5');
    txt(SEATS[r.i].name, x + 48, y + 22, 20, '#ffffff', { align: 'left' });
    txt(r.total.toLocaleString('en-US'), x + w - 12, y + 50, 28, rk[k] === 1 ? '#ffd23c' : '#ffffff', { align: 'right' });
  });
}
function drawGame() {
  ctx.drawImage(CHROME, 0, 0);
  G.lanes.forEach(drawLane);
  drawFx();
  drawSidebar();
  if (G.scene === 'countdown') {
    var n = Math.ceil(G.countdown), aw = 3 * LANE_W + 2 * LANE_GAP, ah = 2 * LANE_H + ROW_GAP;
    var cx = LANES_X + aw / 2, cy = LANES_Y + ah / 2;
    ctx.fillStyle = 'rgba(0,4,12,0.45)'; ctx.fillRect(LANES_X, LANES_Y, aw, ah);
    goldPanel(cx - 300, cy - 170, 600, 340);
    txt('ROUND ' + (G.round + 1) + ' OF ' + CFG.rounds, cx, cy - 110, 30, '#a5cfff', { spacing: 4 });
    if (n > 3) txt('GET READY', cx, cy + 30, 86, '#ffd74d', { shadow: '#8e3c05', sx: 3, sy: 5 });
    else txt(String(n), cx, cy + 30, 190, '#ffd74d', { shadow: '#8e3c05', sx: 4, sy: 7 });
  }
  if (G.paused) {
    ctx.fillStyle = 'rgba(0,0,0,0.65)'; ctx.fillRect(0, 0, W, H);
    goldPanel(W / 2 - 360, H / 2 - 160, 720, 300);
    txt('PAUSED', W / 2, H / 2 - 40, 110, '#ffd74d', { shadow: '#8e3c05', sx: 3, sy: 5 });
    txt('PRESS P OR TAP THE TOP BAR TO RESUME', W / 2, H / 2 + 70, 22, '#a5cfff', { spacing: 3 });
  }
}

// ---------- results / final overlay ----------
function goldPanel(x, y, w, h) {
  ctx.save();
  rr(ctx, x, y, w, h, 25);
  var g = ctx.createRadialGradient(x + w / 2, y, 30, x + w / 2, y, h * 1.1);
  g.addColorStop(0, '#173f70'); g.addColorStop(0.75, '#060a17'); g.addColorStop(1, '#060a17');
  ctx.fillStyle = g; ctx.shadowColor = 'rgba(230,165,49,0.55)'; ctx.shadowBlur = 70; ctx.fill();
  ctx.shadowBlur = 0; ctx.lineWidth = 4; ctx.strokeStyle = '#f5c04d'; ctx.stroke();
  ctx.restore();
}
function medal(x, y, place) {
  var cols = { 1: ['#ffe27a', '#d99a00'], 2: ['#f1f5fa', '#9aa7b8'], 3: ['#ffb27a', '#b5642a'] }[place] || ['#9fb3c8', '#5a6b80'];
  ctx.fillStyle = '#c02032'; ctx.beginPath(); ctx.moveTo(x - 14, y - 46); ctx.lineTo(x - 4, y - 14); ctx.lineTo(x + 4, y - 14); ctx.lineTo(x + 14, y - 46); ctx.closePath(); ctx.fill();
  var g = ctx.createRadialGradient(x - 6, y - 6, 3, x, y, 22); g.addColorStop(0, cols[0]); g.addColorStop(1, cols[1]);
  ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, 22, 0, Math.PI * 2); ctx.fill();
  txt(String(place), x, y + 1, 24, '#3a2400', { drop: false });
}
function drawPodiumOverlay(isFinal) {
  var key = isFinal ? 'total' : 'round';
  var rows = sortedBy(key), rk = ranks(rows, key);
  var px = 385, py = 70, pw = 1150, ph = 940;
  ctx.fillStyle = 'rgba(0,0,0,0.72)'; ctx.fillRect(0, 0, W, H);
  ctx.save(); ctx.translate(OX, OY);
  var W0 = W; W = 1920; // stage coordinates for the rest of this overlay
  try { drawPodiumBody(isFinal, key, rows, rk, px, py, pw, ph); } finally { W = W0; ctx.restore(); }
}
function drawPodiumBody(isFinal, key, rows, rk, px, py, pw, ph) {
  goldPanel(px, py, pw, ph);
  brand(ctx, W / 2 - 128, py + 52, 30);
  txt(isFinal ? 'FINAL RESULTS' : 'ROUND RESULTS', W / 2, py + 132, 78, '#ffd74d', { shadow: '#8e3c05', sx: 3, sy: 5 });
  txt(isFinal ? 'MATCH COMPLETE' : 'ROUND ' + G.round + ' OF ' + CFG.rounds, W / 2, py + 196, 26, '#a5cfff', { spacing: 4 });
  // podium: 2nd, 1st, 3rd
  var order = [1, 0, 2], cw = 300, gap = 22, bx = W / 2 - (3 * cw + 2 * gap) / 2, base = py + 560;
  order.forEach(function (idx, slot) {
    var r = rows[idx], col = SEATS[r.i].col, first = slot === 1;
    var h = first ? 320 : 280, x = bx + slot * (cw + gap), y = base - h;
    ctx.save(); rr(ctx, x, y, cw, h, 15); ctx.fillStyle = '#0d1b31';
    if (first) { ctx.shadowColor = hexA(col, 0.7); ctx.shadowBlur = 30; }
    ctx.fill(); ctx.shadowBlur = 0; ctx.lineWidth = 3; ctx.strokeStyle = col; ctx.stroke(); ctx.restore();
    medal(x + cw / 2, y + 58, rk[idx]);
    var ws = first ? 0.19 : 0.15;
    drawWheel(ctx, x + cw / 2, y + (first ? 145 : 128), G.t * (first ? 1.6 : 1.0), ws, null);
    txt(SEATS[r.i].name + (G.lanes[r.i].cpu ? ' CPU' : ''), x + cw / 2, y + h - 78, 30, '#ffffff');
    var v = r[key];
    txt((key === 'round' && v > 0 ? '+' : '') + v.toLocaleString('en-US'), x + cw / 2, y + h - 34, first ? 40 : 34, first ? '#ffd23c' : '#ffffff');
  });
  // headline
  var tops = rows.filter(function (r, k) { return rk[k] === 1; }).map(function (r) { return SEATS[r.i].name; });
  var head = tops.length > 1 ? 'TIE: ' + tops.join(' + ') : tops[0] + (isFinal ? ' WINS THE MATCH!' : ' TAKES THE ROUND!');
  crown(W / 2 + 18 - ctxWidth(head, 38) / 2 - 58, py + 590, 40);
  txt(head, W / 2 + 18, py + 606, 38, '#ffd34a', { shadow: '#5a2a00', sx: 2, sy: 3 });
  // full rankings by total (2 columns x 3)
  var all = sortedBy('total'), ark = ranks(all, 'total');
  txt('STANDINGS', W / 2, py + 664, 18, '#b2d7fa', { spacing: 4 });
  all.forEach(function (r, k) {
    var colX = px + 60 + (k % 2) * 530, y = py + 690 + Math.floor(k / 2) * 62, w = 500;
    rr(ctx, colX, y, w, 52, 8); ctx.fillStyle = '#142036'; ctx.fill();
    ctx.fillStyle = SEATS[r.i].col; ctx.fillRect(colX, y, 6, 52);
    txt(String(ark[k]), colX + 30, y + 27, 24, '#8ab6d5');
    txt(SEATS[r.i].name, colX + 58, y + 27, 22, '#ffffff', { align: 'left' });
    if (!isFinal) txt((r.round > 0 ? '+' : '') + r.round, colX + 330, y + 27, 20, r.round < 0 ? '#ff4d4d' : '#41dcff', { align: 'right' });
    txt(r.total.toLocaleString('en-US'), colX + w - 16, y + 27, 26, ark[k] === 1 ? '#ffd23c' : '#ffffff', { align: 'right' });
  });
  var foot;
  if (isFinal) foot = G.sceneT > 3 ? 'TAP OR PRESS SPACE FOR A NEW MATCH' : '';
  else foot = 'NEXT ROUND IN ' + Math.max(0, Math.ceil(CFG.resultsTime - G.sceneT));
  if (foot) txt(foot, W / 2, py + ph - 30, 22, '#8ab6d5', { spacing: 4 });
}
function ctxWidth(s, size) { ctx.save(); ctx.font = '900 ' + size + 'px ' + FONT; var w = ctx.measureText(s).width; ctx.restore(); return w; }

function render() {
  if (G.scene === 'loading') drawSplash(1);
  else if (G.scene === 'boot') drawBoot();
  else if (G.scene === 'title') drawTitle();
  else {
    drawGame();
    if (G.scene === 'results') drawPodiumOverlay(false);
    if (G.scene === 'final') drawPodiumOverlay(true);
  }
}

// ---------- boot ----------
function fit() {
  computeLayout();
  cv.width = W; cv.height = H;
  cv.style.width = window.innerWidth + 'px'; cv.style.height = (window.innerHeight-30) + 'px';
  G.lanes.forEach(placeLane);
  if (IMG.bg && IMG.bg.complete && IMG.bg.naturalWidth) buildChrome();
}
window.addEventListener('resize', fit);

function loadImg(k, cb) {
  var im = new Image();
  im.onload = function () { cb(); };
  im.onerror = function () { console.error('asset failed: ' + k); cb(); };
  im.src = ASSETS[k]; IMG[k] = im;
}
function loadAll(done) {
  var keys = Object.keys(ASSETS).filter(function (k) { return k.charAt(0) !== '_' && k !== 'splash' && typeof ASSETS[k] === 'string'; });
  var left = keys.length;
  keys.forEach(function (k) { loadImg(k, function () { if (--left === 0) done(); }); });
}

var last = 0;
function frame(ts) {
  var dt = Math.min(0.05, (ts - last) / 1000 || 0); last = ts;
  if(document.hidden)autoPause();
  update(dt); render();
  requestAnimationFrame(frame);
}
if(!window.BB_COMPANION){
fit();
// splash first (shown while the rest loads), then everything else
loadImg('splash', function () {
  requestAnimationFrame(frame);
  loadAll(function () { buildChrome(); setScene('boot'); });
});
}
else loadAll(function(){ window.BB_ASSETS_READY=true; });
window.__G = G;


// Personal render uses the same wheel, aim, darts and scoring state, without advancing it.
function drawPersonalWorld(g,i){
 if(!IMG.wheel?.complete || !IMG.stand?.complete)return;
 const L=G.lanes[i];g.save();g.beginPath();g.roundRect(25,119,670,410,12);g.clip();g.fillStyle='#0c1425';g.fillRect(25,119,670,410);
 if(L){const r=laneRect(i),body={x:r.x,y:r.y+HEAD_H,w:r.w,h:r.h-HEAD_H-50},sc=Math.min(670/body.w,365/body.h);g.translate(360-(body.x+body.w/2)*sc,347-(body.y+body.h/2)*sc);g.scale(sc,sc);g.beginPath();g.rect(body.x,body.y,body.w,body.h);g.clip();const old=ctx;try{ctx=g;drawLane(L);drawFx(i);}finally{ctx=old;}}
 else drawWheel(g,360,335,G.t*1.1,.55,null);
 g.restore();
}
window.BB={G,CFG,SEATS,press,hostStart,toTitle,togglePause,update,render,startMatch,startRound,throwDart,land,judge,toLocal,aimY,drawPersonalWorld,sortedBy,ranks,cv,get muted(){return muted;},set muted(v){muted=!!v;}};
function autoPause(){if((G.scene==='playing'||G.scene==='countdown')&&!G.paused)togglePause();}
if(!window.BB_COMPANION){addEventListener('blur',autoPause);document.addEventListener('visibilitychange',()=>{if(document.hidden)autoPause();});}

// State-only compatibility with the Barrel Bash relay already present in the supplied OS.
// Companion mode never starts an update loop, controls, sound or a second match.
BB.snapshot=function(){return {scene:G.scene,sceneRound:G.round,round:Math.min(CFG.rounds,G.scene==='results'||G.scene==='final'?G.round:G.round+1),rounds:CFG.rounds,timer:G.timer,countdown:G.countdown,sceneTime:G.sceneT,paused:G.paused,seats:SEATS.map((s,i)=>{const L=G.lanes[i];let place=null;if(G.results){const rows=sortedBy('total');place=ranks(rows,'total')[rows.findIndex(r=>r.i===i)];}return {color:s.name.toLowerCase(),joined:G.joined[i],cpu:!!L?.cpu,score:L?.total||0,roundScore:L?.roundPts||0,throws:L?.throws||0,angle:L?.angle||0,speed:L?.speed||0,dir:L?.dir||1,aimU:L?.aimU??.5,stuck:L?.stuck.length||0,darts:(L?.stuck||[]).map(d=>({x:+d.x.toFixed(3),y:+d.y.toFixed(3),a:+d.a.toFixed(5)})),used:L?.used||Array(6).fill(false),streak:L?.streak||0,paused:G.paused,place,sceneTime:G.sceneT,countdown:G.countdown,sceneRound:G.round,flying:L?.flying?{t:L.flying.t,x:(L.flying.tx-L.px)/SC,y:(L.flying.ty-L.py)/SC}:null};})};};
BB.applySnapshot=function(packet,i){const d=packet.seat;if(!d||typeof d.aimU!=='number'||typeof d.angle!=='number')return false;if(!['title','countdown','playing','results','final','boot','loading'].includes(packet.scene))return false;G.scene=packet.scene;G.timer=Number(packet.timer)||0;G.round=Number.isInteger(d.sceneRound)?d.sceneRound:Math.max(0,Number(packet.round||1)-1);G.sceneT=Number(d.sceneTime)||0;G.t=G.sceneT;G.countdown=Number(d.countdown)||0;G.paused=!!d.paused;G.joined[i]=!!d.joined;const L=newLane(i);placeLane(L);Object.assign(L,{cpu:!!d.cpu,total:Number(d.score)||0,roundPts:Number(d.roundScore)||0,throws:Number(d.throws)||0,angle:d.angle,speed:Number(d.speed)||0,dir:d.dir===-1?-1:1,aimU:d.aimU,streak:Number(d.streak)||0,rank:Number(d.place)||null});L.used=Array.isArray(d.used)?d.used.slice(0,6):Array(6).fill(false);L.stuck=Array.isArray(d.darts)?d.darts.filter(v=>Number.isFinite(v.x)&&Number.isFinite(v.y)&&Number.isFinite(v.a)).slice(-250):[];if(d.flying&&Number.isFinite(d.flying.t)&&Number.isFinite(d.flying.x)&&Number.isFinite(d.flying.y))L.flying={t:d.flying.t,tx:L.px+d.flying.x*SC,ty:L.py+d.flying.y*SC};G.lanes[i]=L;G.results=G.scene==='final'?[{i,total:L.total}]:null;return true;};
