package com.arcadium.og9;

/** Complete D-pad snapshots: no tap latching, repeat requirement or release guessing. */
public final class HeldDpad {
    private int physical;
    private int touch;
    private int axes;
    private int shoulders;
    private int session;
    private int sequence;

    public HeldDpad(int session) { this.session = session & 0xffffff; }
    public void key(int bit, boolean down) {
        if (bit < 0 || bit > 3) return;
        if (down) physical |= 1 << bit;
        else physical &= ~(1 << bit);
    }
    public void touch(int mask) { touch = mask & 15; }
    public void axes(float hatX, float hatY, float stickX, float stickY, float flatX, float flatY) {
        int hat = axisMask(hatX, hatY, .2f, .2f);
        axes = hat != 0 ? hat : axisMask(stickX, stickY, flatX, flatY);
    }
    private static boolean finite(float value) { return !Float.isNaN(value) && !Float.isInfinite(value); }
    private static int axisMask(float x, float y, float flatX, float flatY) {
        if (!finite(x) || !finite(y)) return 0;
        float dx = Math.max(.2f, finite(flatX) ? flatX : .2f);
        float dy = Math.max(.2f, finite(flatY) ? flatY : .2f);
        return (x < -dx ? 4 : x > dx ? 8 : 0) | (y < -dy ? 1 : y > dy ? 2 : 0);
    }
    public void shoulder(int bit, boolean down) {
        if (bit != 0 && bit != 1 && bit != 3) return;
        if (down) shoulders |= 1 << bit;
        else shoulders &= ~(1 << bit);
    }
    public int mask() { return (physical | touch | axes | shoulders) & 15; }
    public void clear() { physical = touch = axes = shoulders = 0; }
    public static boolean racing(String page) { return "/games/rc-trigger-racing/personal/vibe.html".equals(page); }
    public static boolean ghost(String page) {
        return "/games/arcadium-ghost-bubble/personal/vibe.html".equals(page)
            || "/games/arcadium-ghost-bubble/vibe.html".equals(page);
    }
    public static boolean ready(String page, boolean negotiated) {
        return ghost(page) || (negotiated && supports(page));
    }
    public static boolean boop(String page) { return "/games/arcadium-boop/personal/vibe.html".equals(page); }
    public static boolean sports(String page) { return "/games/worm-games-arcadium/personal/vibe.html".equals(page); }
    public String packet() {
        sequence = (sequence + 1) & 0xffffff;
        return String.format(java.util.Locale.ROOT, "H%06x%06x%x", session, sequence, mask());
    }
    public static boolean ghostAdvertisesHeld(String page, String game, int contract) {
        return contract == 1 && "arcadium-ghost-bubble".equals(game)
            && "/games/arcadium-ghost-bubble/personal/vibe.html".equals(page);
    }
    public static boolean known(String page) {
        return ghost(page) || racing(page) || "/games/wormaldeon/personal/vibe.html".equals(page)
            || "/games/npcs-non-playable-characters-of-real-life/personal/vibe.html".equals(page)
            || "/games/worm-games-arcadium/personal/vibe.html".equals(page)
            || "/games/crater-raiders/personal/vibe.html".equals(page)
            || "/games/what-the-freaking-price/personal/vibe.html".equals(page);
    }
    public static boolean supports(String page) {
        return page != null && (known(page) || page.matches("/games/[a-z0-9][a-z0-9-]*/personal/vibe\\.html"));
    }
}
