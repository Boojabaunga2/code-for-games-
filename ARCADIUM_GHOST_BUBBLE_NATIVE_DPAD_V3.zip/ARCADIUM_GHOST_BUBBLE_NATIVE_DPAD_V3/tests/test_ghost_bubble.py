import base64,hashlib,importlib.util,json,sys,tempfile,threading,time,unittest,urllib.request,urllib.error,zipfile
from pathlib import Path
from http.server import ThreadingHTTPServer
from harness import ROOT,ref,modules,updater,routes
old=sys.modules['harness'];sys.modules['harness']=ref
spec=importlib.util.spec_from_file_location('gb_rc_fixture',ROOT.parent/'rc-trigger-racing/tests/test_racing.py');fixture=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixture);sys.modules['harness']=old
class Install(unittest.TestCase):
 setUp=fixture.Install.setUp
 tearDown=fixture.Install.tearDown
 def seed(self):
  fixture.Install.seed(self);(self.root/'rc_racing_routes.py').write_bytes((ROOT.parent/'rc-trigger-racing/rc_racing_routes.py').read_bytes());file=self.root/'arcadium_game_bridge.py';file.write_text(ref.updater.patch_bridge(file.read_text()));return {p.relative_to(self.root).as_posix():p.read_bytes() for p in self.root.rglob('*') if p.is_file()}
 def test_install_repeat_rollback_preserves_home_and_previous_games(self):
  before=self.seed();first=updater.install(self.root);self.assertEqual(updater.patch_bridge((self.root/'arcadium_game_bridge.py').read_text()),(self.root/'arcadium_game_bridge.py').read_text());second=updater.install(self.root);updater.rollback(second)
  catalog=json.loads((self.root/'data/arcadium.json').read_text());games=[g for g in catalog['games'] if g['id']=='arcadium-ghost-bubble'];self.assertEqual(len(games),1);self.assertEqual(games[0]['miniVibeUrl'],'/games/arcadium-ghost-bubble/personal/vibe.html');updater.rollback(first)
  for name,data in before.items():
   if name!='data/arcadium.json':self.assertEqual((self.root/name).read_bytes(),data,name)
  self.assertEqual(json.loads((self.root/'data/arcadium.json').read_text())['games'],json.loads(before['data/arcadium.json'])['games'])
 def test_guards_and_existing_registration(self):
  self.seed();backup=updater.install(self.root);changed=self.root/'games/arcadium-ghost-bubble/mini-vibe.mjs';changed.write_text('later work');self.assertRaises(RuntimeError,updater.rollback,backup);self.assertEqual(changed.read_text(),'later work');c={'games':[{'id':'arcadium-ghost-bubble','image':'approved.png','custom':'KEEP','name':'Ghost Bubble'}]};updater.registration(c);self.assertEqual(c['games'][0]['image'],'approved.png');self.assertEqual(c['games'][0]['custom'],'KEEP');c['games'].append({'id':'ghost-bubble','name':'Ghost Bubble'});self.assertRaises(RuntimeError,updater.registration,c);(self.root/'arcadium_game_bridge.py').write_text('def bridge(Base):\n return Base\n');self.assertRaises(RuntimeError,updater.prepare,self.root)
 def test_exact_zip_and_signed_app(self):
  before=self.seed();archive=ROOT.parents[1]/'downloads/ARCADIUM_GHOST_BUBBLE_NATIVE_DPAD_V3.zip'
  with tempfile.TemporaryDirectory() as folder:
   with zipfile.ZipFile(archive) as z:z.extractall(folder)
   package=Path(folder)/archive.stem;apk=package/'Mini Vibe/Arcadium-Ghost-Bubble.apk';self.assertEqual(hashlib.sha256(apk.read_bytes()).hexdigest(),'ccb399a0e4a5585e66ebbb7983688a10cf2ee3b2b55bdc4da8bc581f8f86f713');self.assertTrue((package/'START_INSTALL.cmd').is_file());self.assertEqual(json.loads((package/'games/arcadium-ghost-bubble/input-capabilities.json').read_text())['arcadiumHeldDpad'],1)
   spec=importlib.util.spec_from_file_location('gb_release_updater',package/'update_ghost_bubble.py');release=importlib.util.module_from_spec(spec);spec.loader.exec_module(release);one=release.install(self.root);two=release.install(self.root);release.rollback(two);release.rollback(one);self.assertEqual((self.root/'arcadium_server.py').read_bytes(),before['arcadium_server.py']);self.assertEqual((self.root/'arcadium_game_bridge.py').read_bytes(),before['arcadium_game_bridge.py']);(package/'games/arcadium-ghost-bubble/mini-vibe.mjs').write_text('corrupted');self.assertRaises(RuntimeError,release.prepare,self.root)
class Routes(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.bridge,Handler=modules();cls.server=ThreadingHTTPServer(('127.0.0.1',0),Handler);cls.server.events={'latest':0,'events':[],'slots':[]};cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True);cls.thread.start();cls.base='http://127.0.0.1:'+str(cls.server.server_port)
 @classmethod
 def tearDownClass(cls):cls.server.shutdown();cls.server.server_close();cls.thread.join()
 def req(self,path,data=None):
  try:
   with urllib.request.urlopen(urllib.request.Request(self.base+path,data=None if data is None else json.dumps(data).encode(),headers={'Content-Type':'application/json'})) as r:return r.status,r.read()
  except urllib.error.HTTPError as e:return e.code,e.read()
 def test_recovery_contract_host_identity_and_renewal(self):
  self.req('/arcadium-vibe/activate/arcadium-ghost-bubble',{})
  mode=json.loads(self.req('/api/vibe/mode?color=red')[1]);self.assertEqual(mode['heldDpad'],1)
  self.req('/arcadium-vibe/activate/rc-trigger-racing',{})
  self.assertEqual(self.req('/arcadium-vibe/activate/arcadium-ghost-bubble',{'renew':True})[0],409)
  self.assertEqual(json.loads(self.req('/api/vibe/mode?color=red')[1])['game'],'rc-trigger-racing')
  self.req('/arcadium-vibe/activate/arcadium-ghost-bubble',{})
  self.bridge.ACTIVE_WEB_GAME['until']=0
  self.assertEqual(self.req('/arcadium-vibe/activate/arcadium-ghost-bubble',{'renew':True})[0],200)
  self.assertEqual(self.req('/arcadium-vibe/activate/arcadium-ghost-bubble',{'renew':1})[0],400)
  H=routes.wrap_ghost_bubble_handler(object)
  from types import SimpleNamespace
  same=SimpleNamespace(client_address=('192.168.1.10',40000),connection=SimpleNamespace(getsockname=lambda:('192.168.1.10',8787)))
  self.assertTrue(H._ghost_bubble_host(same))
  remote=SimpleNamespace(client_address=('192.168.1.11',40000),connection=SimpleNamespace(getsockname=lambda:('192.168.1.10',8787)))
  self.assertFalse(H._ghost_bubble_host(remote))
 def test_six_views_staleness_capability_and_rc_handoff(self):
  self.assertEqual(self.req('/arcadium-vibe/activate/arcadium-ghost-bubble',{})[0],200)
  for i,color in enumerate(routes.COLORS):
   self.assertEqual(json.loads(self.req('/api/vibe/mode?color='+color)[1])['game'],'arcadium-ghost-bubble');frame=b'\xff\xd8'+color.encode();self.assertEqual(self.req('/arcadium-bubble/arcadium-ghost-bubble/frame',{'seat':i+1,'image':base64.b64encode(frame).decode()})[0],200);self.assertEqual(self.req('/arcadium-bubble/arcadium-ghost-bubble/frame?color='+color),(200,frame))
  for path in ('index.html','mini-vibe.mjs','input-capabilities.json','held-dpad.js','assets/observatory-v1.png','personal/vibe.html'):self.assertEqual(self.req('/games/arcadium-ghost-bubble/'+path)[0],200)
  self.assertEqual(self.req('/games/arcadium-ghost-bubble/%2e%2e/%2e%2e/update_ghost_bubble.py')[0],404);routes.FRAMES[1]=(time.monotonic()-4,b'old');self.assertEqual(self.req('/arcadium-bubble/arcadium-ghost-bubble/frame?color=red')[0],503);self.assertEqual(self.req('/arcadium-bubble/arcadium-ghost-bubble/frame',{'seat':0,'image':'invalid'})[0],400)
  self.req('/arcadium-vibe/activate/rc-trigger-racing',{});self.req('/arcadium-vibe/activate/arcadium-ghost-bubble',{'active':False});self.assertEqual(json.loads(self.req('/api/vibe/mode?color=red')[1])['game'],'rc-trigger-racing');self.assertEqual(self.req('/api/vibe/events?after=0')[0],200);self.assertEqual(self.req('/unrelated')[0],200)
if __name__=='__main__':unittest.main()
