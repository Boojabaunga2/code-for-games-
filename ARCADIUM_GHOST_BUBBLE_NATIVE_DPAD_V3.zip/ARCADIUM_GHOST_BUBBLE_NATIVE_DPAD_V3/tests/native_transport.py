"""Exercise the exact input receiver methods from an explicitly supplied OS reference.
Only Handler.do_POST/body_json/json_out are compiled; no module initialization runs.
No venue tokens/configuration are read: test state and invitation are synthetic.
"""
import argparse,ast,json,sys,threading,time
from pathlib import Path
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from urllib.parse import urlparse
import harness

def receiver(reference):
 tree=ast.parse(reference.read_text(encoding='utf-8-sig'));source=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='Handler')
 methods=[n for n in source.body if isinstance(n,ast.FunctionDef) and n.name in ('do_POST','body_json','json_out')]
 assert len(methods)==3
 namespace={'SimpleHTTPRequestHandler':SimpleHTTPRequestHandler,'json':json,'threading':threading,'time':time,'urlparse':urlparse,'PINK_DEVICE_IP':None,'PINK_PAIR_UNTIL':0,'VIBE_LOCK':threading.RLock(),'VIBE_PAIR_TOKEN':'native-transport-test-invitation','VIBE_COLORS':('red','blue','green','yellow','pink','white'),'VIBE_SEQUENCE':0,'VIBE_EVENTS':[]}
 namespace['VIBE_SLOTS']={c:{'color':c,'connected':False,'lastSeen':0,'lastButton':'','count':0} for c in namespace['VIBE_COLORS']}
 node=ast.ClassDef(name='ExactReceiver',bases=[ast.Name(id='SimpleHTTPRequestHandler',ctx=ast.Load())],keywords=[],body=methods,decorator_list=[])
 module=ast.fix_missing_locations(ast.Module(body=[node],type_ignores=[]));exec(compile(module,'exact-input-receiver','exec'),namespace);return namespace
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--server-reference',type=Path,required=True);args=ap.parse_args();native=receiver(args.server_reference);Real=native['ExactReceiver'];bridge,Parent=harness.modules()
 class Handler(Parent):
  json_out=Real.json_out;body_json=Real.body_json
  def do_POST(self):
   if urlparse(self.path).path=='/api/vibe/input':
    Real.do_POST(self)
    with native['VIBE_LOCK']:self.server.events={'latest':native['VIBE_SEQUENCE'],'events':[dict(e) for e in native['VIBE_EVENTS']],'slots':[dict(s,connected=time.time()-s['lastSeen']<8) for s in native['VIBE_SLOTS'].values()]}
    return
   return super().do_POST()
 server=ThreadingHTTPServer(('127.0.0.1',8787),Handler);server.events={'latest':0,'events':[],'slots':[]};print('Exact reference native HTTP receiver + current full wrapper chain on 8787',flush=True);server.serve_forever()
