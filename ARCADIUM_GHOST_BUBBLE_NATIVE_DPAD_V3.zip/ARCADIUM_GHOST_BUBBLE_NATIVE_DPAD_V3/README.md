# Ghost Bubble Native D-pad V3 / Mini Vibe v15

**Already installed PC Repair V2? Leave the PC installation alone.** Install `Mini Vibe/Arcadium-Ghost-Bubble.apk` from this ZIP on each Mini Vibe as an update, keeping app data/pairing. No Windows restart is needed for this native app correction. The included PC installer remains available for a first installation; it includes the same game connection code as V2.

This version responds to the physical test where action buttons worked but the PC showed WAITING FOR HELD SIGNAL. Ghost Bubble now uses an exact native game scope, independent of capability downloads or a disabled negotiation flag. The held-state heartbeat runs throughout the connected controller session and is rearmed on mode/focus transitions, including unchanged mode replies. Focus loss clears held directions while retaining the session heartbeat. Both canonical and legacy viewer page paths are recognized. The native sender uses the same 1.6s request timeouts as the working action-button path and exposes the HTTP result instead of silently hiding it.

The Mini Vibe displays `MINI VIBE v15 / LEFT`, `RIGHT` or `RELEASED`, plus link status, so the installed version and captured direction are visible. The PC indicator receives actual complete-state packets; there is no tap latch, timer-based movement step or guessed release.

Signed APK build, Java held-input regression tests and signing-certificate comparison passed in workflow 41885450694. An end-to-end Chromium test posted authenticated held/release packets through the exact OS input receiver, then through numbered events into actual cannon aiming; an invalid invitation was rejected. All bundled Home assets remain byte-identical. Physical Mini Vibe acceptance remains pending until retest.

---

# Ghost Bubble Input Repair V2

This complete build supersedes the first Ghost Bubble package. It responds to the reported failure where A/B arrived but the D-pad did not; the supplied report showed connected Red, no held snapshots, controller mode, an inactive game lease and unavailable personal feeds. That report establishes the observed state, not the exact device-level cause.

**Install both parts:** run START_INSTALL.cmd on the PC, select Arcadium_OS_COMPACT and restart Windows once. Update each Mini Vibe with Mini Vibe/Arcadium-Ghost-Bubble.apk (**v15**), keeping app data and pairing even if v12 or v13 was installed. Older Ghost Bubble/Boop APKs do not contain this input-enablement correction. Boop shoulder controls and other game controls remain supported.

The PC advertises the verified held-direction contract in its active-mode response. The app enables Ghost Bubble from that response instead of depending on two additional capability downloads. Other games keep their existing capability checks. The game pauses when hidden/occluded while renewing only its own existing lease, so bringing another window over it does not expire the Mini Vibe view. A hidden old game cannot reclaim a lease taken by another game. Host requests also work when this PC opens its own LAN address; other LAN devices cannot produce frames or claim the game.

The lower-left PC indicator and personal screen show actual D-pad LEFT / RIGHT / RELEASED states or WAITING FOR HELD SIGNAL. These are received controller states, not guessed movement. Release still stops; there is no tap latch or timed movement pulse. Physical device acceptance remains unverified until the user retests.

---

# Arcadium Ghost Bubble / Mini Vibe Deluxe

Six-player shared-board bubble shooting on the existing Windows Arcadium OS, port **8787**. The original matching, bouncing shots, misses becoming ghosts, heart loss, player-ghost diving and 90-second match structure remain. The update adds a sharper observatory presentation, colour symbols, personal Mini Vibe cameras and three selectable ghost powers.

## Install

1. Exit any open game and extract the complete ZIP.
2. Double-click **START_INSTALL.cmd** and select the existing **Arcadium_OS_COMPACT** folder. The installer creates an automatic backup and preserves Home, the main server, other games, pairing and approved carousel art.
3. On the first Ghost Bubble installation, **restart Windows once** to load its new server helper. On a repeat installation with an unchanged helper, follow the refresh message instead.
4. On each Mini Vibe, install **Mini Vibe/Arcadium-Ghost-Bubble.apk** as an **update**. Keep app data and pairing; do not uninstall. This signed version 15 includes the Ghost Bubble input-enablement repair. The package ID and signing identity are retained.
5. Open Ghost Bubble from its existing Games carousel card. A joins; START begins. A single joined player gets one CPU opponent automatically.

This is an update to the existing 8787 OS, not a replacement OS or standalone server. Startup configuration is not changed. If an unknown bridge, duplicate registration or conflicting later edit is found, the installer stops without overwriting it.

## Physical controls

- **Hold LEFT / RIGHT:** aim the launcher; after elimination, steer your ghost. Release stops immediately. There is no tap latch or guessed key-release timer; a 450ms lost-link failsafe clears stale state.
- **A / R1:** fire a bubble; as a ghost, cast the selected power.
- **B / L1:** swap loaded/next bubble; as a ghost, select the next power.
- **X:** previous ghost power.
- **Y:** toggle your living-player camera between your lane and the whole board.
- **START:** ready/start, pause/resume, or play again after results.
- **SELECT:** clear your held input; leave a lobby slot.

The PC keeps the original six customisable keyboard layouts, mouse lobby and local gamepad support. **SPACE** fires P1 in play. **Shift + that player's fire key** cycles ghost power on a keyboard. Existing keyboard layouts are preserved. Native seats always follow **red, blue, green, yellow, pink, white**. Previously saved original colour IDs are migrated to a new score key without deleting the old score data.

The Mini Vibe shows actual game state. While alive, its personal camera centres your launcher and incoming threats, with a magnified aim-target inset, loaded/next bubbles, hearts, angle and score. After elimination, the camera follows your actual ghost and the power panel shows your target, power, availability, charges, cooldown and return penalty. There are no fake touch buttons or independent simulations.

## Ghost powers

- **Dive:** original ghost attack. Steer above a living player's lane, press A, and a **0.9-second warning** precedes the dive. A hit steals one heart and awards the original 150 points. It does not consume the extra-power charges. The original return/re-arm sequence remains.
- **Chill:** after a **0.9-second target warning**, aiming is reduced to **65% for two seconds**. It does not reverse input or stop movement. The target gains **six seconds of immunity** against another Chill. Casting at an empty/protected lane does not spend a charge.
- **Haunt Pulse:** after a **0.9-second warning**, adds **8 percentage points** to the shared haunt meter, capped at 100.

Chill and Haunt Pulse share **three charges per match** and an **eight-second cooldown**. Returning after being busted does not refill them. Matching-colour shots can bust a player ghost; it returns after the original **five-second penalty**. A cast is cancelled if its ghost is busted during the warning. Powers are unavailable during countdown, pause, results or the match-ending sequence. A new match resets hearts, ghosts and charges.

## Why one app update is included

Version 14 enables Ghost Bubble from its explicit active-mode contract. For other game pages it retains the capability-probe compatibility introduced in version 12. Unknown game pages must provide `input-capabilities.json` with `arcadiumHeldDpad: 1` and the existing `held-dpad.js` protocol asset. Older games without that opt-in keep their legacy input. Auction, bidding and RC/sports shoulder mappings remain scoped to their existing games. Future games using this compatible D-pad protocol can opt in on the PC without another per-game APK update.

## Backup, rollback and verification

The installer window includes **Rollback this update**. Select its `arcadium_backups/ghost_bubble_v1_*` backup. Later conflicting edits are protected. Reload the server after a rollback.

With Ghost Bubble open on the PC, double-click **VERIFY_GHOST_BUBBLE.py** to save a read-only route/frame report beside the verifier. It never sends controller input.

See **VALIDATION.md**, **CREDITS.md**, **APP_BUILD.json** and **ASSET_MANIFEST.json** for evidence. Automated tests do not establish physical-device latency, six real Mini Vibes, actual venue PLAY/carousel appearance or antivirus acceptance. Those still require a hardware test.
