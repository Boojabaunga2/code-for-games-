# Pacman Unity

This is a Pacman clone, developed with the [Unity 3D](http://unity3d.com) game engine.

This is a learning project and should not be taken as a best-practice example.
