"""Deterministic, complete offline web-game/source package."""
from pathlib import Path
import hashlib,json,zipfile,argparse
ROOT=Path(__file__).resolve().parent
EXCLUDE={'tests','review','__pycache__','.git'}
def files():
 return {p.relative_to(ROOT).as_posix():p.read_bytes() for p in sorted(ROOT.rglob('*')) if p.is_file() and not any(n in EXCLUDE for n in p.relative_to(ROOT).parts) and p.name not in ('CHECKSUMS.json','arcadium-location.json','.gitignore') and not p.name.endswith(('.pyc','.tmp','.zip'))}
def build(target):
 data=files();checks={n:hashlib.sha256(b).hexdigest() for n,b in sorted(data.items())};(ROOT/'CHECKSUMS.json').write_bytes((json.dumps(checks,indent=2)+'\n').encode());data['CHECKSUMS.json']=(ROOT/'CHECKSUMS.json').read_bytes();target=Path(target);target.parent.mkdir(parents=True,exist_ok=True)
 with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
  for n,b in sorted(data.items()):
   info=zipfile.ZipInfo('ARCADIUM_POP_A_SHOT_V1/'+n,(2026,11,9,0,0,0));info.create_system=3;info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,b)
 result={'file':target.name,'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'files':len(data)};print(json.dumps(result));return result
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--output',default=str(ROOT.parents[1]/'downloads/ARCADIUM_POP_A_SHOT_V1.zip'));build(ap.parse_args().output)
