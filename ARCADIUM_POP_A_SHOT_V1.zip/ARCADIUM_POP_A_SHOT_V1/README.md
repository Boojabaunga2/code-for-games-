# ARCADIUM · POP-A-SHOT SHOWDOWN

Complete main Windows Arcadium OS game. Six live hoops, canonical red / blue / green / yellow / pink / white seats, five 30-second elimination rounds. The ZIP contains game source, finished artwork, controller pages, shared-host integration, catalogue registration, installer/start launcher, checksums, verifier, and selective backup/restore.

## Load it

1. Extract the entire ZIP to a normal folder.
2. Close the current black Arcadium **server console**. Closing only the browser leaves the server running.
3. Double-click **START_INSTALL.cmd**.
4. Select your existing **Arcadium_OS_COMPACT** folder containing `arcadium_server.py`, `arcadium_game_bridge.py`, and `data/arcadium.json`.

The launcher verifies the package, backs up affected game/catalogue files, registers the game, and starts your existing server on **8787**. It opens the game after its live host responds. Keep that console open. On later runs, use this launcher again so the shared routes are available. The installed game is also accessible from the existing Games catalogue. No APK update, dependency download, new server, root Home replacement, or pairing reset.

Existing Python 3.9+ with Tkinter is required, as used by the Windows OS. The launcher does not install software or disable protection. `VERIFY_POP_A_SHOT.py` checks actual live routes and all six mode handoffs after launch. The user's specific catalogue/carousel layout and physical devices require on-PC acceptance.

## Play

Each player owns a separate digital hoop. Tap **A** when the moving release marker reaches the green window. Left/right adjusts aim; center aim is best. Shots have a short cadence cooldown, with no shot quota. Holding A is one press, not autofire. Every successful basket is **2 points**. All six players shoot simultaneously. Shots launched before the 30-second buzzer can finish; late inputs cannot create shots.

The lowest score has eight seconds to challenge second-to-last (**A**) or accept elimination (**B**). A timeout accepts elimination. Second-to-last then has eight seconds to accept (**A**) or decline (**B**). Declining or timing out eliminates the lowest player. Accepting reveals independently random in-game hands; the loser is eliminated. **If second-to-last accepts and wins, they begin the next round with +10.** If last place wins, they survive without that bonus.

Hands follow the supplied reference: rock beats scissors; paper beats rock; monkey beats paper; scissors beats monkey; ghost beats scissors; wild beats every other hand. Matching hands and unlisted pairings redraw. These are in-game cryptographic random hands, **not physical GoDice readings**. Scores reset each round; bonus applies once. Tied scores rank the earlier final basket ahead. All-zero ties rotate seat priority each round. Five eliminations leave a champion. Eliminated players spectate.

## Controls and practice

- Mini Vibe: **A** shoot / challenge / accept; **B** decline / accept elimination; **Left / Right** aim; **START** pause / resume.
- Personal screens show the PC's actual lane, score, timer, release marker, round and challenge role. They do not run a second simulation.
- PC: keys **1–6** shoot for red / blue / green / yellow / pink / white. Click a lane to select it; arrows aim, Space is A, B declines, Enter starts/pauses.
- Lobby seat buttons explicitly choose human or CPU. **CPU DEMO** starts all six CPU seats. Default is all six human. Sound starts off and can be enabled with the sound button.
- Losing browser focus pauses the game and clears input. Resume with START or the on-screen button. Leaving returns ownership to the OS. Another game activating displaces this game instead of having its lease stolen back.

## Restore

Close the server first. Run **RESTORE_POP_A_SHOT.py**, select the installation and this game's backup under `arcadium_backups/pop_a_shot_*`. Restore affects this game's files and catalogue entry only, retaining later unrelated catalogue edits. It refuses to overwrite later edits to this game's installed files or metadata.

## Validation limits

See VALIDATION.md for recorded checks. Automated integration uses a minimal original-server/bridge fixture and six real browser pages. It does not establish operation on six physical Mini Vibes, the recipient Windows graphics/antivirus environment, or the full installed OS catalogue. No physical hoop sensors or physical dice are connected by this digital game.
