import { Showdown, COLORS, HEX, HANDS } from "./engine.mjs";
import { lane, drawMini } from "./render.mjs";
const game = new Showdown(),
  slug = "pop-a-shot",
  base = "/arcadium-live/" + slug,
  owner = crypto.randomUUID?.() || String(Date.now()),
  readers = COLORS.map(() => ArcadiumInputState.create()),
  blocked = Array(6).fill(0),
  touch = Array(6).fill(0),
  touchAt = Array(6).fill(-Infinity),
  pads = Array(6).fill(0),
  previous = Array(6).fill(0),
  surfaces = COLORS.map(() =>
    Object.assign(document.createElement("canvas"), {
      width: 720,
      height: 720,
    }),
  );
for (const c of surfaces) c.getContext("2d", { willReadFrequently: true });
const el = (id) => document.getElementById(id),
  timers = [];
let render,
  active = false,
  ever = false,
  displaced = false,
  running = true,
  error = "",
  legacyCursor = null,
  touchCursor = null,
  legacyBusy = false,
  touchBusy = false,
  publishBusy = false,
  nextSeat = 0,
  last = 0,
  lastTurn = "",
  uiKey = "",
  localMask = 0,
  native,
  selectedSeat = 0,
  stageKey = "",
  renderTime = 0,
  viewTime = 0,
  soundOn = false,
  audio = null,
  scoreSnapshot = Array(6).fill(0),
  inputStats = {received:0, lastAge:null};
const fresh = (e, limit = 1000) => {
  let at = Number(e.at);
  if (at < 1e11) at *= 1000;
  return (
    Number.isFinite(at) && Date.now() - at >= -250 && Date.now() - at <= limit
  );
};
function mask(i) {
  return (
    (readers[i].read() & ~blocked[i]) |
    (Date.now() - touchAt[i] < 650 ? touch[i] : 0) |
    pads[i] |
    (i === selectedSeat ? localMask : 0)
  );
}
function clear() {
  for (let i = 0; i < 6; i++) {
    blocked[i] |= readers[i].read();
    readers[i].clear();
    touch[i] = pads[i] = previous[i] = 0;
    touchAt[i] = -Infinity;
  }
  localMask = 0;
}
async function req(path, body) {
  const c = new AbortController(),
    timer = setTimeout(() => c.abort(), 1800);
  try {
    const r = await fetch(path, {
      cache: "no-store",
      priority: body?.image ? "low" : "auto",
      signal: c.signal,
      ...(body
        ? {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(body),
          }
        : {}),
    });
    if (!r.ok) throw Error("HTTP " + r.status);
    return r.json();
  } finally {
    clearTimeout(timer);
  }
}
async function activate() {
  if (!running || displaced || document.hidden) return;
  try {
    await req("/arcadium-vibe/activate/" + slug, { owner, renew: ever });
    active = ever = true;
    error = "";
  } catch (e) {
    active = false;
    error = e.message;
    if (ever) {
      game.paused = true;
      clear();
    }
    if (ever && e.message === "HTTP 409") displaced = true;
  }
}
async function poll(kind) {
  if (
    !running ||
    displaced ||
    document.hidden ||
    (kind === "touch" ? touchBusy : legacyBusy)
  )
    return;
  kind === "touch" ? (touchBusy = true) : (legacyBusy = true);
  try {
    const cursor = kind === "touch" ? touchCursor : legacyCursor,
      d = await req(
        kind === "touch"
          ? base + "/touch/events?after=" + (cursor ?? 0)
          : "/api/vibe/events?after=" + (cursor ?? 0),
      );
    if (cursor !== null && d.latest >= cursor)
      for (const e of d.events
        .filter((e) => e.seq > cursor)
        .sort((a, b) => a.seq - b.seq)) {
        const i = COLORS.indexOf(e.color);
        if (
          i < 0 ||
          !fresh(e, kind === "touch" && e.key?.startsWith("M") ? 650 : 1200)
        )
          continue;
        if (kind === "touch") {
          if (e.turnId !== game.turnId) continue;
          if (/^M[\da-f]{3}$/i.test(e.key)) {
            touch[i] = parseInt(e.key.slice(1), 16);
            touchAt[i] = Date.now();
          } else action(i, e.key);
        } else if (
          !readers[i].seen &&
          ["A", "B", "L1", "R1", "START"].includes(e.button)
        )
          action(i, e.button);
      }
    if (kind === "touch") touchCursor = d.latest;
    else legacyCursor = d.latest;
  } catch (e) {
    error = e.message;
  } finally {
    kind === "touch" ? (touchBusy = false) : (legacyBusy = false);
  }
}
async function publish() {
  if (!active || !running || publishBusy || displaced || document.hidden)
    return;
  publishBusy = true;
  try {
    const state = {
      phase: ({round:"play",champion:"finished",buzzer:"results",risk:"results",decision:"results",duel:"results",result:"results"})[game.phase] || game.phase,
      paused: game.paused,
      turnId: game.turnId,
      dashboards: COLORS.map((_, i) => game.dashboard(i)),
    };
    const packets = surfaces.map((c, i) => {
      drawMini(c.getContext("2d"), game, i);
      return {
        owner,
        seat: i + 1,
        image: c.toDataURL("image/jpeg", 0.66).split(",")[1],
        state,
      };
    });
    await Promise.all(packets.map((packet) => req(base + "/frame", packet)));
  } catch (e) {
    error = e.message;
  } finally {
    publishBusy = false;
  }
}
const icons=[
 '<path d="M7 16v-5c0-3 4-3 4 0V7c0-3 4-3 4 0v4-5c0-3 4-3 4 0v6-3c0-3 4-3 4 0v10c0 5-3 8-7 8h-4c-4 0-8-8-8-10 0-3 3-3 5-1l2 2"/>',
 '<path d="M7 17V8c0-3 4-3 4 0v8V5c0-3 4-3 4 0v11V4c0-3 4-3 4 0v12V7c0-3 4-3 4 0v12l1-4c1-3 5-2 4 1l-2 8c-1 4-5 6-9 6-5 0-7-3-9-7l-4-6c-2-3 1-5 3-3l4 4"/>',
 '<circle cx="6" cy="17" r="5"/><circle cx="26" cy="17" r="5"/><circle cx="16" cy="17" r="12"/><path d="M7 19c0-10 8-11 9-5 4-7 11-4 10 4M9 21c4 8 11 8 15-1"/><circle cx="12" cy="17" r="1"/><circle cx="21" cy="17" r="1"/>',
 '<circle cx="8" cy="23" r="5"/><circle cx="24" cy="23" r="5"/><path d="M11 19 25 3M21 19 7 3"/><circle cx="16" cy="14" r="1.5"/>',
 '<path d="M5 28V15C5-2 27-2 27 15v13l-5-4-6 5-6-5Z"/><ellipse cx="12" cy="13" rx="2" ry="3"/><ellipse cx="21" cy="13" rx="2" ry="3"/><path d="M13 21q3 3 6 0"/>',
 '<path d="m16 2 4 9 10 1-8 7 2 11-8-6-9 6 2-11-8-7 11-1Z"/>'
];
const trophy='<svg class="trophy" viewBox="0 0 160 120" aria-label="Champion trophy"><defs><linearGradient id="goldcup"><stop stop-color="#ffd34a"/><stop offset=".4" stop-color="#fff1a6"/><stop offset=".7" stop-color="#d58108"/><stop offset="1" stop-color="#fff58c"/></linearGradient></defs><path d="M50 18H110L103 55Q100 76 80 82Q60 76 57 55Z" fill="url(#goldcup)" stroke="#fff4b0" stroke-width="2"/><path d="M51 26H32Q24 62 61 65M109 26H128Q136 62 99 65" fill="none" stroke="url(#goldcup)" stroke-width="8"/><path d="M78 81H83V101H103V110H57V101H78Z" fill="url(#goldcup)"/><text x="80" y="58" text-anchor="middle" font-family="Arial" font-style="italic" font-weight="900" font-size="32" fill="#4c2b05">A</text></svg>';
const svg=i=>`<svg viewBox="0 0 32 32" aria-hidden="true">${icons[i]}</svg>`;
el('handLegend').innerHTML=HANDS.map((n,i)=>`<div class="hand-small" style="color:${HEX[i]}">${svg(i)}<small>${n}</small></div>`).join('');
const laneCanvases=[];
for(let i=0;i<6;i++){
 const card=document.createElement('section');card.className='lane';card.style.setProperty('--c',HEX[i]);card.id='lane-'+i;
 card.innerHTML=`<div class="lane-head"><span class="seat">P${i+1}</span><strong>${COLORS[i].toUpperCase()}</strong><button class="seat-type" id="type-${i}" aria-label="Toggle ${COLORS[i]} human or CPU">HUMAN</button></div><canvas width="720" height="480" aria-label="${COLORS[i]} live hoop"></canvas><div class="lane-score"><small>SCORE</small><b id="score-${i}">00</b></div><button class="shoot" id="shoot-${i}">A SHOOT · ${i+1}</button>`;
 el('lanes').append(card);laneCanvases.push(card.querySelector('canvas'));
 card.onclick=()=>selectedSeat=i;
 el('type-'+i).onclick=e=>{e.stopPropagation();if(game.phase==='lobby')game.players[i].human=!game.players[i].human;};
 el('shoot-'+i).onclick=e=>{e.stopPropagation();selectedSeat=i;action(i,'A');};
}
render={draw:()=>laneCanvases.forEach((c,i)=>lane(c.getContext('2d'),game,i,c.width,c.height))};
function tone(freq,duration=.1,type='sine',volume=.08){if(!soundOn||!audio)return;const o=audio.createOscillator(),g=audio.createGain();o.type=type;o.frequency.setValueAtTime(freq,audio.currentTime);g.gain.setValueAtTime(volume,audio.currentTime);g.gain.exponentialRampToValueAtTime(.001,audio.currentTime+duration);o.connect(g);g.connect(audio.destination);o.start();o.stop(audio.currentTime+duration);}
function action(i,key){
 if(displaced||document.hidden||!active||!game.players[i])return false;
 if(game.phase==='lobby'){if(key==='A')game.join(i);else if(key==='START'){game.join(i);game.start();clear();}return true;}
 if(key==='START'){const r=game.action(i,key);clear();return r;}
 const result=game.action(i,key);if(result&&key==='A'&&game.phase==='round')tone(140,.08,'triangle');return result;
}
function roleName(i){return COLORS[i]?.toUpperCase()||'';}
function die(i,hand){return `<div class="die-wrap" style="--c:${HEX[i]}"><strong>${roleName(i)}</strong><div class="die">${svg(hand)}</div><b>${HANDS[hand]}</b></div>`;}
function stageView(){
 const key=game.turnId;if(stageKey===key)return;stageKey=key;
 const phase=game.phase;el('stage').hidden=['round','countdown','buzzer'].includes(phase);
 let html='';
 if(phase==='lobby')html=`<div class="stage-card lobby"><div class="lobby-top"><img class="cover" src="card.png" alt="Pop-A-Shot Showdown cover"><div><small>ARCADIUM</small><h1>POP-A-SHOT<br>SHOWDOWN</h1></div></div><p>Tap A in the green. Every basket counts.<br>Choose your human and CPU seats.</p><div class="seat-setup">${COLORS.map((c,i)=>`<button id="setup-${i}" style="--c:${HEX[i]}">${c.toUpperCase()}<span>HUMAN</span></button>`).join('')}</div><div class="actions"><button id="allHuman">ALL HUMAN</button><button id="demo">CPU DEMO</button><button id="start" class="primary">START SHOWDOWN →</button></div></div>`;
 if(phase==='risk')html=`<div class="stage-card"><small>LOWEST SCORE · ROUND ${game.round}</small><h1 style="color:${HEX[game.low]}">${roleName(game.low)} IS AT RISK</h1><p>Challenge ${roleName(game.second)} for a chance to stay in.<br>Your Mini Vibe: A challenge · B accept elimination.</p><div class="actions"><button class="primary" id="challenge">A · CHALLENGE</button><button class="danger" id="eliminate">B · ACCEPT ELIMINATION</button></div><div class="count" id="decisionClock"></div></div>`;
 if(phase==='decision')html=`<div class="stage-card"><small>CHALLENGE ISSUED BY ${roleName(game.low)}</small><h1 style="color:${HEX[game.second]}">${roleName(game.second)},<br>ACCEPT THE RISK?</h1><p>Win and take +10 into the next round.<br>Lose and you are eliminated. Decline to send ${roleName(game.low)} home.</p><div class="actions"><button class="primary gold" id="accept">A · ACCEPT CHALLENGE</button><button class="danger" id="decline">B · DECLINE</button></div><div class="count" id="decisionClock"></div></div>`;
 if(phase==='duel'){const d=game.duel;html=`<div class="stage-card"><small>THE CHALLENGE · DRAW ${d.number}</small><h1>${d.draw?'NO WINNER · REDRAW':'SHOW YOUR HAND'}</h1><div class="duel-pair">${die(d.seats[0],d.hands[0])}<span class="versus">VS</span>${die(d.seats[1],d.hands[1])}</div><p>${d.draw?'Equal hands or no listed matchup. New hands coming.':roleName(d.seats[d.win])+' WINS THE CHALLENGE'}</p></div>`;tone(d.draw?280:740,.25);}
 if(phase==='result'){const r=game.result;html=`<div class="stage-card"><small>ROUND ${game.round} COMPLETE</small><h1 style="color:${HEX[r.out]}">${roleName(r.out)} IS OUT</h1><p>${r.reason}</p>${r.bonusSeat!==null?`<h1 class="bonus">+10</h1><p>${roleName(r.bonusSeat)} · NEXT ROUND BONUS</p>`:'<p>The remaining players return to the court.</p>'}</div>`;tone(95,.4,'sawtooth',.035);}
 if(phase==='champion')html=`<div class="stage-card"><small>POP-A-SHOT SHOWDOWN</small>${trophy}<h1 class="champion">${roleName(game.winner)}<br>CHAMPION</h1><p>Five rounds. Last player standing.</p><div class="actions"><button class="primary gold" id="replay">PLAY AGAIN →</button></div></div>`;
 el('stageContent').innerHTML=html;
 const bind=(id,fn)=>{if(el(id))el(id).onclick=fn;};
 bind('start',()=>{if(active){game.start();clear();}});bind('allHuman',()=>game.players.forEach(p=>p.human=true));
 for(let i=0;i<6;i++)bind('setup-'+i,()=>{game.players[i].human=!game.players[i].human;});bind('demo',()=>{game.players.forEach(p=>p.human=false);game.start();clear();});
 bind('challenge',()=>action(game.low,'A'));bind('eliminate',()=>action(game.low,'B'));
 bind('accept',()=>action(game.second,'A'));bind('decline',()=>action(game.second,'B'));bind('replay',()=>{game.lobby();clear();});
}
function view(){
 stageView();el('pauseScreen').hidden=!game.paused;el('pause').disabled=['lobby','champion'].includes(game.phase);el('pause').textContent=game.paused?'RESUME':'PAUSE';
 el('roundLabel').textContent=game.round?'ROUND '+game.round:'SHOWDOWN';el('clockLabel').textContent=game.phase==='round'?'TIME REMAINING':game.phase==='countdown'?'GET READY':game.phase==='buzzer'?'BUZZER':'THE SHOWDOWN';
 el('clock').textContent=game.phase==='round'||game.phase==='countdown'?'00:'+String(Math.ceil(game.clock)).padStart(2,'0'):game.phase==='lobby'?'00:30':game.phase==='champion'?'WIN!':'—';
 el('connection').textContent=displaced?'ANOTHER GAME IS ACTIVE · REOPEN SHOWDOWN':active?'MINI VIBES · LIVE':'CONNECTING · '+error;
 if(el('start'))el('start').disabled=!active;
 if(el('decisionClock'))el('decisionClock').textContent=Math.ceil(game.clock)+'s TO DECIDE';
 for(const p of game.players){const i=p.i;el('score-'+i).textContent=String(p.score).padStart(2,'0');el('type-'+i).textContent=p.human?'HUMAN':'CPU';if(el('setup-'+i))el('setup-'+i).querySelector('span').textContent=p.human?'HUMAN':'CPU';el('type-'+i).disabled=game.phase!=='lobby';el('shoot-'+i).disabled=game.phase!=='round'||!p.alive||!p.human||game.paused;
  el('lane-'+i).className='lane'+(!p.alive?' out':'')+(selectedSeat===i?' selected':'')+(game.low===i&&['risk','decision'].includes(game.phase)?' risk':'');
  if(p.score>scoreSnapshot[i])tone(650+p.i*30,.13);scoreSnapshot[i]=p.score;
 }
 const ranking=game.rank();const rankKey=JSON.stringify([game.round,game.players.map(p=>[p.alive,p.score])]);
 if(uiKey!==rankKey){uiKey=rankKey;el('standings').innerHTML=[...ranking,...game.players.filter(p=>!p.alive)].map((p,j)=>`<div class="rank-row${p.alive?'':' out'}" style="--c:${HEX[p.i]}"><span class="pos">${p.alive?j+1:'×'}</span><strong>${p.color.toUpperCase()}</strong><b>${p.score}</b></div>`).join('');}
 const phase=game.phase,alive=game.players.filter(p=>p.alive).length;
 el('banner').textContent=phase==='round'?'SHOOT!':phase==='buzzer'?'BUZZER':phase==='countdown'?'GET READY':phase==='lobby'?'YOUR COURT. YOUR COLOUR.':phase==='champion'?roleName(game.winner)+' TAKES THE CROWN':game.low!==null?roleName(game.low)+' IN DANGER':'THE SHOWDOWN';
 el('subBanner').textContent=phase==='round'?'Tap A when the release meter reaches green.':phase==='buzzer'?'Finishing shots already in the air.':phase==='lobby'?'Choose human or CPU for each seat.':alive+' PLAYERS REMAINING';
 el('matchStatus').textContent=phase==='round'?alive+' PLAYERS ON COURT':phase==='risk'?roleName(game.low)+' · LOWEST SCORE':phase==='decision'?roleName(game.second)+' IS DECIDING':phase==='duel'?'THE CHALLENGE':phase==='champion'?'LAST PLAYER STANDING':'SIX START. ONE TAKES THE CROWN.';
}
function logic(time){
 const dt=Math.min(.05,(time-last)/1000||0);last=time;
 if(lastTurn!==game.turnId){lastTurn=game.turnId;clear();}
 const gp=navigator.getGamepads?.()||[];
 for(let i=0;i<6;i++){
  const p=gp[i];pads[i]=p?((p.axes[0]<-.3||p.buttons[14]?.pressed?4:0)|(p.axes[0]>.3||p.buttons[15]?.pressed?8:0)|(p.buttons[0]?.pressed?16:0)|(p.buttons[1]?.pressed?32:0)|(p.buttons[9]?.pressed?256:0)):0;
  const m=mask(i),edge=m&~previous[i];if(active&&!displaced){game.adjust(i,Number(!!(m&8))-Number(!!(m&4)),dt);for(const [b,k]of[[16,'A'],[32,'B'],[256,'START']])if(edge&b)action(i,k);}previous[i]=m;
 }
 if(active&&!displaced)game.update(dt);
 if(time-viewTime>80){viewTime=time;view();}
}
function frame(time){if(time-renderTime>48){renderTime=time;render.draw();}if(running)requestAnimationFrame(frame);}
function pause(){if(!['lobby','champion'].includes(game.phase)){game.paused=!game.paused;clear();}}
el('pause').onclick=el('resume').onclick=pause;
el('new').onclick=()=>{if(['lobby','champion'].includes(game.phase)||confirm('End this showdown and start a new match?')){game.lobby();clear();}};
el('help').onclick=()=>{if(!['lobby','champion'].includes(game.phase)&&!game.paused)pause();el('rules').showModal();};el('closeHelp').onclick=()=>el('rules').close();
el('sound').onclick=async()=>{soundOn=!soundOn;if(soundOn){audio??=new (window.AudioContext||window.webkitAudioContext)();await audio.resume();tone(600,.12);}el('sound').textContent=soundOn?'SOUND ON':'SOUND OFF';};
addEventListener('keydown',e=>{
 if(el('rules').open)return;if(['ArrowLeft','ArrowRight',' ','Enter'].includes(e.key))e.preventDefault();
 const bit={ArrowLeft:4,ArrowRight:8}[e.key];if(bit){localMask|=bit;return;}if(e.repeat)return;
 if(/^[1-6]$/.test(e.key)){selectedSeat=+e.key-1;action(selectedSeat,'A');}
 if(e.key===' ')action(selectedSeat,'A');if(e.key.toLowerCase()==='b')action(selectedSeat,'B');if(e.key==='Enter')action(selectedSeat,'START');if(e.key==='Escape')pause();
});
addEventListener('keyup',e=>localMask&=~({ArrowLeft:4,ArrowRight:8}[e.key]||0));
function lose(){clear();if(!['lobby','champion'].includes(game.phase))game.paused=true;}
addEventListener('blur',lose);document.addEventListener('visibilitychange',()=>{if(document.hidden)lose();else{legacyCursor=touchCursor=null;activate();}});
function exit(){if(!running)return;running=false;clear();native?.stop();timers.forEach(clearInterval);audio?.close();fetch('/arcadium-vibe/activate/'+slug,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({owner,active:false}),keepalive:true}).catch(()=>{});}
el('exit').onclick=e=>{e.preventDefault();exit();if(parent!==window)parent.postMessage({type:'ARCADIUM_GAME_EXIT',game:slug},'*');else location.href='/';};addEventListener('pagehide',exit);
window.POP_A_SHOT={game,action,mask,clear,surfaces,publish,render,exit,get active(){return active},get displaced(){return displaced},get error(){return error},get input(){return {...inputStats,raw:readers.map(r=>r.read()),blocked:blocked.slice()}}};
native=ArcadiumInputState.connect({onEvent:e=>{inputStats.received++;inputStats.lastAge=Date.now()-Number(e.at);const i=COLORS.indexOf(e.color);if(i>=0&&!displaced&&fresh(e,650)){readers[i].receive(e.button);blocked[i]&=readers[i].read();}},onReset:clear,onError:e=>{if(e)error=e;}});
await activate();await poll('legacy');await poll('touch');view();
timers.push(setInterval(()=>logic(performance.now()),16),setInterval(activate,2200),setInterval(()=>poll('legacy'),45),setInterval(()=>poll('touch'),45),setInterval(publish,250));requestAnimationFrame(frame);
