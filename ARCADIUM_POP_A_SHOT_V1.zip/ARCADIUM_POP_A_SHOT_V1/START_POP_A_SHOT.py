"""Install one game, then run the existing Arcadium server on its existing 8787 port."""
from pathlib import Path
import datetime,hashlib,importlib,json,os,runpy,socket,sys,threading,time,urllib.request,webbrowser
SOURCE=Path(__file__).resolve().parent
SLUG='pop-a-shot'
def digest(data):return hashlib.sha256(data).hexdigest()
def atomic(path,data):
 path=Path(path);tmp=path.with_name(path.name+'.pop-a-shot.tmp')
 try:tmp.write_bytes(data);os.replace(tmp,path)
 finally:tmp.unlink(missing_ok=True)
def verify_package():
 checks=json.loads((SOURCE/'CHECKSUMS.json').read_text(encoding='utf-8'))
 for name,expected in checks.items():
  p=(SOURCE/name).resolve()
  if not p.is_relative_to(SOURCE) or not p.is_file() or digest(p.read_bytes())!=expected:raise RuntimeError('Package file missing or changed: '+name+'. Extract the complete ZIP again.')
def install_game(root):
 verify_package();root=Path(root).resolve()
 for name in ['arcadium_server.py','arcadium_game_bridge.py','data/arcadium.json']:
  if not (root/name).is_file():raise RuntimeError('Select your existing Arcadium_OS_COMPACT folder containing '+name)
 db=json.loads((root/'data/arcadium.json').read_text(encoding='utf-8-sig'))
 if not isinstance(db.get('games'),list):raise RuntimeError('Unrecognized game catalogue; nothing changed.')
 rows=[g for g in db['games'] if g.get('id')==SLUG]
 if len(rows)>1:raise RuntimeError('Duplicate Pop-A-Shot Showdown catalogue entries; nothing changed.')
 old_entry=json.loads(json.dumps(rows[0])) if rows else None
 meta=json.loads((SOURCE/'games'/SLUG/'arcadium-game.json').read_text(encoding='utf-8'))
 if rows:rows[0].update(meta);new_entry=rows[0]
 else:db['games'].append(meta);new_entry=meta
 writes={Path('data/arcadium.json'):(json.dumps(db,ensure_ascii=False,indent=2)+'\n').encode()}
 for p in (SOURCE/'games'/SLUG).rglob('*'):
  if p.is_file():writes[Path('games')/SLUG/p.relative_to(SOURCE/'games'/SLUG)]=p.read_bytes()
 for rel in writes:
  if not (root/rel).resolve().is_relative_to(root):raise RuntimeError('Destination escapes the selected folder.')
 changed={rel:data for rel,data in writes.items() if not (root/rel).is_file() or (root/rel).read_bytes()!=data}
 if not changed:return None
 backup=root/'arcadium_backups'/('pop_a_shot_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f'));backup.mkdir(parents=True)
 record={'root':str(root),'oldEntry':old_entry,'newEntry':new_entry,'files':{}}
 for rel,data in changed.items():
  dst=root/rel;record['files'][rel.as_posix()]={'existed':dst.is_file(),'new_sha256':digest(data)}
  if dst.is_file():saved=backup/rel;saved.parent.mkdir(parents=True,exist_ok=True);saved.write_bytes(dst.read_bytes())
 (backup/'manifest.json').write_text(json.dumps(record,indent=2))
 done=[]
 try:
  for rel,data in changed.items():dst=root/rel;dst.parent.mkdir(parents=True,exist_ok=True);atomic(dst,data);done.append(rel)
 except Exception:
  for rel in reversed(done):
   if record['files'][rel.as_posix()]['existed']:atomic(root/rel,(backup/rel).read_bytes())
   else:(root/rel).unlink(missing_ok=True)
  raise
 return backup
def rollback(root,backup):
 root=Path(root).resolve();backup=Path(backup).resolve();record=json.loads((backup/'manifest.json').read_text(encoding='utf-8'))
 if Path(record['root']).resolve()!=root or not backup.is_relative_to(root/'arcadium_backups'):raise RuntimeError('Backup does not belong to this installation.')
 db=json.loads((root/'data/arcadium.json').read_text(encoding='utf-8-sig'));rows=[g for g in db['games'] if g.get('id')==SLUG]
 if rows!=[record['newEntry']]:raise RuntimeError('Pop-A-Shot Showdown metadata changed later; rollback stopped to preserve it.')
 for name,entry in record['files'].items():
  if name=='data/arcadium.json':continue
  path=(root/name).resolve()
  if not path.is_relative_to(root/'games'/SLUG) or not path.is_file() or digest(path.read_bytes())!=entry['new_sha256']:raise RuntimeError('Game file changed later: '+name+'. Rollback stopped.')
 for name,entry in record['files'].items():
  if name=='data/arcadium.json':continue
  if entry['existed']:atomic(root/name,(backup/name).read_bytes())
  else:(root/name).unlink()
 if record['oldEntry'] is None:db['games']=[g for g in db['games'] if g.get('id')!=SLUG]
 else:rows[0].clear();rows[0].update(record['oldEntry'])
 atomic(root/'data/arcadium.json',(json.dumps(db,ensure_ascii=False,indent=2)+'\n').encode())
def port_open():
 try:
  with socket.create_connection(('127.0.0.1',8787),timeout=.4):return True
 except OSError:return False
def choose_root():
 from tkinter import filedialog
 cfg=SOURCE/'arcadium-location.json'
 if cfg.is_file():
  try:
   root=Path(json.loads(cfg.read_text(encoding='utf-8'))['root'])
   if (root/'arcadium_server.py').is_file():return root
  except (OSError,ValueError,KeyError):pass
 p=filedialog.askdirectory(title='Select your existing Arcadium_OS_COMPACT folder');return Path(p) if p else None
def run_existing_server(root,open_browser=True):
 root=Path(root).resolve();sys.path.insert(0,str(SOURCE));sys.path.insert(0,str(root));os.chdir(root)
 import importlib.util
 def bundled(name,file):
  spec=importlib.util.spec_from_file_location(name,SOURCE/file);mod=importlib.util.module_from_spec(spec);sys.modules[name]=mod;spec.loader.exec_module(mod);return mod
 arcadium_live_host=bundled('_arcadium_pop_live','arcadium_live_host.py');arcadium_native_routes=bundled('_arcadium_pop_native','arcadium_native_routes.py')
 bridge=importlib.import_module('arcadium_game_bridge')
 if not callable(getattr(bridge,'bridge',None)) or not hasattr(bridge,'ACTIVE_WEB_GAME') or not hasattr(bridge,'ACTIVE_LOCK'):raise RuntimeError('Existing shared Arcadium bridge is unavailable. No server source was changed.')
 existing=bridge.bridge
 def wrapped(base):return arcadium_live_host.wrap_live_handler(arcadium_native_routes.wrap_native_input_handler(existing(base)),root/'games')
 bridge.bridge=wrapped
 print('Starting your existing Arcadium server on 8787. Existing Home, pairing and games remain in place.')
 def ready():
  for _ in range(100):
   time.sleep(.2)
   try:
    with urllib.request.urlopen('http://127.0.0.1:8787/arcadium-live/'+SLUG+'/status',timeout=.5) as response:
     if json.load(response).get('protocol')==1:webbrowser.open('http://127.0.0.1:8787/games/'+SLUG+'/index.html');return
   except (OSError,ValueError):pass
 if open_browser:threading.Thread(target=ready,daemon=True).start()
 sys.argv=[str(root/'arcadium_server.py')];runpy.run_path(str(root/'arcadium_server.py'),run_name='__main__')
def main():
 import tkinter as tk
 from tkinter import messagebox
 ui=tk.Tk();ui.withdraw()
 try:
  verify_package();root=choose_root()
  if root is None:return
  while port_open():
   if not messagebox.askretrycancel('Close the running Arcadium server','Close the existing black Arcadium SERVER console, then choose Retry. Closing only the browser is not enough. This launcher will not kill processes.'):return
  backup=install_game(root);atomic(SOURCE/'arcadium-location.json',json.dumps({'root':str(root.resolve())}).encode())
  if backup:print('Automatic game/data backup:',backup)
 except Exception as e:messagebox.showerror('Pop-A-Shot Showdown could not start',str(e));return
 finally:ui.destroy()
 run_existing_server(root)
if __name__=='__main__':main()
