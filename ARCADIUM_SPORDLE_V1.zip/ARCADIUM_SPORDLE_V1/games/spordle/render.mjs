import {ROWS,HEX,COLORS} from './engine.mjs';
export const marks=['#30354e','#ad8433','#267a60'];
export function hits(){const out=[];ROWS.forEach((row,r)=>{const w=r===1?65:63,x=(720-row.length*w)/2;row.forEach((k,c)=>out.push({k:'KEY_'+k,x:x+c*w+2,y:475+r*53,w:w-4,h:47,r,c}));});return out;}
export const KEY_HITS=hits();
export const ACTION_HITS=[{k:'A',x:28,y:654,w:125,h:48},{k:'B',x:160,y:654,w:120,h:48},{k:'START',x:545,y:654,w:148,h:48},{k:'L1',x:300,y:654,w:90,h:48},{k:'R1',x:400,y:654,w:125,h:48}];
function box(g,x,y,w,h,color,r=10){g.fillStyle=color;g.beginPath();g.roundRect(x,y,w,h,r);g.fill();}
function txt(g,t,x,y,size=22,color='#e8efff',align='left'){g.fillStyle=color;g.font=`700 ${size}px Arial`;g.textAlign=align;g.fillText(String(t),x,y);}
export function mini(g,d,images){g.clearRect(0,0,720,720);const bg=g.createLinearGradient(0,0,720,720);bg.addColorStop(0,'#21133c');bg.addColorStop(1,'#070c22');g.fillStyle=bg;g.fillRect(0,0,720,720);const i=d.seat,c=HEX[i];
 box(g,18,16,684,73,'#32234c');txt(g,'ARCADIUM',35,43,14,'#6eeafa');txt(g,'SPORDLE',35,74,30,'#fff');txt(g,`${COLORS[i].toUpperCase()} · ${d.name}`,690,46,18,c,'right');txt(g,d.paused?'PAUSED':`ROUND ${d.round} · ${Math.max(0,Math.ceil(d.limit-d.elapsed))}s`,690,75,21,'#ffe391','right');
 const normal=d.phase==='play'||d.phase==='countdown';
 if(d.phase==='lobby'){g.drawImage(images[i],230,100,260,278);txt(g,d.human?'YOU ARE READY':'A TO JOIN',360,420,38,c,'center');txt(g,'Private board · Same secret word · Six guesses',360,468,22,'#bfc8e3','center');txt(g,'A join • START begin • Empty seats are CPU',360,512,22,'#bfc8e3','center');}
 else if(normal&&d.alive){
  for(let r=0;r<6;r++)for(let n=0;n<5;n++){const guess=d.guesses[r],letter=guess?.word[n]||(r===d.guesses.length?d.draft[n]:'')||'',x=196+n*65,y=103+r*59;box(g,x,y,56,52,guess?marks[guess.marks[n]]:'#191b36',7);g.strokeStyle=letter?'#9990bc':'#46415f';g.lineWidth=1.4;g.strokeRect(x+2,y+2,52,48);txt(g,letter,x+28,y+36,31,'#fff','center');}
  g.drawImage(images[i],15,160,163,175);txt(g,d.solved!==null?'EUREKA!':d.done?'OUT OF GUESSES':'THINK FAST',96,356,17,c,'center');txt(g,d.message||'Your guesses stay on your Mini Vibe',360,465,18,'#dfd3f2','center');
  for(const h of KEY_HITS){const key=h.k.slice(4),selected=d.cursor[0]===h.r&&d.cursor[1]===h.c;box(g,h.x,h.y,h.w,h.h,d.keys[key]!==undefined?marks[d.keys[key]]:'#3a3259',7);if(selected){g.strokeStyle='#71f7ff';g.lineWidth=3;g.strokeRect(h.x+1,h.y+1,h.w-2,h.h-2);}txt(g,key==='BACK'?'⌫':key,h.x+h.w/2,h.y+31,key.length>1?12:24,'#fff','center');}
  if(d.phase==='countdown'){box(g,270,230,180,130,'#1b123af2');txt(g,Math.ceil(d.countdown),360,321,88,'#ffe391','center');}
 }else{
  g.drawImage(images[i+(d.alive?0:6)],20,133,203,218);const cdata=d.challenge,participant=cdata&&[cdata.challenger,cdata.opponent].includes(i);
  txt(g,d.phase==='finished'?(d.winner===i?'CHAMPION!':'MATCH COMPLETE'):!d.alive?'GHOST GENIUS':'STILL IN THE RACE',440,139,28,c,'center');
  if(d.phase==='results'&&cdata?.offer&&cdata.challenger===i){txt(g,'ONE COMEBACK CHANCE',446,203,24,'#ffe391','center');txt(g,'Challenge '+COLORS[cdata.opponent].toUpperCase(),446,243,23,'#fff','center');txt(g,'to a real-coin Flip-Off?',446,277,22,'#d3c4eb','center');}
  else if(d.phase==='flip'&&participant){txt(g,'FLIP YOUR REAL COIN',448,210,25,'#ffe391','center');txt(g,d.ownCoin?'RESULT LOCKED':'Report the side facing up',448,254,23,'#fff','center');txt(g,d.ownCoin?d.ownCoin.toUpperCase():'Keep it private until both report',448,292,22,d.ownCoin==='green'?'#80f6b8':'#ffc3cd','center');}
  else if(d.phase==='reveal'){txt(g,cdata.outcome==='tie'?'MATCH! FLIP AGAIN':cdata.outcome==='win'?'COMEBACK SUCCESS':'CHALLENGER STAYS A GHOST',440,214,22,'#ffe391','center');txt(g,`${COLORS[cdata.challenger]}: ${cdata.reveal[cdata.challenger]}`,440,260,23,'#fff','center');txt(g,`${COLORS[cdata.opponent]}: ${cdata.reveal[cdata.opponent]}`,440,300,23,'#fff','center');}
  else{txt(g,d.phase==='finished'?`YOUR PLACE: ${d.place}`:'Watch the race. Cheer them on.',440,221,24,'#fff','center');txt(g,'Guesses stay private during play.',440,267,20,'#c3bddc','center');}
  if(d.answer)txt(g,'ROUND WORD: '+d.answer,360,397,28,'#87eff6','center');
  let options=[];
  if(d.phase==='results'&&cdata?.offer&&cdata.challenger===i)options=[['CHALLENGE','A · FLIP-OFF'],['PASS','B · STAY GHOST']];
  if(d.phase==='flip'&&participant&&!d.ownCoin)options=[['GREEN','A · GREEN'],['RED','B · RED']];
  for(let n=0;n<options.length;n++){const x=55+n*315;box(g,x,475,295,90,n?'#87394d':'#23735c');txt(g,options[n][1],x+147,532,28,'#fff','center');}
  txt(g,'Physical coins only. No simulated flips.',360,610,21,'#c8bfdc','center');
 }
 for(const h of ACTION_HITS){box(g,h.x,h.y,h.w,h.h,'#322848');txt(g,({A:'A / SELECT',B:'B / ERASE',START:'START / PAUSE',L1:'L / ERASE',R1:'R / ENTER'})[h.k],h.x+h.w/2,h.y+29,13,'#d5dbff','center');}
 if(d.paused){box(g,80,290,560,110,'#17132ef5');txt(g,'PAUSED · START TO RESUME',360,355,29,'#ffe391','center');}
 if(!d.human){box(g,95,300,530,110,'#17132ef5');txt(g,'CPU SEAT · JOIN NEXT MATCH',360,363,27,'#ffe391','center');}
}
export function hit(d,x,y){const c=d.challenge;if(d.phase==='play'&&d.alive&&!d.done){const h=KEY_HITS.find(h=>x>=h.x&&x<=h.x+h.w&&y>=h.y&&y<=h.y+h.h);if(h)return h.k;}
 if(y>=475&&y<=565){if(d.phase==='results'&&c?.offer&&c.challenger===d.seat)return x<360?'CHALLENGE':'PASS';if(d.phase==='flip'&&c&&[c.challenger,c.opponent].includes(d.seat)&&!d.ownCoin)return x<360?'GREEN':'RED';}
 return ACTION_HITS.find(h=>x>=h.x&&x<=h.x+h.w&&y>=h.y&&y<=h.y+h.h)?.k;
}
