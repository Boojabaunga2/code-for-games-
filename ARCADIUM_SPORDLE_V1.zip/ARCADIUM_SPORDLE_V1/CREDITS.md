# Original art and shared components

SPORDLE gameplay, UI, word vocabulary, character vectors and carousel artwork were created for this Arcadium integration. `art.mjs` contains all six original vector characters; `tests/make-art.cjs` renders their branded carousel composition into `card.png`. No external fonts, stock images or runtime CDN assets are required.

`native-input.js` is copied unchanged from Haunt & Seek at source commit `356b99db70abe831787dd1821c5cec90e99b9dd5`. `arcadium_live_host.py` and the launcher derive from that same integration. Host changes are limited to declarative touch key allowances and optional private-frame session validation. The existing shared app, receiver and pairing contract remain in use.

`tests/universal_input_reference.py` is an unchanged copy of `integrations/universal-mini-vibe-input/universal_input_routes.py` at that commit, used to test the actual shared native-input wrapper. The adjacent harness supplies a minimal bridge contract fixture, explicitly not the full installed OS.
