# Arcadium Barrel Bash — Shared Mini Vibe V1

Extract the whole ZIP. Double-click START_INSTALL.cmd, choose your existing Arcadium_OS_COMPACT folder, wait for installation, and restart Windows once. Launch Barrel Bash from the carousel. Python 3.9+ with Tkinter is required (the Python used by Arcadium); the installer downloads no software.

Keep your current shared Mini Vibe app and pairing. No APK, new receiver, new listener or separate relay. Uses the normal Arcadium server on port 8787. The original Barrel Bash card and all supplied art are retained; yellow and pink now match the standard shared seat order.

## Play

Six players, five rounds, 30 seconds each. Unlimited timed throws. The crosshair sweeps while the target spins; press A when the crosshair lines up with a target. The dart takes 0.14 seconds to arrive, so lead the spinning wheel. Each target scores once per round. A target scores 100; a bullseye 500. Consecutive hits multiply up to ×3. Hitting the character costs 300 and loses your streak. Wood, repeats and bounced darts do not score. Later rounds spin faster and reverse. Every player continues through every round; highest cumulative score wins, with shared places on ties. There is no elimination/ghost-power system in this game.

- A: join your color in the lobby; one timed throw per press during play. Holding A does not auto-fire. The D-pad is not needed for this timing game.
- START: join if not ready; once joined, launch. During countdown/play, pause or resume. After the final podium, return to the lobby.
- B: show/hide your personal rules panel.
- PC: keys 1–6 throw/join in standard red, blue, green, yellow, pink, white order. Space starts; P/Escape pauses. Local USB gamepads use A/B/START. PC buttons provide start, pause, sound and exit.

The lobby waits for you instead of starting after 12 seconds. All six joined seats still begin automatically after a brief ready delay. Empty seats are labeled CPU opponents when the host starts. Join before the match; no silent CPU score takeover mid-match. Replays clear the old scores and ready states. Losing PC focus pauses a live match; press START to resume.

Each Mini Vibe receives its actual spinning target and moving crosshair from the same simulation, including used targets, stuck darts and impacts. It also shows timer, round, score, throw count, next combo and podium place. Touch A sends one throw per press; it does not generate a duplicate via the app bridge. Rules and score panels are personal to your color. No Internet is needed to play.

## Preservation and rollback

The update writes only Barrel Bash files, its route helper, its own catalogue registration and a guarded additive bridge wrapper. Shared input, Home, startup, pairing and every other game's files/art remain unchanged. Package checksums detect incomplete extraction or changes. Backups are under arcadium_backups/barrel_bash_v1_*. The installer has rollback and refuses to overwrite later edits. An unknown bridge or duplicate game registration stops installation before writes.

Automated tests and limits are in VALIDATION.md. Real Mini Vibe/Wi-Fi acceptance still needs a physical test. Keep Windows protection enabled and leave a blocked download blocked.
