import assert from'node:assert/strict';import{createGame}from'../games/bad-influence/engine.mjs';
let time=1000;const make=()=>createGame({now:()=>time});
function connect(g){for(let n=1;n<=12;n++)g.connect(n,true);}
function rolls(g,i,l,r){for(const[slot,value]of [[2*i+1,l],[2*i+2,r]]){assert(g.rollStart(slot,time));assert(g.stableRoll(slot,value,time));}}
function lock(g,i,choice=0,role=1){g.action(i,'CHOICE_'+role);g.action(i,'A');g.action(i,'CHOICE_'+choice);g.action(i,'A');g.action(i,'A');assert(g.S.players[i].locked);}
function begin(g){connect(g);g.next();g.next();assert.equal(g.S.phase,'input');}
{
 const g=make();begin(g);for(let k=0;k<10000;k++)g.update(.25);assert(g.S.players.every(p=>p.dice.every(v=>v===null)),'Waiting cannot invent rolls');assert.equal(g.stableRoll(1,6),false,'A baseline without roll-start is not a fresh roll');assert.equal(g.rollStart(1,time-1),false);assert.equal(g.stableRoll(1,7),false);g.action(0,'A');assert.equal(g.S.players[0].locked,false);rolls(g,0,3,6);assert.equal(g.S.players[0].step,'role');g.update(.1,[4]);assert.equal(g.S.players[0].role,0);g.update(.1,[0]);g.update(.25,[0]);assert.equal(g.S.players[0].role,0,'Release stops menu movement');lock(g,0,0,1);assert.equal(g.S.players[0].review.dice[0],3);assert.equal(g.rollStart(1),false,'Locked dice cannot be overwritten');assert.equal(g.stableRoll(1,6),false);g.connect(1,false);assert.equal(g.S.players[0].review.dice[0],3);assert.equal(g.next(),false,'No early reveal');g.action(0,'B');assert.equal(g.S.players[0].locked,false);assert.equal(g.action(0,'A'),false,'Disconnected unlocked player cannot relock until dice reconnect');
}
{
 const g=make();begin(g);for(let i=0;i<6;i++){rolls(g,i,i+1,6);lock(g,i);}assert(g.next());assert.equal(g.S.phase,'results');assert.deepEqual(g.S.players.map(p=>p.score),[1,2,3,4,5,6]);assert.equal(g.tally(),false,'Cannot score twice');g.next();assert.equal(g.live().length,5);assert.equal(g.S.players[0].alive,false);g.next();assert(g.live().every(p=>p.dice.every(v=>v===null)&&!p.locked));
}
{
 const g=make();connect(g);g.S.round=1;g.S.phase='intro';g.S.players.forEach(p=>p.score=1);g.next();for(let i=0;i<6;i++){rolls(g,i,1,6);const opts=g.options(i); // at role here, then choose a specific target through decision options
  g.action(i,'CHOICE_1');g.action(i,'A');const target=i===0?1:0;const targetIndex=g.options(i).indexOf(g.S.players[target].id);g.action(i,'CHOICE_'+targetIndex);g.action(i,'A');g.action(i,'A');}
 g.next();assert.equal(g.S.players.reduce((n,p)=>n+p.score,0),6,'Attack transfers cannot mint points');assert(g.S.players.every(p=>p.score>=0));assert.equal(g.S.players[0].roundScore,-1+1,'Incoming gains are not used as a larger victim opening bank');
}
{
 const g=make();connect(g);g.S.round=3;g.S.phase='intro';g.S.players.forEach((p,i)=>{p.alive=i<3;p.score=10;});g.next();for(let i=0;i<3;i++){rolls(g,i,3,3);g.action(i,'A');const id=g.S.players[i===2?0:2].id;g.action(i,'CHOICE_'+g.options(i).indexOf(id));g.action(i,'A');g.action(i,'A');}g.next();assert.equal(g.S.players[2].roundScore,-4,'Two same-target attackers each get +2 power');assert.equal(g.S.players[0].roundScore,2);assert.equal(g.S.players[1].roundScore,2);assert.equal(g.S.players.slice(0,3).reduce((n,p)=>n+p.score,0),30);
}
{
 const g=make();connect(g);g.S.round=2;g.S.phase='intro';g.S.players.forEach((p,i)=>p.alive=i<4);g.next();for(let i=0;i<4;i++){rolls(g,i,4,2);lock(g,i,i%2);}g.next();assert(g.live().every(p=>p.roundScore===4),'Exact majority ties reward everyone');
 const h=make();connect(h);h.S.round=4;h.S.phase='intro';h.S.players.forEach((p,i)=>{p.alive=i<2;p.score=3;});h.next();rolls(h,0,2,4);rolls(h,1,5,2);lock(h,0,1);lock(h,1,1);h.next();assert.equal(h.S.players[0].roundScore,6);assert.equal(h.S.players[1].roundScore,-5);assert.equal(h.S.players[1].score,0);h.next();assert.equal(h.S.winner,0);h.undo();assert.equal(h.S.phase,'results');assert.equal(h.S.paused,true);h.S.paused=false;h.reset();assert(h.S.players.every(p=>p.connected.every(Boolean)&&p.dice.every(v=>v===null)));
}
// All five elimination rounds with genuine-value event transcripts.
{
 const g=make();connect(g);g.next();for(let r=0;r<5;r++){g.next();for(const p of g.live()){rolls(g,p.seat,(p.seat+r)%6+1,6);lock(g,p.seat,0);}g.next();assert.equal(g.S.phase,'results');g.next();assert.equal(g.live().length,5-r);}assert.equal(g.S.phase,'champion');assert.notEqual(g.S.winner,null);
}
console.log('PASS fresh physical GoDice requirements, no automatic dice, roles, hold/release, locked-roll freeze, corrected/capped simultaneous transfers, all five rounds, ties, champion, undo and restart');
