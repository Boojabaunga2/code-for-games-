from pathlib import Path
import hashlib,json,zipfile
ROOT=Path(__file__).resolve().parent;REPO=ROOT.parents[1]
def payload():return {p.relative_to(ROOT).as_posix():p.read_bytes() for p in ROOT.rglob('*') if p.is_file() and not any(n in ('__pycache__','tests','review') for n in p.relative_to(ROOT).parts) and p.name not in ('CHECKSUMS.json','.gitignore') and not p.name.endswith(('.pyc','_REPORT.json','_RECEIPT.json'))}
def manifest():
 files=payload();(ROOT/'CHECKSUMS.json').write_text(json.dumps({n:hashlib.sha256(b).hexdigest() for n,b in files.items()},indent=2));return files
if __name__=='__main__':
 files=manifest();files['CHECKSUMS.json']=(ROOT/'CHECKSUMS.json').read_bytes()
 for p in (ROOT/'tests').glob('*'):
  if p.is_file():files['tests/'+p.name]=p.read_bytes()
 target=REPO/'downloads/ARCADIUM_BAD_INFLUENCE_V1.zip'
 with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
  for n,b in files.items():z.writestr(target.stem+'/'+n,b)
 print(target,target.stat().st_size)
