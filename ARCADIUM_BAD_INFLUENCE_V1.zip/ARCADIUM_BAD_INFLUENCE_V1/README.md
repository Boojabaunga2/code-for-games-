# Bad Influence — Real GoDice / Six Private Mini Vibes

Extract the complete ZIP. Double-click **START_INSTALL.cmd**, select **Arcadium_OS_COMPACT**, restart Windows once. Open Bad Influence in the carousel. Keep your current universal Mini Vibe v16 app and pairing. **No new APK.** The Shared Mini Vibe Controls PC platform must already be installed.

## This uses physical GoDice

Six players, TWO real D6 GoDice per player, 12 slots total. In Chrome/Edge on the Arcadium PC, open **PAIR 12 GODICE**. Pair JAX left/right, NOVA left/right, RICO left/right, LUNA left/right, BLAZE left/right, ZOE left/right. Each Bluetooth selection must be made from that slot's Pair button. Controller colors map in the standard order red, blue, green, yellow, pink, white; character art and names stay the same.

Open a round, then each player rolls both actual GoDice. A real roll-start followed by its stable result fills the player's Mini Vibe automatically. Initial pairing baselines, old/cached rolls, simulated dice, fake/tilt notifications and values outside 1–6 do not count as fresh round rolls. No random or manual number replacement exists in normal play. The simulator library is retained only because it ships with the original shared manager; the game never pairs a simulated die or accepts its events.

If an unlocked player's die disconnects, reconnect and roll before locking. Locked decisions freeze accepted physical results, so later rolls/disconnects cannot secretly change a committed score. Pairing is on the PC, not on the Mini Vibes. Real Bluetooth performance with your 12 dice still requires venue testing.

## Private controller flow

Both dice fresh → choose which is TROUBLE (the other is SURVIVAL) → choose secret answer/opponent → review → lock. All surviving players act simultaneously.

- D-pad or shoulders select. Held D-pad repeats through options; release stops selection movement.
- A confirms the current stage. The final A locks the decision. Touch supports the same choices.
- B backs up or unlocks a decision for correction before the reveal.
- START advances the table when eligible; an early reveal is blocked until every survivor is locked. START resumes a paused table.
- X/Y plays harmless character reactions. Eliminated players can react and watch, but cannot affect decisions or scores.
- PC **REVEAL & SCORE** publishes the decisions together. Before that, TV cards show waiting/locked states, not answers, targets or dice roles.
- PC **UNDO LAST STEP** restores the last completed stage and pauses for table reconciliation. No physical dice are rerolled by undo. Review the table and resume explicitly.

## Five rounds, original rules

1. Everybody's a Liar: TRUE/FALSE. A correct answer scores Survival; wrong scores zero.
2. Pass the Disaster: Trouble attacks the victim's Survival. Unblocked points transfer from the victim's existing bank.
3. Terrible Advice: match the majority to score Survival. A perfectly split vote rewards everyone.
4. Friendly Fire: two attackers selecting one opponent each receive +2 attack power.
5. Everyone's Screwed: SAFE scores Survival. CHAOS scores 3× Survival if Trouble is 4 or more; otherwise loses Survival, with total scores floored at zero.

Rounds 1–4 eliminate the lowest ROUND score, then lowest total bank, then alphabetical character name if still tied, matching the supplied prototype's deterministic tie rule. Final champion is highest total bank, then round score, then name.

The supplied attack loop could mint points by awarding a full attack while flooring the victim at zero. This build honors the stated cap: every victim can lose at most their opening bank. Multiple attackers split a limited bank proportionally in whole points, using largest remainder and rotating seat priority for exact ties. Transfers are simultaneous and conserve total points. Incoming gains cannot be immediately re-stolen in the same reveal.

## Visuals and preservation

Original six character portraits and original GoDice SDK/manager are retained. A clean generated neon stage removes the old baked preview sidebar and fictional scoreboards. Real UI supplies scores/labels. Existing carousel art is preserved; a branded original-cast fallback is provided for new registrations.

Installer backs up the previous game, adds only this game's helper and wrapper call, and updates its catalogue entry. Home, main server, shared controller receiver, pairing and other games stay in place. Reinstall is idempotent; rollback refuses to overwrite later edits. Select the bad_influence_v1_* backup from the installer to restore.

No external fonts, assets, services or AI calls are needed during play. The original GoDice storage key is overridden to this game's own key, avoiding cross-game browser settings changes. Physical GoDice/Mini Vibe acceptance remains; see VALIDATION.md.
