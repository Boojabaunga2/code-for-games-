# BOOP / Laser Riot — complete Arcadium update

Six-player hexagonal Pong in a new neon championship arena. All six colours defend their own wall with three hearts. Unjoined colours are CPU opponents. Lose your last heart and keep playing as a ghost. The last living paddle wins; START resets the match for a replay.

## Install

1. Exit any open game and extract the entire ZIP.
2. Double-click **START_INSTALL.cmd** on the PC. Select the existing **Arcadium_OS_COMPACT** folder. It finds Python/Tkinter or offers the official Windows Python package when missing.
3. Restart Windows once to load the additional game route. Open Arcadium normally and launch BOOP from Games.
4. On each Mini Vibe install **Mini Vibe/Arcadium-Boop.apk** as an update. Do not uninstall or clear data. This signed v13 app adds Boop's true held shoulder controls and retains the previous games' controls, pairing and Home assets. The PC update alone cannot add held shoulders to an older APK.

The installer preserves the existing main server, Home, pairing, approved carousel artwork, custom catalog fields and previous game helpers. It updates the existing Boop entry rather than adding a duplicate. An unknown bridge/duplicate catalog stops the install before any edits. A checksummed backup is saved under `arcadium_backups/boop_v1_*`; the installer also provides rollback and refuses to overwrite later changes.

## Mini Vibe controls

| Input | Alive | Ghost |
|---|---|---|
| Hold L1 / R1 | Paddle left / right; release stops | Previous / next ghost power on press |
| D-pad LEFT / RIGHT | Same as shoulders | Same as shoulders |
| A | Fire laser at selected rival | Cast selected power |
| B | Cycle living rival target | Cycle living rival target |
| X | Use collected sabotage | Previous power |
| Y | Switch own defence / full-arena view | View stays full arena with power panel |
| START | Join/start, pause/resume, replay | Pause/resume or replay |
| SELECT | Leave lobby, clear held input | Clear held input |

A joins/unjoins your colour in the lobby. START begins with CPU opponents in the empty seats. New devices wait for the next match rather than silently taking over a running player. No tap-to-latch movement: shoulders are native held/released snapshots, with a lost-link stop. Both shoulders cancel. Local USB gamepads use LB/RB, A/B/X/Y and START.

The six original keyboard layouts remain: Q/W/E/1, R/T/Y/2, U/I/O/3, A/S/D/4, F/G/H/5, J/K/L/6. First two keys move left/right, third fires laser/casts, number cycles target. Enter/Space selects menus; Escape pauses; M mutes. Mouse can launch a solo lobby with P1 plus five CPUs.

## Laser volleys

A fires a bright moving laser towards the selected rival's current paddle position. The destination is fixed at launch, so moving away is risky: the laser must be caught by the paddle to deflect. Deflection changes ownership/colour and sends the laser towards its previous owner. Successive deflections gain a little speed, capped at 1000 px/s. A shield absorbs a laser.

A missed laser freezes paddle movement for **two seconds**. It never directly removes a heart, never pauses the ball and never removes the paddle: a well-positioned stunned paddle can still return the ball/laser. The opponent has a further 2.5 seconds of stun immunity, preventing stun chains. Three battery cells, 1.4s firing cooldown; one cell regenerates every four active seconds. Cooldowns and stun timers stop on pause. Lasers cannot fire during countdown, pause, hitstop or results. No random aim scatter.

## Personal screens and ghosts

Each Mini Vibe receives its own 720×720 view from the same PC simulation. Its defending wall is rotated to the bottom, so left/right is consistent for all six players. Hearts, target, battery, cooldown, incoming lasers and stun countdown are live. Y provides a full-arena overview. Eliminated players switch to their own ghost and seven powers: Nudge, Bumper, Fake Ball, Distract, Shrink, Warp and Multiball. The panel shows the selected power, target, description and cooldown. Ghost walls become solid; ghosts can keep changing the live match.

## Integration / limits

Uses the existing server on **8787**, shared active-game lease and ordered native input stream. No separate server, WebSocket port, pairing reset or firmware change. Only the host produces frame images; LAN devices read their colour's frame. Images expire after 2.5 seconds and the active lease expires after seven seconds. Exiting releases only this game's lease, without clearing a later game.

Software, signing, Windows launcher and package checks are documented in VALIDATION.md. Physical Mini Vibe responsiveness, six-device Wi-Fi throughput and antivirus acceptance still need venue testing. `VERIFY_BOOP.py` saves a read-only report while the game runs.
