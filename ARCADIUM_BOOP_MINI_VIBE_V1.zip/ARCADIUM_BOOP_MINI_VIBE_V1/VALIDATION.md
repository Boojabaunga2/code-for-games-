# Validation

Software verification is distinct from physical-device acceptance.

- Actual Chromium game and ordered native-event input through the existing full wrapper chain: six colour joins, all six held shoulders, reversal, release, stale safety and keyboard movement.
- Actual laser collision: fire, paddle deflect, ownership/return target change, miss, exactly two seconds of movement stun, live ball motion during stun, recovery, no direct laser heart loss, immunity, battery regeneration and pause guards.
- Target selection, collected shield, elimination, shoulder power choice and ghost cast. All seven ghost power effects/cooldowns, solid ghost-wall bounce, a real ball goal and a complete match to winner through actual ball physics also passed.
- Six distinct actual personal renders, JPEG feeds, live colour viewer, read-only render purity, pause/resume, disconnected input stop, last-paddle winner and replay reset, responsive 1024×600 display and no script errors.
- Three Python tests cover guarded install/repeat, selective rollback preserving unrelated changes, existing art/custom fields, duplicate refusal, exact extracted ZIP and signed APK hash, corruption refusal, static capabilities/art, traversal refusal, stale frames and Ghost Bubble lease handoff.
- Signed Mini Vibe Android build and actual Java input tests succeeded in workflow 41875712184. Original signing certificate compared against the existing release; bundled Home asset bytes independently verified during packaging.
- Real Windows CMD launcher test uses Python3.12/Tkinter from a path containing spaces and ampersand, independent of .py associations. Workflow evidence recorded in review/final-summary.json after completion.

Not yet verified: six physical Mini Vibes, the user's exact OS installation, venue Wi-Fi latency/throughput and antivirus acceptance. Screenshots in review are captured from the executable Chromium game; test fixtures stage ghost elimination for repeatable captures.
