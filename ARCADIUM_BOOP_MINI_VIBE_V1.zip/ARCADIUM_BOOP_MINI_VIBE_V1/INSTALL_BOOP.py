"""Double-click targeted installer. Never replaces Home or the main server."""
from pathlib import Path
import tkinter as tk
from tkinter import filedialog
import json
from update_boop import install,rollback
ui=tk.Tk();ui.title('Arcadium Boop / Mini Vibe Deluxe');ui.geometry('730x390')
status=tk.StringVar(value='Close any open game. Install into your existing Arcadium_OS_COMPACT folder. Keeps Home, other games, pairing and port 8787.')
tk.Label(ui,text='GHOST BUBBLE / MINI VIBE DELUXE',font=('Segoe UI',16,'bold')).pack(pady=20)
tk.Label(ui,textvariable=status,wraplength=680,justify='left',font=('Segoe UI',11)).pack(padx=20,pady=15)
def run():
 folder=filedialog.askdirectory(title='Select the existing Arcadium_OS_COMPACT folder')
 if not folder:return
 try:
  root=Path(folder); helper=root/'boop_routes.py'; before=helper.read_bytes() if helper.exists() else None; backup=install(root); restart=before!=helper.read_bytes(); Path(__file__).with_name('BOOP_INSTALL_RECEIPT.json').write_text(json.dumps({'backup':str(backup)},indent=2));status.set('Installed with backup: '+str(backup)+('\n\nRestart Windows once to load the route. ' if restart else '\n\nRefresh Arcadium with Ctrl+F5 and reopen the game. ')+ 'Launch Boop Deluxe from Games. Install the included Mini Vibe APK once as an update. Keep pairing and app data. Boop shoulder controls require the included v13 app. Physical verification is still required.')
 except Exception as error:status.set('Stopped: '+str(error))
def undo():
 folder=filedialog.askdirectory(title='Select this update’s boop_v1_* backup')
 if not folder:return
 try:rollback(Path(folder));status.set('Restored the previous Boop files and registration. Restart Windows once before reopening Arcadium.')
 except Exception as error:status.set('Rollback stopped: '+str(error))
tk.Button(ui,text='Install Boop Deluxe',command=run,padx=20,pady=10).pack(pady=8)
tk.Button(ui,text='Rollback this update',command=undo).pack();ui.mainloop()
