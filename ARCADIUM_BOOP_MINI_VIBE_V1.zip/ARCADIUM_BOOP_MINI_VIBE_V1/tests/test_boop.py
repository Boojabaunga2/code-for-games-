import base64,hashlib,importlib.util,json,sys,tempfile,threading,time,unittest,urllib.request,urllib.error,zipfile
from pathlib import Path
from http.server import ThreadingHTTPServer
from harness import ROOT,modules,updater,routes
APK_SHA='3fa008b42fd511856cfce6a8cc3c463177dfe7be94ac96cb34e9525e7963b700'
class Install(unittest.TestCase):
 def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);self.seed()
 def tearDown(self):self.tmp.cleanup()
 def seed(self):
  (self.root/'data').mkdir(exist_ok=True);(self.root/'data/arcadium.json').write_text(json.dumps({'games':[{'id':'arcadium-boop','name':'ARCADIUM BOOP','image':'approved.png','custom':'preserve'},{'id':'other-game','launchUrl':'unchanged.html'}]}))
  (self.root/'arcadium_server.py').write_text('import arcadium_game_bridge\n# existing server preserved\n')
  (self.root/'arcadium_game_bridge.py').write_text('import threading\nfrom e3mi_routes import wrap_e3mi_handler\nfrom ghost_bubble_routes import wrap_ghost_bubble_handler\nACTIVE_WEB_GAME={"game":None,"until":0}\nACTIVE_LOCK=threading.RLock()\ndef bridge(Base):\n    class GameBridge(Base):\n        pass\n    return wrap_ghost_bubble_handler(wrap_e3mi_handler(GameBridge))\n')
  (self.root/'e3mi_routes.py').write_text('def wrap_e3mi_handler(Base): return Base\n')
  (self.root/'ghost_bubble_routes.py').write_bytes((ROOT.parent/'ghost-bubble/ghost_bubble_routes.py').read_bytes())
  (self.root/'HOME.html').write_text('do not touch Home');(self.root/'pairing.json').write_text('do not touch pairing')
 def test_install_repeat_selective_rollback(self):
  before={p.relative_to(self.root).as_posix():p.read_bytes() for p in self.root.rglob('*') if p.is_file()};one=updater.install(self.root);two=updater.install(self.root)
  self.assertEqual(updater.patch_bridge((self.root/'arcadium_game_bridge.py').read_text()),(self.root/'arcadium_game_bridge.py').read_text())
  cat=json.loads((self.root/'data/arcadium.json').read_text());self.assertEqual(len(cat['games']),2);g=cat['games'][0];self.assertEqual(g['image'],'approved.png');self.assertEqual(g['custom'],'preserve');self.assertEqual(g['miniVibeUrl'],'/games/arcadium-boop/personal/vibe.html');updater.rollback(two)
  cat['games'][1]['later']='keep';(self.root/'data/arcadium.json').write_text(json.dumps(cat));updater.rollback(one)
  for name,data in before.items():
   if name!='data/arcadium.json':self.assertEqual((self.root/name).read_bytes(),data,name)
  self.assertEqual(json.loads((self.root/'data/arcadium.json').read_text())['games'][1]['later'],'keep')
 def test_guards_and_exact_package(self):
  cat={'games':[{'name':'BOOP'},{'id':'arcadium-boop'}]};self.assertRaises(RuntimeError,updater.registration,cat)
  one=updater.install(self.root);(self.root/'games/arcadium-boop/deluxe.mjs').write_text('later edit');self.assertRaises(RuntimeError,updater.rollback,one)
  self.tmp.cleanup();self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);self.seed()
  zfile=ROOT.parents[1]/'downloads/ARCADIUM_BOOP_MINI_VIBE_V1.zip'
  with tempfile.TemporaryDirectory() as d:
   with zipfile.ZipFile(zfile) as z:z.extractall(d)
   package=Path(d)/zfile.stem;self.assertEqual(hashlib.sha256((package/'Mini Vibe/Arcadium-Boop.apk').read_bytes()).hexdigest(),APK_SHA)
   self.assertTrue((package/'START_INSTALL.cmd').is_file());spec=importlib.util.spec_from_file_location('boop_exact_release',package/'update_boop.py');u=importlib.util.module_from_spec(spec);spec.loader.exec_module(u);first=u.install(self.root);u.rollback(first);(package/'games/arcadium-boop/deluxe.mjs').write_text('corrupt');self.assertRaises(RuntimeError,u.install,self.root)
class Routes(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.bridge,H=modules();cls.server=ThreadingHTTPServer(('127.0.0.1',0),H);cls.server.events={'latest':0,'events':[],'slots':[]};cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True);cls.thread.start();cls.base='http://127.0.0.1:'+str(cls.server.server_port)
 @classmethod
 def tearDownClass(cls):cls.server.shutdown();cls.server.server_close();cls.thread.join()
 def req(self,path,data=None):
  try:
   with urllib.request.urlopen(urllib.request.Request(self.base+path,data=None if data is None else json.dumps(data).encode(),headers={'Content-Type':'application/json'})) as r:return r.status,r.read()
  except urllib.error.HTTPError as e:return e.code,e.read()
 def test_six_views_staleness_and_handoff(self):
  self.assertEqual(self.req('/arcadium-vibe/activate/arcadium-boop',{})[0],200)
  for i,color in enumerate(routes.COLORS):
   mode=json.loads(self.req('/api/vibe/mode?color='+color)[1]);self.assertEqual(mode['game'],'arcadium-boop');self.assertEqual(mode['page'],'/games/arcadium-boop/personal/vibe.html');data=b'\xff\xd8'+color.encode();self.assertEqual(self.req('/arcadium-bubble/arcadium-boop/frame',{'seat':i+1,'image':base64.b64encode(data).decode()})[0],200);self.assertEqual(self.req('/arcadium-bubble/arcadium-boop/frame?color='+color),(200,data))
  for path in ['index.html','deluxe.mjs','personal/vibe.html','input-capabilities.json','held-dpad.js','card.svg','assets/arena-v1.png']:self.assertEqual(self.req('/games/arcadium-boop/'+path)[0],200)
  self.assertEqual(self.req('/games/arcadium-boop/%2e%2e/%2e%2e/update_boop.py')[0],404);routes.FRAMES[1]=(time.monotonic()-4,b'old');self.assertEqual(self.req('/arcadium-bubble/arcadium-boop/frame?color=red')[0],503);self.assertEqual(self.req('/arcadium-bubble/arcadium-boop/frame',{'seat':0,'image':'invalid'})[0],400)
  self.req('/arcadium-vibe/activate/arcadium-ghost-bubble',{});self.req('/arcadium-vibe/activate/arcadium-boop',{'active':False});self.assertEqual(json.loads(self.req('/api/vibe/mode?color=red')[1])['game'],'arcadium-ghost-bubble');self.assertEqual(self.req('/api/vibe/events?after=0')[0],200)
if __name__=='__main__':unittest.main()
