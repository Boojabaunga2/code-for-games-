export const COLORS = ['#ff666d', '#65baff', '#7ee5a0', '#ffda70', '#ff94d7', '#e9ecff'];
export const NAMES = ['RED', 'BLUE', 'GREEN', 'YELLOW', 'PINK', 'WHITE'];
export const POWERS = ['SPECTRAL SLOW', 'BULLSEYE REVEAL', 'LUCKY TAG'];
export const TARGETS = { bullseye:{name:'BULLSEYE',points:100,rx:1,ry:1,speed:1}, duck:{name:'DUCK',points:75,rx:1,ry:.85,speed:1}, rabbit:{name:'RABBIT',points:100,rx:.78,ry:1.15,speed:.8}, cans:{name:'TIN CANS',points:60,rx:.9,ry:.95,speed:.25}, bottles:{name:'BOTTLES',points:80,rx:.65,ry:1.1,speed:.35}, bat:{name:'BAT',points:90,rx:1.15,ry:.7,speed:1.2}, golden:{name:'GOLDEN DUCK',points:150,rx:1,ry:.9,speed:1.5} };
export const ROUND_NAMES = ['Moonlight warm-up', 'Carnival chaos', 'Midnight mischief', 'Phantom frenzy', 'The final shot'];

export function createGame(random = Math.random) {
  const S = { mode: 'lobby', round: 1, time: 30, t: 0, wait: 0, joined: Array(6).fill(false), players: [], targets: [], effects: [], bolts: [], history: [], winner: null, slowUntil: 0, revealUntil: 0 };
  const fresh = i => ({ i, x: 160 + i * 190, y: 350, score: 0, total: 0, assists: 0, hits: 0, shots: 0, out: false, used: false, focus: 0, cooldown: 0, power: 0, powerCd: 0, bot: 0, botTarget: 0, botFired: false, combo: 0, shotAt: -10 });
  S.players = NAMES.map((_, i) => fresh(i));
  function makeTargets() {
    const kinds=['bullseye','duck','rabbit','cans','bottles','bat','golden','duck','rabbit','bullseye','cans','bottles'];
    S.targets = kinds.map((kind,i) => ({ id:i,kind,x:130+(i%4)*310+Math.floor(i/4)*30,y:210+Math.floor(i/4)*110,base:210+Math.floor(i/4)*110,vx:(i%2?1:-1)*(55+S.round*26)*TARGETS[kind].speed,r:(49-S.round*5)*(kind==='golden'?.88:1),phase:random()*6,motion:0,tag:null,born:S.t-1 }));
  }
  makeTargets();
  function start() {
    S.players = NAMES.map((_, i) => fresh(i));
    S.round = 1; S.history = []; S.winner = null; S.effects = []; S.bolts = [];
    nextRound();
  }
  function nextRound() {
    S.mode = 'countdown'; S.wait = 3; S.time = 30; S.slowUntil = 0; S.revealUntil = 0;
    S.players.forEach(p => { p.score = 0; p.used = false; p.focus = 0; p.cooldown = 0; p.powerCd = 0; p.combo = 0; });
    makeTargets();
  }
  function eliminate() {
    const alive = S.players.filter(p => !p.out).map(p => ({ p, tie: random() })).sort((a, b) => a.p.score - b.p.score || a.p.total - b.p.total || a.p.hits - b.p.hits || a.tie - b.tie);
    const loser = alive[0].p; loser.out = true;
    S.history.push({ round: S.round, eliminated: loser.i, score: loser.score });
    S.players.forEach(p => { p.total += p.score; });
    S.mode = S.round === 5 ? 'results' : 'round-end'; S.wait = 8;
    if (S.round === 5) S.winner = S.players.find(p => !p.out).i;
  }
  function next() { if (S.mode === 'results') start(); else if (S.mode === 'round-end') { S.round++; nextRound(); } }
  function effect(p, label, x, y, kind = 'hit', life = 1.1) { S.effects.push({ i: p.i, x, y, label, color: COLORS[p.i], life, maxLife: life, kind, seed: random() * 9 }); }
  function shoot(i) {
    const p = S.players[i];
    if (S.mode !== 'play' || p.cooldown > 0) return;
    p.cooldown = p.out ? .65 : .32; p.shots++; p.shotAt = S.t;
    S.bolts.push({ i, x: p.x, y: p.y, fromX: 105 + i * 214, fromY: 640, at: S.t, ghost: p.out });
    const target = [...S.targets].sort((a,b)=>b.y-a.y).find(t => {const shape=TARGETS[t.kind],focus=p.focus>0?1.2:1;return Math.hypot((t.x-p.x)/(t.r*shape.rx*focus),(t.y-p.y)/(t.r*shape.ry*focus))<=1;});
    if (!target) { p.combo = 0; effect(p, '', p.x, p.y, 'miss', .45); return; }
    if (p.out) { target.tag = { i, until: S.t + 5 }; effect(p, 'HAUNTED!', target.x, target.y, 'tag'); return; }
    const d = Math.hypot(target.x - p.x, target.y - p.y) / target.r, score = target.kind==='bullseye' ? (d < .24 ? 100 : d < .6 ? 60 : 30) : TARGETS[target.kind].points;
    p.score += score; p.hits++; p.combo++;
    if (target.tag && target.tag.until > S.t) { const spirit = S.players[target.tag.i]; spirit.total += 40; spirit.assists += 40; effect(spirit, 'ASSIST +40', target.x, target.y - 46, 'assist'); }
    effect(p, '+' + score, target.x, target.y, (target.kind==='bullseye'&&score===100)||target.kind==='golden' ? 'perfect' : 'hit');
    Object.assign(S.effects.at(-1),{skin:target.id%3,prop:target.kind,radius:target.r});
    target.x = 90 + random() * 1100; target.base = 210 + Math.floor(random()*3)*110; target.y = target.base; target.tag = null; target.born = S.t;
  }
  function power(i) {
    const p = S.players[i]; if (S.mode !== 'play') return;
    if (!p.out) { if (p.used) return; p.used = true; p.focus = 4; effect(p, 'DEADEYE', p.x, p.y, 'power', 1.4); return; }
    if (p.powerCd > 0) return; p.powerCd = 8;
    if (p.power === 0) S.slowUntil = S.t + 3;
    else if (p.power === 1) S.revealUntil = S.t + 5;
    else { const t = S.targets.reduce((a, b) => Math.hypot(a.x - p.x, a.y - p.y) < Math.hypot(b.x - p.x, b.y - p.y) ? a : b); t.tag = { i, until: S.t + 8 }; }
    effect(p, POWERS[p.power], p.x, p.y, 'power', 1.5);
  }
  function button(i, b) {
    if (i < 0 || i >= 6) return;
    if (S.mode === 'lobby') { if (b === 'A') S.joined[i] = true; if (b === 'SELECT') S.joined[i] = false; if (b === 'START') { S.joined[i] = true; start(); } return; }
    if (b === 'START') { if (S.mode === 'play') S.mode = 'pause'; else if (S.mode === 'pause') S.mode = 'play'; else if (['round-end', 'results'].includes(S.mode)) next(); return; }
    if (S.mode !== 'play') return;
    if (b === 'A') { S.joined[i] = true; shoot(i); }
    if (b === 'Y') power(i);
    if (b === 'B' && S.players[i].out) S.players[i].power = (S.players[i].power + 1) % 3;
  }
  function update(dt, masks = Array(6).fill(0)) {
    dt = Math.min(.05, Math.max(0, dt));
    if (['pause', 'lobby', 'results'].includes(S.mode)) return;
    S.t += dt;
    S.effects.forEach(e => e.life -= dt); S.effects = S.effects.filter(e => e.life > 0);
    S.bolts = S.bolts.filter(b => S.t - b.at < .4);
    if (S.mode === 'countdown') { S.wait -= dt; if (S.wait <= 0) S.mode = 'play'; return; }
    if (S.mode === 'round-end') { S.wait -= dt; if (S.wait <= 0) next(); return; }
    S.time = Math.max(0, S.time - dt);
    for (const t of S.targets) {
      const motionDt=dt*(S.t<S.slowUntil?.3:1);t.motion+=motionDt;t.x += t.vx * motionDt;
      if (t.x < t.r + 55 || t.x > 1225 - t.r) { t.x = Math.max(t.r + 55, Math.min(1225 - t.r, t.x)); t.vx *= -1; }
      t.y = t.base + (t.kind==='rabbit'?-Math.abs(Math.sin(t.motion*(2+S.round*.15)+t.phase))*45:t.kind==='bat'?Math.sin(t.motion*(2+S.round*.2)+t.phase)*28:Math.sin(t.motion*(.6+S.round*.25)+t.phase)*(t.kind==='duck'||t.kind==='golden'?4:S.round*3));
    }
    for (const p of S.players) {
      p.cooldown = Math.max(0, p.cooldown - dt); p.focus = Math.max(0, p.focus - dt); p.powerCd = Math.max(0, p.powerCd - dt);
      const m = masks[p.i] || 0, speed = p.focus > 0 ? 180 : 350;
      p.x = Math.max(35, Math.min(1245, p.x + ((m & 8 ? 1 : 0) - (m & 4 ? 1 : 0)) * speed * dt));
      p.y = Math.max(135, Math.min(535, p.y + ((m & 2 ? 1 : 0) - (m & 1 ? 1 : 0)) * speed * dt));
      if (!S.joined[p.i] && !p.out) {
        p.bot -= dt;
        if (p.bot <= 0) { p.bot = .85 + random() * .85; p.botTarget = Math.floor(random() * S.targets.length); p.botOffset = (random() - .5) * 2.1; p.botFired = false; }
        const t = S.targets[p.botTarget];
        p.x += (t.x + p.botOffset * t.r - p.x) * Math.min(1, dt * 7);
        p.y += (t.y + p.botOffset * t.r * .7 - p.y) * Math.min(1, dt * 7);
        if (p.bot < .2 && !p.botFired) { shoot(p.i); p.botFired = true; }
      }
    }
    if (S.time <= 0) eliminate();
  }
  return { S, start, next, button, update, shoot, power };
}
