import {COLORS, NAMES, POWERS, TARGETS} from './engine.mjs';
const TAU = Math.PI * 2;
const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
function load(src) { return new Promise((resolve, reject) => { const i = new Image(); i.onload = () => resolve(i); i.onerror = () => reject(Error('Missing game artwork: ' + src)); i.src = src; }); }
export async function createRenderer(game) {
  const S = game.S;
  const [bg, hunters, boards, props] = await Promise.all(['gallery.png', 'hunters.png', 'targets.png','gallery-props.png'].map(s => load('./assets/' + s)));
  const staticScene = Object.assign(document.createElement('canvas'), {width:1280,height:720});
  const b = staticScene.getContext('2d'); b.drawImage(bg,0,0,1280,720);
  const shade = b.createLinearGradient(0,100,0,590); shade.addColorStop(0,'#0b092400'); shade.addColorStop(.5,'#09072424'); shade.addColorStop(1,'#140c1622'); b.fillStyle=shade;b.fillRect(0,100,1280,500);
  for(const y of [270,380,490]){b.fillStyle='#180f25a6';b.fillRect(72,y+7,1136,10);const wood=b.createLinearGradient(0,y,0,y+12);wood.addColorStop(0,'#b98d55');wood.addColorStop(.3,'#69412f');wood.addColorStop(1,'#302034');b.fillStyle=wood;b.fillRect(72,y,1136,9);b.fillStyle='#d8b87d77';b.fillRect(73,y,1134,1);}
  const scene = Object.assign(document.createElement('canvas'),{width:1280,height:720});
  let now = 0, captureBase = false;
  scene.getContext('2d').drawImage(staticScene,0,0);
  const targetSprites=Array.from({length:3},(_,i)=>{const a=Object.assign(document.createElement('canvas'),{width:256,height:256});a.getContext('2d').drawImage(boards,i*boards.width/3,0,boards.width/3,boards.height,0,0,256,256);return a});
  const hunterSprites=Array.from({length:6},(_,i)=>{const a=Object.assign(document.createElement('canvas'),{width:256,height:256});a.getContext('2d').drawImage(hunters,(i%3)*hunters.width/3,Math.floor(i/3)*hunters.height/2,hunters.width/3,hunters.height/2,0,0,256,256);return a});
  const propKinds=['duck','rabbit','cans','bottles','bat','golden'],propCenters={duck:.64,rabbit:.68,cans:.55,bottles:.55,bat:.52,golden:.60};
  const propSprites=Object.fromEntries(propKinds.map((kind,i)=>{const a=Object.assign(document.createElement('canvas'),{width:256,height:256});a.getContext('2d').drawImage(props,(i%3)*props.width/3,Math.floor(i/3)*props.height/2,props.width/3,props.height/2,0,0,256,256);return[kind,a]}));
  const worldCanvas=Object.assign(document.createElement('canvas'),{width:1280,height:720});
  function text(c,s,x,y,size=20,color='#fff1d4',align='left',font='Arial') { c.fillStyle=color;c.font=`900 ${size}px ${font}`;c.textAlign=align;c.textBaseline='middle';c.fillText(String(s),x,y); }
  function panel(c,x,y,w,h,color='#261b3d',stroke='#b08c59',r=16) { c.beginPath();c.roundRect(x,y,w,h,r);c.fillStyle=color;c.fill();if(stroke){c.strokeStyle=stroke;c.lineWidth=1.5;c.stroke();} }
  function character(c,i,x,y,size,alpha=1) { c.save();c.globalAlpha=alpha;c.drawImage(hunterSprites[i],x-size/2,y-size,size,size);c.restore(); }
  function spirit(c,x,y,r,color,phase=0) {
    c.save();c.translate(x,y+Math.sin(now*2+phase)*6);c.shadowColor=color;c.shadowBlur=24;
    const g=c.createRadialGradient(-r*.3,-r*.5,2,0,0,r*1.4);g.addColorStop(0,'#f2fff5');g.addColorStop(.3,color);g.addColorStop(1,'#80bdf077');c.fillStyle=g;
    c.beginPath();c.moveTo(-r,r*.75);c.bezierCurveTo(-r*1.2,0,-r*.8,-r*1.2,0,-r*1.15);c.bezierCurveTo(r,-r*1.1,r*1.15,0,r,r*.75);for(let k=4;k>=0;k--)c.lineTo(-r+k*r/2,r*.75+Math.sin(k*1.8+now*3)*r*.18);c.closePath();c.fill();c.shadowBlur=0;
    c.fillStyle='#211733';for(const dx of [-.32,.32]){c.beginPath();c.ellipse(dx*r,-r*.2,r*.12,r*.2,0,0,TAU);c.fill();}c.beginPath();c.ellipse(0,r*.2,r*.17,r*.14,0,0,TAU);c.fill();c.restore();
  }
  function reticle(c,p) {
    const color=COLORS[p.i],r=p.focus>0?14:19;c.save();c.translate(p.x,p.y);c.shadowColor='#090515';c.shadowBlur=4;
    c.strokeStyle='#110f22';c.lineWidth=5;c.beginPath();c.arc(0,0,r,0,TAU);c.stroke();c.strokeStyle=color;c.lineWidth=2;
    for(let i=0;i<4;i++){const a=i*TAU/4;c.beginPath();c.arc(0,0,r,a+.25,a+1.32);c.stroke();c.beginPath();c.moveTo(Math.cos(a)*(r+5),Math.sin(a)*(r+5));c.lineTo(Math.cos(a)*(r+12),Math.sin(a)*(r+12));c.stroke();}
    c.fillStyle='#fff';c.beginPath();c.arc(0,0,2,0,TAU);c.fill();c.shadowBlur=0;
    panel(c,-15,r+14,30,16,'#100c26d9',color,5);text(c,p.i+1,0,r+22,10,color,'center');
    if(p.out){c.globalAlpha=.7;c.strokeStyle=color;c.setLineDash([3,4]);c.beginPath();c.arc(0,0,r+8,-now,TAU-now);c.stroke();}c.restore();
  }
  function target(c,t) {
    const pop=clamp((S.t-t.born)/.22,0,1),isProp=t.kind!=='bullseye',size=t.r*(isProp?2.7:2.5),skin=t.id%3;
    c.save();c.translate(t.x,t.y);c.rotate(Math.sin(now*1.4+t.phase)*(t.kind==='bat'?.1:isProp?.018:.055));c.scale(pop,pop);
    c.fillStyle='#08031544';c.beginPath();c.ellipse(2,12,t.r*.9,t.r*.85,0,0,TAU);c.fill();if(t.kind==='golden'){c.shadowColor='#ffdc75';c.shadowBlur=14;}c.drawImage(isProp?propSprites[t.kind]:targetSprites[skin],-size/2,-size*(isProp?propCenters[t.kind]:.535),size,size);c.shadowBlur=0;
    if(t.tag&&t.tag.until>S.t){c.shadowColor=COLORS[t.tag.i];c.shadowBlur=16;c.strokeStyle=COLORS[t.tag.i];c.lineWidth=3;c.setLineDash([7,5]);c.beginPath();c.arc(0,0,t.r+11,now,TAU+now);c.stroke();c.setLineDash([]);spirit(c,0,-t.r-22,13,COLORS[t.tag.i],t.id);}
    if(S.t<S.revealUntil){c.shadowColor='#c3ffff';c.shadowBlur=16;c.strokeStyle='#c3ffff';c.lineWidth=2;c.beginPath();c.arc(0,0,t.r*.24,0,TAU);c.moveTo(-t.r*.35,0);c.lineTo(t.r*.35,0);c.moveTo(0,-t.r*.35);c.lineTo(0,t.r*.35);c.stroke();}
    c.restore();
  }
  function effects(c) {
    for(const bolt of S.bolts){const age=S.t-bolt.at,u=clamp(age/.16,0,1),x=bolt.fromX+(bolt.x-bolt.fromX)*u,y=bolt.fromY+(bolt.y-bolt.fromY)*u;
      if(age<.2){c.save();c.strokeStyle=COLORS[bolt.i];c.shadowColor=COLORS[bolt.i];c.shadowBlur=12;c.lineWidth=3;c.beginPath();c.moveTo(x-(bolt.x-bolt.fromX)*.09,y-(bolt.y-bolt.fromY)*.09);c.lineTo(x,y);c.stroke();c.fillStyle='#fff9dc';c.beginPath();c.arc(x,y,3,0,TAU);c.fill();c.restore();}
    }
    for(const e of S.effects){const age=e.maxLife-e.life,u=age/e.maxLife;c.save();c.translate(e.x,e.y);c.globalAlpha=Math.min(1,e.life*3);
      if(['hit','perfect'].includes(e.kind)&&age<.5&&e.skin!==undefined){const isProp=e.prop&&e.prop!=='bullseye',size=e.radius*(isProp?2.7:2.5);for(let j=0;j<5;j++){const a=j*TAU/5,d=age*100;c.save();c.translate(Math.cos(a)*d,Math.sin(a)*d+age*age*80);c.rotate(age*(j%2?1:-1)*2);c.globalAlpha*=Math.max(0,1-age*2);c.beginPath();c.moveTo(0,0);c.arc(0,0,size*.7,a,a+TAU/5);c.closePath();c.clip();c.drawImage(isProp?propSprites[e.prop]:targetSprites[e.skin],-size/2,-size*(isProp?propCenters[e.prop]:.535),size,size);c.restore();}}
      if(['hit','perfect','miss','tag'].includes(e.kind)){
        c.strokeStyle=e.kind==='perfect'?'#ffeaae':e.color;c.lineWidth=2;c.shadowColor=e.color;c.shadowBlur=12;c.beginPath();c.arc(0,0,8+u*70,0,TAU);c.stroke();
        for(let j=0;j<(e.kind==='perfect'?18:9);j++){const a=j*2.4+e.seed,r=age*(60+j*7);c.fillStyle=j%2?'#ffe7a6':e.color;c.save();c.translate(Math.cos(a)*r,Math.sin(a)*r+age*age*65);c.rotate(a+age*3);c.fillRect(-2,-2,j%2?6:3,3);c.restore();}
      }
      if(e.label){const lift=age*50,scale=1+Math.sin(clamp(age/.18,0,1)*Math.PI)*.18;c.translate(0,-lift);c.scale(scale,scale);c.shadowColor='#180925';c.shadowBlur=4;c.lineWidth=5;c.strokeStyle='#291c3a';c.font='900 32px Georgia';c.textAlign='center';c.strokeText(e.label,0,0);text(c,e.label,0,0,32,e.kind==='perfect'?'#ffe69a':e.color,'center','Georgia');if(e.kind==='perfect')text(c,'BULLSEYE!',0,-31,13,'#fff5d7','center');}c.restore();
    }
  }
  function world(c,only=null,crew=true) {
    c.clearRect(0,0,1280,720);c.drawImage(staticScene,0,0);
    const gl=c.createRadialGradient(660,420,80,660,420,650);gl.addColorStop(0,'#8a7db509');gl.addColorStop(1,'#08021d66');c.fillStyle=gl;c.fillRect(0,0,1280,720);
    for(let i=0;i<36;i++){const x=(i*157+now*(i%2?6:-5)+12800)%1280,y=140+(i*83)%410+Math.sin(now+i)*9;c.globalAlpha=.2+Math.sin(now*2+i)*.15;c.fillStyle=i%3?'#ffe5a0':'#a6fdd9';c.beginPath();c.arc(x,y,i%4?1.4:2.4,0,TAU);c.fill();}c.globalAlpha=1;
    if(S.mode!=='lobby'){for(const t of [...S.targets].sort((a,b)=>a.y-b.y))target(c,t);}
    // Light mist drifts behind the firing line.
    for(let i=0;i<3;i++){const x=240+i*420+Math.sin(now*.2+i)*50,g=c.createRadialGradient(x,510,0,x,510,260);g.addColorStop(0,'#acb6fc09');g.addColorStop(1,'#acb6fc00');c.fillStyle=g;c.fillRect(x-260,330,520,280);}
    if(S.t<S.slowUntil){c.fillStyle='#5bd4b512';c.fillRect(0,0,1280,720);for(let i=0;i<4;i++)spirit(c,90+i*360,200+Math.sin(i)*100,19,'#a6f3d1',i);}
    effects(c);
    if(captureBase){scene.getContext('2d').drawImage(c.canvas,0,0);captureBase=false;}
    if(S.mode!=='lobby'){if(only===null)S.players.forEach(p=>reticle(c,p));else reticle(c,S.players[only]);}
    if(crew){
      for(const p of S.players){const x=107+p.i*213,bob=Math.sin(now*2.5+p.i)*2,recoil=clamp(1-(S.t-p.shotAt)/.22,0,1),size=S.mode==='lobby'?182:158;c.save();
        c.fillStyle='#0c052a65';c.beginPath();c.ellipse(x,680,63,11,0,0,TAU);c.fill();
        const glow=c.createRadialGradient(x,663,2,x,663,82);glow.addColorStop(0,COLORS[p.i]+'55');glow.addColorStop(1,COLORS[p.i]+'00');c.fillStyle=glow;c.fillRect(x-82,580,164,140);
        if(p.out){c.filter='saturate(.4) brightness(1.1)';character(c,p.i,x,690+bob,size,.38);c.filter='none';spirit(c,x,583,30,COLORS[p.i],p.i);}
        else{c.translate(x,690+bob+recoil*4);c.rotate(-recoil*.045+Math.sin(now*1.3+p.i)*.015+(p.x-640)*.00002);c.scale(1+recoil*.018,1-recoil*.015);character(c,p.i,0,0,size);if(p.focus>0){c.strokeStyle=COLORS[p.i];c.lineWidth=2;c.shadowColor=COLORS[p.i];c.shadowBlur=15;c.beginPath();c.ellipse(0,-12,70,13,0,0,TAU);c.stroke();}}
        c.restore();
      }
    }
  }
  function camera(i){const p=S.players[i],w=840,h=525;return{x:clamp(p.x-w/2,0,1280-w),y:clamp(p.y-h/2,85,130),w,h};}
  function cameraImage(c,i,x,y,w,h){const a=camera(i);c.save();c.beginPath();c.rect(x,y,w,h);c.clip();c.drawImage(scene,a.x,a.y,a.w,a.h,x,y,w,h);c.save();c.translate(x-a.x*w/a.w,y-a.y*h/a.h);c.scale(w/a.w,h/a.h);if(S.mode!=='lobby')reticle(c,S.players[i]);c.restore();c.restore();}
  function screen(c,i){const p=S.players[i],w=1280/3,h=360,color=COLORS[i];c.save();c.translate((i%3)*w,Math.floor(i/3)*h);panel(c,4,4,w-8,h-8,p.out?'#211830':'#171027',color,10);panel(c,9,9,w-18,34,'#302039',null,7);character(c,i,30,45,43);text(c,NAMES[i]+' / '+(p.out?'GHOST':'P'+(i+1)),57,27,14,color);text(c,p.out?p.assists:p.score,w-23,28,23,'#fff0ce','right','Georgia');
    cameraImage(c,i,11,47,w-22,245);c.strokeStyle='#806144';c.lineWidth=1;c.strokeRect(11,47,w-22,245);
    panel(c,18,56,77,20,'#160b27d9',color,5);text(c,p.out?'GHOST CAM':'AIM CAM',56,67,9,color,'center');
    if(p.out)spirit(c,w-39,267,17,color,i);else character(c,i,w-41,292,70);
    text(c,p.out?POWERS[p.power]:'DUCK 75 · RABBIT 100 · GOLD 150',17,308,10,p.out?'#cfb8ef':'#d1b985');text(c,p.out?(p.powerCd>0?'Y: '+Math.ceil(p.powerCd)+'s':'Y: CAST'):(p.focus>0?'FOCUS ACTIVE':p.used?'FOCUS USED':'Y: FOCUS'),w-18,330,10,color,'right');text(c,p.out?'A TAG · B POWER':'A FIRE · D-PAD AIM',17,330,10,'#c0a8cb');text(c,S.joined[i]?'PLAYER':'CPU',w-18,307,8,'#b3a0bd','right');
    const ready=p.out?1-p.powerCd/8:p.focus>0?p.focus/4:p.used?0:1;c.fillStyle='#100a1c';c.fillRect(17,342,w-34,3);c.fillStyle=color;c.fillRect(17,342,(w-34)*ready,3);c.restore();}
  function field(c) { now=performance.now()/1000;captureBase=true;if(S.mode==='lobby'){world(c);return;}world(worldCanvas.getContext('2d'),null,false);c.fillStyle='#0e0918';c.fillRect(0,0,1280,720);for(let i=0;i<6;i++)screen(c,i); }

  function personal(canvas,i) {
    now=performance.now()/1000;const c=canvas.getContext('2d'),p=S.players[i],color=COLORS[i];
    c.fillStyle='#100b20';c.fillRect(0,0,720,720);
    const g=c.createLinearGradient(0,0,720,720);g.addColorStop(0,'#322240');g.addColorStop(1,'#110c21');c.fillStyle=g;c.fillRect(0,0,720,720);
    panel(c,12,12,696,696,'#140f26',color,23);panel(c,25,23,670,82,'#251a35','#66506d',15);
    character(c,i,70,109,99);text(c,'GHOSTSHOT',131,45,17,'#e5bc75','left','Georgia');text(c,NAMES[i]+(p.out?' / GHOST CREW':' / CROSSBOW'),131,78,23,color);
    text(c,'ROUND '+S.round+' / 5',674,44,13,'#bba9cc','right');text(c,String(Math.ceil(S.time)).padStart(2,'0')+'s',674,78,27,'#fff0c5','right');
    const crop=camera(i),cropW=crop.w,cropH=crop.h,sx=crop.x,sy=crop.y;
    c.save();c.beginPath();c.roundRect(25,117,670,418,15);c.clip();c.drawImage(scene,sx,sy,cropW,cropH,25,117,670,418);c.save();c.translate(25-sx*670/cropW,117-sy*418/cropH);c.scale(670/cropW,418/cropH);if(S.mode!=='lobby')reticle(c,p);c.restore();
    const edge=c.createRadialGradient(360,320,160,360,320,390);edge.addColorStop(0,'#08021d00');edge.addColorStop(1,'#09031b99');c.fillStyle=edge;c.fillRect(25,117,670,418);c.restore();
    c.strokeStyle='#a98c68';c.lineWidth=2;c.beginPath();c.roundRect(25,117,670,418,15);c.stroke();panel(c,41,134,115,26,'#140a29ce',color,7);text(c,p.out?'SPIRIT VISION':'AIM CAM',98,148,11,color,'center');
    if(S.t<S.slowUntil||S.t<S.revealUntil){panel(c,189,492,342,29,'#342142e8','#b7f4d7',8);text(c,S.t<S.slowUntil?'SPECTRAL SLOW ACTIVE':'BULLSEYES REVEALED',360,507,13,'#b7f4d7','center');}
    panel(c,25,550,222,80,'#2d203b','#796044',13);text(c,p.out?'GHOST ASSISTS':'ROUND SCORE',43,569,11,'#b6a1b8');text(c,p.out?p.assists:p.score,43,603,32,color);text(c,'PTS',229,607,12,'#b9a8bb','right');
    panel(c,259,550,436,80,'#2d203b','#796044',13);text(c,p.out?POWERS[p.power]:'DEADEYE FOCUS',278,570,13,'#f1dab5');text(c,p.out?(p.powerCd>0?Math.ceil(p.powerCd)+'s TO RECHARGE':'Y  CAST POWER'):(p.focus>0?'FOCUS ACTIVE':p.used?'USED THIS ROUND':'Y  STEADY YOUR AIM'),278,602,19,color);
    const progress=p.out?1-p.powerCd/8:p.focus>0?p.focus/4:p.used?0:1;panel(c,666,564,7,51,'#110c1e',null,3);c.fillStyle=color;c.fillRect(666,615-progress*51,7,progress*51);
    text(c,'✥  D-PAD AIM',40,663,16,'#d6c6dd');text(c,p.out?'A  HAUNT TARGET':'A  FIRE CROSSBOW',685,663,16,color,'right');text(c,p.out?'B  CHANGE POWER  ·  Y  CAST':'UNLIMITED BOLTS  ·  Y  FOCUS',360,694,11,'#ac97b7','center');
    if(S.mode==='lobby'){panel(c,97,184,526,296,'#1b1033ed','#e5bd71',22);character(c,i,225,445,220);text(c,S.joined[i]?'YOU’RE IN!':'READY TO HAUNT?',450,246,24,color,'center','Georgia');text(c,'A   JOIN YOUR COLOUR',450,308,17,'#fff0cf','center');text(c,'START   LET’S PLAY',450,350,16,'#d9bd8e','center');text(c,'6 PLAYERS · 5 ROUNDS',450,404,13,'#a998bc','center');}
    else if(S.mode!=='play'){panel(c,115,240,490,170,'#1b1033ec',color,20);text(c,S.mode==='countdown'?Math.max(1,Math.ceil(S.wait)):S.mode==='pause'?'PAUSED':S.mode==='results'?NAMES[S.winner]+' WINS!':p.out?'YOU’RE A GHOST!':'YOU SURVIVED!',360,295,35,color,'center','Georgia');text(c,S.mode==='countdown'?'READY YOUR CROSSBOW':p.out?'KEEP PLAYING. CAST YOUR POWERS.':'START TO CONTINUE',360,357,16,'#e7d2ac','center');}
    return canvas;
  }
  return {field,personal,character,camera,screen,layout:{columns:3,rows:2,seats:NAMES},ready:true};
}
