from pathlib import Path
import json,base64,hashlib,zipfile
BASE=Path(__file__).resolve().parent
probe='''<!doctype html><script>(async()=>{let result;try{const r=await fetch('/arcadium-live/SLUG/status',{cache:'no-store'}),s=await r.json();if(!r.ok||s.protocol!==1||s.game!=='SLUG')throw Error('Shared game host is unavailable.');const n=await fetch('/api/vibe/native-events?after=0',{cache:'no-store'});if(!n.ok)throw Error('Shared Mini Vibe input is unavailable.');const input=await n.json();if(!Number.isSafeInteger(input.latest)||!Array.isArray(input.events))throw Error('Shared Mini Vibe input returned an incompatible response.');result={ok:true};}catch(e){result={ok:false,error:e.message};}parent.postMessage({...result,nonce:location.hash.slice(1)},'*');})();</script>'''
payload={'files':[],'entries':[]}
for slug,parent in [('worm-whiplash','worm-whiplash'),('ghostshot','ghostshot-browser')]:
 root=BASE.parent/parent/'games'/slug
 entry=json.loads((root/'arcadium-game.json').read_text());payload['entries'].append(entry)
 files={p.relative_to(root).as_posix():p.read_bytes() for p in root.rglob('*') if p.is_file() and '_pc' not in p.relative_to(root).parts and p.suffix.lower() in {'.html','.mjs','.js','.css','.png','.jpg','.jpeg','.webp','.json','.txt','.svg','.woff','.woff2','.mp3','.wav','.ogg'}}
 files['import-check.html']=probe.replace('SLUG',slug).encode()
 if slug=='worm-whiplash':
  files['app.mjs']=files['app.mjs'].replace(b'Close the Arcadium server console. Extract the complete ZIP and run<br><b>WORM_WHIPLASH_SETUP.exe</b>. Select your existing<br><b>Arcadium_OS_COMPACT</b> folder. Play waits until the host is ready.',b'Open your existing Arcadium launcher on this PC.<br>Use the browser importer to check the shared Mini Vibe host.<br>Play waits until the host is ready.')
 for name,data in files.items():
  payload['files'].append({'game':slug,'path':f'games/{slug}/{name}','sha256':hashlib.sha256(data).hexdigest(),'data':base64.b64encode(data).decode()})
html='''<!doctype html><meta charset="utf-8"><title>Arcadium Game Import</title><style>body{background:#0b1020;color:#edf3ff;font:18px system-ui;max-width:820px;margin:50px auto;padding:20px}button{padding:16px;margin:20px 12px 20px 0;font:inherit;background:#e73550;color:white;border:0;border-radius:8px}a{color:#6ccaff}pre{white-space:pre-wrap;background:#171f34;padding:20px}label{display:block;margin:16px}</style><h1>ARCADIUM · Game Import</h1><p>Open your existing Arcadium launcher first. Keep it running on this PC at port 8787.</p><p>This imports game artwork, browser code and two catalogue entries. It checks your shared game host before finishing. It does not install or run a Windows launcher or change your server, pairing files or Windows settings.</p><label><input type="checkbox" value="worm-whiplash" checked> Worm Whiplash — includes platform fish bowls</label><label><input type="checkbox" value="ghostshot" checked> Ghostshot: Crossbow Knockout</label><p>Choose your existing <b>Arcadium_OS_COMPACT</b> folder when prompted. A backup is saved inside it.</p><button id="install">Choose OS folder &amp; import</button><button id="restore">Restore backup</button><pre id="status">Ready. Use Microsoft Edge or Google Chrome on your Arcadium PC.</pre><div id="links"></div>'''
html+='<script>const PAYLOAD='+json.dumps(payload,separators=(',',':'))+';</script><script>'+ (BASE/'importer.js').read_text()+'</script>'
out=Path('/workspace/outputs/ARCADIUM_TWO_GAME_BROWSER_IMPORT.zip')
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 z.writestr('OPEN_GAME_IMPORT.html',html)
 for name in ['importer.js','build.py','README.txt']:z.write(BASE/name,'source/'+name)
 z.writestr('README.txt',(BASE/'README.txt').read_text())
 z.write(BASE/'VALIDATION.md','VALIDATION.md')
 for p in (BASE/'tests').glob('*'):z.write(p,'source/tests/'+p.name)
 for f in payload['files']:
  if Path(f['path']).suffix in {'.mjs','.js','.css','.html','.json'}:z.writestr('source/'+f['path'],base64.b64decode(f['data']))

print(out, out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest(),len(payload['files']))
