# Assets and licenses

The six base transparent RC car SVG sprites, six original helmeted pit-crew monkey sprites and 180 seat-color/model variants for the thirty-car garage are original programmatic vector artwork created for this implementation; they are retained legacy artwork; the V3 runtime uses original procedural 3D vehicle meshes and numbered liveries. All track geometry, table materials, rails, curbs, LED lighting, furniture, HUD graphics and synthetic audio are original runtime-generated artwork/code, included in source. No external art, fonts, audio samples or CDN is required; the local Three.js engine and MIT license are bundled. System UI/Arial fonts use the device’s existing font installation.

The final RC Trigger Racing 3:4 cinematic carousel card was generated with OpenAI image generation for this project and shown to the user before inclusion. No third-party trademarked vehicle designs or external stock-image licenses were requested. Distribution rights remain subject to the repository owner's existing terms and the applicable OpenAI output terms; no new blanket license for the rest of Arcadium is implied.

ASSET_MANIFEST.json records SHA-256 hashes, purpose, origin and transparency for each bundled asset.

3D repair V3: Three.js 0.170.0 and its RoomEnvironment helper are bundled locally under the MIT license in vendor/THREE-LICENSE.txt. Models, racing roundels, invented liveries and the studio/track scenes are original programmatic artwork. No Scalextric/Carrera/TYCO packaging, logos or vehicle imagery is included.

Deluxe V4 adds five original panoramic environment matte paintings (pine mountain valley, neon waterfront city, red-rock canyon, Pacific coast and night arena) and one transparent pine foliage cutout generated with OpenAI image generation for this game. They are bundled game assets, not screenshots of completed gameplay. In-game review images are separately captured from the actual browser renderer. Original procedural terrain, track materials, foliage placement, pits, lighting and the detailed thirty-vehicle meshes are included in source. No third-party vehicle brands, manufacturer liveries or stock environment models are used.
