# RC Racing — restore / continue after Windows reinstall

Remote branch: **feat/rc-racing-3d-repair**, repair stacked on original PR **#29**, stacked on original PR **#27**, stacked on **feat/price-worm-crater-mini-vibe**. Clone the repository and check out this branch to restore the full project. This is the RC project backup, not a backup of unrelated personal Windows files or the user's complete live OS installation.

The Windows/Mini Vibe game is implemented and software-tested: five original stunt circuits, five ten-lap rounds, thirty actual 3D vehicles in five classes with original numbered liveries, physical shoulder throttle/brake, rotating modern-retro personal display, actual power/speed/lap/crash telemetry, six-step walking recovery plus two-second re-slot, bounded two-step Ghost Roadblock, ramp jumps, magnetic wall/ceiling sections, double-loop inverted jump, podium/standings, carousel registration, guarded one-click installer, rollback, verifier, complete source/art and tests.

**The user confirmed Android-tablet/phone hosting is for later.** It is not a blocker or claimed feature of this Windows/Mini Vibe release. Direct instructions preserve 10-lap default racing and manual shoulder recovery, superseding Issue #28's suggested shorter defaults and auto-respawn. Optional short races/lap settings are available explicitly in the lobby.

Full release ZIP: **downloads/ARCADIUM_RC_TRIGGER_RACING_DELUXE_V4.zip**. Extract, run START_INSTALL.cmd against the existing Arcadium_OS_COMPACT, follow the installer’s refresh/restart instruction. Existing RC v11 Mini Vibes need no APK reinstall. The installer preserves Home, other games, approved existing cards, pairing and server port 8787.

Signed Android app: version **11**, package **com.arcadium.home**. Existing signing identity and all 45 bundled Home assets retained. CI run **41729374431**, release **arcadium-home-og9-106-67ad4d9b** contains Arcadium-Home.apk. Its SHA-256 is **213b818689160d075bccd41ce7f12a656927d307486d940f0f8a961cddc85bf5**. The complete ZIP renames it Mini Vibe/Arcadium-RC-Racing.apk without changing its bytes.

See README.md for exact rules and controls, VALIDATION.md for reproduction and evidence, ASSET_MANIFEST.json/CREDITS.md for assets, and review/ for real implementation captures. Current software checks: 11 engine tests, five Python package/integration tests and expanded six-client browser smoke test, plus signed Android build/input/certificate verification.

Physical Mini Vibe controls/six real devices, actual Windows server reload and carousel appearance, and antivirus acceptance require user testing. Do not label those verified from file-copy or automated tests.

Do not rebuild or replace Arcadium Home. Reuse the existing numbered event stream and bridge lease; keep canonical red, blue, green, yellow, pink, white. Do not introduce another production listener. The 8787 harness is development-only and its injection routes are not shipped in production.

Deluxe V4 includes the full detailed fleet, five themed worlds, studio category garage, closer personal cameras, 30fps main render cap and packet-edge recovery regression fix. Existing RC v11 Mini Vibes keep the same APK and pairing. Source, assets and the exact full ZIP must all be pushed before delivery.
