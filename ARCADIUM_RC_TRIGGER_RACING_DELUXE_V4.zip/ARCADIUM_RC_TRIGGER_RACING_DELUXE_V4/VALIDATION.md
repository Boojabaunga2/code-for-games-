# RC Trigger Racing — Windows/Mini Vibe validation

## Passed software checks

**11 Node engine tests**: five distinct closed tracks and ten-lap default; 1–6 human clients/canonical colors; real throttle/brake/release; disconnect/rejoin; complete five-round ten-lap championship with actual finishes on all tracks; temporary ghost rotation; warning/charge/cooldown/immunity/reset rules; reckless-throttle de-slot cost; pause; ties/co-champions/no sixth round; thirty equal-performance car choices persisting across rounds; exact-position alternating-shoulder recovery with two-second wait and release safety; one-time two-step roadblock without timer reset; ramp/inverted-jump states and two loop rotations; cyclic track selection and short distance-classified races.

**Five Python package/integration tests**: targeted install, repeat install and selective rollback; unchanged Home, main Windows server and prior helpers/games; approved-image/custom-field preservation; unknown-bridge, ambiguous registration and later-edit refusal; six mode/frame/static-asset routes, stale frames, traversal rejection and prior-game handoff; exact final ZIP extraction/installation/repeat/rollback and corrupted-payload refusal, including exact signed APK digest.

**3D repair V3:** Node geometry checks cover all five finite closed orthonormal rail paths, 24-unit lane spacing, real inverted loop/ceiling normals, steep wall climbing and exact-position floor-to-rail recovery. Vehicle roster checks cover all five classes, six choices per class and thirty unique numbers. Actual browser captures verify the integrated main/garage/personal renderer. Controller checks cache previously rendered views to isolate held-event timing from software-GPU stalls; each real seat camera is then rendered through the JPEG transport. This does not establish real-device rendering throughput. The earlier V1 browser suite is not evidence of V3 hardware performance.

**Windows launcher:** GitHub Actions run **41753284472** passed on windows-latest with Python 3.12/Tkinter, exercising START_INSTALL.cmd from a path containing spaces and an ampersand. Missing-runtime winget download and real user-device installation remain untested.

**Android:** Java held-input tests passed locally and in signed build **41729374431**, source **67ad4d9b2ca09b8fc514e5772fa8c6f76e540461**, release **arcadium-home-og9-106-67ad4d9b**. Compilation, signing and prior-certificate comparison passed. Package ID remains com.arcadium.home, version 11. All 45 bundled Home assets remain byte-identical. Packaged APK SHA-256: **213b818689160d075bccd41ce7f12a656927d307486d940f0f8a961cddc85bf5**.

## Reproduce from repository root

```
node integrations/rc-trigger-racing/tests/engine.test.mjs
python integrations/rc-trigger-racing/build_package.py --apk /path/to/Arcadium-Home.apk
python -m unittest discover -s integrations/rc-trigger-racing/tests -v
python integrations/rc-trigger-racing/tests/harness.py
# Separate terminal, with Playwright/Chromium installed:
node integrations/rc-trigger-racing/tests/browser.cjs
```

The test harness is not the production server and must not run alongside the actual venue OS on 8787. Test-only stream injection routes are not installed by the production helper. The test fixture uses mock venue clients, not six real authenticated Mini Vibes.

## Hardware acceptance still required

Physical Mini Vibe controls/axis latency, six actual devices, real Android update/reconnect, the user's actual Windows restart/carousel/PLAY, and antivirus acceptance remain unverified. Software tests are not physical acceptance. Check R1 hold/release, L1 brake, choosing a car, Y rotation, loop/jump behavior, recovery and ghost roadblock, disconnect/rejoin, exit to Command Deck and launching another existing game.

Android tablet with phone controllers is explicitly a later phase, confirmed by the user. This release targets the existing Windows OS, Mini Vibes, and offline local keyboard/gamepads.

## V3 final browser result

Passed: 1–6 mock venue clients; held throttle/release; disconnect/rejoin; 30 loaded models and PC selection; Y rotation; alternating walking/roadblock/re-slot; actual inverted jump; six distinct actual 720×720 views; no touch buttons; read-only rendering; complete five-round ten-lap session and releasing the RC lease on exit. See review/finished-v3/browser-validation.txt and actual screenshots. Graphics and event timing are isolated as described above; these are software checks, not a claim of six-device frame rate.

## Deluxe V4

Deterministic engine/roster/rail-geometry checks remain applicable. A new input regression verifies distinct shoulder packets received between rendered frames count exactly once during walking recovery, require six alternating steps, and retain the full two-second wait.

The actual browser graphics check constructs all thirty race-detail models, checks finite geometry/bounds and four/six wheel-animation groups as appropriate, renders all five themed worlds, captures all five garage categories and six distinct 720×720 personal views, and checks the resized UI after its resize event. No actual-device frame rate or six-device latency claim follows from the software GPU.

Five generated panoramic background textures and the transparent pine cutout are separately credited in CREDITS.md/ASSET_MANIFEST.json. All vehicle, track and foreground scenery geometry is original source code. Finished screenshots show actual game-renderer output; race positions are staged and the simulation is frozen during visual inspection. A separate bridge regression exercises actual numbered controller events and a full championship.

Final Deluxe V4 native browser regression passed: 1–6 connected mock venue clients, held throttle/release, Y rotation, exact walking recovery/roadblock/re-slot, actual inverted jump, six distinct JPEG views, disconnect/reconnect with repeated held snapshots after foreground resume, pure rendering, complete five-round ten-lap session and releasing only RC’s lease on exit. See review/finished-v4/native-validation.txt. Model/graphics/responsive checks and the exact extracted-package install/repeat/rollback/route suite passed as well.
