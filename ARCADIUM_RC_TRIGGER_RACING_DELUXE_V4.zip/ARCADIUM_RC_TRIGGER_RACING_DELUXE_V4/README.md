# Arcadium RC Trigger Racing

**Windows Arcadium OS + Mini Vibes. Five tracks. Five rounds. Ten laps. Thirty selectable cars.** The game is local/offline, uses the existing OS carousel and server on **8787**, and has no runtime CDN, account or external art dependency. Android-tablet/phone hosting is a later phase, as confirmed by the user; it is not part of this delivery.

## Install

1. Extract the **whole ZIP**.
2. Double-click **START_INSTALL.cmd**, select your existing **Arcadium_OS_COMPACT** folder, and wait for the backup/install result.
3. For a first install, **restart Windows once** to load the added helper. For an existing RC installation with the same helper, **Ctrl+F5** and reopen the game; the installer tells you which. Open Arcadium normally, choose **RC Trigger Racing** from Games, and press PLAY.
4. If RC Racing v11 is not already installed, install **Mini Vibe/Arcadium-RC-Racing.apk** on each Mini Vibe **as an update**. Existing v11 users need no new APK. Keep app data and pairing. Reconnect normally.

The installer preserves Home, the main server source, approved existing cards, other games, player data and pairing. It adds one catalog entry and one shared-bridge wrapper, with checksums and backups. The install window also provides **Rollback**: select its `rc_trigger_racing_v1_*` backup, then restart Windows once. It refuses unknown bridge structures, duplicate registrations and conflicting later edits rather than overwriting them.

## Controls

- **Hold R1 or D-pad RIGHT:** gas. **Hold L1 or DOWN:** brake. Release to coast. Actual held/released state is used; there are no guessed movement pulses.
- **START:** start/pause/resume/advance. **SELECT:** cut input. No Enter key is required.
- Press-only keypad fallback: **A** raises the throttle lever by 25%; **B** cuts it. This is a documented throttle lever, not a fabricated held direction.
- **Y** rotates only your personal 720×720 display by 90°. Hold the handheld sideways with its shoulder button as gas. The display shows actual speed, throttle power, lap/position, grip stress, best lap, round crashes and championship crash total.
- The Mini Vibe screen has **no fake touch buttons**. In the garage, use LEFT/RIGHT to browse, UP/DOWN to jump six cars, A to confirm, START to race. Direction browsing repeats after 320ms, then every 140ms.
- PC keyboard throttle/brake pairs by seat: **Q/W, E/R, T/Y, U/I, O/P, A/S**. **SPACE** starts/pauses; Escape returns. Browser gamepads use right/left trigger values, with shoulder fallback.

Six canonical colors remain red, blue, green, yellow, pink, white. Connected seats become humans; unpaired seats use CPU drivers. Disconnect brakes safely; rejoin retains the car and progress. Humans do not silently become AI. Local keyboard/gamepads and CPUs work without a venue server; serve the game folder locally for development because ES modules are restricted under file://. Production launch is through the existing OS, not another server.

## Thirty-car garage

**Five classes × six numbered vehicles = 30 choices: race cars, trucks, vans, off-road and classics.** Original two/three-color liveries, roof and side numbers, recognizable bodies, windows, wheels and suspension are real 3D meshes. Body paint stays independent of driver identity; canonical seat colors remain in the HUD and car markers. All have equal performance: no purchases, unlock economy or hidden advantage. Click **GARAGE / 30 CARS** on the PC, select a seat footer and click a car card. Click GARAGE again to return. Car choices persist across rounds.

## Five original stunt tracks

Click a track preview in the lobby to choose where the championship starts; all five then run in cyclic order without repeats.

1. **Cliffhanger Climb:** wall climb, elevated magnetic section, glowing gates and ramp.
2. **Zero-G Rush:** ceiling-running magnetic track, gravity-defying elevation and jumps.
3. **Daredevil Gap:** figure-eight crossing with a timed airborne jump over the other track section.
4. **Grand Prix 500:** long technical chicanes, lap/split timing and precise throttle control.
5. **Double Loop Chaos:** two momentum-dependent vertical loop rotations followed by an inverted airborne jump and magnetic catch into the same lane. The live stunt camera shows your real car and current stunt state.

Default: **10 laps per race**, five rounds, 240-second safety cap, three-second countdown and eight-second classification. The PC can select 1–20 laps or optional 30/60/90-second sprints. The default remains the user's ten-lap championship. A timed sprint classifies unfinished cars by actual distance at the flag.

All cars stay on their own sampled closed paths. Race distance and corner limits use the same reference path, so the visible inside lane has no permanent advantage; lane assignment rotates each round. Curves build grip stress when overspeeded. Actual takeoff speed, airborne time, hard-landing stress, loop height and momentum affect the car. Magnetic assistance after recovering inside a stunt prevents an endless zero-speed fall at the same restart position. Track boundaries cannot be crossed by steering or controller input.

## Run over and re-slot your car

A de-slot freezes the car at its current race distance. **Release the shoulders**, then alternate six separate **R1/L1 taps** to move your pit-crew runner to it. Holding or repeating one shoulder does not count as extra steps; pressing both together does not skip the walk. A/B is the press-only alternative; local keyboard/gamepad shoulder/trigger edges work too.

After reaching the car, wait **two seconds** while it is re-slotted. Release held controls to rejoin from exactly the same distance, at zero speed. The race continues for everybody else. CPU drivers follow the same six-step/two-second sequence. Disconnect or pause never teleports the car or skips recovery.

## Ghosts, points and ties

Only the last active racer becomes a ghost for the **following round**. The previous ghost returns after its one-round shift: not cumulative elimination. A last-place tie uses rotating deterministic selection `(round-1) modulo tied-driver-count`, in canonical seat order.

Ghost controls: **R1/A** deploys, **L1/B** changes power, **LEFT/UP** changes target. The ghost screen shows the actual target, power, charges and cooldown. **Three charges per ghost round**, a **12-second shared cooldown**, **one-second visible warning**, **1.6-second effect**, and **seven-second post-effect target immunity**. No powers in the first/final five seconds. No stacking, finished-driver targeting, collisions, inverted controls or hard stuns.

- **Static:** throttle capped at 70%.
- **Magnet:** 10 additional speed-units/second drag.
- **Draft damper:** acceleration reduced to 65%.
- **Ghost Roadblock:** targets a walking recovery only; after the warning, adds **two extra steps once per recovery**, at most eight total. It cannot reset or interrupt the two-second re-slot timer. If the driver reaches the car before the warning ends, the block does not apply.

Charges, effects, cooldowns and immunity reset each round. Values are configurable in `engine.mjs` → `DEFAULTS.ghost`; roadblock extra steps are capped at two. Ghosts do not score racing points that round.

Racing points by placement: **10, 8, 6, 4, 2, 1**. Finish time, then unfinished distance determine classification. Times within 1ms (unfinished distance within 0.01 units) share competition placement and points; following ranks skip appropriately. Equal championship points give **co-champions**. No money, prizes or unreviewed economy is introduced.

## Verification / source

Run **VERIFY_RC_RACING.py** with the game open on the PC to save a read-only six-seat route/frame report. HTTP success is not proof of hardware controls.

`engine.mjs` owns the simulation; `tracks.mjs` paths/elevations; `input.mjs` controls; `geometry.mjs` shared elevated rail/car frames; `scene3d.mjs` and `models3d.mjs` real offline Three.js geometry; `render.mjs` and `personal.mjs` the shared-engine views; `native.mjs` existing numbered events, active lease and six frame feeds. `rc_racing_routes.py` adds host-only producers and personal LAN display routes, with stale-frame rejection; no new listener. See **VALIDATION.md**, **ASSET_MANIFEST.json** and **CREDITS.md**.

The signed app retains `com.arcadium.home`, existing signing identity, Home assets and prior controls; version 11 adds RC's game-specific R1/L1 mapping. Build **41729374431**, source `67ad4d9b2ca09b8fc514e5772fa8c6f76e540461`, release `arcadium-home-og9-106-67ad4d9b`.

**Physical Mini Vibes, six real devices, actual Windows reload/carousel appearance and antivirus acceptance still require the user's hardware test.** Automated source, engine, browser and installer tests do not establish physical acceptance. Android tablet/phone mode is explicitly deferred.

## Fresh Windows / “Choose an app to open .py”

Use **START_INSTALL.cmd**, not the .py file. The launcher finds an existing Python 3.9+ with Tkinter and starts the same installer directly, without relying on Windows file associations. If Python is missing, it installs the official **Python.Python.3.12** winget package for the current Windows account, then opens the installer. Internet is needed only for that missing runtime installation; the game itself remains offline. This does not replace Home or set up a new Arcadium OS. If winget is unavailable or dependency installation fails, it stops visibly without changing Arcadium files. The launcher preserves the existing signing identity and pairing. It does not configure Windows startup.

## Deluxe V4

Real elevated six-lane road meshes, supports, vertical loops, an inverted jump and actual airborne car positions replace the flat-map presentation. The main camera follows a selected driver or shows the complete track; each handheld renders its own driver from the same authoritative simulation. Five track cards are actual renderer captures. Graphics require WebGL2 in Chrome/Edge on the host PC; the Mini Vibe receives JPEG frames and does not run a second 3D simulation. All engine dependencies are bundled offline.

The approved sculpted-car treatment now covers the complete thirty-vehicle roster. Race cars and classics use smooth lofted coupe bodies, shaped glazing, lights, racing numbers, wheels and brakes. Utility models add vans, pickup beds, roll cages, six-wheel trucks, roof equipment and off-road tires. The garage has a large selected-machine studio view and five category tabs, with six choices in each; physical D-pad browsing and START remain available.

The five circuits now run through **Pine Ridge**, **Neon District**, **Red Rock Run**, **Pacific Grand Prix** and **Thunderdome**. Locally bundled original panoramic background art combines with actual 3D foreground trees, terrain, rocks, pits and lighting. Background art is a distant backdrop; cars, rails, stunt motion and nearby props are rendered geometry. The main scene uses a 30fps render cap while inputs and the fixed-step simulation continue independently. Racing uses reduced-detail meshes; close-up garage views retain the higher-detail model treatment.

The Windows package is **ARCADIUM_RC_TRIGGER_RACING_DELUXE_V4.zip**. It contains the same signed v11 APK for first-time setup; devices already running RC v11 need no app update. The helper is unchanged, so existing RC users can refresh and reopen after installation. All runtime assets remain local/offline. Review screenshots and browser evidence live in the GitHub `review/finished-v4` directory, not in the installation ZIP.

Recovery consumes real shoulder state edges as packets arrive, so multiple walking taps received between rendered frames remain distinct. It does not fabricate held inputs, repeat taps, change the six-step requirement or shorten the two-second re-slot delay.
