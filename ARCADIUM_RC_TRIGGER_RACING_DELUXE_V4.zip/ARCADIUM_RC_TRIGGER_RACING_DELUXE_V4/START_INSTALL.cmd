@echo off
setlocal EnableExtensions DisableDelayedExpansion
title Arcadium RC Trigger Racing Setup
cd /d "%~dp0"
if not exist "%~dp0INSTALL_RC_RACING.py" goto incomplete
if not exist "%~dp0CHECKSUMS.json" goto incomplete
if not exist "%~dp0games\rc-trigger-racing\index.html" goto incomplete

echo Arcadium RC Trigger Racing - Windows setup
echo Finding an existing Python installation with its standard window toolkit...
call :find_python
if defined ARCADIUM_RC_PY_EXE goto launch
if defined ARCADIUM_RC_USE_PY goto launch

echo.
echo Python with Tkinter was not found after the Windows reinstall.
echo Installing the official Python 3.12 package for your Windows account.
echo This needs an Internet connection. Arcadium files have not been changed.
where winget.exe >nul 2>&1
if errorlevel 1 goto no_winget
winget install --id Python.Python.3.12 --exact --source winget --scope user --silent --accept-package-agreements --accept-source-agreements --disable-interactivity
if errorlevel 1 goto dependency_failed
call :find_python
if defined ARCADIUM_RC_PY_EXE goto launch
if defined ARCADIUM_RC_USE_PY goto launch
goto dependency_failed

:launch
echo Opening the Arcadium installer. Select your existing Arcadium_OS_COMPACT folder.
if defined ARCADIUM_RC_USE_PY (
  py -3 "%~dp0INSTALL_RC_RACING.py"
) else (
  "%ARCADIUM_RC_PY_EXE%" "%~dp0INSTALL_RC_RACING.py"
)
if errorlevel 1 goto installer_failed
exit /b 0

:find_python
set "ARCADIUM_RC_PY_EXE="
set "ARCADIUM_RC_USE_PY="
for /d %%D in ("%LOCALAPPDATA%\Programs\Python\Python3*") do call :probe "%%~fD\python.exe"
for /d %%D in ("%LOCALAPPDATA%\Python\pythoncore-*") do call :probe "%%~fD\python.exe"
for /d %%D in ("%ProgramFiles%\Python3*") do call :probe "%%~fD\python.exe"
for /d %%D in ("%SystemDrive%\Python3*") do call :probe "%%~fD\python.exe"
for /f "delims=" %%P in ('where python.exe 2^>nul') do call :probe "%%P"
if defined ARCADIUM_RC_PY_EXE exit /b 0
where py.exe >nul 2>&1
if errorlevel 1 exit /b 0
py -3 -c "import sys, tkinter; assert sys.version_info >= (3,9)" >nul 2>&1
if not errorlevel 1 set "ARCADIUM_RC_USE_PY=1"
exit /b 0

:probe
if defined ARCADIUM_RC_PY_EXE exit /b 0
if not exist "%~1" exit /b 0
rem Skip the Windows Store placeholder, which can open a store instead of Python.
if /i "%~1"=="%LOCALAPPDATA%\Microsoft\WindowsApps\python.exe" exit /b 0
"%~1" -c "import sys, tkinter; assert sys.version_info >= (3,9)" >nul 2>&1
if errorlevel 1 exit /b 0
set "ARCADIUM_RC_PY_EXE=%~f1"
exit /b 0

:incomplete
echo.
echo STOP: Extract the WHOLE ZIP first, then double-click START_INSTALL.cmd.
echo Keep the games folder, CHECKSUMS.json and Python files beside this launcher.
pause
exit /b 1

:no_winget
echo.
echo STOP: Windows App Installer / winget is not available on this Windows setup.
echo Install official Python 3.12 with Tcl/Tk from https://www.python.org/downloads/windows/
echo Then run START_INSTALL.cmd again. No Arcadium files were changed.
pause
exit /b 1

:dependency_failed
echo.
echo STOP: Python setup did not complete. The winget output above explains why.
echo No Arcadium files were changed. Keep this window open and send its message.
pause
exit /b 1

:installer_failed
echo.
echo STOP: The Python installer exited with an error. Keep this window open.
pause
exit /b 1
