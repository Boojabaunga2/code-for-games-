import zipfile,hashlib,base64,importlib.util,json,sys,tempfile,threading,time,unittest,urllib.request,urllib.error
from pathlib import Path
from http.server import ThreadingHTTPServer
from harness import ROOT,ref,modules,updater,routes
# Borrow only fixture setup, never discover earlier suites as part of this suite.
old=sys.modules['harness'];sys.modules['harness']=ref
spec=importlib.util.spec_from_file_location('rc_fixture_suite',ROOT.parent/'three-game-party/tests/test_party.py');fixture=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixture);sys.modules['harness']=old
class Install(unittest.TestCase):
 setUp=fixture.Install.setUp
 tearDown=fixture.Install.tearDown
 def seed(self):
  fixture.Install.seed(self,False);(self.root/'party_routes.py').write_bytes((ROOT.parent/'three-game-party/party_routes.py').read_bytes());(self.root/'arcadium_game_bridge.py').write_text(ref.updater.patch_bridge((self.root/'arcadium_game_bridge.py').read_text()));return {p.relative_to(self.root).as_posix():p.read_bytes() for p in self.root.rglob('*') if p.is_file()}
 def test_install_repeat_safe_rollback_and_home_preserved(self):
  before=self.seed();first=updater.install(self.root);catalog=json.loads((self.root/'data/arcadium.json').read_text());self.assertEqual(catalog['games'][-1]['id'],'rc-trigger-racing');self.assertEqual(catalog['games'][-1]['image'],'/games/rc-trigger-racing/card.png');self.assertEqual(updater.patch_bridge((self.root/'arcadium_game_bridge.py').read_text()),(self.root/'arcadium_game_bridge.py').read_text());second=updater.install(self.root);updater.rollback(second)
  for name,data in before.items():
   if name not in ('arcadium_game_bridge.py','data/arcadium.json'):self.assertEqual((self.root/name).read_bytes(),data,name)
  c=json.loads((self.root/'data/arcadium.json').read_text());c['activity'].append({'preserve':'later'});(self.root/'data/arcadium.json').write_text(json.dumps(c));updater.rollback(first);self.assertEqual((self.root/'arcadium_game_bridge.py').read_bytes(),before['arcadium_game_bridge.py']);self.assertEqual(json.loads((self.root/'data/arcadium.json').read_text())['games'],json.loads(before['data/arcadium.json'])['games'])
 def test_unknown_bridge_and_later_edit_guard(self):
  self.seed();backup=updater.install(self.root);file=self.root/'games/rc-trigger-racing/engine.mjs';file.write_text('later work');self.assertRaises(RuntimeError,updater.rollback,backup);self.assertEqual(file.read_text(),'later work');(self.root/'arcadium_game_bridge.py').write_text('def bridge(Base):\n return Base\n');self.assertRaises(RuntimeError,updater.prepare,self.root)
 def test_duplicate_registration_refuses_and_approved_image_preserved(self):
  c={'games':[{'id':'rc-trigger-racing','image':'approved.png','custom':'KEEP'}]};updater.registration(c);self.assertEqual(c['games'][0]['image'],'approved.png');self.assertEqual(c['games'][0]['custom'],'KEEP');c['games'].append({'id':'rc-trigger-racing'});self.assertRaises(RuntimeError,updater.registration,c)
 def test_exact_release_zip_install_repeat_rollback_and_corrupt_payload(self):
  before=self.seed();archive=ROOT.parents[1]/'downloads/ARCADIUM_RC_TRIGGER_RACING_DELUXE_V4.zip'
  with tempfile.TemporaryDirectory() as directory:
   with zipfile.ZipFile(archive) as z:
    self.assertEqual([Path(n).name for n in z.namelist() if Path(n).suffix.lower() in ('.cmd','.bat','.exe','.ps1')],['START_INSTALL.cmd']);z.extractall(directory)
   folder=Path(directory)/archive.stem
   self.assertTrue((folder/'games/rc-trigger-racing/worlds.mjs').is_file());self.assertTrue((folder/'games/rc-trigger-racing/fleet-models.mjs').is_file());self.assertEqual(len(list((folder/'games/rc-trigger-racing/assets').glob('world-*-v4.png'))),5)
   self.assertIn('winget install --id Python.Python.3.12',(folder/'START_INSTALL.cmd').read_text())
   self.assertEqual(hashlib.sha256((folder/'Mini Vibe/Arcadium-RC-Racing.apk').read_bytes()).hexdigest(),'213b818689160d075bccd41ce7f12a656927d307486d940f0f8a961cddc85bf5')
   specification=importlib.util.spec_from_file_location('rc_release_installer',folder/'update_racing.py');release=importlib.util.module_from_spec(specification);specification.loader.exec_module(release)
   first=release.install(self.root);second=release.install(self.root);release.rollback(second);release.rollback(first)
   self.assertEqual((self.root/'arcadium_game_bridge.py').read_bytes(),before['arcadium_game_bridge.py'])
   self.assertEqual((self.root/'arcadium_server.py').read_bytes(),before['arcadium_server.py'])
   (folder/'games/rc-trigger-racing/engine.mjs').write_text('corrupted');self.assertRaises(RuntimeError,release.prepare,self.root)
class Routes(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.bridge,Handler=modules();cls.server=ThreadingHTTPServer(('127.0.0.1',0),Handler);cls.server.events={'latest':0,'events':[],'slots':[]};cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True);cls.thread.start();cls.base='http://127.0.0.1:'+str(cls.server.server_port)
 @classmethod
 def tearDownClass(cls):cls.server.shutdown();cls.server.server_close();cls.thread.join()
 def req(self,path,data=None):
  try:
   with urllib.request.urlopen(urllib.request.Request(self.base+path,data=None if data is None else json.dumps(data).encode(),headers={'Content-Type':'application/json'})) as r:return r.status,r.read()
  except urllib.error.HTTPError as e:return e.code,e.read()
 def test_six_modes_frames_assets_staleness_and_previous_games(self):
  self.assertEqual(self.req('/arcadium-vibe/activate/rc-trigger-racing',{})[0],200)
  for i,color in enumerate(routes.COLORS):
   self.assertEqual(json.loads(self.req('/api/vibe/mode?color='+color)[1])['game'],'rc-trigger-racing');frame=b'\xff\xd8'+color.encode();self.assertEqual(self.req('/arcadium-racing/rc-trigger-racing/frame',{'seat':i+1,'image':base64.b64encode(frame).decode()})[0],200);self.assertEqual(self.req('/arcadium-racing/rc-trigger-racing/frame?color='+color),(200,frame))
  for path in ('card.png','engine.mjs','assets/car-white.svg','personal/vibe.html'):self.assertEqual(self.req('/games/rc-trigger-racing/'+path)[0],200)
  self.assertEqual(self.req('/games/rc-trigger-racing/%2e%2e/%2e%2e/update_racing.py')[0],404);routes.FRAMES['rc-trigger-racing'][1]=(time.monotonic()-4,b'old');self.assertEqual(self.req('/arcadium-racing/rc-trigger-racing/frame?color=red')[0],503)
  self.req('/arcadium-vibe/activate/crater-raiders',{});self.assertEqual(json.loads(self.req('/api/vibe/mode?color=red')[1])['game'],'crater-raiders');self.req('/arcadium-vibe/activate/rc-trigger-racing',{'active':False});self.assertEqual(json.loads(self.req('/api/vibe/mode?color=red')[1])['game'],'crater-raiders');self.assertEqual(self.req('/unrelated')[0],200);self.assertEqual(self.req('/api/vibe/events?after=0')[0],200)
if __name__=='__main__':unittest.main()
