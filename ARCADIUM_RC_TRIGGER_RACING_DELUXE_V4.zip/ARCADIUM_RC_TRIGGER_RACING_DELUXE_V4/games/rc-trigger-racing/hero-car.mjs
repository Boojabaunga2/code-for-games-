// Original Circuit GT proof model. Same dimensions / wheel contract as the racing roster.
import * as T from './vendor/three.module.js';
let studio=true;export function modelDetail(detail='studio'){studio=detail==='studio';}
const mat=(color,roughness=.35,metalness=.2)=>new T.MeshPhysicalMaterial({color,roughness,metalness,clearcoat:1,clearcoatRoughness:.12});
function mesh(g,geo,material,x=0,y=0,z=0){const m=new T.Mesh(geo,material);m.position.set(x,y,z);m.castShadow=true;m.receiveShadow=true;g.add(m);return m;}
function rounded(g,w,h,d,x,y,z,m,r=.15){const shape=new T.Shape(),a=w/2,b=d/2;shape.moveTo(-a+r,-b);shape.lineTo(a-r,-b);shape.quadraticCurveTo(a,-b,a,-b+r);shape.lineTo(a,b-r);shape.quadraticCurveTo(a,b,a-r,b);shape.lineTo(-a+r,b);shape.quadraticCurveTo(-a,b,-a,b-r);shape.lineTo(-a,-b+r);shape.quadraticCurveTo(-a,-b,-a+r,-b);const geo=new T.ExtrudeGeometry(shape,{depth:h,steps:1,bevelEnabled:true,bevelSize:r*.35,bevelThickness:r*.35,bevelSegments:studio?3:1,curveSegments:studio?8:3});geo.rotateX(-Math.PI/2);return mesh(g,geo,m,x,y-h/2,z);}
function tube(g,points,r,m){return mesh(g,new T.TubeGeometry(new T.CatmullRomCurve3(points.map(p=>new T.Vector3(...p))),Math.max(12,points.length*8),r,6,false),m);}
function surface(g,sections,m,{arches=false,axles=[-10.8,10.5],radius=3.3}={}){const vs=[],uv=[],indices=[],N=sections.length-1,K=studio?24:12;for(let i=0;i<=N;i++){const [x,w,b,t]=sections[i];for(let k=0;k<=K;k++){const a=k/K*Math.PI*2,side=Math.sin(a),top=Math.max(0,Math.cos(a)),bottom=Math.max(0,-Math.cos(a));let y=b+(t-b)*Math.pow(top,.42)-bottom*.8;if(arches&&Math.abs(side)>.8){let lift=0;for(const axle of axles){const dx=x-axle;if(Math.abs(dx)<radius+.4)lift=Math.max(lift,radius+Math.sqrt((radius+.4)**2-dx**2)-b);}y=Math.max(y,b+Math.max(0,lift)*Math.min(1,(Math.abs(side)-.8)/.12));}vs.push(x,y,w*side);uv.push(i/N,k/K);if(i<N&&k<K){const a=i*(K+1)+k,c=a+K+1;indices.push(a,a+1,c,c,a+1,c+1);}}}const geo=new T.BufferGeometry();geo.setAttribute('position',new T.Float32BufferAttribute(vs,3));geo.setAttribute('uv',new T.Float32BufferAttribute(uv,2));geo.setIndex(indices);geo.computeVertexNormals();return mesh(g,geo,m);}
const texCache=new Map();function lettering(text,{color='#f4f0e6',bg=null,width=1024,height=256,size=150,weight=900,italic=false}={}){const key=JSON.stringify([text,color,bg,width,height,size,italic]);if(texCache.has(key))return texCache.get(key);const canvas=document.createElement('canvas');canvas.width=width;canvas.height=height;const c=canvas.getContext('2d');if(bg){c.fillStyle=bg;c.fillRect(0,0,width,height);}c.fillStyle=color;c.font=`${italic?'italic ':''}${weight} ${size}px Arial`;c.textAlign='center';c.textBaseline='middle';c.fillText(text,width/2,height/2+height*.04,width*.94);const texture=new T.CanvasTexture(canvas);texture.colorSpace=T.SRGBColorSpace;texCache.set(key,texture);return texture;}
function label(g,text,w,h,x,y,z,options={},rotation=[0,0,0]){const m=new T.MeshBasicMaterial({map:lettering(text,options),transparent:true,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-3,side:T.DoubleSide});const o=mesh(g,new T.PlaneGeometry(w,h),m,x,y,z);o.rotation.set(...rotation);return o;}
export function detailedWheel(radius,side,knobby=false){const wheel=new T.Group(),rubber=mat('#101115',.94,0),metal=mat('#a6b2be',.25,.9),rimMat=mat('#d6b57c',.26,.8),dark=mat('#111720',.55,.25),red=mat('#f02736',.22,.3);const tire=mesh(wheel,new T.CylinderGeometry(3.3,3.3,2.55,studio?56:24),rubber);tire.rotation.x=Math.PI/2;
 for(const z of [-1.29,1.29]){mesh(wheel,new T.TorusGeometry(2.95,.12,studio?8:4,studio?56:24),rubber,0,0,z);mesh(wheel,new T.TorusGeometry(2.36,.12,studio?8:4,studio?56:24),metal,0,0,z);}
 const disc=mesh(wheel,new T.CylinderGeometry(2,2,.15,48),metal,0,0,side*.9);disc.rotation.x=Math.PI/2;const hub=mesh(wheel,new T.CylinderGeometry(.7,.7,2.7,24),rimMat);hub.rotation.x=Math.PI/2;
 for(let n=0;n<10;n++){const a=n*Math.PI/5;const spoke=rounded(wheel,2,.18,.27,Math.cos(a)*1.35,Math.sin(a)*1.35,side*1.35,rimMat,.08);spoke.rotation.z=a;const bolt=mesh(wheel,new T.SphereGeometry(.10,6,5),dark,Math.cos(a)*.44,Math.sin(a)*.44,side*1.42);}
 rounded(wheel,.65,1.6,.35,1.45,.45,side*1.1,red,.2);
 for(let n=0;n<(studio?36:18);n++){const a=n*Math.PI*2/(studio?36:18);const tread=rounded(wheel,.055,.08,1.9,Math.sin(a)*3.31,Math.cos(a)*3.31,0,dark,.01);tread.rotation.z=-a;}
 label(wheel,'ARCADIUM',3.8,.45,0,2.75,side*1.38,{width:1024,height:128,size:105,color:'#bcb9ad'},[0,side<0?Math.PI:0,0]);wheel.scale.setScalar(radius/3.3);if(knobby){for(let n=0;n<18;n++){const a=n*Math.PI/9,block=rounded(wheel,.65,.3,2.8,Math.sin(a)*3.28,Math.cos(a)*3.28,0,rubber,.05);block.rotation.z=-a;}}return wheel;}
export function makeHeroCar(spec,seat=0,seatColor='#ff304f',options={}){
 modelDetail(options.detail);const classic=spec.category==='CLASSICS',variant=spec.style,number=String(spec.number).padStart(2,'0');
 const g=new T.Group(),paint=mat(spec.paint,.22,.5),pearl=mat(spec.accent,.24,.25),dark=mat('#111720',.55,.25),metal=mat('#a6b2be',.25,.9),rimMat=mat('#d6b57c',.26,.8),rubber=mat('#101115',.94,0),glass=mat('#081925',.09,.55),red=mat('#f02736',.22,.3),led=new T.MeshStandardMaterial({color:'#dcefff',emissive:'#dcefff',emissiveIntensity:2}),amber=new T.MeshBasicMaterial({color:'#ffbb55'});
 // Dense lofted body with a low nose, rear haunches and genuine open wheel arches.
 const keys=[[-17.2,4.7,3.6,5.6],[-16,6.1,3.4,6.4],[-13,7.1,3.5,7.1],[-10.8,7.35,3.5,7.8],[-7,6.7,3.6,7.35],[-3,6.45,3.5,7.1],[3,6.6,3.5,6.95],[7,7.05,3.5,7.5],[10.5,7.4,3.4,7.9],[13,7.15,3.3,6.8],[16,6.7,3.15,5.7],[17.4,5.7,3.1,5.05]];
 const sections=[];for(let i=0;i<keys.length-1;i++)for(let n=0;n<8;n++){const u=n/8;sections.push(keys[i].map((v,k)=>{const a=keys[Math.max(0,i-1)][k],b=v,c=keys[i+1][k],d=keys[Math.min(keys.length-1,i+2)][k];return .5*((2*b)+(-a+c)*u+(2*a-5*b+4*c-d)*u*u+(-a+3*b-3*c+d)*u*u*u);}));}sections.push(keys.at(-1));if(variant==='prototype')sections.forEach(s=>s[3]*=.88);if(variant==='stock')sections.forEach(s=>s[1]*=1.04);surface(g,sections,paint,{arches:true});
 // White central racing band follows the same sculpted body rather than floating boxes.
 const stripe=[];for(const [x,w,b,t] of sections){if(x>-6&&x<4)continue;stripe.push([x,1.7,t-.03,t+.05]);}surface(g,stripe.filter(s=>s[0]<-6),pearl);surface(g,stripe.filter(s=>s[0]>4),pearl);
 rounded(g,34,1,12.6,0,2.3,0,dark,.6);rounded(g,5,.45,15.7,15.1,2.6,0,dark,.3);rounded(g,4,.35,14.9,-15.1,2.6,0,dark,.2);
 for(const side of [-1,1]){rounded(g,20,.8,.9,0,2.5,side*7.05,dark,.2);tube(g,[[-8,4,side*6.75],[0,3.5,side*6.8],[7,4,side*7.1]],.13,metal);}
 // A continuous tinted greenhouse, sculpted roof and painted pillars.
 const cabin=[[-8,3.5,7.1,7.2],[-6.3,4.4,7.1,9.8],[-3.9,4.45,7.1,11],[-.7,4.32,7.1,11.15],[2,4.35,7,10.7],[5.3,4.9,6.95,7.3]];
 const coupe=new T.Group();g.add(coupe);coupe.position.y=variant==='prototype'?3:classic?1.4:2.1;coupe.scale.y=variant==='prototype'?.5:['racehatch','compact','saloon'].includes(variant)?.95:classic?.8:.7;coupe.scale.x=['racehatch','compact','saloon'].includes(variant)?1.3:variant==='fastback'?1.2:1;const smooth=[];for(let i=0;i<cabin.length-1;i++)for(let j=0;j<8;j++){const u=j/8;smooth.push(cabin[i].map((v,k)=>v+(cabin[i+1][k]-v)*u));}smooth.push(cabin.at(-1));surface(coupe,smooth,glass);
 surface(coupe,[[-4.8,3.75,10.1,10.9],[-3.9,3.95,10.4,11.18],[-1,3.9,10.5,11.32],[1.4,3.7,10.3,11.1],[2,3.1,10.1,10.65]],paint);
 surface(coupe,[[-4.8,1.55,10.8,11.03],[-3.9,1.6,11.12,11.24],[-1,1.6,11.27,11.38],[1.4,1.55,10.97,11.18]],pearl);
 for(const side of [-1,1]){tube(coupe,[[5.3,7.15,side*4.9],[2,10.7,side*3.2]],.14,paint);tube(coupe,[[-8,7.15,side*3.5],[-4.8,10.8,side*3.1]],.15,paint);tube(coupe,[[-7,7.3,side*4.4],[-2,7.5,side*4.7],[4.3,7.3,side*4.8]],.1,metal);tube(coupe,[[-1.1,7.3,side*4.5],[-1.6,10.6,side*3.6]],.13,dark);rounded(coupe,1.9,.24,.25,-1.8,7,side*6.55,metal,.08);tube(coupe,[[2.7,8.1,side*4.4],[3.5,7.8,side*6.2]],.15,dark);rounded(coupe,1.7,.8,1.4,3.5,8.2,side*6.4,dark,.3);
 // Body seams, sill graphics and side intakes.
 tube(g,[[-6.5,7.2,side*6],[-6.7,6,side*6.7],[-6.5,4.2,side*6.85],[3.2,4.1,side*6.8],[4,6.3,side*6.65],[3.8,7.1,side*6.15]],.035,dark);
 rounded(g,3.2,1.3,.2,-6.6,5.2,side*6.95,dark,.25);for(let n=0;n<4;n++)rounded(g,.15,1.05,.27,-7.5+n*.55,5.2,side*7.1,metal,.03);
 label(g,number,5.5,3.1,-.7,5.7,side*6.7,{size:210,width:512,height:256,bg:'#eee9dd',color:'#101a25',italic:true},[0,side<0?Math.PI:0,0]);label(g,'ARCADIUM',7.4,.65,-.7,3.95,side*7.1,{size:100,width:1024,height:128},[0,side<0?Math.PI:0,0]);
 }
 // Triple-segment projector lamps, front intake mesh and splitter canards.
 rounded(g,.3,1.45,9.8,17.1,3.9,0,dark,.2);for(let n=0;n<12;n++)rounded(g,.36,.72,.09,17.3,3.8,-4.2+n*.76,dark,.02);
 for(const side of [-1,1]){rounded(g,3,.24,1.8,14.2,6.05,side*4.75,dark,.28);for(let n=0;n<3;n++){const light=rounded(g,.24,.18,1.32,13.4+n*.65,6.27,side*4.75,led,.05);light.rotation.z=-.12;}rounded(g,.2,.24,.5,17.1,4.7,side*5.25,amber,.03);
 rounded(g,.22,.55,4.5,-16.95,5,side*3.7,dark,.15);rounded(g,.26,.16,3.8,-17.13,5.1,side*3.6,red,.05);
 for(let n=0;n<5;n++)rounded(g,2.5,.12,.24,9.2+n*.25,7.25-n*.12,side*5.2,dark,.04);
 const fin=rounded(g,3.5,.15,1,15.7,3.1,side*7,dark,.04);fin.rotation.z=-.12;
 }
 // Rear wing with separate mounts/end plates, diffuser vanes and exhausts.
 if(!classic){for(const side of [-1,1])rounded(g,.75,3.4,.28,-12.9,8,side*3.2,dark,.08);
 const wing=rounded(g,4,.38,16.6,-13.5,10.3,0,dark,.25);wing.rotation.z=-.1;
 for(const side of [-1,1])rounded(g,4.2,1.65,.19,-13.5,10.6,side*8.25,paint,.2);
 label(g,'ARCADIUM',12,1.7,-13.5,10.65,0,{size:150,width:1024,height:256},[-Math.PI/2,0,Math.PI/2]);
 }
 for(let n=0;n<7;n++)rounded(g,4,1,.16,-15.4,2.3,-5.4+n*1.8,dark,.04);
 for(const side of [-1,1]){const pipe=mesh(g,new T.CylinderGeometry(.53,.53,1.4,24),metal,-16.9,3.4,side*4.6);pipe.rotation.z=Math.PI/2;const bore=mesh(g,new T.CircleGeometry(.4,24),dark,-17.62,3.4,side*4.6);bore.rotation.y=-Math.PI/2;}
 // Independent detailed wheels keep the live racing animation contract.
 g.userData.wheels=[];for(const x of [-10.8,10.5])for(const side of [-1,1]){const wheel=detailedWheel(3.3,side);wheel.position.set(x,3.3,side*6.75);g.add(wheel);g.userData.wheels.push(wheel);}
 // Hood number, small invented team graphics, flush hood pins and tow strap.
 label(g,number,4.2,4.2,8.7,8.06,0,{width:512,height:512,size:340,color:'#17222c',italic:true},[-Math.PI/2,0,-Math.PI/2]);
 label(g,spec.name,5.7,.7,14.1,6.35,0,{size:130,width:1024,height:128,color:'#fff2db'},[-Math.PI/2,0,-Math.PI/2]);
 for(const side of [-1,1]){mesh(g,new T.CylinderGeometry(.19,.19,.1,16),metal,13.3,6.8,side*3);rounded(g,.2,.8,.25,17.4,3.5,side*2.6,red,.03);}
 label(coupe,number,3.5,3.5,-1,11.4,0,{width:512,height:512,size:340,color:'#17222c',italic:true},[-Math.PI/2,0,-Math.PI/2]);rounded(coupe,.2,2.7,.2,-5,12,0,dark,.05);mesh(coupe,new T.SphereGeometry(.18,8,6),new T.MeshBasicMaterial({color:seatColor}),-5,13.45,0);
 if(classic){rounded(g,.7,.65,13,17.1,3.25,0,metal,.2);rounded(g,.7,.65,13,-17,3.25,0,metal,.2);for(const side of [-1,1]){const lamp=mesh(g,new T.CylinderGeometry(.8,.8,.25,20),led,16.5,5.3,side*4.8);lamp.rotation.z=Math.PI/2;}}g.scale.x=spec.length/35;g.scale.z=spec.width/14;g.userData.spec=spec;g.userData.paint=paint;g.userData.hero=true;return g;
}

export {mat,mesh,rounded,tube,surface,label};
