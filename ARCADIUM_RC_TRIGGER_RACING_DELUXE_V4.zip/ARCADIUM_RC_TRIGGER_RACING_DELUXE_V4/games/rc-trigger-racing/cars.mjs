// Five realistic slot-car categories, six numbered liveries each. Regulated equal performance.
const rows=[
 ['CIRCUIT GT','RACE CARS','coupe',35,14,4,4,3.3,7,'#ec3d19','#ece7dd','#111720'],
 ['TOURING CUP','RACE CARS','touring',34,14,4.7,4,3.3,12,'#d92b39','#f4efda','#152d49'],
 ['ENDURANCE','RACE CARS','prototype',40,15,3.2,4,3.2,21,'#f4f2e9','#83bd33','#273946'],
 ['OVAL STOCK','RACE CARS','stock',39,15,4.5,4,3.4,48,'#172f62','#f79432','#f5f0dc'],
 ['SPRINT COUPE','RACE CARS','sprint',33,14,3.9,4,3.3,33,'#f2c32d','#1b2232','#fbf5df'],
 ['CLUB RACER','RACE CARS','racehatch',29,13,4.8,4,3.1,86,'#50b7a2','#f4eedb','#1e3f53'],
 ['TROPHY RUNNER','TRUCKS','trophy',38,15,5.2,4,4.4,5,'#ee6b23','#164b85','#f5efd9'],
 ['STADIUM TRUCK','TRUCKS','stadium',35,15,5.5,4,4.2,17,'#1c2834','#d1db36','#eeeeec'],
 ['BAJA PICKUP','TRUCKS','pickup',38,14,5,4,4.1,24,'#ece7d7','#e34736','#253748'],
 ['SHORT COURSE','TRUCKS','shortcourse',33,15,5,4,4.3,41,'#216aa3','#f4f0de','#eea035'],
 ['SUPERTRUCK','TRUCKS','cabover',36,15,5.5,6,3.7,62,'#e5b323','#222b38','#f1ecdb'],
 ['SPORT PICKUP','TRUCKS','streetpickup',37,14,4.5,4,3.6,95,'#972e35','#efdbc2','#253039'],
 ['PANEL VAN','VANS','panelvan',35,14,9,4,3.4,8,'#efe6cc','#235e9b','#d94b39'],
 ['CREW VAN','VANS','crewvan',37,14,9,4,3.5,14,'#233c68','#f1c32e','#eeeee0'],
 ['MICROBUS','VANS','microbus',34,14,10,4,3.4,26,'#54b8af','#f1e8c9','#34494c'],
 ['PIT SERVICE','VANS','servicevan',38,15,10,4,3.5,39,'#c2c8ca','#c72d3b','#2c3b4c'],
 ['EXPRESS VAN','VANS','delivery',36,14,10,4,3.4,52,'#20292f','#92be39','#ede9da'],
 ['WORKS VAN','VANS','shortvan',30,14,9,4,3.2,77,'#e36732','#ede6ca','#28445c'],
 ['DUNE BUGGY','OFF-ROAD','buggy',32,12,3.5,4,4.3,3,'#e8b52b','#27363b','#ece5ca'],
 ['TRAIL 4X4','OFF-ROAD','trail',31,14,6,4,4.4,11,'#527c4c','#e2d5b9','#25362e'],
 ['RALLY RAID','OFF-ROAD','raid',37,15,6,4,4.2,28,'#f0ede1','#346cb4','#da4b3d'],
 ['SAND RAIL','OFF-ROAD','sandrail',37,12,2.8,4,4.3,45,'#de5235','#e6dfc7','#26333b'],
 ['CROSS COUNTRY','OFF-ROAD','utv',29,13,3.5,4,4.1,63,'#247f9c','#f0e3b8','#233a45'],
 ['RALLY HATCH','OFF-ROAD','rallyhatch',30,13,4.6,4,3.8,90,'#3266aa','#eee9d9','#edb632'],
 ['VINTAGE MUSCLE','CLASSICS','muscle',39,15,4.5,4,3.5,6,'#e5702a','#252a30','#efe8d6'],
 ['CLASSIC GT','CLASSICS','fastback',38,14,4,4,3.4,19,'#b82938','#efe4c9','#293942'],
 ['PONY COUPE','CLASSICS','pony',37,14,4.4,4,3.4,32,'#18324b','#e1bb5e','#efeadb'],
 ['RETRO COMPACT','CLASSICS','compact',26,13,5.2,4,3,56,'#e9dec2','#a72b37','#2e4351'],
 ['CLUB ROADSTER','CLASSICS','roadster',31,13,3.2,4,3.2,69,'#2d8e7d','#f0e5c7','#273b3f'],
 ['HISTORIC SALOON','CLASSICS','saloon',35,14,4.7,4,3.3,88,'#9dbdc9','#efeee0','#b8373c']
];
export const CARS=rows.map(([name,category,style,length,width,height,wheels,radius,number,paint,accent,secondary],id)=>({id,name,category,family:category,style,length,width,height,wheels,radius,number,paint,accent,secondary}));
export const CATEGORIES=['RACE CARS','TRUCKS','VANS','OFF-ROAD','CLASSICS'];
export const carIndex=value=>((Math.trunc(Number(value)||0)%30)+30)%30;
