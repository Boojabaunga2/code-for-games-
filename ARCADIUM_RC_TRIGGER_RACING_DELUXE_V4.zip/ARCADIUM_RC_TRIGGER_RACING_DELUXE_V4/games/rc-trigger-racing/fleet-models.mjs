import * as T from './vendor/three.module.js';
import {mat,mesh,rounded,tube,surface,label,detailedWheel,modelDetail} from './hero-car.mjs';
export function makeUtilityCar(s,seat,color,options={}){
 modelDetail(options.detail);const g=new T.Group(),L=s.length,W=s.width,R=s.radius,van=s.category==='VANS',truck=s.category==='TRUCKS',open=['buggy','sandrail','utv'].includes(s.style),paint=mat(s.paint,.25,.42),accent=mat(s.accent,.25,.3),dark=mat('#101923',.6,.3),metal=mat('#a6b1b9',.26,.85),glass=mat('#0b2030',.12,.45),red=mat('#f42c3c',.22,.2),light=new T.MeshStandardMaterial({color:'#e5f4ff',emissive:'#c9eaff',emissiveIntensity:1.3}),axles=s.wheels===6?[-L*.33,-L*.08,L*.31]:[-L*.31,L*.3],number=String(s.number).padStart(2,'0');
 // A lofted, rounded shell with cut-up wheel arches: utility bodies share details, not one silhouette.
 const body=van?[[ -L*.47,W*.38,R+1,R+5],[-L*.43,W*.49,R+1,R+6],[L*.31,W*.49,R+1,R+6],[L*.46,W*.41,R+1,R+4.6]]:open?[[-L*.4,W*.32,R+1,R+2.2],[0,W*.38,R+1,R+2.6],[L*.43,W*.27,R+1,R+2]]:[[-L*.47,W*.4,R+.3,R+3],[-L*.32,W*.5,R+.4,R+4.3],[L*.3,W*.49,R+.4,R+4.5],[L*.47,W*.4,R+.3,R+3.3]];
 const dense=[];for(let i=0;i<body.length-1;i++)for(let n=0;n<12;n++){const u=n/12;dense.push(body[i].map((v,k)=>v+(body[i+1][k]-v)*u));}dense.push(body.at(-1));surface(g,dense,paint,{arches:true,axles,radius:R});rounded(g,L*.88,1.1,W*.74,0,R*.65,0,dark,.5);
 let roof=R+10,roofX=0;
 if(van){
  const H=s.style==='microbus'?9:s.height,top=R+H+4,front=s.style==='shortvan'?L*.3:L*.39,back=-L*.43;
  rounded(g,front-back, H, W*.94,(front+back)/2,R+4+H/2,0,paint,1.3);
  roof=top+.22;roofX=-L*.05;rounded(g,front-back-1,.3,W*.83,roofX,roof,0,accent,.8);
  rounded(g,.15,4.3,W*.74,front+.09,top-3.3,0,glass,.45);
  for(const side of [-1,1]){rounded(g,L*.2,4,.14,front-L*.12,top-3.2,side*W*.477,glass,.45);if(['microbus','crewvan','servicevan'].includes(s.style))for(let n=0;n<3;n++)rounded(g,L*.15,3.8,.16,back+L*.13+n*L*.175,top-3.2,side*W*.478,glass,.4);
   rounded(g,L*.77,1.8,.16,-L*.04,R+5.5,side*W*.48,accent,.12);tube(g,[[front-L*.25,R+3.9,side*W*.483],[front-L*.25,top-.8,side*W*.483]],.055,dark);rounded(g,1.4,.2,.25,front-L*.17,R+6.5,side*W*.49,metal,.05);rounded(g,1.8,.8,1.2,front-L*.03,R+7,side*W*.55,dark,.25);
   label(g,number,6,4.2,-L*.08,R+8,side*W*.488,{size:210,width:512,height:256,bg:s.accent,color:'#17212a',italic:true},[0,side<0?Math.PI:0,0]);label(g,'ARCADIUM / WORKS',L*.48,.75,-L*.03,R+3.7,side*W*.49,{size:100,width:1024,height:128},[0,side<0?Math.PI:0,0]);}
  for(const z of [-W*.18,W*.18]){tube(g,[[back+.5,top+.7,z],[front-.5,top+.7,z]],.12,metal);rounded(g,.2,3.5,.8,back-.08,R+5,z,red,.12);}if(s.style==='servicevan')for(const side of [-1,1])rounded(g,L*.5,.8,.8,0,roof+1,side*W*.3,dark,.12);
 }else if(open){
  const top=R+(s.style==='utv'?8:6.5),rear=-L*.24,front=L*.17;roof=top+.4;roofX=-L*.03;
  for(const side of [-1,1]){tube(g,[[rear-L*.08,R+1.8,side*W*.33],[rear,top,side*W*.34],[front,top,side*W*.34],[front+L*.13,R+2,side*W*.34]],.35,accent);tube(g,[[rear,top,side*W*.34],[front+L*.1,R+2,side*W*.34]],.22,metal);rounded(g,L*.38,.65,W*.13,-L*.06,R+1,side*W*.42,dark,.2);rounded(g,4,4,3,-L*.07,R+3,side*2.2,dark,.8);}
  for(const x of [rear,front])tube(g,[[x,top,-W*.34],[x,top,W*.34]],.35,accent);
  if(s.style==='utv')rounded(g,L*.43,.45,W*.8,-L*.04,roof,0,paint,.6);else{rounded(g,L*.21,.4,W*1.04,-L*.35,top-1,0,dark,.3);for(const side of [-1,1])rounded(g,3,1.5,.18,-L*.35,top-.6,side*W*.51,accent,.1);}
  const hood=rounded(g,L*.27,.65,W*.54,L*.27,R+3.2,0,paint,.45);label(g,number,4,4,L*.27,R+3.62,0,{width:512,height:512,size:340,color:'#17212a',bg:s.accent},[-Math.PI/2,0,-Math.PI/2]);
  for(const side of [-1,1]){tube(g,[[-L*.31,R*.8,side*W*.5],[-L*.11,R+4,side*W*.3]],.22,metal);tube(g,[[L*.31,R*.8,side*W*.5],[L*.14,R+4,side*W*.3]],.22,metal);}
 }else{
  const cabover=s.style==='cabover',suv=['trail','raid'].includes(s.style),cabLength=cabover?L*.42:suv?L*.62:L*.36,cx=cabover?L*.22:suv?-L*.04:L*.05,top=R+(cabover?11:suv?10:9),base=R+4.1,back=cx-cabLength*.5,front=cx+cabLength*.5;roof=top+.3;roofX=cx;
  surface(g,[[back-1,W*.39,base,base+.2],[back+1.3,W*.38,base,top-.3],[front-2,W*.37,base,top],[front+2.1,W*.43,base,base+.3]],glass);
  rounded(g,cabLength-2,.5,W*.75,cx,top+.12,0,paint,.5);rounded(g,cabLength-3,.12,W*.25,cx,top+.46,0,accent,.15);
  for(const side of [-1,1]){tube(g,[[back-1,base,side*W*.39],[back+1.3,top-.3,side*W*.32]],.22,paint);tube(g,[[front+2.1,base,side*W*.43],[front-2,top,side*W*.31]],.22,paint);rounded(g,1.4,.2,.3,cx-2,base+.2,side*W*.46,metal,.06);rounded(g,2,.85,1.1,front-.4,base+2,side*W*.52,dark,.25);
   rounded(g,L*.65,1.25,.2,-L*.01,R+1.5,side*W*.495,accent,.1);label(g,number,5,3.3,cx,R+3.3,side*W*.5,{width:512,height:256,size:210,color:'#14202a',bg:s.accent,italic:true},[0,side<0?Math.PI:0,0]);label(g,'ARCADIUM',L*.28,.65,cx,R+1.1,side*W*.51,{width:1024,height:128,size:100},[0,side<0?Math.PI:0,0]);}
  if(truck&&!cabover){const bedX=-L*.29;rounded(g,L*.31,.5,W*.75,bedX,base-.3,0,dark,.3);for(const side of [-1,1])rounded(g,L*.35,2,.65,bedX,base+.5,side*W*.43,paint,.3);rounded(g,.65,2,W*.83,-L*.46,base+.5,0,accent,.3);if(['trophy','stadium','shortcourse'].includes(s.style))for(const side of [-1,1])tube(g,[[-L*.39,base+.8,side*W*.3],[-L*.15,top-1,side*W*.3],[-L*.1,top-1,side*W*.3]],.35,dark);}
  if(suv){rounded(g,L*.47,.5,W*.67,-L*.05,roof+.8,0,dark,.3);for(const side of [-1,1])tube(g,[[-L*.28,roof+1.5,side*W*.27],[L*.18,roof+1.5,side*W*.27]],.15,metal);const spare=detailedWheel(R,1,true);spare.scale.multiplyScalar(.86);spare.rotation.y=Math.PI/2;spare.position.set(-L*.48,R+5,0);g.add(spare);}
  for(let n=0;n<5;n++)rounded(g,L*.12,.12,.16,L*.3,R+4.65,-W*.2+n*W*.1,dark,.03);
 }
 // Shared close-up finish: real tires, fender lips, mirrors, lights, tow points and numbers.
 g.userData.wheels=[];for(const x of axles)for(const side of [-1,1]){const wheel=detailedWheel(R,side,s.category==='OFF-ROAD'||['trophy','stadium'].includes(s.style));wheel.position.set(x,R,side*W*.48);g.add(wheel);g.userData.wheels.push(wheel);}
 for(const side of [-1,1]){rounded(g,.3,1.3,W*.27,L*.46,R+2.1,side*W*.32,dark,.3);rounded(g,.34,.48,W*.2,L*.478,R+2.3,side*W*.32,light,.1);rounded(g,.3,1.2,.75,-L*.472,R+2.2,side*W*.37,red,.1);rounded(g,L*.1,.45,W*.1,L*.43,R*.65,side*W*.38,metal,.08);}
 rounded(g,.6,.8,W*.83,L*.47,R+.6,0,metal,.2);rounded(g,.3,1.4,W*.37,L*.485,R+2,0,dark,.2);for(let n=0;n<6;n++)rounded(g,.32,.75,.12,L*.49,R+2,-W*.14+n*W*.056,metal,.02);
 if(!open)label(g,number,5.5,5.5,roofX,roof+.31,0,{width:512,height:512,size:340,color:'#15202b',bg:s.accent,italic:true},[-Math.PI/2,0,-Math.PI/2]);
 tube(g,[[-L*.3,roof-.3,0],[-L*.3,roof+2.7,0]],.08,dark);mesh(g,new T.SphereGeometry(.18,8,6),new T.MeshBasicMaterial({color}),-L*.3,roof+2.85,0);
 g.userData.spec=s;g.userData.paint=paint;g.userData.hero=true;return g;
}
