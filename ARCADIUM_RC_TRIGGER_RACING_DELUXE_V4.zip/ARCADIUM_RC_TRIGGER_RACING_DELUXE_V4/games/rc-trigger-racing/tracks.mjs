import {stuntProfile} from './geometry.mjs';
export const COLORS=['red','blue','green','yellow','pink','white'];
export const PAINT=['#ff4057','#35baff','#67ed85','#ffe267','#ff79d4','#f2f4ff'];
const definitions=[
 ['workshop','CLIFFHANGER CLIMB','Climb the wall. Own the drop.','#b57743','#f2b65e',[[250,420],[350,220],[650,170],[910,240],[1140,170],[1400,310],[1370,570],[1150,710],[900,660],[720,520],[510,700],[300,650]],110],
 ['neon','ZERO-G RUSH','Magnetic ceiling rails. Full-send confidence.','#122e4d','#4cdeff',[[280,370],[400,180],[760,170],[1200,180],[1410,340],[1370,650],[1100,720],[940,600],[1050,420],[830,320],[650,440],[700,650],[450,720],[260,570]],95],
 ['canyon','DAREDEVIL GAP','Launch over the crossing. Catch your lane.','#986943','#ffbc64',[[280,450],[390,220],[650,180],[900,450],[1180,720],[1390,610],[1380,300],[1130,170],[900,450],[650,720],[360,680]],88],
 ['glacier','GRAND PRIX 500','Split times. Technical turns. Racing precision.','#324a69','#a2eaff',[[270,430],[380,200],[660,170],[850,300],[1060,170],[1350,240],[1400,520],[1200,710],[940,720],[800,590],[620,710],[350,660]],78],
 ['voltage','DOUBLE LOOP CHAOS','Twin loops. One impossible inverted jump.','#332b49','#ff865d',[[260,380],[430,190],[720,180],[870,340],[1050,190],[1370,230],[1400,470],[1240,700],[1000,710],[880,530],[680,530],[540,710],[300,650]],86]
];
const mix=(a,b,t)=>a+(b-a)*t;
export function createTrack(def,index){
 const [id,name,motto,table,accent,points,grip]=def,raw=[],n=points.length;
 for(let i=0;i<n;i++)for(let j=0;j<48;j++){
  const t=j/48,p0=points[(i+n-1)%n],p1=points[i],p2=points[(i+1)%n],p3=points[(i+2)%n];
  const axis=k=>.5*((2*p1[k])+(-p0[k]+p2[k])*t+(2*p0[k]-5*p1[k]+4*p2[k]-p3[k])*t*t+(-p0[k]+3*p1[k]-3*p2[k]+p3[k])*t*t*t);
  raw.push({x:axis(0),y:axis(1)});
 }
 let length=0;const distances=[0];for(let i=1;i<=raw.length;i++){const a=raw[i-1],b=raw[i%raw.length];length+=Math.hypot(b.x-a.x,b.y-a.y);distances.push(length);}
 const samples=[];let at=0;for(let i=0;i<720;i++){const d=i/720*length;while(distances[at+1]<d)at++;const f=(d-distances[at])/(distances[at+1]-distances[at]),a=raw[at],b=raw[(at+1)%raw.length];samples.push({x:mix(a.x,b.x,f),y:mix(a.y,b.y,f)});}
 for(let i=0;i<samples.length;i++){const a=samples[(i+samples.length-3)%samples.length],b=samples[(i+3)%samples.length],s=samples[i];s.angle=Math.atan2(b.y-a.y,b.x-a.x);}
 for(let i=0;i<samples.length;i++){let da=samples[(i+4)%720].angle-samples[(i+716)%720].angle;while(da>Math.PI)da-=2*Math.PI;while(da< -Math.PI)da+=2*Math.PI;samples[i].curve=Math.abs(da)/(length*8/720);}
 const track={id,index,name,motto,table,accent,grip,length,samples};
 track.at=function(distance,lane=2.5){const u=((distance%length)+length)%length/length*720,i=Math.floor(u),f=u-i,a=samples[i],b=samples[(i+1)%720];let da=b.angle-a.angle;while(da>Math.PI)da-=Math.PI*2;while(da< -Math.PI)da+=Math.PI*2;const angle=a.angle+da*f,offset=(lane-2.5)*13;return {x:mix(a.x,b.x,f)-Math.sin(angle)*offset,y:mix(a.y,b.y,f)+Math.cos(angle)*offset,angle,curve:mix(a.curve,b.curve,f)};};
 track.safe=function(distance){let curve=0;for(let d=0;d<=55;d+=11)curve=Math.max(curve,track.at(distance+d).curve);return Math.min(480,Math.sqrt(grip*4/Math.max(.0005,curve)));};
 const rampFractions=[[.25],[.15,.62],[.15,.66],[.22,.72],[.12,.85]][index];
 track.jumps=rampFractions.map((fraction,j)=>{let best=fraction,curve=Infinity;for(let u=fraction-.035;u<=fraction+.035;u+=.003){const value=track.at(u*length).curve;if(value<curve){curve=value;best=u;}}return {at:best*length,height:45+j*12,duration:.55+j*.08,inverted:false};});
 if(index===2){let closest=Infinity,cross=0;for(let i=72;i<360;i++){const point=samples[i],d=Math.hypot(point.x-900,point.y-450);if(d<closest){closest=d;cross=i/720*length;}}track.crossing=cross;track.jumps[0]={at:cross-120,height:95,duration:.85,inverted:false};}
 track.stunt=index===4?{kind:'double',start:length*.36,end:length*.58,height:240,minSpeed:170}:index===0?{kind:'wall',start:length*.39,end:length*.56,height:240,minSpeed:120}:index===1?{kind:'ceiling',start:length*.4,end:length*.58,height:220,minSpeed:140}:null;
 if(index===4)track.jumps.push({at:track.stunt.start+(track.stunt.end-track.stunt.start)*.75,height:95,duration:.85,inverted:true});
 track.loop=function(distance){if(!track.stunt)return null;const d=((distance%length)+length)%length,progress=(d-track.stunt.start)/(track.stunt.end-track.stunt.start);if(progress<0||progress>1)return null;return stuntProfile(track.stunt,progress);};
 return track;
}
export const TRACKS=definitions.map(createTrack);
