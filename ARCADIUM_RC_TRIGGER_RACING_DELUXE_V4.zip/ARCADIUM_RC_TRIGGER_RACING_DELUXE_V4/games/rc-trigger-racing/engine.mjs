import {TRACKS,COLORS} from './tracks.mjs';
export const DEFAULTS=Object.freeze({laps:10,rounds:5,raceSeconds:240,countdownSeconds:3,resultSeconds:8,points:[10,8,6,4,2,1],ghost:{enabled:true,charges:3,cooldown:12,warning:1,duration:1.6,immunity:7,openingGrace:5,closingGrace:5,stepBlock:2,powers:['static','magnet','draft','pitblock']}});
export class Championship{
 constructor(options={}){this.config={...DEFAULTS,...options,ghost:{...DEFAULTS.ghost,...options.ghost}};this.time=0;this.phase='lobby';this.round=0;this.selectedTrack=0;this.ghostSeat=-1;this.paused=false;this.history=[];this.fx=[];this.events=[];this.players=COLORS.map((color,i)=>({i,color,carModel:[0,6,12,18,24,5][i],displayRotation:0,totalDerails:0,points:0,wins:0,human:false,connected:false,input:{throttle:0,brake:0},notch:0}));this.resetCars();}
 resetCars(){this.players.forEach(p=>Object.assign(p,{distance:0,speed:0,heat:0,lapStartedAt:0,lastLap:null,bestLap:null,derail:0,recovery:null,air:null,jumps:0,hardLandings:0,loopProgress:null,loopHeight:0,loopRescueUntil:0,derails:0,finish:null,ghost:false,target:0,power:0,charges:this.config.ghost.charges,cooldown:0,immune:0,effect:null,notch:0,input:{throttle:0,brake:0}}));this.fx=[];}
 connect(i,connected=true){const p=this.players[i];if(!p)return;if(connected){p.human=true;p.connected=true;}else if(p.connected){p.connected=false;this.input(i,0,1);p.notch=0;}}
 input(i,throttle,brake=0){const p=this.players[i];if(!p)return;p.input={throttle:Number.isFinite(throttle)?Math.max(0,Math.min(1,throttle)):0,brake:Number.isFinite(brake)?Math.max(0,Math.min(1,brake)):0};}
 start(){this.history=[];this.round=0;this.ghostSeat=-1;this.players.forEach(p=>{p.points=0;p.wins=0;p.totalDerails=0;});this.next();}
 next(){if(this.round>=this.config.rounds){this.phase='champion';return;}this.round++;this.track=TRACKS[(this.selectedTrack+this.round-1)%TRACKS.length];this.resetCars();this.players.forEach(p=>{p.lane=(p.i+this.round-1)%6;p.ghost=p.i===this.ghostSeat;});this.phase='countdown';this.phaseTime=0;this.raceTime=0;this.paused=false;this.events.push({type:'round',round:this.round});}
 order(){return this.players.filter(p=>!p.ghost).slice().sort((a,b)=>a.finish!==null&&b.finish!==null?a.finish-b.finish:a.finish!==null?-1:b.finish!==null?1:b.distance-a.distance||a.i-b.i);}
 standings(){return this.players.slice().sort((a,b)=>b.points-a.points||a.i-b.i);}
 champions(){const best=Math.max(...this.players.map(p=>p.points));return this.players.filter(p=>p.points===best);}
 targets(power='static'){return this.order().filter(p=>p.finish===null&&(power==='pitblock'?p.recovery?.phase==='walk'&&!p.recovery.blocked:p.derail===0));}
 ghostAction(i){const p=this.players[i],g=this.config.ghost;if(!p)return false;const power=g.powers[p.power%g.powers.length],targets=this.targets(power),target=targets[p.target%Math.max(1,targets.length)];
  if(this.phase!=='race'||this.paused||!p?.ghost||!g.enabled||p.charges<=0||p.cooldown>0||this.raceTime<g.openingGrace||this.raceTime>this.config.raceSeconds-g.closingGrace||!target||target.immune>0)return false;
  p.charges--;p.cooldown=g.cooldown;target.immune=g.warning+g.duration+g.immunity;this.fx.push({owner:i,target:target.i,power,age:0,warning:g.warning,duration:g.duration});this.events.push({type:'ghost',seat:i,target:target.i});return true;
 }
 crash(p){if(p.derail>0)return;p.derail=1;p.air=null;p.recovery={phase:'walk',steps:0,goal:6,lastSide:null,lastMask:0,held:false,armed:false,remaining:2};p.notch=0;p.input={throttle:0,brake:0};p.derails++;p.totalDerails++;p.speed=0;if(this.track.stunt&&this.track.loop(p.distance))p.loopRescueUntil=Math.floor(p.distance/this.track.length)*this.track.length+this.track.stunt.end;this.events.push({type:'derail',seat:p.i});}
 recoveryTap(i,side){const p=this.players[i],r=p?.recovery;if(this.phase!=='race'||this.paused||!r||r.phase!=='walk'||!['left','right'].includes(side)||r.lastSide===side)return false;r.armed=true;if(!r.firstSide)r.firstSide=side;r.lastSide=side;r.steps++;if(r.steps>=r.goal){r.phase='reslot';r.remaining=2;}return true;}
 recoveryInput(i,mask){const p=this.players[i],r=p?.recovery;if(!r)return;const buttons=mask&10;r.held=buttons!==0;if(!r.armed){r.lastMask=buttons;if(buttons)return;r.armed=true;}const old=r.lastMask||0;r.lastMask=buttons;if(buttons===8&&!(old&8))this.recoveryTap(i,'right');if(buttons===2&&!(old&2))this.recoveryTap(i,'left');}
 togglePause(){if(this.phase!=='race'&&this.phase!=='countdown')return;this.paused=!this.paused;this.players.forEach(p=>{p.notch=0;p.input={throttle:0,brake:0};});}
 step(dt){if(!Number.isFinite(dt)||dt<=0)return;dt=Math.min(dt,.05);this.time+=dt;if(this.paused)return;this.phaseTime=(this.phaseTime||0)+dt;
  if(this.phase==='countdown'){if(this.phaseTime>=this.config.countdownSeconds){this.phase='race';this.phaseTime=0;this.events.push({type:'go'});}return;}
  if(this.phase==='results'){if(this.phaseTime>=this.config.resultSeconds)this.next();return;}if(this.phase!=='race')return;
  this.raceTime+=dt;const t=this.track,total=t.length*this.config.laps;
  this.fx.forEach(f=>{f.age+=dt;if(f.power==='pitblock'&&!f.applied&&f.age>=f.warning){const recovery=this.players[f.target].recovery;if(recovery?.phase==='walk'&&!recovery.blocked){recovery.goal+=Math.min(2,Math.max(0,this.config.ghost.stepBlock));recovery.blocked=true;}f.applied=true;}});this.fx=this.fx.filter(f=>f.age<f.warning+f.duration);
  for(const p of this.players){p.cooldown=Math.max(0,p.cooldown-dt);p.immune=Math.max(0,p.immune-dt);if(p.ghost){if(!p.human&&p.cooldown===0){p.power=(this.round+p.charges)%this.config.ghost.powers.length;if(!this.targets(this.config.ghost.powers[p.power]).length)p.power=0;p.target=(this.round+p.charges)%Math.max(1,this.targets(this.config.ghost.powers[p.power]).length);this.ghostAction(p.i);}continue;}if(p.finish!==null)continue;
   if(p.derail>0){const r=p.recovery;p.speed=0;p.input={throttle:0,brake:0};if(r){if(!p.human&&r.phase==='walk'){r.auto=(r.auto||0)+dt;if(r.auto>=.18){r.auto=0;this.recoveryTap(p.i,r.lastSide==='left'?'right':'left');}}else if(r.phase==='reslot'){r.remaining=Math.max(0,r.remaining-dt);if(r.remaining===0)r.phase='ready';}else if(r.phase==='ready'&&!r.held){p.derail=0;p.heat=0;p.recovery=null;this.events.push({type:'reslotted',seat:p.i});}}continue;}
   let throttle=p.human?(p.connected?p.input.throttle:0):1,brake=p.human?(p.connected?p.input.brake:1):0;
   let safe=t.safe(p.distance),ahead=t.safe(p.distance+75);const upcoming=t.jumps.some(j=>{const gap=(j.at-p.distance%t.length+t.length)%t.length;return gap<160;});if(upcoming){safe=Math.min(safe,360);ahead=Math.min(ahead,360);}const skill=.89+(p.i%3)*.025;
   if(!p.human){if(p.speed>Math.min(safe,ahead)*skill){throttle=0;brake=p.speed>safe*1.02?.5:0;}else throttle=Math.min(1,(safe*skill-p.speed)/40+.2);}
   if(!p.human&&t.stunt){const until=(t.stunt.start-p.distance%t.length+t.length)%t.length;if(t.loop(p.distance)||until<220){throttle=1;brake=0;}}
   const active=this.fx.find(f=>f.target===p.i&&f.age>=f.warning);p.effect=active?.power||null;
   if(p.effect==='static')throttle=Math.min(throttle,.7);
   const airborne=!!p.air;let acceleration=(airborne?0:throttle*400)*(p.effect==='draft'?.65:1),drag=airborne?4:(1-throttle)*180+28+brake*650+(p.effect==='magnet'?10:0);
   const old=p.distance;p.speed=Math.max(0,Math.min(480,p.speed+(acceleration-drag)*dt));
   const excess=(airborne||t.loop(p.distance))?-1:p.speed/safe-1.04;p.heat=Math.max(0,Math.min(1,p.heat+(excess>0?excess*3.5:-1.5)*dt));
   if(p.heat>=1){this.crash(p);continue;}
   p.distance+=p.speed*dt;
   const loop=t.loop(p.distance);p.loopProgress=loop?.progress??null;p.loopHeight=loop?.height||0;
   if(loop&&!airborne&&p.distance>=p.loopRescueUntil){const before=t.loop(old);if(before){const v2=p.speed*p.speed-2*100*(loop.height-before.height);p.speed=Math.sqrt(Math.max(0,v2));}if(loop.height>45&&p.speed<t.stunt.minSpeed){this.crash(p);continue;}}
   if(p.air){p.air.age+=dt;if(p.air.age>=p.air.duration){const impact=Math.max(0,(p.air.takeoffSpeed-360)/240);if(impact>.1){p.hardLandings++;p.heat=Math.min(1,p.heat+impact*.45);}this.events.push({type:'land',seat:p.i});p.air=null;}}
   if(!p.air){for(const ramp of t.jumps){const lap=Math.floor(old/t.length),gate=lap*t.length+ramp.at;if(old<gate&&p.distance>=gate){p.air={age:0,duration:ramp.duration,height:ramp.height,takeoffSpeed:p.speed,inverted:ramp.inverted,startDistance:p.distance,startHeight:loop?.height||0};p.jumps++;this.events.push({type:'jump',seat:p.i,inverted:ramp.inverted});break;}}}
   if(Math.floor(p.distance/t.length)>Math.floor(old/t.length)){const crossing=this.raceTime-dt+dt*((Math.floor(old/t.length)+1)*t.length-old)/Math.max(.0001,p.distance-old),lap=crossing-p.lapStartedAt;p.lastLap=lap;p.bestLap=p.bestLap===null?lap:Math.min(p.bestLap,lap);p.lapStartedAt=crossing;this.events.push({type:'lap',seat:p.i});}
   if(p.distance>=total){const fraction=(total-old)/Math.max(.0001,p.distance-old);p.distance=total;p.finish=this.raceTime-dt+dt*fraction;p.speed=0;this.events.push({type:'finish',seat:p.i});}
  }
  if(this.order().every(p=>p.finish!==null)||this.raceTime>=this.config.raceSeconds)this.finishRound();
 }
 finishRound(){if(this.phase!=='race')return;const rows=this.order().map((p,index,all)=>{let place=index+1;if(index){const previous=all[index-1];const tie=p.finish!==null&&previous.finish!==null?Math.abs(p.finish-previous.finish)<.001:p.finish===null&&previous.finish===null&&Math.abs(p.distance-previous.distance)<.01;if(tie)place=this._rankRows[index-1].place;}const points=this.config.points[place-1]||0;const row={seat:p.i,color:p.color,place,points,time:p.finish,distance:p.distance,derails:p.derails};(this._rankRows??=[])[index]=row;return row;});delete this._rankRows;
  rows.forEach(row=>{const p=this.players[row.seat];p.points+=row.points;if(row.place===1)p.wins++;});
  const last=rows.at(-1),tied=rows.filter(r=>r.place===last.place).sort((a,b)=>a.seat-b.seat);this.ghostSeat=this.config.ghost.enabled?tied[(this.round-1)%tied.length].seat:-1;
  this.history.push({round:this.round,track:this.track.id,rows,ghost:this.players.find(p=>p.ghost)?.i??-1,nextGhost:this.ghostSeat});this.phase='results';this.phaseTime=0;this.players.forEach(p=>this.input(p.i,0,0));this.events.push({type:'results'});
 }
 snapshot(){return {phase:this.phase,round:this.round,track:this.track?.id,paused:this.paused,raceTime:this.raceTime,ghostSeat:this.ghostSeat,players:this.players.map(p=>({...p,input:{...p.input}})),history:this.history,fx:this.fx.map(f=>({...f}))};}
}
