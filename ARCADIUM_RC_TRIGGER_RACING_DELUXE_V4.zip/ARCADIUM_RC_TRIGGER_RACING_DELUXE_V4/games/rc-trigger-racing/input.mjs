import {carIndex} from './cars.mjs';
export class Inputs{
 constructor(game){this.game=game;this.relays=Array.from({length:6},()=>ArcadiumHeldDpad.create());this.keys=new Set();this.local=new Set();this.lastMask=[0,0,0,0,0,0];this.pairs=[['KeyQ','KeyW'],['KeyE','KeyR'],['KeyT','KeyY'],['KeyU','KeyI'],['KeyO','KeyP'],['KeyA','KeyS']];this.pads=new Set();this.browseAt=[0,0,0,0,0,0];}
 clear(i){this.relays[i].clear();this.game.players[i].notch=0;this.game.input(i,0,0);this.game.recoveryInput(i,0);this.lastMask[i]=0;}
 clearAll(){this.keys.clear();for(let i=0;i<6;i++)this.clear(i);}
 native(event){const i=this.game.players.findIndex(p=>p.color===String(event.color).toLowerCase());if(i<0)return;const p=this.game.players[i],b=String(event.button).toUpperCase();if(this.relays[i].receive(event.button)){if(p.recovery)this.game.recoveryInput(i,this.relays[i].read());return;}this.game.connect(i,true);
  if(b==='START'){if(this.game.phase==='lobby'||this.game.phase==='champion')this.game.start();else if(this.game.phase==='results')this.game.next();else this.game.togglePause();return;}
  if(b==='SELECT'){this.clear(i);return;}
  if(b==='Y'){p.displayRotation=(p.displayRotation+1)%4;return;}
  if(p.derail>0){if(b==='A'||b==='R1')this.game.recoveryTap(i,'right');if(b==='B'||b==='L1')this.game.recoveryTap(i,'left');return;}
  if(this.game.phase==='lobby'){if(b==='LEFT'||b==='B')p.carModel=carIndex(p.carModel-1);if(b==='RIGHT')p.carModel=carIndex(p.carModel+1);if(b==='A')p.ready=true;return;}
  if(p.ghost){if(b==='A'||b==='R1')this.game.ghostAction(i);if(b==='B'||b==='L1')p.power++;if(b==='LEFT'||b==='UP')p.target++;return;}
  if(b==='A')p.notch=Math.min(1,p.notch+.25);if(b==='B')p.notch=0;
 }
 update(){const g=this.game;const pads=navigator.getGamepads?.()||[];
  for(let i=0;i<6;i++){const p=g.players[i],mask=this.relays[i].read(),prior=this.lastMask[i];this.lastMask[i]=mask;const pair=this.pairs[i],pad=pads[i];
   if(g.phase==='lobby'){if(mask&&(mask!==prior||g.time>=this.browseAt[i])){const delta=mask&4?-1:mask&8?1:mask&1?-6:mask&2?6:0;p.carModel=carIndex(p.carModel+delta);this.browseAt[i]=g.time+(mask!==prior?.32:.14);}continue;}
   if(p.derail>0){const local=this.local.has(i)?(this.keys.has(pair[0])?8:0)|(this.keys.has(pair[1])?2:0):0;const padRight=(pad?.buttons[7]?.value||pad?.buttons[5]?.value||0)>.2,padLeft=(pad?.buttons[6]?.value||pad?.buttons[4]?.value||0)>.2;g.recoveryInput(i,mask|local|(padRight?8:0)|(padLeft?2:0));continue;}
   if(p.ghost){if((mask&8)&&!(prior&8))g.ghostAction(i);if((mask&2)&&!(prior&2))p.power++;if((mask&(1|4))&&!(prior&(1|4)))p.target++;continue;}
   let throttle=Math.max(mask&8?1:0,p.notch),brake=mask&2?1:0;
   if(this.local.has(i)){throttle=Math.max(throttle,this.keys.has(pair[0])?1:0);brake=Math.max(brake,this.keys.has(pair[1])?1:0);}
   if(pad){if(!this.pads.has(i)){g.connect(i,true);this.local.add(i);this.pads.add(i);}throttle=Math.max(throttle,pad.buttons[7]?.value||pad.buttons[5]?.value||0);brake=Math.max(brake,pad.buttons[6]?.value||pad.buttons[4]?.value||0);}
   else if(this.pads.has(i)){this.pads.delete(i);if(!this.keys.has(pair[0])&&!this.keys.has(pair[1])){g.connect(i,false);this.local.delete(i);}}
   if(p.human)g.input(i,throttle,brake);
  }
 }
 keyboard(event,down){if(down)this.keys.add(event.code);else this.keys.delete(event.code);this.pairs.forEach((pair,i)=>{if(pair.includes(event.code)){this.local.add(i);this.game.connect(i,true);const p=this.game.players[i];if(this.game.phase==='lobby'&&down&&!event.repeat)p.carModel=carIndex(p.carModel+(pair[0]===event.code?1:-1));if(p.ghost&&down&&!event.repeat){if(pair[0]===event.code)this.game.ghostAction(i);else p.power++;}event.preventDefault();}});}
}
