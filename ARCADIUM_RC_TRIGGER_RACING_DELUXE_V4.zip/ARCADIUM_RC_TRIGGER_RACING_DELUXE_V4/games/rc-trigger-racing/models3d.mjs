import {CARS} from './cars.mjs';
import {PAINT} from './tracks.mjs';
import {makeHeroCar} from './hero-car.mjs';
import {makeUtilityCar} from './fleet-models.mjs';
export function makeCar(id,seat=0,options={}){
 const s=CARS[id];if(!s)throw new RangeError('Unknown garage model');
 return ['RACE CARS','CLASSICS'].includes(s.category)?makeHeroCar(s,seat,PAINT[seat],options):makeUtilityCar(s,seat,PAINT[seat],options);
}
