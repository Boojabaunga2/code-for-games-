// Shared geometric rail frame. Engine height and the 3D scene use this same profile.
const clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v));
const smooth=t=>{t=clamp(t);return t*t*(3-2*t);};
const add=(a,b)=>a.map((v,i)=>v+b[i]);
const mul=(a,s)=>a.map(v=>v*s);
const sub=(a,b)=>a.map((v,i)=>v-b[i]);
const unit=a=>{const d=Math.hypot(...a)||1;return a.map(v=>v/d);};
const cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
export function stuntProfile(stunt,u){
 if(stunt.kind==='double'){const pitch=u*Math.PI*4;return {progress:u,height:stunt.height*(1-Math.cos(pitch))/2,pitch,warp:u,shift:stunt.height/2*Math.sin(pitch),roll:0};}
 const climb=u<.25?smooth(u*4):u>.75?smooth((1-u)*4):1;
 const warp=u<.25?.035*smooth(u*4):u>.75?.965+.035*smooth((u-.75)*4):.035+.93*smooth((u-.25)*2);
 const roll=stunt.kind==='ceiling'?climb*Math.PI:0;
 return {progress:u,height:stunt.height*climb,pitch:roll,warp,shift:0,roll};
}
function core(t,d){
 const q=((d%t.length)+t.length)%t.length,s=t.stunt;
 let base=t.at(q,2.5),height=0,roll=0;
 if(s&&q>=s.start&&q<=s.end){const u=(q-s.start)/(s.end-s.start),p=stuntProfile(s,u);base=t.at(s.start+(s.end-s.start)*p.warp,2.5);height=p.height;roll=p.roll;if(p.shift){base={...base,x:base.x+Math.cos(base.angle)*p.shift,y:base.y+Math.sin(base.angle)*p.shift};}}
 return {position:[base.x-800,14+height,base.y-450],angle:base.angle,roll};
}
export function railFrame(t,d,lane=2.5){
 const c=core(t,d),before=core(t,d-.25),after=core(t,d+.25),forward=unit(sub(after.position,before.position));
 let right=unit([-Math.sin(c.angle),0,Math.cos(c.angle)]),up=unit(cross(right,forward));right=unit(cross(forward,up));
 if(c.roll){const cosine=Math.cos(c.roll),sine=Math.sin(c.roll),a=up,b=right;up=add(mul(a,cosine),mul(b,sine));right=add(mul(b,cosine),mul(a,-sine));}
 const position=add(c.position,mul(right,(lane-2.5)*24));
 return {position,forward,up,right};
}
export function carFrame(t,p){
 const ground=railFrame(t,p.distance,p.lane);
 if(p.air){const a=p.air,u=clamp(a.age/a.duration),start=railFrame(t,a.startDistance,p.lane),end=railFrame(t,a.startDistance+a.takeoffSpeed*a.duration,p.lane);
  const position=start.position.map((v,i)=>v+(end.position[i]-v)*u);position[1]+=Math.sin(u*Math.PI)*a.height;
  return {...ground,position,air:{start,end,u,inverted:a.inverted}};
 }
 if(p.recovery){const lane=ground,side=mul(lane.right,95+(2.5-Math.abs(p.lane-2.5))*24),position=add(lane.position,side);position[1]=8;const forward=unit([lane.forward[0],0,lane.forward[2]]),up=[0,1,0],right=unit(cross(forward,up)),fallen={position,forward,up,right};const u=p.recovery.phase==='walk'?0:p.recovery.phase==='reslot'?1-p.recovery.remaining/2:1;return {...ground,position:position.map((value,i)=>value+(lane.position[i]-value)*u),recovery:{start:fallen,end:lane,u}};}

 return ground;
}
