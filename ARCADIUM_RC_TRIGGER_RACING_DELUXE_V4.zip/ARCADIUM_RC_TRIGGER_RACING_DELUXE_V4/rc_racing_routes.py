"""RC Racing screens on the existing Arcadium 8787 bridge; no listener."""
import base64,binascii,importlib,json,mimetypes,threading,time
from pathlib import Path
from urllib.parse import urlsplit,parse_qs,unquote
SLUGS=('rc-trigger-racing',)
COLORS=('red','blue','green','yellow','pink','white')
BASE=Path(__file__).resolve().parent
LOCK=threading.RLock();FRAMES={};STATES={}
PRICE_FIELDS={'state','round','rounds','score','guess','locked','live','timeLeft','cursor','canRestart','product','accepts'}
def wrap_racing_handler(Parent):
 class RacingHandler(Parent):
  def _racing_shared(self):
   bridge=importlib.import_module('arcadium_game_bridge');return bridge.ACTIVE_WEB_GAME,bridge.ACTIVE_LOCK
  def _racing_active(self,slug=None):
   state,lock=self._racing_shared()
   with lock:return state['game'] in SLUGS and (slug is None or state['game']==slug) and time.time()<state['until']
  def _racing_send(self,data,mime='application/json',status=200):
   self.send_response(status);self.send_header('Content-Type',mime);self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
  def do_POST(self):
   path=urlsplit(self.path).path;parts=path.strip('/').split('/')
   activate=len(parts)==3 and parts[:2]==['arcadium-vibe','activate'] and parts[2] in SLUGS
   producer=len(parts)==3 and parts[0]=='arcadium-racing' and parts[1] in SLUGS and parts[2] in ('frame','state')
   if not activate and not producer:return super().do_POST()
   if self.client_address[0] not in ('127.0.0.1','::1','::ffff:127.0.0.1'):return self.send_error(403)
   slug=parts[2] if activate else parts[1]
   try:
    size=int(self.headers.get('Content-Length','0'))
    if size<0 or size>(1024 if activate else 300000):return self.send_error(413)
    body=json.loads(self.rfile.read(size) or b'{}')
    if not isinstance(body,dict):raise ValueError()
    if activate:
     enabled=body.get('active',True)
     if not isinstance(enabled,bool):raise ValueError()
     shared,lock=self._racing_shared()
     with lock:
      if enabled:
       if shared['game']!=slug or time.time()>=shared['until']:
        with LOCK:
         FRAMES.pop(slug,None);STATES.pop(slug,None)
       shared.update(game=slug,until=time.time()+7)
      elif shared['game']==slug:
       shared.update(game=None,until=0)
       with LOCK:FRAMES.pop(slug,None);STATES.pop(slug,None)
    else:
     if not self._racing_active(slug):return self.send_error(409)
     if parts[2]=='frame':
      seat=body['seat']
      if type(seat) is not int or seat not in range(1,7):raise ValueError()
      image=base64.b64decode(body['image'],validate=True)
      if len(image)>200000 or not image.startswith(b'\xff\xd8'):raise ValueError()
      with LOCK:FRAMES.setdefault(slug,{})[seat]=(time.monotonic(),image)
     else:
      if slug!='what-the-freaking-price':raise ValueError()
      seats=body['seats']
      if not isinstance(seats,list) or len(seats)!=6:raise ValueError()
      clean=[]
      for seat in seats:
       if not isinstance(seat,dict) or set(seat)!=PRICE_FIELDS:raise ValueError()
       if not isinstance(seat['guess'],str) or len(seat['guess'])>12 or (seat['guess'] and not seat['guess'].isdigit()):raise ValueError()
       if type(seat['cursor']) is not int or not 0<=seat['cursor']<12:raise ValueError()
       if not all(isinstance(seat[k],bool) for k in ('locked','live','canRestart','accepts')):raise ValueError()
       if any(not isinstance(seat[k],(int,float)) or isinstance(seat[k],bool) for k in ('round','rounds','score','timeLeft')):raise ValueError()
       if not isinstance(seat['state'],str) or len(seat['state'])>32 or not isinstance(seat['product'],str) or len(seat['product'])>240:raise ValueError()
       clean.append({k:seat[k] for k in PRICE_FIELDS})
      with LOCK:STATES[slug]=(time.monotonic(),clean)
    return self._racing_send(b'{"ok":true}')
   except (ValueError,TypeError,KeyError,UnicodeError,binascii.Error):return self.send_error(400)
  def do_GET(self):
   path=urlsplit(self.path).path;parts=path.strip('/').split('/')
   if path in ('/api/vibe/mode','/api/vibe/launch') and self._racing_active():
    shared,lock=self._racing_shared()
    with lock:slug=shared['game']
    page='/games/'+slug+'/personal/vibe.html';return self._racing_send(json.dumps(dict(mode='web-game',game=slug,page=page,url=page,active=True)).encode())
   if len(parts)>=3 and parts[0]=='games' and parts[1] in SLUGS:
    slug=parts[1];relative='/'.join(parts[2:]);relative='vibe.html' if relative=='personal/vibe.html' else relative
    folder=(BASE/'games'/slug).resolve();file=(folder/unquote(relative)).resolve()
    if not file.is_relative_to(folder) or not file.is_file():return self.send_error(404)
    return self._racing_send(file.read_bytes(),('application/javascript' if file.suffix=='.mjs' else mimetypes.guess_type(file.name)[0]) or 'application/octet-stream')
   if len(parts)!=3 or parts[0]!='arcadium-racing' or parts[1] not in SLUGS:return super().do_GET()
   slug=parts[1];kind=parts[2]
   if kind=='status':return self._racing_send(json.dumps(dict(build='rc-racing-v1',game=slug,active=self._racing_active(slug))).encode())
   if kind not in ('frame','state'):return self.send_error(404)
   color=parse_qs(urlsplit(self.path).query).get('color',[''])[0].lower()
   if color not in COLORS:return self.send_error(400)
   if not self._racing_active(slug):return self.send_error(503)
   seat=COLORS.index(color)+1
   with LOCK:
    packet=FRAMES.get(slug,{}).get(seat) if kind=='frame' else STATES.get(slug)
    if not packet or time.monotonic()-packet[0]>2.5:return self.send_error(503)
    data=packet[1] if kind=='frame' else json.dumps(dict(packet[1][seat-1],seat=seat,color=color)).encode()
   return self._racing_send(data,'image/jpeg' if kind=='frame' else 'application/json')
 return RacingHandler
