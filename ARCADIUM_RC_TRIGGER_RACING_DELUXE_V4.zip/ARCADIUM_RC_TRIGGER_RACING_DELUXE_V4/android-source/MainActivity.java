package com.arcadium.og9;

import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.InputDevice;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.net.Uri;
import android.media.ToneGenerator;
import android.media.AudioManager;
import android.speech.tts.TextToSpeech;
import java.util.Locale;
import android.view.WindowManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.provider.Settings;
import android.os.BatteryManager;
import android.content.IntentFilter;
import java.io.InputStream;
import java.net.URLConnection;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import org.json.JSONObject;
import java.nio.charset.StandardCharsets;

public final class MainActivity extends Activity {
    private WebView web;
    private TextToSpeech bitsVoice;
    private boolean bitsVoiceReady = false;
    private boolean screenReceiverRegistered = false;
    private final BroadcastReceiver screenReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (Intent.ACTION_SCREEN_ON.equals(intent.getAction()) && web != null) {
                // Only while this app's process remains alive. We do not start
                // background activities or bypass a secure keyguard.
                runOnUiThread(() -> showWake());
            }
        }
    };
    private void greetAsBits() {
        runOnUiThread(() -> {
            if (bitsVoiceReady && bitsVoice != null) {
                bitsVoice.speak("Hey! I'm Bits! Welcome to Arcadium. There's always room at our table!",
                    TextToSpeech.QUEUE_FLUSH, null, "bits-greeting");
            } else {
                playTone(ToneGenerator.TONE_PROP_ACK, 150);
            }
        });
    }
    private volatile int held = 0;
    // Native SFX avoid WebView's audio-unlock restrictions on physical controllers.
    private ToneGenerator sfx;
    private long lastSoundAt = 0L;
    private synchronized void playTone(int tone, int duration) {
        try { if (sfx != null) sfx.startTone(tone, duration); }
        catch (RuntimeException ignored) { }
    }
    private void sfxOnButton(int code) {
        long now = android.os.SystemClock.uptimeMillis();
        if (now - lastSoundAt < 90) return;
        lastSoundAt = now;
        if (code == KeyEvent.KEYCODE_BUTTON_A)
            playTone(ToneGenerator.TONE_PROP_BEEP, 42);
        else if (code == KeyEvent.KEYCODE_BUTTON_X)
            playTone(ToneGenerator.TONE_PROP_ACK, 110);
        else if (code == KeyEvent.KEYCODE_BUTTON_B)
            playTone(ToneGenerator.TONE_PROP_BEEP2, 55);
        else if (code == KeyEvent.KEYCODE_BUTTON_Y)
            playTone(ToneGenerator.TONE_PROP_PROMPT, 70);
    }
    private static final String HOST = "appassets.androidplatform.net";
    // Bit positions are fixed in assets/controller.js.
    private static int bit(int code) {
        switch (code) {
            case KeyEvent.KEYCODE_DPAD_UP: return 0;
            case KeyEvent.KEYCODE_DPAD_DOWN: return 1;
            case KeyEvent.KEYCODE_DPAD_LEFT: return 2;
            case KeyEvent.KEYCODE_DPAD_RIGHT: return 3;
            case KeyEvent.KEYCODE_BUTTON_A: return 4;
            case KeyEvent.KEYCODE_BUTTON_B: return 5;
            case KeyEvent.KEYCODE_BUTTON_X: return 6;
            case KeyEvent.KEYCODE_BUTTON_Y: return 7;
            case KeyEvent.KEYCODE_BUTTON_START: return 8;
            case KeyEvent.KEYCODE_BUTTON_SELECT: return 9;
            case KeyEvent.KEYCODE_BUTTON_L1: return 10;
            case KeyEvent.KEYCODE_BUTTON_R1: return 11;
            default: return -1;
        }
    }
    // Hold START+SELECT together for two seconds to return Home from any in-app game.
    private final android.os.Handler homeHandler = new android.os.Handler(android.os.Looper.getMainLooper());
    private boolean startHeld = false;
    private boolean selectHeld = false;
    private boolean shortcutArmed = false;
    private final Runnable goHomeIfHeld = () -> {
        if (startHeld && selectHeld && shortcutArmed && web != null) {
            shortcutArmed = false;
            playTone(ToneGenerator.TONE_PROP_ACK, 140);
            showHome();
        }
    };
    private void cancelHomeShortcut() {
        homeHandler.removeCallbacks(goHomeIfHeld);
        shortcutArmed = false;
    }

// Arcadium OS local connection, isolated from OG9 and the Living Card.
private volatile boolean joinVisible = false;
private volatile boolean discovering = false;
private volatile String hostUrl = null;
private volatile String pairToken = null;
private volatile String playerColor = "red";
private volatile boolean joinActive = false;
private volatile boolean auctionVisible = false;
private volatile boolean modeCheckBusy = false;
// The PC is authoritative about which controller page each game needs.
private volatile String activeVibePage = "";
private volatile boolean dpadEnabled = false;
private boolean heldDpadReady() { return dpadEnabled && HeldDpad.supports(activeVibePage); }
// Held-state relay is scoped to compatible game pages. Legacy buttons stay unchanged.
private final HeldDpad heldDpad = new HeldDpad(new java.security.SecureRandom().nextInt());
private boolean dpadBusy = false;
private boolean dpadDirty = true;
private final Runnable dpadTick = new Runnable() {
    @Override public void run() {
        if (joinActive && joinVisible && heldDpadReady()) {
            sendDpadState();
            vibeHandler.postDelayed(this, 80);
        }
    }
};
private void sendDpadState() {
    if (dpadBusy || !joinActive || !joinVisible || !heldDpadReady()
            || hostUrl == null || pairToken == null) return;
    final String url = hostUrl, token = pairToken, color = playerColor;
    final String packet = heldDpad.packet();
    dpadBusy = true; dpadDirty = false;
    new Thread(() -> {
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection)new URL(url + "/api/vibe/input").openConnection();
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(600); connection.setReadTimeout(600);
            connection.setDoOutput(true);
            connection.setRequestProperty("Content-Type", "application/json");
            JSONObject payload = new JSONObject();
            payload.put("pair", token); payload.put("color", color); payload.put("button", packet);
            try (java.io.OutputStream out = connection.getOutputStream()) {
                out.write(payload.toString().getBytes(StandardCharsets.UTF_8));
            }
            connection.getResponseCode();
        } catch (Exception ignored) {
            // The game clears direction when state heartbeats become stale.
        } finally {
            if (connection != null) connection.disconnect();
            runOnUiThread(() -> {
                dpadBusy = false;
                if (dpadDirty) sendDpadState();
            });
        }
    }, "Arcadium-Held-Dpad").start();
}
private void resetDpad() {
    heldDpad.clear(); dpadDirty = true;
    sendDpadState();
    vibeHandler.removeCallbacks(dpadTick);
}

// Probe an existing game asset, not a new service. Older PC games keep legacy input.
private Boolean heldProtocolAvailable(String base, String page) {
    if (!HeldDpad.supports(page)) return false;
    HttpURLConnection conn = null;
    try {
        String asset = page.replace("/personal/vibe.html", "/held-dpad.js");
        conn = (HttpURLConnection)new URL(base + asset).openConnection();
        conn.setConnectTimeout(800); conn.setReadTimeout(800);
        conn.setRequestProperty("Cache-Control", "no-cache");
        if (conn.getResponseCode() == 404) return false;
        if (conn.getResponseCode() != 200) return null;
        java.io.ByteArrayOutputStream body = new java.io.ByteArrayOutputStream();
        try (InputStream in = conn.getInputStream()) {
            byte[] bytes = new byte[1024]; int n;
            while (body.size() <= 8192 && (n = in.read(bytes)) > 0) body.write(bytes, 0, n);
        }
        return body.toString("UTF-8").contains("ArcadiumHeldDpad");
    } catch (Exception ignored) { return null; }
    finally { if (conn != null) conn.disconnect(); }
}
private final Runnable modeChecker = new Runnable() {
  @Override public void run() {
    if (!joinActive || !joinVisible) return;
    final String base = hostUrl;
    if (base != null && !modeCheckBusy) {
      modeCheckBusy = true;
      new Thread(() -> {
        String nextPage = ""; boolean nextDpad = false; HttpURLConnection conn = null;
        try {
          String endpoint = base + "/api/vibe/mode?color=" + Uri.encode(playerColor);
          conn = (HttpURLConnection) new URL(endpoint).openConnection();
          conn.setConnectTimeout(1600); conn.setReadTimeout(1600);
          if (conn.getResponseCode() == 200) {
            java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
            try (InputStream in = conn.getInputStream()) {
              byte[] b = new byte[1024]; int n;
              while ((n = in.read(b)) > 0) bos.write(b, 0, n);
            }
            JSONObject response = new JSONObject(bos.toString("UTF-8"));
            String mode = response.optString("mode", "controller");
            if ("chimp-auction".equals(mode)) nextPage = "/ca/vibe";
            else if ("web-game".equals(mode)) {
              String page = response.optString("page", "");
              // Only navigate to game pages on the discovered Arcadium PC.
              if (page.startsWith("/games/") && page.endsWith("/vibe.html")
                  && !page.contains("..") && !page.contains("\\"))
                nextPage = page;
            }
          }
          if (HeldDpad.supports(nextPage)) {
            Boolean capability = heldProtocolAvailable(base, nextPage);
            nextDpad = capability == null ? (nextPage.equals(activeVibePage) && dpadEnabled) : capability;
          }
        } catch (Exception ignored) {
          // A transient failure must not kick players out of a running game.
          nextPage = null;
        } finally { if (conn != null) conn.disconnect(); }
        final String page = nextPage;
        final boolean enabled = nextDpad;
        runOnUiThread(() -> {
          if (!joinActive || !joinVisible || !base.equals(hostUrl) || page == null) return;
          boolean samePage = page.equals(activeVibePage);
          if (samePage && enabled == dpadEnabled) return;
          resetDpad();
          activeVibePage = page; dpadEnabled = enabled;
          if (heldDpadReady()) vibeHandler.post(dpadTick);
          if (samePage) { web.reload(); return; }
          auctionVisible = "/ca/vibe".equals(page);
          if (page.isEmpty()) {
            web.loadUrl("https://" + HOST + "/vibe-join.html");
          } else {
            String seatColor = playerColor;
            int seat = java.util.Arrays.asList("red","blue","green","yellow","pink","white").indexOf(seatColor) + 1;
            if (seat < 1) return;
            web.loadUrl(base + page + "?player=" + seat
                + "&seat=" + Uri.encode(seatColor) + "&color=" + Uri.encode(seatColor));
          }
        });
        modeCheckBusy = false;
      }, "Arcadium-Mode-Check").start();
    }
    vibeHandler.postDelayed(this, 1800);
  }
};
private DatagramSocket discoverySocket;
private final android.os.Handler vibeHandler = new android.os.Handler(android.os.Looper.getMainLooper());
private final Runnable heartbeat = new Runnable() {
    @Override public void run() {
        if (joinActive && joinVisible) {
            sendVibeButton("PING");
            vibeHandler.postDelayed(this, 2500);
        }
    }
};
private void joinMainScreen() {
    resetDpad();
    joinVisible = true; joinActive = true;
    homeVisible = false; wakeVisible = false; auctionVisible=false; activeVibePage="";
    web.loadUrl("https://" + HOST + "/vibe-join.html");
    startDiscovery();
    vibeHandler.removeCallbacks(heartbeat);
    vibeHandler.postDelayed(heartbeat, 1200);
    vibeHandler.removeCallbacks(modeChecker);
    vibeHandler.postDelayed(modeChecker,2200);
}
private void leaveMainScreen() {
    resetDpad();
    joinVisible = false; joinActive = false;
    vibeHandler.removeCallbacks(heartbeat); vibeHandler.removeCallbacks(modeChecker);auctionVisible=false;activeVibePage="";
    hostUrl = null; pairToken = null;
    stopDiscovery();
    showHome();
}
private void notifyVibe(String state) {
    runOnUiThread(() -> {
        if (web != null && joinVisible) web.evaluateJavascript(
            "window.vibeStatus(" + JSONObject.quote(state) + ")",null);
    });
}
private void stopDiscovery() {
    discovering = false;
    if (discoverySocket != null) { discoverySocket.close(); discoverySocket = null; }
}
private void startDiscovery() {
    if (discovering) return;
    discovering = true;
    new Thread(() -> {
        try (DatagramSocket sock = new DatagramSocket(null)) {
            sock.setReuseAddress(true);
            sock.bind(new java.net.InetSocketAddress(8788));
            sock.setSoTimeout(2500);
            discoverySocket = sock;
            byte[] buf = new byte[2048];
            while (discovering && joinActive) {
                try {
                    DatagramPacket pkt = new DatagramPacket(buf, buf.length);
                    sock.receive(pkt);
                    JSONObject msg = new JSONObject(new String(pkt.getData(),pkt.getOffset(),pkt.getLength(),StandardCharsets.UTF_8));
                    if (!"ARCADIUM_VIBE_V1".equals(msg.optString("magic"))) continue;
                    int port = msg.optInt("port",0);
                    String token = msg.optString("pair", "");
                    if (port < 1 || port > 65535 || token.length() < 12) continue;
                    hostUrl = "http://" + pkt.getAddress().getHostAddress() + ":" + port;
                    pairToken = token;
                    notifyVibe("CONNECTED · " + pkt.getAddress().getHostAddress());
                    sendVibeButton("PING");
                } catch (java.net.SocketTimeoutException ignored) { }
                catch (Exception ignored) { }
            }
        } catch(Exception ex) { notifyVibe("Discovery unavailable · check Wi-Fi"); }
        finally { discovering = false; discoverySocket = null; }
    },"Arcadium-Vibe-Discovery").start();
}
private final java.util.concurrent.ExecutorService priceInputSender = java.util.concurrent.Executors.newSingleThreadExecutor();
private void sendVibeButton(String button) {
    final String url=hostUrl, token=pairToken, color=playerColor;
    if (url == null || token == null || !joinActive) return;
    final boolean orderedPrice = "/games/what-the-freaking-price/personal/vibe.html".equals(activeVibePage) && !"PING".equals(button);
    final long queuedAt = android.os.SystemClock.elapsedRealtime();
    Runnable request = () -> {
        if (orderedPrice && (!joinActive || !joinVisible || !url.equals(hostUrl)
                || !token.equals(pairToken) || !color.equals(playerColor)
                || !"/games/what-the-freaking-price/personal/vibe.html".equals(activeVibePage)
                || android.os.SystemClock.elapsedRealtime() - queuedAt > 1500)) return;
        HttpURLConnection connection=null;
        try {
            connection=(HttpURLConnection)new URL(url+"/api/vibe/input").openConnection();
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(1600); connection.setReadTimeout(1600);
            connection.setDoOutput(true);
            connection.setRequestProperty("Content-Type","application/json");
            JSONObject payload=new JSONObject();
            payload.put("pair",token);payload.put("color",color);payload.put("button",button);
            byte[] raw=payload.toString().getBytes(StandardCharsets.UTF_8);
            try(java.io.OutputStream os=connection.getOutputStream()) { os.write(raw); }
            if(connection.getResponseCode()!=200) notifyVibe("Pairing refused · restart Arcadium OS");
        }catch(Exception ex) {notifyVibe("PC unavailable · check same Wi-Fi");}
        finally {if(connection!=null)connection.disconnect();}
    };
    if (orderedPrice) priceInputSender.execute(request);
    else new Thread(request,"Arcadium-Vibe-Send").start();
}

    private boolean homeVisible = true;
    private boolean wakeVisible = true;
    private boolean hasPaused = false;
    private void showWake() {
        resetDpad();
        if (joinVisible) { joinVisible=false; joinActive=false; stopDiscovery(); vibeHandler.removeCallbacks(heartbeat); vibeHandler.removeCallbacks(modeChecker); auctionVisible=false; activeVibePage=""; }
        if (web == null) return;
        held = 0;
        startHeld = false; selectHeld = false; cancelHomeShortcut();
        homeVisible = true;
        wakeVisible = true;
        web.loadUrl("https://" + HOST + "/wake.html");
    }
    private void showHome() {
        resetDpad();
        if (joinVisible) { joinVisible=false; joinActive=false; stopDiscovery(); vibeHandler.removeCallbacks(heartbeat); vibeHandler.removeCallbacks(modeChecker); auctionVisible=false; activeVibePage=""; }
        held = 0;
        startHeld = false; selectHeld = false; cancelHomeShortcut();
        homeVisible = true;
        wakeVisible = false;
        web.loadUrl("https://" + HOST + "/home.html");
    }
    private void showGames() {
        held = 0;
        startHeld = false; selectHeld = false; cancelHomeShortcut();
        homeVisible = false;
        wakeVisible = false;
        web.loadUrl("https://" + HOST + "/index.html");
    }
    // Open the separately installed OG9 application, not the old embedded index.html.
    // An explicit launcher component works without Android 11 package visibility queries.
    private void launchInstalledOG9() {
        try {
            Intent launch = new Intent(Intent.ACTION_MAIN);
            launch.addCategory(Intent.CATEGORY_LAUNCHER);
            launch.setClassName("com.arcadium.og9", "com.arcadium.og9.MainActivity");
            startActivity(launch);
        } catch (Exception error) {
            // Some builds may use a different launcher activity class.
            try {
                Intent launch = getPackageManager().getLaunchIntentForPackage("com.arcadium.og9");
                if (launch == null) throw new android.content.ActivityNotFoundException("OG9 launcher not found");
                startActivity(launch);
            } catch (Exception failed) {
                new android.app.AlertDialog.Builder(this)
                    .setTitle("OG9 not available")
                    .setMessage("Arcadium OG9 could not be opened. Please check that the separate Arcadium OG9 app is installed.")
                    .setPositiveButton("OK", (dialog, which) -> dialog.dismiss())
                    .show();
            }
        }
    }

    // Launch the separately installed official High Noon app.
    // Package identity is fixed in the High Noon Android build.
    private void launchInstalledHighNoon() {
        try {
            Intent launch = new Intent(Intent.ACTION_MAIN);
            launch.addCategory(Intent.CATEGORY_LAUNCHER);
            launch.setClassName("com.arcadium.highnoon", "com.arcadium.highnoon.MainActivity");
            startActivity(launch);
        } catch (Exception error) {
            try {
                Intent launch = getPackageManager().getLaunchIntentForPackage("com.arcadium.highnoon");
                if (launch == null) throw new android.content.ActivityNotFoundException("High Noon launcher not found");
                startActivity(launch);
            } catch (Exception failed) {
                new android.app.AlertDialog.Builder(this)
                    .setTitle("High Noon not installed")
                    .setMessage("Install the official High Noon APK to launch it from Arcadium Home.")
                    .setPositiveButton("OK", (dialog, which) -> dialog.dismiss())
                    .show();
            }
        }
    }

    public class HomeBridge {
        @JavascriptInterface public void join() { runOnUiThread(() -> joinMainScreen()); }
        @JavascriptInterface public void leaveVibe() { runOnUiThread(() -> leaveMainScreen()); }
        @JavascriptInterface public void setVibeColor(String color) {
            if (java.util.Arrays.asList("red","blue","green","yellow","pink","white").contains(color)) playerColor = color;
        }
        @JavascriptInterface public void priceKey(String key) {
            runOnUiThread(() -> {
                String packet = PriceInput.encode(key, activeVibePage);
                if (packet != null && joinActive && joinVisible) sendVibeButton(packet);
            });
        }
        @JavascriptInterface public void setDpadState(int mask) {
            if (mask < 0 || mask > 15) return;
            runOnUiThread(() -> {
                if (!joinActive || !joinVisible || !heldDpadReady()) return;
                heldDpad.touch(mask); dpadDirty = true; sendDpadState();
            });
        }
        @JavascriptInterface public void vibeButton(String button) {
            if (java.util.Arrays.asList("UP","DOWN","LEFT","RIGHT","A","B","X","Y","START","SELECT","L1","R1").contains(button)) sendVibeButton(button);
        }
        @JavascriptInterface public void play() { runOnUiThread(() -> launchInstalledOG9()); }
        @JavascriptInterface public void highNoon() { runOnUiThread(() -> launchInstalledHighNoon()); }
        @JavascriptInterface public void home() { runOnUiThread(() -> showHome()); }
        @JavascriptInterface public void bitsSpeak() { greetAsBits(); }
        @JavascriptInterface public void awaken() { runOnUiThread(() -> showHome()); }
        @JavascriptInterface public void androidSettings() {
            runOnUiThread(() -> {
                try { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
                catch(Exception ignored) { }
            });
        }
        @JavascriptInterface public int battery() {
            Intent status = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (status == null) return -1;
            int level = status.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = status.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
            return level < 0 || scale <= 0 ? -1 : Math.round(100f * level / scale);
        }
    }
    public class ButtonBridge {
        @JavascriptInterface public int getHeld() { return held; }
        @JavascriptInterface public void playSfx(String event) {
            if ("crash".equals(event)) playTone(ToneGenerator.TONE_PROP_NACK, 190);
            else if ("win".equals(event)) playTone(ToneGenerator.TONE_PROP_ACK, 170);
            else if ("start".equals(event)) playTone(ToneGenerator.TONE_PROP_BEEP, 75);
        }
    }
    private void fullscreen() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }
    @Override public void onCreate(Bundle state) {
        super.onCreate(state); fullscreen();
        if (android.os.Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
        } else {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED);
        }
        // No turnScreenOn: the user's hardware button remains in control.
        bitsVoice = new TextToSpeech(getApplicationContext(), status -> {
            if (status == TextToSpeech.SUCCESS && bitsVoice != null) {
                int result = bitsVoice.setLanguage(Locale.US);
                bitsVoiceReady = result != TextToSpeech.LANG_MISSING_DATA &&
                    result != TextToSpeech.LANG_NOT_SUPPORTED;
                if (bitsVoiceReady) { bitsVoice.setSpeechRate(0.96f); bitsVoice.setPitch(1.04f); }
            }
        });
        try {
            registerReceiver(screenReceiver, new IntentFilter(Intent.ACTION_SCREEN_ON));
            screenReceiverRegistered = true;
        } catch (Exception ignored) { }
        setVolumeControlStream(AudioManager.STREAM_MUSIC);
        try { sfx = new ToneGenerator(AudioManager.STREAM_MUSIC, 65); }
        catch (RuntimeException ignored) { sfx = null; }
        web = new WebView(this); web.setBackgroundColor(0xff030815);
        web.setFocusable(true); web.setFocusableInTouchMode(true);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false); s.setAllowContentAccess(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setUseWideViewPort(true); s.setLoadWithOverviewMode(true);
        web.addJavascriptInterface(new ButtonBridge(), "ArcadiumNative");
        web.addJavascriptInterface(new HomeBridge(), "ArcadiumHome");
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (!"https".equals(u.getScheme()) || !HOST.equals(u.getHost()))
                    return super.shouldInterceptRequest(view, request);
                try {
                    String path = u.getEncodedPath();
                    if (path == null || "/".equals(path)) path = "/index.html";
                    path = Uri.decode(path.substring(1));
                    if (path.startsWith("/") || path.contains("..") || path.contains("\\")) return null;
                    InputStream input = getAssets().open(path);
                    String mime = URLConnection.guessContentTypeFromName(path);
                    if (path.endsWith(".html")) mime = "text/html";
                    if (path.endsWith(".js")) mime = "application/javascript";
                    if (mime == null) mime = "application/octet-stream";
                    return new WebResourceResponse(mime, "UTF-8", input);
                } catch (Exception ex) { return null; }
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri uri = req.getUrl();
                if ("https".equals(uri.getScheme()) && HOST.equals(uri.getHost())) return false;
                // Trust only controller/game pages on the currently discovered PC.
                if (hostUrl != null && req.getUrl().toString().startsWith(hostUrl + "/")) {
                    String p = uri.getPath();
                    if (p != null && (p.startsWith("/games/") || p.startsWith("/ca/")
                        || p.startsWith("/gp/") || p.startsWith("/wtd/") || p.startsWith("/pg/"))) return false;
                }
                return true;
            }
        });
        setContentView(web);
        showWake();
        web.requestFocus();
    }
    private float axisFlat(MotionEvent event, int axis) {
        InputDevice device = event.getDevice();
        if (device == null) return .2f;
        InputDevice.MotionRange range = device.getMotionRange(axis, event.getSource());
        if (range == null) range = device.getMotionRange(axis);
        return range == null ? .2f : range.getFlat();
    }
    @Override public boolean dispatchGenericMotionEvent(MotionEvent event) {
        if (joinActive && joinVisible && heldDpadReady()
                && event.getActionMasked() == MotionEvent.ACTION_MOVE
                && (event.isFromSource(InputDevice.SOURCE_JOYSTICK)
                    || event.isFromSource(InputDevice.SOURCE_GAMEPAD)
                    || event.isFromSource(InputDevice.SOURCE_DPAD))) {
            int previous = heldDpad.mask();
            heldDpad.axes(event.getAxisValue(MotionEvent.AXIS_HAT_X), event.getAxisValue(MotionEvent.AXIS_HAT_Y),
                    event.getAxisValue(MotionEvent.AXIS_X), event.getAxisValue(MotionEvent.AXIS_Y),
                    axisFlat(event, MotionEvent.AXIS_X), axisFlat(event, MotionEvent.AXIS_Y));
            if (heldDpad.mask() != previous) { dpadDirty = true; sendDpadState(); }
            return true;
        }
        return super.dispatchGenericMotionEvent(event);
    }
    @Override public boolean dispatchKeyEvent(KeyEvent event) {
        final int code = event.getKeyCode();
        final boolean down = event.getAction() == KeyEvent.ACTION_DOWN;
        if (code == KeyEvent.KEYCODE_BUTTON_START || code == KeyEvent.KEYCODE_BUTTON_SELECT) {
            if (code == KeyEvent.KEYCODE_BUTTON_START) startHeld = down;
            else selectHeld = down;
            if (startHeld && selectHeld && !shortcutArmed) {
                shortcutArmed = true;
                homeHandler.postDelayed(goHomeIfHeld, 2000);
            } else if (!startHeld || !selectHeld) cancelHomeShortcut();
        }
        if (joinVisible) {
            if (code == KeyEvent.KEYCODE_BACK && down) { leaveMainScreen(); return true; }
            int controllerBit = bit(code);
            if (controllerBit >= 0) {
                if (controllerBit >= 10 && heldDpadReady() && (HeldDpad.sports(activeVibePage) || HeldDpad.racing(activeVibePage))) {
                    int previous = heldDpad.mask();
                    heldDpad.shoulder(controllerBit == 10 ? (HeldDpad.racing(activeVibePage) ? 1 : 0) : 3, down);
                    if (heldDpad.mask() != previous) { dpadDirty = true; sendDpadState(); }
                    return true;
                }
                if (controllerBit < 4 && heldDpadReady()) {
                    int previous = heldDpad.mask();
                    heldDpad.key(controllerBit, down);
                    if (heldDpad.mask() != previous) { dpadDirty = true; sendDpadState(); }
                    return true;
                }
                if (down && event.getRepeatCount() == 0) {
                    String[] buttons={"UP","DOWN","LEFT","RIGHT","A","B","X","Y","START","SELECT","L1","R1"};
                    playerColor = playerColor == null ? "red" : playerColor;
                    if(auctionVisible){
                        final String[] keys={"ArrowUp","ArrowDown","ArrowLeft","ArrowRight","a","b","x","y","Enter","Escape","l","r"};
                        String key=keys[controllerBit];
                        web.evaluateJavascript("document.dispatchEvent(new KeyboardEvent('keydown',{key:"+JSONObject.quote(key)+",bubbles:true}))",null);
                    } else sendVibeButton(buttons[controllerBit]);
                    sfxOnButton(code);
                }
                if(!down && auctionVisible && controllerBit==6) web.evaluateJavascript("document.dispatchEvent(new KeyboardEvent('keyup',{key:'x',bubbles:true}))",null);
                return true;
            }
        }
        if (wakeVisible) {
            if (down && event.getRepeatCount() == 0 &&
                (bit(code) >= 0 || code == KeyEvent.KEYCODE_ENTER || code == KeyEvent.KEYCODE_BACK)) {
                showHome();
            }
            return true;
        }
        if (homeVisible) {
            if (code == KeyEvent.KEYCODE_BACK) {
                return true;
            }
            if (bit(code) >= 0) {
                if (event.getAction() == KeyEvent.ACTION_DOWN && event.getRepeatCount() == 0) {
                    final int k = code;
                    runOnUiThread(() -> web.evaluateJavascript("window.homeKey && window.homeKey(" + k + ")", null));
                }
                return true;
            }
        }
        int index = bit(event.getKeyCode());
        if (index >= 0) {
            if (event.getAction() == KeyEvent.ACTION_DOWN) {
                held |= (1 << index);
                if (event.getRepeatCount() == 0) sfxOnButton(event.getKeyCode());
            }
            else if (event.getAction() == KeyEvent.ACTION_UP) held &= ~(1 << index);
            return true;
        }
        return super.dispatchKeyEvent(event);
    }
    @Override protected void onPause() {
        resetDpad();
        hasPaused = true;
        super.onPause();
    }
    @Override protected void onResume() {
        super.onResume();
        if (hasPaused && web != null) {
            hasPaused = false;
            // Android manages the actual keyguard; show Arcadium's wake screen when our activity returns.
            showWake();
        }
    }
    @Override public void onWindowFocusChanged(boolean focus) {
        super.onWindowFocusChanged(focus);
        if (focus) { fullscreen(); if (joinActive && joinVisible && heldDpadReady()) { vibeHandler.removeCallbacks(dpadTick); vibeHandler.post(dpadTick); } } else { resetDpad(); held = 0; startHeld = false; selectHeld = false; cancelHomeShortcut(); }
    }
    @Override public void onBackPressed() {
        if (homeVisible) return;
        web.evaluateJavascript("(function(){var g=document.getElementById('gameView');if(g&&g.style.display==='flex'&&typeof back==='function'){back();return;}if(typeof back==='function'){back();return;}ArcadiumHome.home();})()",null);
    }
    @Override protected void onDestroy() {
        resetDpad();
        priceInputSender.shutdownNow();
        cancelHomeShortcut();
        stopDiscovery(); vibeHandler.removeCallbacks(heartbeat); vibeHandler.removeCallbacks(modeChecker);joinActive = false;
        held = 0;
        if (screenReceiverRegistered) {
            try { unregisterReceiver(screenReceiver); } catch (Exception ignored) { }
            screenReceiverRegistered = false;
        }
        if (bitsVoice != null) { bitsVoice.stop(); bitsVoice.shutdown(); bitsVoice = null; }
        if (sfx != null) { sfx.release(); sfx = null; }
        if (web != null) { web.destroy(); web = null; }
        super.onDestroy();
    }
}
