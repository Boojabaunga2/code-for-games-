# Source and artwork

Rules, original crime-caper cast, original sprite/environment art, embedded fonts, heist scenes and asynchronous director: user-provided dirty-deeds.zip (7,415,345 bytes). The actual `dirty-deeds/index.html` is the canonical game used here; legacy Gumpy copies, extra relays and cached bytecode are excluded. Exact original script hashes are in tests/source-contracts.json; the pure physical-dice rules engine remains unchanged.

New Arcadium-branded illustrated cover and city environment: generated specifically for this requested overhaul. New widescreen dashboard, private decision renderer, explicit human-entry/review safeguards and shared controller transport: this update. Cover artwork is promotional; review/ screenshots show the actual browser build.

Native Input V1 reader is copied unchanged from the established Arcadium shared input integration. Scoped route and guarded Windows installer derive from the preceding tested integrations. No new APK or online runtime art/AI service is required.
