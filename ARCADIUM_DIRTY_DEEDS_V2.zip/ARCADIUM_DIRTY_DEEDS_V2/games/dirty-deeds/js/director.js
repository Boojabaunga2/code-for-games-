
/* DIRTY DEEDS big screen: game director, questions to the Multi-Vibes, transport, input. */
(function () {
  'use strict';
  var DD = window.DD;
  var Q0 = new URLSearchParams(location.search);
  var AUTOTEST = false;

  var G = window.G = {
    S: null, scene: { name: 'boot', t0: 0, d: {} },
    Q: {}, done: {}, dirty: {}, focus: 0,
    banner: '', sub: '', toasts: [], hits: [],
    seats: [], tw: {}, twAlive: {},
    srv: { base: '', ok: false, since: 0, boot: null, seats: [], tried: false },
    paused: false, menu: 0, firstGame: true, hostWaiter: null, coinWaiter: null,
    autotest: AUTOTEST, games: 0, privacy: {}
  };
  for (var i = 1; i <= 6; i++) G.seats[i] = { mode: AUTOTEST ? 'cpu' : 'human' };
  var AUTOHOST = false;


  function S() { return G.S; }
  function P(seat) { return DD.P(G.S, seat); }
  function act(seat) { return G.seats[seat].mode !== 'off'; }
  function isCpu(seat) { return G.seats[seat].mode === 'cpu'; }
  G.isCpu = isCpu;
  G.online = function (seat) {
    if (isCpu(seat)) return true;
    if (G.tw[seat] && !G.tw[seat].closed && G.twAlive[seat]) return true;
    var s = G.srv.seats[seat - 1];
    return !!(G.srv.ok && s && s.online);
  };
  G.joined = function (seat) {
    if (isCpu(seat)) return true;
    if (G.tw[seat] && !G.tw[seat].closed) return true;
    var s = G.srv.seats[seat - 1];
    return !!(G.srv.ok && s && s.claimed);
  };
  G.setScene = function (name, d) { G.scene = { name: name, t0: C.now(), d: d || {} }; return G.scene.d; };
  G.st = function () { return C.now() - G.scene.t0; };
  function setBanner(b, s) { G.banner = b || ''; G.sub = s || ''; markAll(); }

  /* ================= QUESTIONS ================= */
  var qn = 0;
  function ask(seat, q) {
    q.qid = 'q' + (++qn) + '_' + seat;
    return new Promise(function (res) {
      q._res = res;
      G.Q[seat] = q; G.done[seat] = false;
      mark(seat);
      if (isCpu(seat)) {
        C.wait(500 + Math.random() * 1600).then(function () {
          if (G.Q[seat] === q) answer(seat, q.qid, cpuAnswer(seat, q), 'cpu');
        });
      }
    });
  }
  function cpuAnswer(seat, q) {
    var k = q.cpu || q.kind;
    if (k === 'route' || k === 'approach' || k === 'pick' || k === 'target') {
      var ok = q.options.filter(function (o) { return !o.disabled; });
      if (k === 'route' || k === 'approach') { var v = DD.cpu(G.S, seat, { kind: k }); if (ok.some(function (o) { return o.id === v; })) return v; }
      return ok[Math.floor(Math.random() * ok.length)].id;
    }
    return DD.cpu(G.S, seat, { kind: k, options: q.options });
  }
  function answer(seat, qid, v, src) {
    var q = G.Q[seat];
    if (G.paused) return false;
    if (!q || q.qid !== qid) return false;
    var val = q.check(v);
    if (val === undefined || val === null) return false;
    G.Q[seat] = null; G.done[seat] = true;
    C.sfx('lock');
    mark(seat);
    q._res(val);
    return true;
  }
  G.answer = answer;
  G.forceAll=function(){G.toast('Human dice are entered on Mini Vibes. No automatic rolls.');};

  function askAll(seats, make) {
    seats.forEach(function (s) { G.done[s] = false; });
    return Promise.all(seats.map(function (s) { return ask(s, make(s)); }));
  }
  function clearDone() { G.done = {}; markAll(); }

  /* question builders (check() returns the clean value, or undefined when invalid) */
  function qPick(title, text, options, cpuKind) {
    return { kind: 'pick', title: title, text: text, options: options, cpu: cpuKind,
      check: function (v) { var o = options.filter(function (x) { return x.id === v && !x.disabled; })[0]; return o ? o.id : undefined; } };
  }
  function seatOpts(list, disabledFn) {
    return list.map(function (s) {
      var p = P(s);
      return { id: s, label: p.short, sub: p.chimps + ' chimps', icon: 'face_' + p.color, color: p.hex, disabled: disabledFn ? !!disabledFn(s) : false };
    });
  }
  function qTarget(title, text, seats) {
    var q = qPick(title, text, seatOpts(seats));
    q.kind = 'target';
    q.check = function (v) { v = v | 0; return seats.indexOf(v) >= 0 ? v : undefined; };
    return q;
  }
  function qDie(seat, title, text) {
    return { kind: 'die', title: title, text: text, color: P(seat).color, check: function (v) { return v === (v | 0) && v >= 0 && v <= 9 ? v : undefined; } };
  }
  function qWar(seat, title) {
    if (G.S.warDice === 'd10') return qDie(seat, title, 'Roll your Dirty Die. Highest roll wins (0 = 10).');
    return { kind: 'rps', title: title, text: 'Roll the RoshamboMoWo die and enter what you got.', check: function (v) { return v === (v | 0) && v >= 1 && v <= 6 ? v : undefined; } };
  }

  /* ================= VIEWS (what each Multi-Vibe shows) ================= */
  function mark(seat) { G.dirty[seat] = true; }
  function markAll() { for (var s = 1; s <= 6; s++) G.dirty[s] = true; }
  G.markAll = markAll;
  function clean(q) {
    if (!q) return null;
    var o = {};
    for (var k in q) if (k[0] !== '_' && k !== 'check' && k !== 'cpu') o[k] = q[k];
    return o;
  }
  function viewFor(seat) {
    var v = { game: 'dd', seat: seat, color: DD.COLORS[seat - 1], hex: DD.HEX[DD.COLORS[seat - 1]], name: DD.NAMES[seat - 1], short: DD.SHORT[seat - 1],
      mode: G.seats[seat].mode, banner: G.banner, sub: G.sub, q: clean(G.Q[seat]), done: !!G.done[seat], priv: G.privacy[seat] || [], pay: [] };
    var st = G.S;
    if (st) {
      var p = P(seat);
      v.inGame = p.active; v.chimps = p.chimps; v.heat = p.heat; v.ghost = p.ghost; v.round = st.round; v.rounds = DD.CFG.rounds; v.vault = st.vault;
      v.pay = G.toasts.filter(function (t) { return t.from === seat || t.to === seat; }).map(function (t) {
        if (t.from === seat) return t.to === 'vault' ? 'PUT ' + t.n + ' IN THE VAULT' : 'GIVE ' + t.n + ' TO ' + DD.SHORT[t.to - 1];
        return t.from === 'vault' ? 'TAKE ' + t.n + ' FROM THE VAULT' : 'TAKE ' + t.n + ' FROM ' + DD.SHORT[t.from - 1];
      });
    }
    return v;
  }
  G.viewFor=viewFor;
  var lastSent = {};
  function flushViews() {
    var out = {}, any = false;
    for (var s = 1; s <= 6; s++) {
      if (!G.dirty[s]) continue;
      G.dirty[s] = false;
      var v = viewFor(s), js = JSON.stringify(v);
      if (lastSent[s] === js) continue;
      lastSent[s] = js; out[s] = v; any = true;
      if (G.tw[s] && !G.tw[s].closed) { try { G.tw[s].postMessage({ dd: 1, view: v }, '*'); } catch (e) { } }
    }

  }
  setInterval(flushViews, 80);
  setInterval(function () { lastSent = {}; markAll(); }, 4000); /* heartbeat: re-send every view so a handheld never gets stuck on a stale screen */
  setInterval(function () { for (var s = 1; s <= 6; s++) if (G.toasts.some(function (t) { return t.from === s || t.to === s; })) mark(s); }, 1000);

  function poll() {}
  G.releaseSeat=function(){};
  /* ================= TRANSPORT: test windows (one PC, no server) ================= */
  window.addEventListener('message', function (e) {
    var d = e.data;
    if (!d || d.dd !== 1 || !d.msg) return;
    for (var s = 1; s <= 6; s++) if (G.tw[s] && e.source === G.tw[s]) { onMsg(s, d.msg, 'tw'); return; } /* seat comes from the window, never the message */
  });
  G.openTest = function (seat) {
    if (!window.DD_VIBE_HTML) return;
    var w = window.open('', 'dd_vibe_' + seat, 'width=400,height=440,left=' + (20 + ((seat - 1) % 3) * 410) + ',top=' + (20 + Math.floor((seat - 1) / 3) * 470));
    if (!w) { toast('Allow pop-ups to open test windows'); return; }
    w.document.open();
    w.document.write(window.DD_VIBE_HTML.replace('<head>', '<head><script>window.DD_TEST_SEAT=' + seat + ';<\/script>'));
    w.document.close();
    G.tw[seat] = w; G.twAlive[seat] = Date.now(); delete lastSent[seat]; mark(seat);
  };
  G.openNextTest = function () {
    for (var s = 1; s <= 6; s++) if (G.seats[s].mode === 'human' && (!G.tw[s] || G.tw[s].closed)) { G.openTest(s); return; }
  };

  /* ================= LEDGER -> physical chimp instructions ================= */
  var ledgerSeen = 0;
  function flushLedger() {
    var L = G.S.ledger;
    if (ledgerSeen > L.length) ledgerSeen = 0;
    var add = L.slice(ledgerSeen); ledgerSeen = L.length;
    /* merge identical routes */
    var m = {};
    add.forEach(function (e) { var k = e.from + '>' + e.to; if (!m[k]) m[k] = { from: e.from, to: e.to, n: 0, why: e.why }; m[k].n += e.n; });
    Object.keys(m).forEach(function (k) { var e = m[k]; e.t0 = C.now(); if (e.why === 'ante') e.silent = true; G.toasts.push(e); if (e.from !== 'vault') mark(e.from); if (e.to !== 'vault') mark(e.to); });
    while (G.toasts.length > 6) G.toasts.shift();
    if (add.length) C.sfx('cash');
    return add;
  }
  G.flushLedger = flushLedger;
  function toast(text) { G.toasts.push({ text: text, t0: C.now() }); }
  G.toast = toast;
  setInterval(function () { var t = C.now(); G.toasts = G.toasts.filter(function (x) { return t - x.t0 < 7000; }); }, 500);

  /* ================= HOST INPUT ================= */
  function hostWait() { return new Promise(function (res) { G.hostWaiter = res; if (AUTOHOST) C.wait(800).then(function () { if (G.hostWaiter === res) { G.hostWaiter = null; res(); } }); }); }
  function advance() { if (G.hostWaiter) { var r = G.hostWaiter; G.hostWaiter = null; C.sfx('click'); r(); return true; } return false; }
  G.advance = advance;
  function exitGame() {
    try { window.parent && window.parent !== window && window.parent.postMessage({ arcadium: 'exit', game: 'dirty-deeds' }, '*'); } catch (e) { }
    try { if (window.ArcadiumOS && window.ArcadiumOS.exit) { window.ArcadiumOS.exit(); return; } } catch (e) { }
    try { if (window.Android && window.Android.exitGame) { window.Android.exitGame(); return; } } catch (e) { }
    if (history.length > 1) history.back(); else window.close();
  }
  G.exitGame = exitGame;
  function setPause(on) {
    G.paused = on; C.clock.paused = on; G.menu = 0;
    if (C.audio.ctx) { if (on) C.audio.ctx.suspend(); else C.audio.ctx.resume(); }
  }
  G.setPause = setPause;

  window.addEventListener('keydown', function (e) {
    C.audio.init();
    var k = e.key;
    if (G.paused) {
      if (k === 'ArrowUp' || k === 'ArrowDown') G.menu = 1 - G.menu;
      else if (k === 'Enter' || k === ' ') { if (G.menu === 0) setPause(false); else exitGame(); }
      else if (k === 'Escape' || k === 'p' || k === 'P') setPause(false);
      e.preventDefault(); return;
    }
    if (k === 'p' || k === 'P') { if (G.S) setPause(true); return; }
    if (k === 'Escape') { if (G.S && G.scene.name !== 'final') setPause(true); else exitGame(); return; }
    if (k === 'm' || k === 'M') { C.audio.music = !C.audio.music; toast(C.audio.music ? 'MUSIC ON' : 'MUSIC OFF'); return; }
    if (k === 'n' || k === 'N') { C.audio.on = !C.audio.on; toast(C.audio.on ? 'SOUND ON' : 'SOUND OFF'); return; }
    if (k === 'f' || k === 'F') { G.forceAll(); return; }
    if (k === 't' || k === 'T') { G.openNextTest(); return; }
    if (G.scene.name === 'lobby' && k >= '1' && k <= '6') { G.cycleSeat(+k); return; }
    if (G.scene.name === 'coin' && k >= '1' && k <= '6') { G.pickCoin(+k); return; }
    if (G.scene.name === 'coin' && (k === 'ArrowLeft' || k === 'ArrowRight')) { G.coinMove(k === 'ArrowLeft' ? -1 : 1); return; }
    if (G.scene.name === 'coin' && (k === 'Enter' || k === ' ')) { G.pickCoin(G.scene.d.tied[G.scene.d.sel || 0]); return; }
    if (k === 'Enter' || k === ' ') { advance(); e.preventDefault(); }
  });
  C.cv.addEventListener('pointerdown', function (e) {
    C.audio.init();
    var p = C.toLogical(e.clientX, e.clientY);
    for (var i = G.hits.length - 1; i >= 0; i--) {
      var h = G.hits[i];
      if (p.x >= h.x && p.x <= h.x + h.w && p.y >= h.y && p.y <= h.y + h.h) { h.fn(); return; }
    }
    if (G.paused) return;
    advance();
  });
  G.hit = function (x, y, w, h, fn) { G.hits.push({ x: x, y: y, w: w, h: h, fn: fn }); };

  G.cycleSeat = function (s) {
    var order = ['human', 'cpu', 'off'];
    var m = G.seats[s].mode;
    G.seats[s].mode = order[(order.indexOf(m) + 1) % 3];
    if (G.seats[s].mode !== 'human' && G.tw[s] && !G.tw[s].closed) { /* keep window, just idle */ }
    C.sfx('click'); markAll();
  };
  G.pickCoin = function (seat) {
    var d = G.scene.d;
    if (!d.tied || d.tied.indexOf(seat) < 0 || !G.coinWaiter) return;
    var r = G.coinWaiter; G.coinWaiter = null; C.sfx('stamp'); r(seat);
  };
  G.coinMove = function (dir) { var d = G.scene.d; d.sel = ((d.sel || 0) + dir + d.tied.length) % d.tied.length; C.sfx('click'); };

  /* decision coin tie-break: the host taps / types the seat that LOST (or WON) the flip */
  async function coin(tied, title, sub) {
    var d = G.setScene('coin', { tied: tied, title: title, sub: sub, sel: 0 });
    setBanner('DECISION COIN!', 'Flip an Arcadium decision coin');
    tied.forEach(function (s) { G.privacy[s] = ['TIE! FLIP YOUR DECISION COIN', 'The host taps the result on the big screen']; mark(s); });
    C.sfx('drum');
    var allCpu = tied.every(isCpu);
    var res = await new Promise(function (r) {
      G.coinWaiter = r;
      if (allCpu || AUTOHOST) C.wait(2400).then(function () { if (G.coinWaiter === r) { G.coinWaiter = null; r(tied[Math.floor(Math.random() * tied.length)]); } });
    });
    d.chosen = res; d.t1 = C.now();
    tied.forEach(function (s) { G.privacy[s] = []; mark(s); });
    await C.wait(1400);
    return res;
  }

  /* ================= THE GAME ================= */
  async function boot() {
    G.setScene('boot', { p: 0 });
    var t0 = Date.now();
    await C.load(function (p) { G.scene.d.p = p; });
    await document.fonts.ready.catch(function () { });
    var left = 2600 - (Date.now() - t0);
    if (left > 0 && !AUTOTEST) await new Promise(function (r) { setTimeout(r, left); });
    poll();
    var sp = document.getElementById('splash'); if (sp) sp.style.display = 'none';
  }

  async function title() {
    G.setScene('title');
    setBanner('DIRTY DEEDS', 'Waiting for the host');
    await hostWait();
    C.audio.init();
    C.sfx('boom');
  }

  async function lobby() {
    var d = G.setScene('lobby');
    setBanner('PICK YOUR BOSS', 'Waiting for the host to start');
    var readyQ = {};
    for (;;) {
      /* ask joined human seats to READY UP */
      for (var s = 1; s <= 6; s++) {
        if (G.seats[s].mode === 'human' && G.joined(s) && !G.Q[s] && !G.done[s]) {
          (function (seat) {
            readyQ[seat] = true;
            ask(seat, { kind: 'ready', title: 'YOU ARE ' + DD.NAMES[seat - 1], text: 'Press READY when you have your 3 tool dice, your Dirty Die and 20 Poker Chimps.', button: 'READY',
              check: function (v) { return v ? true : undefined; } }).then(function () { readyQ[seat] = false; });
          })(s);
        }
        if (G.seats[s].mode !== 'human' && G.Q[s]) { G.Q[s] = null; G.done[s] = false; mark(s); }
      }
      var activeSeats = [], waiting = [];
      for (var s2 = 1; s2 <= 6; s2++) {
        if (G.seats[s2].mode === 'off') continue;
        activeSeats.push(s2);
        if (G.seats[s2].mode === 'human' && !G.done[s2]) waiting.push(s2);
      }
      d.canStart = activeSeats.length >= 3 && !waiting.length;
      d.waiting = waiting; d.count = activeSeats.length;
      if (d.canStart) {
        if (!G.hostWaiter && !d.go) hostWait().then(function () { d.go = true; });
        if (d.go) break;
      } else { G.hostWaiter = null; d.go = false; }
      await C.wait(300);
    }
    G.hostWaiter = null;
    for (var s4 = 1; s4 <= 6; s4++) { G.Q[s4] = null; }
    clearDone();
  }

  async function howTo() {
    G.setScene('howto');
    setBanner('HOW TO PLAY', 'Read the big screen');
    await Promise.race([hostWait(), C.wait(16000)]);
    G.hostWaiter = null;
  }

  function startGame() {
    var seats = [];
    for (var s = 1; s <= 6; s++) seats.push({ active: G.seats[s].mode !== 'off', cpu: G.seats[s].mode === 'cpu' });
    G.S = DD.newGame({ seed: (Date.now() ^ (Math.random() * 1e9)) >>> 0, seats: seats, warDice: (G.warChoice||Q0.get('war'))==='d10'?'d10':'rps' });
    ledgerSeen = 0; G.toasts = []; G.privacy = {}; G.Q = {}; G.done = {};
    markAll();
  }

  function livingSeats() { return DD.living(G.S).map(function (p) { return p.seat; }); }
  function ghostSeats() { return DD.ghosts(G.S).map(function (p) { return p.seat; }); }
  function activeSeats() { return DD.actives(G.S).map(function (p) { return p.seat; }); }
  function setPriv(seat, lines) { G.privacy[seat] = lines; mark(seat); }
  function A_NAME(a) { return a ? a.toUpperCase() : ''; }

  async function round() {
    var st = G.S;
    G.roundStart = {};
    st.players.forEach(function (p) { G.roundStart[p.seat] = p.chimps; });
    var info = DD.startRound(st);
    G.privacy = {};
    clearDone();
    /* --- round intro + ante --- */
    G.setScene('intro', { info: info });
    setBanner('ROUND ' + info.round + ' OF ' + DD.CFG.rounds, 'Ante up: 2 Poker Chimps into the vault');
    C.sfx('whoosh');
    await C.wait(1800);
    flushLedger();
    await C.wait(3200);

    /* --- 1. CASE THE JOINT (living) + ghost plans (ghosts) --- */
    G.setScene('case', {});
    setBanner('CASE THE JOINT', 'Secretly choose your approach');
    var approachOpts = [
      { id: 'sneak', label: 'SNEAK', sub: 'Dice 7+ crack it. Heat -1', icon: 'act_hide' },
      { id: 'hack', label: 'HACK', sub: 'Dice 6+ crack it. Alarm -1', icon: 'obj_keycard' },
      { id: 'smash', label: 'SMASH', sub: 'Dice 5+ crack it. Heat +2', icon: 'act_threaten' },
      { id: 'swindle', label: 'SWINDLE', sub: 'Dice 7+ crack it. +1 Dirty Deed', icon: 'act_bribe' }
    ];
    var L = livingSeats(), Gh = ghostSeats();
    var jobs = L.map(function (s) {
      return ask(s, qPick('CASE THE JOINT', 'Pick your secret approach. The same 3 dice you roll for the numbers will crack the vault.', approachOpts, 'approach')).then(function (a) {
        DD.setApproach(st, s, a); setPriv(s, ['APPROACH: ' + A_NAME(a)]);
      });
    }).concat(Gh.map(function (s) {
      var q = {
        kind: 'ghost', title: 'GHOST BOSS', text: 'Pick one ghost power for this round (or pass). It fires automatically at the right moment.',
        powers: Object.keys(DD.GHOST_POWERS).map(function (k) { var g = DD.GHOST_POWERS[k]; return { id: k, label: g.name, sub: g.text, target: g.target, icon: 'act_ghostpower' }; }),
        targets: seatOpts(livingSeats()), cpu: 'ghost',
        check: function (v) { if (!v || typeof v !== 'object') return undefined; return DD.setGhostPlan(st, s, { power: v.power, target: v.target }) ? st.players[s - 1].plan : undefined; }
      };
      return ask(s, q).then(function (plan) {
        setPriv(s, [plan.power === 'pass' ? 'NO HAUNTING THIS ROUND' : 'POWER: ' + DD.GHOST_POWERS[plan.power].name + (plan.target ? ' on ' + DD.SHORT[plan.target - 1] : '')]);
      });
    }));
    await Promise.all(jobs);
    await C.wait(900);

    /* --- 2. THE NUMBERS --- */
    var pd = G.setScene('paper', { target: st.target, round: st.round });
    setBanner('THE DIRTY DAILY', 'The numbers are coming out...');
    C.sfx('whoosh');
    await C.wait(2600);
    C.sfx('stamp');
    await C.wait(1400);
    setBanner('PLAY THE NUMBERS', 'Target ' + pad3(st.target) + ': roll 3 tool dice, get closest (over or under)');
    pd.entering = true;
    await askAll(activeSeats(), function (s) {
      var p = P(s);
      return { kind: 'digits', title: 'PLAY THE NUMBERS', text: 'Roll your 3 tool D10s. Arrange them to get CLOSEST to the target, over or under. Exact hit = 3 moves!',
        target: st.target, approach: p.ghost ? null : p.approach, min: p.ghost ? null : DD.CFG.approach[p.approach].min, ghost: p.ghost,
        check: function (v) { if (!Array.isArray(v)) return undefined; v = v.map(function (x) { return +x; }); return DD.validDigits(v) ? v : undefined; } };
    }).then(function (all) {
      activeSeats().forEach(function (s, i) { DD.setNumber(st, s, all[i]); });
    });
    await C.wait(700);
    /* reveal */
    var stand = DD.numbersStandings(st);
    var winner = stand.tied[0];
    var nd = G.setScene('numbers', { stand: stand, rows: stand.order.map(function (p) { return { seat: p.seat, number: p.number, dist: p.dist }; }),
      ghosts: DD.ghosts(st).filter(function (g) { return g.number !== null; }).map(function (g) { return { seat: g.seat, number: g.number, dist: g.dist }; }), target: st.target });
    setBanner('NUMBERS IN!', 'Closest to ' + pad3(st.target) + ' wins');
    C.sfx('drum');
    var nRows = nd.rows.length;
    await C.wait(1100 + nRows * 650 + 600);
    if (stand.tied.length > 1) {
      winner = await coin(stand.tied, 'TIE FOR CLOSEST!', 'Flip a decision coin: tap the WINNER');
      G.setScene('numbers', nd); G.scene.t0 -= 99999;
    }
    var res = DD.resolveNumbers(st, winner);
    nd.res = res; nd.tRes = C.now() - G.scene.t0;
    C.sfx(res.rows.some(function (r) { return r.exact; }) ? 'good' : 'cash');
    setBanner(DD.SHORT[res.winner - 1] + ' WINS THE NUMBERS', res.rows.some(function (r) { return r.exact; }) ? 'BULLSEYE! Exact hit = 3 moves' : 'Worst number pays the winner');
    await C.wait(1200);
    flushLedger();
    await C.wait(3000);

    /* --- 3. ROLL & MOVE --- */
    var order = res.order;
    for (var oi = 0; oi < order.length; oi++) {
      var seat = order[oi], p = P(seat);
      if (p.ghost) continue;
      for (var m = 0; m < p.moves; m++) {
        await turn(seat, p.moves > 1 ? 'MOVE ' + (m + 1) + ' OF ' + p.moves : '', 0);
      }
    }

    /* --- 4. THE VAULT --- */
    var crack = DD.crack(st);
    G.setScene('vault', { crack: crack });
    setBanner('CRACK THE VAULT', 'Security ' + crack.security + ' - the crew needs ' + crack.security + ' cracks');
    C.sfx('laser');
    await C.wait(1600 + crack.rows.length * 900 + 600);
    C.sfx(crack.ok ? 'good' : 'alarm');
    if (!crack.ok) C.sfx('siren');
    setBanner(crack.ok ? 'THE VAULT IS OPEN!' : 'THE VAULT HOLDS!', crack.ok ? crack.vault + ' chimps inside' : 'Alarm! Everyone heat +1');
    await C.wait(3400);

    /* --- 5. DIRTY DEEDS --- */
    if (crack.ok) {
      var dd = G.setScene('deeds', { phase: 'secret', vault: st.vault });
      setBanner('DIRTY DEEDS', 'Secretly choose: play fair... or not');
      var deedOpts = Object.keys(DD.DEEDS).map(function (k) { return { id: k, label: DD.DEEDS[k].name, sub: DD.DEEDS[k].text, icon: { grab: 'obj_stashbag', lift: 'act_stealcrew', frame: 'ui_target', dcross: 'act_betray' }[k], needTarget: k === 'lift' || k === 'frame' }; });
      clearDone();
      await askAll(livingSeats(), function (s) {
        var tg = DD.targetsFor(st, s);
        var share = st.vault > 0 ? Math.max(1, Math.floor(st.vault / livingSeats().length)) : 0;
        return { kind: 'deed', title: 'DIRTY DEEDS', text: 'Fair share is ' + share + '. Grab works on 3+, Lift 6+, Frame 4+, Double-Cross 8+ (Dirty Die, 0 = 10).',
          options: deedOpts.map(function (o) { var c = {}; for (var k in o) c[k] = o[k]; if (o.needTarget && !tg.length) c.disabled = true; return c; }),
          targets: seatOpts(tg), cpu: 'deed',
          check: function (v) {
            if (!v || !DD.DEEDS[v.deed]) return undefined;
            var need = v.deed === 'lift' || v.deed === 'frame';
            if (need && tg.indexOf(v.target | 0) < 0) return undefined;
            return { deed: v.deed, target: need ? v.target | 0 : null };
          } };
      }).then(function (all) {
        livingSeats().forEach(function (s, i) {
          DD.setDeed(st, s, all[i].deed, all[i].target);
          setPriv(s, ['DEED: ' + DD.DEEDS[all[i].deed].name + (all[i].target ? ' on ' + DD.SHORT[all[i].target - 1] : '')]);
        });
      });
      setBanner('ROLL YOUR DIRTY DIE', 'Everyone rolls their colour Dirty Die');
      dd.phase = 'roll';
      clearDone();
      await askAll(livingSeats(), function (s) { return qDie(s, 'ROLL YOUR DIRTY DIE', 'Your deed: ' + DD.DEEDS[P(s).deed].name + '. Enter what your Dirty Die shows (0 = 10).'); }).then(function (all) {
        livingSeats().forEach(function (s, i) { DD.setDeedRoll(st, s, all[i]); });
      });
      var dr = DD.resolveDeeds(st);
      dd.res = dr; dd.phase = 'reveal'; dd.tReveal = C.now() - G.scene.t0;
      setBanner('THE DEEDS ARE DONE', 'Who betrayed who?');
      C.sfx('drum');
      await C.wait(2200 + dr.steps.length * 1700 + 1500);
    }

    /* --- 6. THE GETAWAY --- */
    var fx = DD.applyGetawayGhosts(st);
    clearDone();
    var gd = G.setScene('getaway', { phase: 'choose', fx: fx });
    setBanner('THE GETAWAY', 'Cops are coming! Pick your route');
    C.sfx('siren');
    await askAll(livingSeats(), function (s) {
      var pp = P(s), need = DD.getawayNeed(st, pp);
      setPriv(s, ['HEAT ' + pp.heat + ' + ALARM ' + st.alarm, 'YOU NEED ' + need + '+ TO ESCAPE', 'LOOT IN YOUR BAG: ' + pp.hot]);
      var opts = Object.keys(DD.ROUTES).map(function (k) { var r = DD.ROUTES[k]; return { id: k, label: r.name, sub: r.text, icon: { floor: 'veh_car', alley: 'veh_dumpster', low: 'act_hide' }[k] }; });
      return qPick('THE GETAWAY', 'You need ' + need + '+ on your Dirty Die to escape (0 = 10). Your bag: ' + pp.hot + ' loot.', opts, 'route');
    }).then(function (all) { livingSeats().forEach(function (s, i) { DD.setRoute(st, s, all[i]); }); });
    var rollers = livingSeats().filter(function (s) { return P(s).route !== 'low'; });
    if (rollers.length) {
      setBanner('PUNCH IT!', 'Roll your Dirty Die to escape');
      gd.phase = 'roll';
      await askAll(rollers, function (s) { return qDie(s, 'ESCAPE ROLL', 'Need ' + DD.getawayNeed(st, P(s)) + '+ (' + DD.ROUTES[P(s).route].name + ' adds +' + DD.ROUTES[P(s).route].bonus + '). 0 = 10.'); }).then(function (all) {
        rollers.forEach(function (s, i) { DD.setEscRoll(st, s, all[i]); });
      });
    }
    var gr = DD.resolveGetaway(st);
    gd.res = gr; gd.phase = 'chase'; gd.tChase = C.now() - G.scene.t0;
    setBanner('THE CHASE!', '');
    C.sfx('screech');
    await C.wait(7600);
    flushLedger();
    await C.wait(1500);

    /* --- 7. ROUND END --- */
    G.privacy = {}; clearDone();
    var re = DD.roundEnd(st);
    G.setScene('roundend', { re: re });
    setBanner('END OF ROUND ' + st.round, 'Check your Poker Chimp count');
    await C.wait(6500);
    if (re.tied && re.tied.length) {
      var out = re.tied[0];
      if (re.tied.length > 1) out = await coin(re.tied, 'TIE FOR LAST PLACE!', 'Flip a decision coin: tap who becomes the GHOST');
      DD.eliminate(st, out);
      G.setScene('ghost', { seat: out });
      setBanner(DD.SHORT[out - 1] + ' IS A GHOST BOSS', 'The boss never leaves!');
      C.sfx('ghost');
      await C.wait(5200);
    }
    return re.final;
  }

  function pad3(n) { return ('00' + n).slice(-3); }
  G.pad3 = pad3;

  /* one Roll & Move turn on the city board */
  async function turn(seat, label, depth) {
    var st = G.S, p = P(seat);
    var bd = G.scene.name === 'board' ? G.scene.d : G.setScene('board', {});
    bd.active = seat; bd.label = label; bd.ev = null; bd.dice = null; bd.hop = null;
    G.focus = seat;
    setBanner(p.short + ' ROLLS TO MOVE', label || 'Roll your Dirty Die');
    var roll = await ask(seat, qDie(seat, 'ROLL & MOVE', 'Roll your ' + p.color.toUpperCase() + ' Dirty Die and enter it (0 = 10).' + (label ? ' ' + label : '')));
    bd.dice = { v: DD.dieVal(roll), t0: C.now(), col: p.color };
    C.sfx('dice');
    await C.wait(1300);
    var mv = DD.step(st, seat, roll);
    bd.hop = { seat: seat, path: mv.path, from: mv.from, t0: C.now() };
    for (var i = 0; i < mv.path.length; i++) { await C.wait(170); C.sfx('hop'); }
    await C.wait(250);
    bd.hop = null; bd.dice = null;
    await land(seat, depth || 0);
    G.focus = 0;
  }
  function ev(bd, o) { o.t0 = C.now(); bd.ev = o; }

  async function land(seat, depth) {
    var st = G.S, p = P(seat), bd = G.scene.d;
    var Lk = DD.landing(st, seat), info;
    var name = p.short;
    if (Lk.kind === 'war') {
      ev(bd, { title: 'RIVAL TURF!', text: name + ' declares war on ' + DD.SHORT[Lk.owner - 1], icon: 'act_threaten', col: DD.HEX[DD.COLORS[Lk.owner - 1]] });
      C.sfx('boom'); await C.wait(1500);
      await crewWar(seat, Lk.owner, DD.CFG.crewStake, 'CREW WAR!');
      return;
    }
    if (Lk.kind === 'casino') {
      var tg = DD.targetsFor(st, seat, true);
      ev(bd, { title: 'CASINO', text: 'Double takeover... or cash out?', icon: 'ui_jackpot', col: '#ffd21f' });
      var opts = [{ id: 'takeover', label: 'DOUBLE TAKEOVER', sub: 'Crew War for 6 chimps', icon: 'act_raid', disabled: !tg.length },
        { id: 'cash', label: 'CASH OUT', sub: 'Take 2 from the vault', icon: 'act_bribe' }];
      var ch = await ask(seat, qPick('CASINO', 'Risk a Double Takeover (6 chimps on the line) or cash out 2 from the vault.', opts));
      if (ch === 'cash') {
        DD.casinoCashOut(st, seat); flushLedger();
        ev(bd, { title: 'CASH OUT!', text: name + ' takes 2 from the vault', icon: 'ui_jackpot', col: '#ffd21f' });
        C.money(360, 330, 30); await C.wait(2200); return;
      }
      var t = await ask(seat, qTarget('DOUBLE TAKEOVER', 'Pick a rival boss to hit for 6 chimps.', tg));
      await crewWar(seat, t, DD.CFG.casinoStake, 'DOUBLE TAKEOVER!');
      return;
    }
    if (Lk.kind === 'docks') {
      var td = DD.targetsFor(st, seat, true);
      if (!td.length) { ev(bd, { title: 'DOCKS', text: 'Nobody to rob. The fish are disappointed.', icon: 'act_stealcrew', col: '#2f7bff' }); await C.wait(2200); return; }
      ev(bd, { title: 'THE DOCKS', text: name + ' tries to steal a crew! 6+ takes 2, miss pays 1', icon: 'act_stealcrew', col: '#2f7bff' });
      var t2 = await ask(seat, qTarget('THE DOCKS', 'Steal a crew: pick a target. Then roll your Dirty Die: 6+ steals 2, miss and you pay them 1.', td));
      var r2 = await ask(seat, qDie(seat, 'THE DOCKS', 'Steal from ' + DD.SHORT[t2 - 1] + ': 6+ takes 2 chimps. 0 = 10.'));
      var dres = DD.applyDocks(st, seat, t2, r2);
      flushLedger();
      ev(bd, { title: dres.ok ? 'CREW STOLEN!' : 'BOTCHED JOB!', text: dres.ok ? name + ' rolled ' + dres.roll + ' and takes ' + dres.n + ' from ' + DD.SHORT[t2 - 1] : name + ' rolled ' + dres.roll + ' and pays ' + dres.n + ' to ' + DD.SHORT[t2 - 1], icon: dres.ok ? 'act_stealcrew' : 'ui_oops', col: dres.ok ? '#22d14a' : '#ff2b3a', from: dres.ok ? t2 : seat, to: dres.ok ? seat : t2 });
      C.sfx(dres.ok ? 'good' : 'bad'); await C.wait(2600); return;
    }
    if (Lk.kind === 'club') {
      var tc = DD.targetsFor(st, seat);
      if (!tc.length) { ev(bd, { title: 'UNDERGROUND CLUB', text: 'The club is empty tonight.', icon: 'act_swap', col: '#a040ff' }); await C.wait(2000); return; }
      ev(bd, { title: 'UNDERGROUND CLUB', text: 'Dirty deal: your heat -2, a rival heat +2', icon: 'act_swap', col: '#a040ff' });
      var t3 = await ask(seat, qTarget('DIRTY DEAL', 'Tip off the cops: your heat -2, their heat +2.', tc));
      DD.applyClub(st, seat, t3);
      ev(bd, { title: 'DIRTY DEAL!', text: name + ' rats out ' + DD.SHORT[t3 - 1] + '. Heat moves!', icon: 'ui_heat', col: '#ff6a00', from: seat, to: t3 });
      C.sfx('whoosh'); await C.wait(2400); return;
    }
    if (Lk.kind === 'roof') {
      var rr = DD.applyRoof(st, seat);
      flushLedger();
      ev(bd, { title: rr.ev.title, text: rr.ev.text, icon: 'act_ambush', col: '#ff3fd0', card: true });
      C.sfx('whoosh'); await C.wait(3000);
      if (rr.again && depth < 3) await turn(seat, 'LUCKY BANANA: MOVE AGAIN', depth + 1);
      return;
    }
    if (Lk.kind === 'train') {
      ev(bd, { title: 'ALL ABOARD!', text: name + ' catches the train: extra roll!', icon: 'act_getaway', col: '#ffd21f' });
      C.sfx('good'); await C.wait(1800);
      if (depth < 3) await turn(seat, 'TRAIN STATION: EXTRA ROLL', depth + 1);
      return;
    }
    info = DD.applySimple(st, seat, Lk.kind);
    flushLedger();
    var titles = { home: 'HOME TURF', abandoned: 'ABANDONED TURF', haunted: 'HAUNTED TURF', hiding: 'LAYING LOW', safe: 'SAFE HOUSE', ware: 'WAREHOUSE' };
    var icons = { home: 'ui_loyalty', abandoned: 'ui_jackpot', haunted: 'act_ghostpower', hiding: 'act_hide', safe: 'act_defend', ware: 'act_recruit' };
    ev(bd, { title: titles[Lk.kind] || 'HMM', text: info.text, icon: icons[Lk.kind] || 'ui_nice', col: '#22d14a', from: info.from, to: info.from ? seat : null });
    C.sfx(Lk.kind === 'haunted' ? 'ghost' : 'good');
    await C.wait(2300);
  }

  async function crewWar(a, d, stake, title) {
    var st = G.S;
    var war = DD.newWar(st, a, d, stake);
    var back = G.scene;
    var wd = G.setScene('war', { war: war, title: war.last ? 'THE LAST CREW!' : title, phase: 'intro' });
    setBanner(war.last ? 'THE LAST CREW!' : title, DD.SHORT[a - 1] + ' vs ' + DD.SHORT[d - 1] + (war.last ? ' - best 2 of 3' : ''));
    C.sfx('boom');
    await C.wait(1800);
    while (!war.done) {
      wd.phase = 'roll'; wd.cur = null;
      clearDone();
      var f = await Promise.all([ask(a, qWar(a, 'CREW WAR: ATTACK!')), ask(d, qWar(d, 'CREW WAR: DEFEND!'))]);
      var r = DD.warRoll(st, war, f[0], f[1]);
      wd.cur = war.rounds[war.rounds.length - 1]; wd.tCur = C.now();
      wd.phase = 'show';
      C.sfx('dice');
      await C.wait(900);
      C.sfx(r === 'tie' ? 'bad' : 'hit');
      await C.wait(r === 'tie' ? 1600 : 2000);
    }
    var n = DD.finishWar(st, war, title === 'DOUBLE TAKEOVER!' ? 'double takeover' : 'crew takeover');
    wd.phase = 'result'; wd.tRes = C.now(); wd.moved = n;
    flushLedger();
    C.sfx(war.winner === 'a' ? 'good' : 'boom');
    await C.wait(3600);
    clearDone();
    G.scene = back; back.d.ev = null;
  }

  async function finale() {
    var st = G.S;
    var fr = DD.finalResults(st);
    if (fr.tied.length > 1) {
      var w = await coin(fr.tied, 'TIE FOR THE CROWN!', 'Flip a decision coin: tap the WINNER');
      fr = DD.finalResults(st, w);
    }
    var fd = G.setScene('final', { fr: fr });
    setBanner('THE BIG REVEAL', 'Look at the big screen!');
    C.sfx('drum');
    await C.wait(23000);
    fd.done = true;
    C.confetti(140); C.money(360, 300, 60, 9); C.sfx('good');
    var W = P(fr.winner);
    setBanner(W.short + ' WINS!', fr.title);
    activeSeats().forEach(function (s) {
      ask(s, { kind: 'ready', title: s === fr.winner ? 'YOU WIN!' : 'GAME OVER', text: s === fr.winner ? 'You are ' + fr.title + '.' : 'Winner: ' + W.name, button: 'PLAY AGAIN', check: function (v) { return v ? true : undefined; } });
    });
    await hostWait();
    for (var s = 1; s <= 6; s++) G.Q[s] = null;
    clearDone();
  }

  async function main() {
    await boot();
    await title();
    for (;;) {
      await lobby();
      startGame();
      if (G.firstGame && !AUTOHOST) await howTo();
      G.firstGame = false;
      for (var r = 0; r < DD.CFG.rounds; r++) {
        var fin = await round();
        if (fin) break;
      }
      await finale();
      G.games++;
      if (AUTOHOST) { window.DD_TEST_DONE = (window.DD_TEST_DONE || 0) + 1; }
      G.S = null; markAll();
    }
  }
  G.start = main;
})();

