
/* DIRTY DEEDS — THE NUMBERS RACKET : rules engine (pure logic, no DOM).
   Deterministic: all randomness comes from the seeded RNG in the state.
   Physical dice are INPUTS (players enter what they rolled).
   Chimps are conserved: sum(player chimps) + vault never changes. */
(function (root) {
  'use strict';

  var COLORS = ['red', 'blue', 'green', 'yellow', 'pink', 'white'];
  var HEX = { red: '#ff2b3a', blue: '#2f7bff', green: '#22d14a', yellow: '#ffd21f', pink: '#ff3fd0', white: '#f2f2f2' };
  var NAMES = ['TONY TWO-TIMES', 'VINNY THE VISE', 'SALVATORE SLIPPERY', 'LUCKY LOUIE BANANAS', 'FRANKIE FINGERS', 'DON KNUCKLES McGEE'];
  var SHORT = ['TONY', 'VINNY', 'SAL', 'LOUIE', 'FRANKIE', 'DON'];

  var CFG = {
    startChimps: 20,
    rounds: 5,
    ante: 2,
    exactMoves: 3,
    crewStake: 3,
    casinoStake: 6,
    lastCrew: 5,
    heatMax: 10,
    approach: {
      sneak: { min: 7, heat: -1 },
      hack: { min: 6, alarm: -1 },
      smash: { min: 5, heat: 2 },
      swindle: { min: 7, deedBonus: 1 }
    }
  };

  /* ---------- board: 24 spaces, 7 per side incl. corners, clockwise from top-left ---------- */
  var BOARD = [
    { t: 'safe' }, { t: 'turf', c: 0 }, { t: 'docks' }, { t: 'turf', c: 1 }, { t: 'roof' }, { t: 'turf', c: 2 },
    { t: 'casino' }, { t: 'turf', c: 3 }, { t: 'ware' }, { t: 'turf', c: 4 }, { t: 'docks' }, { t: 'turf', c: 5 },
    { t: 'club' }, { t: 'turf', c: 0 }, { t: 'roof' }, { t: 'turf', c: 1 }, { t: 'ware' }, { t: 'turf', c: 2 },
    { t: 'train' }, { t: 'turf', c: 3 }, { t: 'docks' }, { t: 'turf', c: 4 }, { t: 'roof' }, { t: 'turf', c: 5 }
  ];
  var SPACE_INFO = {
    safe: { name: 'SAFE HOUSE', sub: 'Protected + cool off' },
    turf: { name: 'TURF', sub: 'Crew War!' },
    docks: { name: 'DOCKS', sub: 'Steal a crew' },
    roof: { name: 'ROOFTOPS', sub: 'Special event' },
    casino: { name: 'CASINO', sub: 'Double takeover' },
    ware: { name: 'WAREHOUSE', sub: 'Recruit' },
    train: { name: 'TRAIN STATION', sub: 'Extra roll' },
    club: { name: 'UNDERGROUND CLUB', sub: 'Dirty deal' }
  };

  var ROOF_EVENTS = [
    { id: 'pigeon', title: 'PIGEON HEIST', text: 'Trained pigeons snatch 1 chimp from every richer boss (max 3).' },
    { id: 'collapse', title: 'ROOF COLLAPSE', text: 'You fall into a stash! Take 2 from the vault. Heat +2.' },
    { id: 'sniper', title: 'SNIPER PIGEON', text: 'The richest boss drops 2 chimps into the vault.' },
    { id: 'banana', title: 'LUCKY BANANA', text: 'Slip! Roll your Dirty Die and move again.' },
    { id: 'taxman', title: 'THE TAX MAN', text: 'Every living boss pays 1 chimp into the vault.' },
    { id: 'wrongroof', title: 'WRONG ROOFTOP', text: 'You swap places with a random rival.' },
    { id: 'chopper', title: 'POLICE CHOPPER', text: 'Spotlight on you! Heat +3.' },
    { id: 'laundry', title: 'LAUNDRY LINE', text: 'Disguised as bedsheets. Your heat -3.' }
  ];

  var DEEDS = {
    grab: { name: 'GRAB', text: 'Take a fair share' },
    lift: { name: 'LIFT', text: 'Steal 2 from a rival' },
    frame: { name: 'FRAME', text: 'Heat +3 on a rival' },
    dcross: { name: 'DOUBLE-CROSS', text: 'Big score, big risk' }
  };
  var ROUTES = {
    floor: { name: 'FLOOR IT', text: '+3 to escape. Caught = 2 bail', bonus: 3, bail: 2 },
    alley: { name: 'BACK ALLEYS', text: 'Normal escape. Caught = 1 bail', bonus: 0, bail: 1 },
    low: { name: 'LAY LOW', text: 'Always escape, drop half loot', bonus: 0, bail: 0 }
  };
  var GHOST_POWERS = {
    insidejob: { name: 'INSIDE JOB', text: 'Vault security -1', phase: 'vault', target: false },
    fakeid: { name: 'FAKE ID', text: 'Heat +3 on a boss before the getaway', phase: 'getaway', target: true },
    phantom: { name: 'PHANTOM FINGERS', text: '2 loot slips from a boss back into the vault', phase: 'deeds', target: true },
    smoke: { name: 'SMOKE BOMB', text: 'A boss is immune to wars & steals this round', phase: 'move', target: true },
    ghostgetaway: { name: 'GHOST GETAWAY', text: '+3 to a boss\'s escape roll', phase: 'getaway', target: true }
  };
  /* RoshamboMoWo die (established mapping): 1 Rock 2 Paper 3 Monkey 4 Scissors 5 Ghost 6 Wild */
  var RPS = ['', 'ROCK', 'PAPER', 'MONKEY', 'SCISSORS', 'GHOST', 'WILD'];
  var RPS_RING = [1, 4, 2, 3, 5]; /* Rock, Scissors, Paper, Monkey, Ghost: each beats next and 3rd-next */
  var RPS_VERB = {
    '1-4': 'ROCK SMASHES SCISSORS', '1-3': 'ROCK BONKS MONKEY', '4-2': 'SCISSORS CUT PAPER', '4-5': 'SCISSORS SNIP GHOST',
    '2-3': 'PAPER WRAPS MONKEY', '2-1': 'PAPER COVERS ROCK', '3-5': 'MONKEY SPOOKS GHOST', '3-4': 'MONKEY STEALS SCISSORS',
    '5-1': 'GHOST PASSES THROUGH ROCK', '5-2': 'GHOST BLOWS AWAY PAPER'
  };

  function rng(state) {
    /* mulberry32 on state.seed */
    state.seed = (state.seed + 0x6D2B79F5) >>> 0;
    var t = state.seed;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }
  function rint(S, n) { return Math.floor(rng(S) * n); }
  function dieVal(roll) { return roll === 0 ? 10 : roll; } /* D10 face 0 counts as 10 */
  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }

  function newGame(opts) {
    opts = opts || {};
    var S = {
      v: 1,
      seed: (opts.seed >>> 0) || 12345,
      warDice: opts.warDice === 'd10' ? 'd10' : 'rps',
      round: 0,
      vault: 0,
      claimed: 0,
      alarm: 0,
      target: null,
      players: [],
      log: [],
      ledger: [],
      over: false,
      history: []
    };
    for (var i = 0; i < 6; i++) {
      var sd = (opts.seats && opts.seats[i]) || {};
      S.players.push({
        seat: i + 1, ix: i, color: COLORS[i], hex: HEX[COLORS[i]], name: NAMES[i], short: SHORT[i],
        active: !!sd.active, cpu: !!sd.cpu,
        chimps: sd.active ? CFG.startChimps : 0,
        ghost: false, ghostRound: 0, pos: 0, heat: 0,
        approach: null, digits: null, number: null, dist: null,
        protect: false, moves: 0,
        deed: null, deedTarget: null, deedRoll: null, hot: 0,
        route: null, escRoll: null, escaped: null,
        plan: null, charge: 0,
        stats: { numWins: 0, exact: 0, warsWon: 0, warsLost: 0, stolen: 0, lost: 0, betrayed: [], caught: 0, escaped: 0, loot: 0, dcross: 0, worst: null }
      });
    }
    return S;
  }

  function P(S, seat) { return S.players[seat - 1]; }
  function living(S) { return S.players.filter(function (p) { return p.active && !p.ghost; }); }
  function ghosts(S) { return S.players.filter(function (p) { return p.active && p.ghost; }); }
  function actives(S) { return S.players.filter(function (p) { return p.active; }); }
  function total(S) { var t = S.vault; S.players.forEach(function (p) { t += p.chimps; }); return t; }

  function note(S, p, n, why) {
    if (!p || n <= 0) return;
    p.stats.lost += n;
    if (!p.stats.worst || n > p.stats.worst.n) p.stats.worst = { n: n, why: why, round: S.round };
  }

  /* move chimps; from/to are seats or 'vault'. Returns the amount actually moved. */
  function transfer(S, from, to, n, why) {
    if (n <= 0 || from === to) return 0;
    var have = from === 'vault' ? S.vault - S.claimed : P(S, from).chimps;
    n = Math.max(0, Math.min(n, have));
    if (!n) return 0;
    if (from === 'vault') S.vault -= n; else P(S, from).chimps -= n;
    if (to === 'vault') S.vault += n; else P(S, to).chimps += n;
    S.ledger.push({ from: from, to: to, n: n, why: why });
    if (from !== 'vault') note(S, P(S, from), n, why);
    if (to !== 'vault' && from !== 'vault') P(S, to).stats.stolen += n;
    return n;
  }
  function addHeat(p, n) { p.heat = clamp(p.heat + n, 0, CFG.heatMax); }

  /* ---------------- ROUND START ---------------- */
  function startRound(S) {
    S.round++;
    S.ledger = [];
    S.claimed = 0;
    S.alarm = clamp(S.round - 1, 0, 10);
    var d1 = 1 + rint(S, 9), d2 = rint(S, 10), d3 = rint(S, 10);
    S.target = d1 * 100 + d2 * 10 + d3;
    S.players.forEach(function (p) {
      p.approach = null; p.digits = null; p.number = null; p.dist = null; p.protect = false; p.moves = 0;
      p.deed = null; p.deedTarget = null; p.deedRoll = null; p.hot = 0; p.route = null; p.escRoll = null; p.escaped = null;
      p.plan = null;
      if (p.active && p.ghost) p.charge = 1;
    });
    var ante = [];
    living(S).forEach(function (p) { var n = transfer(S, p.seat, 'vault', CFG.ante, 'ante'); ante.push({ seat: p.seat, n: n }); });
    return { round: S.round, target: S.target, ante: ante, vault: S.vault };
  }

  function setApproach(S, seat, a) {
    var p = P(S, seat);
    if (!p.active || p.ghost || !CFG.approach[a]) return false;
    p.approach = a; return true;
  }
  function setGhostPlan(S, seat, plan) {
    var p = P(S, seat);
    if (!p.active || !p.ghost) return false;
    if (!plan || plan.power === 'pass') { p.plan = { power: 'pass' }; return true; }
    var g = GHOST_POWERS[plan.power];
    if (!g || p.charge < 1) return false;
    if (g.target) {
      var t = P(S, plan.target | 0);
      if (!t || !t.active || t.ghost) return false;
    }
    p.plan = { power: plan.power, target: g.target ? plan.target | 0 : null };
    return true;
  }
  function validDigits(d) {
    return d && d.length === 3 && d.every(function (x) { return x === (x | 0) && x >= 0 && x <= 9; });
  }
  function setNumber(S, seat, digits) {
    var p = P(S, seat);
    if (!p.active || !validDigits(digits)) return false;
    p.digits = digits.slice(); p.number = digits[0] * 100 + digits[1] * 10 + digits[2];
    p.dist = Math.abs(p.number - S.target);
    return true;
  }
  function successes(S, p) {
    if (!p.digits || !p.approach) return 0;
    var min = CFG.approach[p.approach].min;
    return p.digits.filter(function (d) { return dieVal(d) >= min; }).length;
  }

  /* ---------------- THE NUMBERS ----------------
     closest to the target (over OR under) wins. Exact hit = 3 Roll & Move turns.
     Farthest living boss pays 1 chimp to the winner. A ghost closer than every living boss
     "takes the action": the payment goes into the vault instead. */
  function numbersStandings(S) {
    var L = living(S).slice().sort(function (a, b) { return a.dist - b.dist || a.seat - b.seat; });
    var best = L.length ? L[0].dist : 0;
    return { order: L, tied: L.filter(function (p) { return p.dist === best; }).map(function (p) { return p.seat; }) };
  }
  function resolveNumbers(S, winnerSeat) {
    var st = numbersStandings(S);
    var L = st.order;
    var winner = winnerSeat && st.tied.indexOf(winnerSeat) >= 0 ? winnerSeat : st.tied[0];
    var W = P(S, winner);
    W.stats.numWins++;
    /* move order: winner first then by distance */
    var order = [winner].concat(L.filter(function (p) { return p.seat !== winner; }).map(function (p) { return p.seat; }));
    L.forEach(function (p) {
      p.moves = p.dist === 0 ? CFG.exactMoves : 1;
      if (p.dist === 0) p.stats.exact++;
    });
    var worstD = L.length ? L[L.length - 1].dist : 0;
    var payers = L.filter(function (p) { return p.dist === worstD && p.seat !== winner; }).map(function (p) { return p.seat; });
    var ghostBeat = null;
    ghosts(S).forEach(function (g) {
      if (g.number !== null && g.dist < W.dist && (ghostBeat === null || g.dist < P(S, ghostBeat).dist)) ghostBeat = g.seat;
    });
    var pays = [];
    payers.forEach(function (s) {
      var to = ghostBeat ? 'vault' : winner;
      var n = transfer(S, s, to, 1, ghostBeat ? 'numbers (ghost took the action)' : 'worst number');
      pays.push({ from: s, to: to, n: n });
    });
    var ghostExact = ghosts(S).filter(function (g) { return g.dist === 0; }).map(function (g) { return g.seat; });
    return { target: S.target, winner: winner, order: order, rows: L.map(function (p) { return { seat: p.seat, number: p.number, dist: p.dist, exact: p.dist === 0 }; }),
      ghostRows: ghosts(S).filter(function (g) { return g.number !== null; }).map(function (g) { return { seat: g.seat, number: g.number, dist: g.dist }; }),
      payers: payers, pays: pays, ghostBeat: ghostBeat, ghostExact: ghostExact };
  }

  /* ---------------- BOARD ---------------- */
  function step(S, seat, roll) {
    var p = P(S, seat);
    var n = dieVal(roll);
    var path = [];
    for (var i = 0; i < n; i++) { p.pos = (p.pos + 1) % BOARD.length; path.push(p.pos); }
    return { from: (p.pos - n + BOARD.length * 2) % BOARD.length, path: path, pos: p.pos, space: BOARD[p.pos] };
  }
  function immune(S, seat) {
    var p = P(S, seat);
    if (p.protect) return true;
    return ghosts(S).some(function (g) { return g.plan && g.plan.power === 'smoke' && g.plan.target === seat; });
  }
  /* what landing means; returns {kind:...} for the director */
  function landing(S, seat) {
    var p = P(S, seat), sp = BOARD[p.pos];
    if (sp.t === 'turf') {
      var owner = S.players[sp.c];
      if (owner.seat === seat) return { kind: 'home' };
      if (!owner.active) return { kind: 'abandoned', owner: owner.seat };
      if (owner.ghost) return { kind: 'haunted', owner: owner.seat };
      if (immune(S, owner.seat)) return { kind: 'hiding', owner: owner.seat };
      return { kind: 'war', owner: owner.seat };
    }
    return { kind: sp.t };
  }
  function targetsFor(S, seat, needChimps) {
    return living(S).filter(function (q) { return q.seat !== seat && !immune(S, q.seat) && (!needChimps || q.chimps > 0); }).map(function (q) { return q.seat; });
  }
  function applySimple(S, seat, kind) {
    var p = P(S, seat), out = { kind: kind, text: '' };
    if (kind === 'home') { var n = transfer(S, 'vault', seat, 1, 'home turf'); addHeat(p, -1); out.text = 'HOME TURF! +' + n + ' from the vault, heat -1'; out.gain = n; }
    else if (kind === 'abandoned') { var a = transfer(S, 'vault', seat, 1, 'abandoned turf'); out.text = 'ABANDONED TURF! +' + a + ' from the vault'; out.gain = a; }
    else if (kind === 'haunted') { addHeat(p, 1); out.text = 'HAUNTED TURF! The ghost spooks you. Heat +1'; }
    else if (kind === 'hiding') { out.text = 'They\'re hiding! No war today.'; }
    else if (kind === 'safe') { p.protect = true; addHeat(p, -2); out.text = 'SAFE HOUSE! Protected this round, heat -2'; }
    else if (kind === 'ware') {
      var rich = living(S).filter(function (q) { return q.seat !== seat && !immune(S, q.seat); }).sort(function (a, b) { return b.chimps - a.chimps || a.seat - b.seat; })[0];
      if (rich) { var r = transfer(S, rich.seat, seat, 1, 'recruited by ' + p.short); out.text = 'RECRUIT! 1 chimp jumps from ' + rich.short + ' to your crew'; out.from = rich.seat; out.gain = r; }
      else out.text = 'Nobody to recruit.';
    }
    return out;
  }
  function applyRoof(S, seat) {
    var ev = ROOF_EVENTS[rint(S, ROOF_EVENTS.length)];
    var p = P(S, seat), out = { kind: 'roof', ev: ev, moves: [] };
    if (ev.id === 'pigeon') {
      var c = 0;
      living(S).filter(function (q) { return q.seat !== seat && q.chimps > p.chimps && !immune(S, q.seat); })
        .sort(function (a, b) { return b.chimps - a.chimps; }).forEach(function (q) {
          if (c < 3) { c += transfer(S, q.seat, seat, 1, 'pigeon heist'); out.moves.push(q.seat); }
        });
    } else if (ev.id === 'collapse') { transfer(S, 'vault', seat, 2, 'roof collapse'); addHeat(p, 2); }
    else if (ev.id === 'sniper') {
      var r = living(S).slice().sort(function (a, b) { return b.chimps - a.chimps || a.seat - b.seat; })[0];
      if (r) { transfer(S, r.seat, 'vault', 2, 'sniper pigeon'); out.victim = r.seat; }
    } else if (ev.id === 'banana') { out.again = true; }
    else if (ev.id === 'taxman') { living(S).forEach(function (q) { transfer(S, q.seat, 'vault', 1, 'tax man'); }); }
    else if (ev.id === 'wrongroof') {
      var rv = living(S).filter(function (q) { return q.seat !== seat; });
      if (rv.length) { var o = rv[rint(S, rv.length)]; var tp = o.pos; o.pos = p.pos; p.pos = tp; out.swap = o.seat; }
    } else if (ev.id === 'chopper') addHeat(p, 3);
    else if (ev.id === 'laundry') addHeat(p, -3);
    return out;
  }
  function applyDocks(S, seat, target, roll) {
    var p = P(S, seat), v = dieVal(roll);
    if (v >= 6) { var n = transfer(S, target, seat, 2, 'docks steal by ' + p.short); return { ok: true, n: n, roll: v }; }
    var m = transfer(S, seat, target, 1, 'botched docks job'); addHeat(p, 1);
    return { ok: false, n: m, roll: v };
  }
  function applyClub(S, seat, target) {
    addHeat(P(S, seat), -2); addHeat(P(S, target), 2);
    P(S, seat).stats.betrayed.push({ who: target, how: 'dirty deal' });
    return { target: target };
  }
  function casinoCashOut(S, seat) { return transfer(S, 'vault', seat, 2, 'casino cash out'); }

  /* ---------------- CREW WAR ---------------- */
  function newWar(S, attacker, defender, stake) {
    var D = P(S, defender);
    var last = D.chimps <= CFG.lastCrew;
    return { a: attacker, d: defender, stake: last ? D.chimps : stake, last: last, need: last ? 2 : 1, aw: 0, dw: 0, rounds: [], done: false, winner: null };
  }
  function rpsBeats(x, y) {
    if (x === 6 && y !== 6) return true;
    if (x === 6 || y === 6) return false;
    var i = RPS_RING.indexOf(x), j = RPS_RING.indexOf(y);
    return j === (i + 1) % 5 || j === (i + 3) % 5;
  }
  function warRoll(S, war, af, df) {
    var r;
    if (S.warDice === 'd10') {
      var a = dieVal(af), d = dieVal(df);
      r = a > d ? 'a' : d > a ? 'd' : 'tie';
    } else {
      r = af === df ? 'tie' : rpsBeats(af, df) ? 'a' : rpsBeats(df, af) ? 'd' : 'tie';
    }
    var verb = '';
    if (S.warDice === 'rps' && r !== 'tie') {
      var w = r === 'a' ? af : df, l = r === 'a' ? df : af;
      verb = w === 6 ? 'WILD CARD WINS!' : (RPS_VERB[w + '-' + l] || '');
    }
    war.rounds.push({ af: af, df: df, r: r, verb: verb });
    if (r === 'a') war.aw++; else if (r === 'd') war.dw++;
    if (war.aw >= war.need || war.dw >= war.need) {
      war.done = true; war.winner = war.aw >= war.need ? 'a' : 'd';
    }
    return r;
  }
  function finishWar(S, war, why) {
    var A = P(S, war.a), D = P(S, war.d), n;
    if (war.winner === 'a') { n = transfer(S, war.d, war.a, war.stake, (why || 'crew takeover') + ' by ' + A.short); A.stats.warsWon++; D.stats.warsLost++; }
    else { n = transfer(S, war.a, war.d, war.stake, 'counterattack by ' + D.short); D.stats.warsWon++; A.stats.warsLost++; }
    war.moved = n;
    return n;
  }

  /* ---------------- THE VAULT ---------------- */
  function security(S) {
    var sec = Math.ceil(living(S).length * 1.3);
    ghosts(S).forEach(function (g) { if (g.plan && g.plan.power === 'insidejob') sec--; });
    return Math.max(1, sec);
  }
  function crack(S) {
    var rows = [], tot = 0;
    living(S).forEach(function (p) {
      var s = successes(S, p); tot += s;
      var a = CFG.approach[p.approach] || {};
      if (a.heat) addHeat(p, a.heat < 0 && s === 0 ? 0 : a.heat);
      if (a.alarm && s > 0) S.alarm = clamp(S.alarm + a.alarm, 0, 10);
      rows.push({ seat: p.seat, approach: p.approach, digits: p.digits, s: s, min: a.min });
    });
    var sec = security(S);
    var inside = ghosts(S).filter(function (g) { return g.plan && g.plan.power === 'insidejob'; }).map(function (g) { return g.seat; });
    var ok = tot >= sec;
    if (!ok) { S.alarm = clamp(S.alarm + 2, 0, 10); living(S).forEach(function (p) { addHeat(p, 1); }); }
    return { rows: rows, total: tot, security: sec, ok: ok, inside: inside, vault: S.vault };
  }

  /* ---------------- DIRTY DEEDS ---------------- */
  function setDeed(S, seat, deed, target) {
    var p = P(S, seat);
    if (!p.active || p.ghost || !DEEDS[deed]) return false;
    if (deed === 'lift' || deed === 'frame') {
      if (targetsFor(S, seat).indexOf(target | 0) < 0) return false;
      p.deedTarget = target | 0;
    } else p.deedTarget = null;
    p.deed = deed; return true;
  }
  function setDeedRoll(S, seat, roll) {
    var p = P(S, seat);
    if (roll !== (roll | 0) || roll < 0 || roll > 9) return false;
    p.deedRoll = roll; return true;
  }
  function resolveDeeds(S) {
    var L = living(S);
    var share = S.vault > 0 ? Math.max(1, Math.floor(S.vault / L.length)) : 0;
    var steps = [];
    function eff(p) { return dieVal(p.deedRoll) + (p.approach === 'swindle' ? CFG.approach.swindle.deedBonus : 0); }
    var ord = L.slice().sort(function (a, b) { return eff(b) - eff(a) || (a.approach === 'swindle' ? -1 : 0) - (b.approach === 'swindle' ? -1 : 0) || a.seat - b.seat; });
    function claim(p, n) { n = Math.max(0, Math.min(n, S.vault - S.claimed)); p.hot += n; S.claimed += n; return n; }
    /* pass 1: grabs + double-crosses (highest roll first) */
    ord.forEach(function (p) {
      var r = eff(p), st = { seat: p.seat, deed: p.deed, roll: p.deedRoll, eff: r, target: p.deedTarget };
      if (p.deed === 'grab') {
        if (r >= 3) { st.ok = true; st.n = claim(p, share); st.text = 'GRABS ' + st.n; }
        else { st.ok = false; st.n = claim(p, share - 1); addHeat(p, 1); st.text = 'FUMBLES! only ' + st.n + ', heat +1'; }
        steps.push(st);
      } else if (p.deed === 'dcross') {
        p.stats.dcross++;
        if (r >= 8) { st.ok = true; st.n = claim(p, share * 2 + 1); addHeat(p, 2); st.text = 'DOUBLE-CROSS! scores ' + st.n + ', heat +2'; }
        else { st.ok = false; st.n = 0; addHeat(p, 3); S.alarm = clamp(S.alarm + 2, 0, 10); st.text = 'CAUGHT BY THE CREW! 0 loot, heat +3, ALARM!'; }
        steps.push(st);
      }
    });
    /* pass 2: frames */
    ord.forEach(function (p) {
      if (p.deed !== 'frame') return;
      var r = eff(p), T = P(S, p.deedTarget), st = { seat: p.seat, deed: 'frame', roll: p.deedRoll, eff: r, target: p.deedTarget };
      st.n = claim(p, share - 1);
      if (r >= 4) { addHeat(T, 3); st.ok = true; st.text = 'FRAMES ' + T.short + '! heat +3 on them'; p.stats.betrayed.push({ who: T.seat, how: 'frame' }); }
      else { addHeat(p, 2); st.ok = false; st.text = 'FRAME BACKFIRES! heat +2'; }
      steps.push(st);
    });
    /* pass 3: lifts (take from the target's loot first, then their stash) */
    ord.forEach(function (p) {
      if (p.deed !== 'lift') return;
      var r = eff(p), T = P(S, p.deedTarget), st = { seat: p.seat, deed: 'lift', roll: p.deedRoll, eff: r, target: p.deedTarget };
      if (r >= 6) {
        var fromHot = Math.min(2, T.hot); T.hot -= fromHot; p.hot += fromHot;
        var rest = transfer(S, T.seat, p.seat, 2 - fromHot, 'lifted by ' + p.short);
        if (fromHot) note(S, T, fromHot, 'loot lifted by ' + p.short);
        st.ok = true; st.n = fromHot + rest; st.text = 'LIFTS ' + st.n + ' from ' + T.short + '!';
        p.stats.betrayed.push({ who: T.seat, how: 'lift' });
      } else {
        var m = transfer(S, p.seat, T.seat, 1, 'caught lifting'); addHeat(p, 2);
        st.ok = false; st.n = m; st.text = 'CAUGHT RED-HANDED! pays ' + m + ' to ' + T.short + ', heat +2';
      }
      steps.push(st);
    });
    /* ghost: phantom fingers */
    ghosts(S).forEach(function (g) {
      if (!g.plan || g.plan.power !== 'phantom') return;
      var T = P(S, g.plan.target), n = Math.min(2, T.hot);
      T.hot -= n; S.claimed -= n;
      steps.push({ seat: g.seat, ghost: true, power: 'phantom', target: T.seat, n: n, text: 'PHANTOM FINGERS! ' + n + ' loot slips out of ' + T.short + '\'s bag' });
    });
    return { share: share, steps: steps, vault: S.vault };
  }

  /* ---------------- GETAWAY ---------------- */
  function setRoute(S, seat, r) {
    var p = P(S, seat);
    if (!p.active || p.ghost || !ROUTES[r]) return false;
    p.route = r; return true;
  }
  function setEscRoll(S, seat, roll) {
    var p = P(S, seat);
    if (roll !== (roll | 0) || roll < 0 || roll > 9) return false;
    p.escRoll = roll; return true;
  }
  function getawayNeed(S, p) { return clamp(2 + p.heat + Math.floor(S.alarm / 2), 2, 14); }
  function applyGetawayGhosts(S) {
    var fx = [];
    ghosts(S).forEach(function (g) {
      if (g.plan && g.plan.power === 'fakeid') { addHeat(P(S, g.plan.target), 3); fx.push({ seat: g.seat, power: 'fakeid', target: g.plan.target }); }
      if (g.plan && g.plan.power === 'ghostgetaway') fx.push({ seat: g.seat, power: 'ghostgetaway', target: g.plan.target });
    });
    return fx;
  }
  function resolveGetaway(S) {
    var rows = [];
    living(S).forEach(function (p) {
      var R = ROUTES[p.route] || ROUTES.alley;
      var help = ghosts(S).filter(function (g) { return g.plan && g.plan.power === 'ghostgetaway' && g.plan.target === p.seat; }).length * 3;
      var need = getawayNeed(S, p);
      var row = { seat: p.seat, route: p.route, need: need, hot: p.hot, help: help };
      if (p.route === 'low') {
        var drop = Math.floor(p.hot / 2);
        p.hot -= drop; S.claimed -= drop;
        row.esc = true; row.drop = drop; row.total = null;
        addHeat(p, -2);
      } else {
        var tot = dieVal(p.escRoll) + R.bonus + help;
        row.roll = p.escRoll; row.total = tot; row.esc = tot >= need;
      }
      rows.push(row);
    });
    rows.forEach(function (row) {
      var p = P(S, row.seat);
      S.claimed -= p.hot;
      if (row.esc) {
        row.got = transfer(S, 'vault', p.seat, p.hot, 'escaped with the loot');
        p.stats.loot += row.got; p.stats.escaped++; p.escaped = true;
        addHeat(p, -1);
      } else {
        var R = ROUTES[p.route] || ROUTES.alley;
        row.dropped = p.hot;
        if (p.hot) note(S, p, p.hot, 'busted in the getaway (dropped the loot)');
        row.bail = transfer(S, p.seat, 'vault', R.bail, 'bail');
        p.stats.caught++; p.escaped = false; p.heat = 0;
      }
      p.hot = 0;
    });
    S.claimed = 0;
    return { rows: rows, vault: S.vault };
  }

  /* ---------------- ROUND END ---------------- */
  function roundEnd(S) {
    var L = living(S);
    var res = { round: S.round, standings: actives(S).map(function (p) { return { seat: p.seat, chimps: p.chimps, ghost: p.ghost }; }) };
    ghosts(S).forEach(function (g) { g.charge = 0; });
    if (S.round >= CFG.rounds) { res.final = true; return res; }
    if (L.length <= 2) { res.none = true; return res; }
    var min = Math.min.apply(null, L.map(function (p) { return p.chimps; }));
    res.tied = L.filter(function (p) { return p.chimps === min; }).map(function (p) { return p.seat; });
    return res;
  }
  function eliminate(S, seat) {
    var p = P(S, seat);
    p.ghost = true; p.ghostRound = S.round; p.protect = false; p.hot = 0;
    return p;
  }

  /* ---------------- FINAL ---------------- */
  var TITLES = {
    lift: ['THE FIVE-FINGER FRAUDSTER', 'KING OF THE CLEAN LIFT'],
    war: ['THE TURF TYRANT', 'BOSS OF ALL BOSSES'],
    numbers: ['THE NUMBERS PROPHET', 'MAYOR OF THE RACKET'],
    loot: ['THE BANANA BARON', 'VAULT VACUUM'],
    dcross: ['THE DOUBLE-DEALING DUKE', 'TWO-FACED TYCOON'],
    clean: ['THE UNTOUCHABLE', 'TEFLON CHIMP'],
    def: ['GODFATHER OF GRAND LARCENY']
  };
  function finalResults(S, tieWinner) {
    var L = living(S).slice().sort(function (a, b) { return b.chimps - a.chimps || a.seat - b.seat; });
    var top = L.length ? L[0].chimps : 0;
    var tied = L.filter(function (p) { return p.chimps === top; }).map(function (p) { return p.seat; });
    var w = tieWinner && tied.indexOf(tieWinner) >= 0 ? tieWinner : tied[0];
    var W = P(S, w), st = W.stats, key = 'def', best = 0;
    var lifts = st.betrayed.filter(function (b) { return b.how === 'lift'; }).length;
    [['lift', lifts * 2], ['war', st.warsWon * 2], ['numbers', st.numWins * 2 + st.exact * 3], ['loot', st.loot / 2], ['dcross', st.dcross * 2],
      ['clean', st.caught === 0 && st.escaped >= 3 ? 5 : 0]].forEach(function (k) { if (k[1] > best) { best = k[1]; key = k[0]; } });
    var t = TITLES[key][S.seed % TITLES[key].length];
    var disaster = null;
    actives(S).forEach(function (p) { if (p.stats.worst && (!disaster || p.stats.worst.n > disaster.n)) disaster = { seat: p.seat, n: p.stats.worst.n, why: p.stats.worst.why, round: p.stats.worst.round }; });
    var betrayals = [];
    actives(S).forEach(function (p) { p.stats.betrayed.forEach(function (b) { betrayals.push({ from: p.seat, to: b.who, how: b.how }); }); });
    return {
      winner: w, tied: tied, title: t,
      ranking: actives(S).slice().sort(function (a, b) { return (a.ghost - b.ghost) || b.chimps - a.chimps || (b.ghostRound - a.ghostRound); }).map(function (p) {
        return { seat: p.seat, chimps: p.chimps, ghost: p.ghost, ghostRound: p.ghostRound, escaped: p.stats.escaped, caught: p.stats.caught };
      }),
      disaster: disaster, betrayals: betrayals
    };
  }

  /* simple CPU brain (test seats / filling empty chairs) */
  function cpu(S, seat, ask, R) {
    R = R || Math.random;
    var p = P(S, seat);
    function pick(a) { return a[Math.floor(R() * a.length)]; }
    function d10() { return Math.floor(R() * 10); }
    switch (ask.kind) {
      case 'approach': return pick(['sneak', 'hack', 'smash', 'swindle']);
      case 'digits': {
        var d = [d10(), d10(), d10()];
        /* try all 6 orders, choose closest */
        var perms = [[0, 1, 2], [0, 2, 1], [1, 0, 2], [1, 2, 0], [2, 0, 1], [2, 1, 0]], best = null;
        perms.forEach(function (o) { var v = d[o[0]] * 100 + d[o[1]] * 10 + d[o[2]]; var x = Math.abs(v - S.target); if (!best || x < best.x) best = { x: x, o: o }; });
        return [d[best.o[0]], d[best.o[1]], d[best.o[2]]];
      }
      case 'die': return d10();
      case 'rps': return 1 + Math.floor(R() * 6);
      case 'target': return pick(ask.options).id;
      case 'pick': return pick(ask.options.filter(function (o) { return !o.disabled; })).id;
      case 'deed': {
        var tg = targetsFor(S, seat);
        var dd = pick(tg.length ? ['grab', 'grab', 'lift', 'frame', 'dcross'] : ['grab', 'dcross']);
        return { deed: dd, target: (dd === 'lift' || dd === 'frame') ? pick(tg) : null };
      }
      case 'route': return pick(p.heat > 5 ? ['low', 'floor', 'alley'] : ['floor', 'alley', 'alley', 'low']);
      case 'ghost': {
        var L = living(S).map(function (q) { return q.seat; });
        var pw = pick(['insidejob', 'fakeid', 'phantom', 'smoke', 'ghostgetaway', 'pass']);
        return { power: pw, target: GHOST_POWERS[pw] && GHOST_POWERS[pw].target ? pick(L) : null };
      }
      case 'ready': return true;
    }
    return null;
  }

  var DD = {
    COLORS: COLORS, HEX: HEX, NAMES: NAMES, SHORT: SHORT, CFG: CFG, BOARD: BOARD, SPACE_INFO: SPACE_INFO,
    ROOF_EVENTS: ROOF_EVENTS, DEEDS: DEEDS, ROUTES: ROUTES, GHOST_POWERS: GHOST_POWERS, RPS: RPS,
    newGame: newGame, P: P, living: living, ghosts: ghosts, actives: actives, total: total, dieVal: dieVal,
    startRound: startRound, setApproach: setApproach, setGhostPlan: setGhostPlan, setNumber: setNumber, validDigits: validDigits,
    successes: successes, numbersStandings: numbersStandings, resolveNumbers: resolveNumbers,
    step: step, landing: landing, immune: immune, targetsFor: targetsFor, applySimple: applySimple, applyRoof: applyRoof,
    applyDocks: applyDocks, applyClub: applyClub, casinoCashOut: casinoCashOut,
    newWar: newWar, warRoll: warRoll, finishWar: finishWar, rpsBeats: rpsBeats,
    security: security, crack: crack, setDeed: setDeed, setDeedRoll: setDeedRoll, resolveDeeds: resolveDeeds,
    setRoute: setRoute, setEscRoll: setEscRoll, getawayNeed: getawayNeed, applyGetawayGhosts: applyGetawayGhosts, resolveGetaway: resolveGetaway,
    roundEnd: roundEnd, eliminate: eliminate, finalResults: finalResults, cpu: cpu, rng: rng
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = DD; else root.DD = DD;
})(this);

