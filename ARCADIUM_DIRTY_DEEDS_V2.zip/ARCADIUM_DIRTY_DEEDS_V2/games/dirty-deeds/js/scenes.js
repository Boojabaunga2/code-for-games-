
/* DIRTY DEEDS big screen: every scene's drawing + the render loop. 720x720 logical. */
(function () {
  'use strict';
  var DD = window.DD, ctx = C.ctx, W = 720, H = 720;
  var k = C.k, E = C.ease, txt = C.txt, spr = C.spr;
  var COL = DD.COLORS, HEX = DD.HEX;
  var R = {};
  var VEH = { red: 'veh_car', blue: 'veh_van', green: 'veh_suv', yellow: 'veh_truck', pink: 'veh_moto', white: 'veh_car' };
  var APPROACH_ICON = { sneak: 'act_hide', hack: 'obj_keycard', smash: 'act_threaten', swindle: 'act_bribe' };
  var DEED_ICON = { grab: 'obj_stashbag', lift: 'act_stealcrew', frame: 'ui_target', dcross: 'act_betray' };
  function P(s) { return DD.P(G.S, s); }
  function once(d, key, fn) { if (!d['_' + key]) { d['_' + key] = true; fn(); } }
  function nameOf(s) { return DD.SHORT[s - 1]; }
  function sin(t, sp, a) { return Math.sin(t * sp) * a; }

  /* ---------------- shared backdrops ---------------- */
  function bgCity(t, dark) {
    C.cover('m_city', 0, 0, W, H, { zoom: 1.15, ax: 0.5 + Math.sin(t / 9000) * 0.4, ay: 0.4, filter: 'saturate(1.08)' });
    ctx.fillStyle = 'rgba(8,4,20,' + (dark === undefined ? 0.6 : dark) + ')'; ctx.fillRect(0, 0, W, H);
  }
  function bgNoir(c1, c2) {
    var g = ctx.createLinearGradient(0, 0, 0, H); g.addColorStop(0, c1 || '#1a0b2e'); g.addColorStop(1, c2 || '#05020c');
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
  }
  function plateX(i) { return 3 + i * 119; }
  function plateCenter(seat) { return { x: plateX(seat - 1) + 58, y: 684 }; }
  G.plateCenter = plateCenter;
  var VAULT_POS = { x: 650, y: 23 };

  /* ---------------- HUD ---------------- */
  function hudTop(t) {
    var S = G.S; if (!S) return;
    ctx.fillStyle = 'rgba(6,3,14,0.82)'; ctx.fillRect(0, 0, W, 46);
    ctx.fillStyle = '#ffd21f'; ctx.fillRect(0, 46, W, 3);
    C.panel(6, 6, 116, 34, { fill: '#c41020', r: 8, lw: 3 });
    txt('ROUND ' + S.round + '/' + DD.CFG.rounds, 64, 24, { size: 22 });
    txt(G.banner, 360, 24, { size: 28, maxW: 400, fill: '#ffd21f' });
    /* vault */
    spr('obj_safe', 606, 23, 34);
    txt(String(S.vault), 650, 24, { size: 28, align: 'left' });
    /* alarm */
    var al = S.alarm / 10;
    spr('act_heat', 700, 23, 30, { alpha: 0.5 + al * 0.5 });
    if (al > 0.3) { ctx.save(); ctx.globalAlpha = 0.15 + 0.15 * Math.sin(t / 120); ctx.fillStyle = '#ff0020'; ctx.fillRect(686, 4, 30, 38); ctx.restore(); }
  }
  function plates(t) {
    var S = G.S; if (!S) return;
    ctx.fillStyle = 'rgba(6,3,14,0.85)'; ctx.fillRect(0, 648, W, 72);
    for (var i = 0; i < 6; i++) {
      var p = S.players[i], x = plateX(i), y = 651;
      if (!p.active) { C.panel(x, y, 116, 66, { fill: '#111', r: 8, lw: 2, alpha: 0.4 }); continue; }
      var focus = G.focus === p.seat;
      C.panel(x, y - (focus ? 4 : 0), 116, 66, { grad: [p.ghost ? '#2a3440' : shade(p.hex, 0.55), '#0a0610'], r: 8, lw: 3, glow: focus ? p.hex : null, stroke: focus ? '#fff' : '#000' });
      ctx.save();
      C.rr(x + 5, y + 5 - (focus ? 4 : 0), 52, 56, 6); ctx.clip();
      C.cover('face_' + p.color, x + 5, y + 5 - (focus ? 4 : 0), 52, 56, { filter: p.ghost ? 'grayscale(1) brightness(1.3)' : '' });
      ctx.restore();
      txt(p.short, x + 87, y + 15, { size: 17, maxW: 56 });
      if (p.ghost) {
        spr('act_ghostpower', x + 87, y + 42, 32, { alpha: 0.8 + sin(t, 0.004, 0.2) });
      } else {
        spr('chimp_' + p.color, x + 72, y + 40, 26);
        txt(String(p.chimps), x + 97, y + 41, { size: 24 });
        /* heat bar */
        ctx.fillStyle = '#000'; ctx.fillRect(x + 60, y + 57, 52, 5);
        ctx.fillStyle = p.heat > 6 ? '#ff2b3a' : p.heat > 3 ? '#ff9a1f' : '#ffd21f'; ctx.fillRect(x + 60, y + 57, 52 * p.heat / 10, 5);
      }
      /* status badge */
      var bx = x + 102, by = y - 4;
      if (G.Q[p.seat]) { badge(bx, by, '#3a3a3a', dots(t)); }
      else if (G.done[p.seat]) { badge(bx, by, '#1aa83a', 'OK'); }
      if (!G.online(p.seat)) badge(x + 10, by, '#c41020', 'OFF');
      else if (G.isCpu(p.seat)) badge(x + 14, by, '#555', 'CPU');
    }
  }
  function badge(x, y, col, s) {
    ctx.save(); C.rr(x - 16, y - 6, 32, 16, 6); ctx.fillStyle = col; ctx.fill(); ctx.lineWidth = 2; ctx.strokeStyle = '#000'; ctx.stroke(); ctx.restore();
    txt(s, x, y + 2, { size: 13, font: 'b', stroke: 0 });
  }
  function dots(t) { var n = Math.floor(t / 300) % 4; return '...'.slice(0, n) || ' '; }
  function shade(hex, f) {
    var n = parseInt(hex.slice(1), 16), r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
    return 'rgb(' + Math.round(r * f) + ',' + Math.round(g * f) + ',' + Math.round(b * f) + ')';
  }
  function face(s, x, y, size, o) {
    o = o || {};
    var p = P(s), col = HEX[COL[s - 1]];
    ctx.save();
    ctx.beginPath(); ctx.arc(x, y, size / 2 + 3, 0, 7); ctx.fillStyle = '#000'; ctx.fill();
    if (o.glow) { ctx.shadowColor = col; ctx.shadowBlur = 20; }
    ctx.beginPath(); ctx.arc(x, y, size / 2, 0, 7); ctx.fillStyle = col; ctx.fill(); ctx.shadowBlur = 0;
    ctx.beginPath(); ctx.arc(x, y, size / 2 - 3, 0, 7); ctx.clip();
    C.cover('face_' + COL[s - 1], x - size / 2, y - size / 2, size, size, { filter: (p && p.ghost) || o.gray ? 'grayscale(1) brightness(1.2)' : '' });
    ctx.restore();
  }
  G.face = face;

  /* chimp-move toasts: what to move physically */
  function toasts(t) {
    var list = G.toasts.filter(function (e) { return !e.silent; }).slice(-4), y = 58;
    list.forEach(function (e, i) {
      var age = C.now() - e.t0, a = Math.min(1, age / 250) * Math.min(1, (7000 - age) / 600);
      if (a <= 0) return;
      var x = W - 8 - 190 + (1 - E.out(Math.min(1, age / 300))) * 200;
      ctx.save(); ctx.globalAlpha = a;
      C.panel(x, y, 190, 40, { fill: e.text ? '#20123a' : '#fff4d6', r: 8, lw: 3 });
      if (e.text) txt(e.text, x + 95, y + 20, { size: 18, maxW: 176 });
      else {
        ep(e.from, x + 26, y + 20); C.arrow(x + 50, y + 20, x + 100, y + 20, '#ffd21f', 5, 0.001); ep(e.to, x + 124, y + 20);
        spr('chimp_' + chipCol(e), x + 158, y + 20, 26);
        txt('x' + e.n, x + 176, y + 21, { size: 20, fill: '#fff' });
      }
      ctx.restore();
      y += 46;
    });
  }
  function chipCol(e) { return e.from !== 'vault' ? COL[e.from - 1] : e.to !== 'vault' ? COL[e.to - 1] : 'yellow'; }
  function ep(who, x, y) { if (who === 'vault') spr('obj_safe', x, y, 30); else face(who, x, y, 30); }

  /* ================= SCENES ================= */
  R.boot = function (t, d) {
    C.cover('m_splash', 0, 0, W, H);
    ctx.fillStyle = 'rgba(0,0,0,0.6)'; ctx.fillRect(160, 676, 400, 14);
    ctx.fillStyle = '#e8e8e8'; ctx.fillRect(162, 678, 396 * (d.p || 0), 10);
  };

  R.title = function (t) {
    bgCity(t, 0.45);
    C.rays(360, 250, 520, t / 4000, 'rgba(255,40,60,0.10)', 18);
    var s = 1 + sin(t, 0.002, 0.02);
    ctx.save(); ctx.translate(360, 250); ctx.scale(s, s);
    C.cover('m_title', -300, -174, 600, 347);
    ctx.restore();
    for (var i = 0; i < 6; i++) {
      var x = 85 + i * 110, y = 500 + sin(t + i * 400, 0.003, 6);
      ctx.save(); ctx.beginPath(); ctx.arc(x, y, 46, 0, 7); ctx.fillStyle = HEX[COL[i]]; ctx.shadowColor = HEX[COL[i]]; ctx.shadowBlur = 24; ctx.fill(); ctx.restore();
      ctx.save(); ctx.beginPath(); ctx.arc(x, y, 42, 0, 7); ctx.clip(); C.cover('face_' + COL[i], x - 42, y - 42, 84, 84); ctx.restore();
      txt(DD.SHORT[i], x, y + 60, { size: 20, fill: HEX[COL[i]] });
    }
    if (Math.floor(t / 600) % 2) txt('PRESS ENTER OR TAP TO START', 360, 625, { size: 34, fill: '#ffd21f' });
    txt('SIX BOSSES  -  REAL DICE  -  REAL POKER CHIMPS  -  ONE DIRTY CITY', 360, 676, { size: 17, font: 'b', fill: '#ddd', stroke: 3 });
    if (Math.random() < 0.02) C.money(Math.random() * 720, -10, 3, 2);
  };

  R.lobby = function (t, d) {
    bgNoir('#220a12', '#06030c');
    C.rays(360, 360, 700, t / 9000, 'rgba(255,210,31,0.05)', 22);
    txt('PICK YOUR BOSS', 360, 36, { size: 44, grad: ['#fff4b0', '#ffb300'] });
    for (var i = 0; i < 6; i++) {
      var seat = i + 1, m = G.seats[seat].mode;
      var cx = 26 + (i % 3) * 228, cy = 70 + Math.floor(i / 3) * 278, w = 212, h = 264;
      var col = HEX[COL[i]];
      C.panel(cx, cy, w, h, { fill: '#000', r: 12, lw: 4, glow: m !== 'off' ? col : null, stroke: m !== 'off' ? col : '#333' });
      ctx.save(); C.rr(cx + 4, cy + 4, w - 8, h - 8, 9); ctx.clip();
      C.cover('m_card_' + COL[i], cx + 4, cy + 4, w - 8, h - 8, { ay: 0.2, filter: m === 'off' ? 'grayscale(1) brightness(0.35)' : '' });
      ctx.restore();
      /* status strip */
      var label, lc = '#fff', sub = '';
      if (m === 'off') { label = 'EMPTY SEAT'; lc = '#888'; sub = 'press ' + seat + ' to add'; }
      else if (m === 'cpu') { label = 'CPU BOSS'; lc = '#9fd7ff'; sub = 'press ' + seat + ' to remove'; }
      else if (G.done[seat]) { label = 'READY!'; lc = '#5dff8a'; sub = 'Player ' + seat; }
      else if (G.joined(seat)) { label = 'PRESS READY'; lc = '#ffd21f'; sub = 'on your Multi-Vibe'; }
      else { label = 'WAITING'; lc = '#ff9a9a'; sub = 'open PLAYER ' + seat + ' on a Multi-Vibe'; }
      ctx.fillStyle = 'rgba(0,0,0,0.78)'; ctx.fillRect(cx + 4, cy + h - 62, w - 8, 58);
      txt(label, cx + w / 2, cy + h - 42, { size: 28, fill: lc });
      txt(sub, cx + w / 2, cy + h - 16, { size: 15, font: 'b', stroke: 2, fill: '#ddd', maxW: w - 16 });
      badge(cx + 22, cy + 18, col === '#f2f2f2' ? '#777' : col, String(seat));
      (function (s) { G.hit(cx, cy, w, h - 70, function () { G.cycleSeat(s); }); })(seat);
      if (m === 'human' && (!G.tw[seat] || G.tw[seat].closed) && window.DD_VIBE_HTML) {
        C.panel(cx + w - 82, cy + 8, 74, 26, { fill: '#2f7bff', r: 6, lw: 2 });
        txt('TEST', cx + w - 45, cy + 22, { size: 17 });
        (function (s) { G.hit(cx + w - 82, cy + 8, 74, 26, function () { G.openTest(s); }); })(seat);
      }
    }
    var srv = G.srv.ok ? 'MULTI-VIBE SERVER CONNECTED' : 'MULTI-VIBE SERVER NOT FOUND (test windows still work)';
    txt(srv, 360, 640, { size: 16, font: 'b', fill: G.srv.ok ? '#5dff8a' : '#ff9a9a', stroke: 3 });
    txt('1-6 / TAP CARD: human, CPU, empty   -   T or TEST: open a test window   -   P pause', 360, 664, { size: 14, font: 'b', fill: '#bbb', stroke: 3 });
    if (d.canStart) {
      if (Math.floor(t / 500) % 2) txt('ALL SET! PRESS ENTER TO START', 360, 698, { size: 30, fill: '#5dff8a' });
    } else txt(d.count < 3 ? 'NEED AT LEAST 3 BOSSES' : 'WAITING FOR EVERY BOSS TO PRESS READY', 360, 698, { size: 24, fill: '#ffd21f' });
  };

  R.howto = function (t) {
    bgCity(t, 0.7);
    ctx.save(); ctx.translate(360, 345); ctx.rotate(-0.012);
    C.panel(-330, -310, 660, 610, { fill: '#f1e6c8', r: 4, lw: 5 });
    C.halftone(-325, -305, 650, 600, 0.06);
    txt('THE DIRTY DAILY', 0, -268, { size: 46, fill: '#111', stroke: 0, font: 'h' });
    ctx.fillStyle = '#111'; ctx.fillRect(-310, -238, 620, 4); ctx.fillRect(-310, -230, 620, 1);
    txt('HOW THE NUMBERS RACKET WORKS', 0, -210, { size: 22, font: 'b', fill: '#111', stroke: 0 });
    var steps = [
      ['act_hide', 'CASE THE JOINT', 'Secretly pick Sneak, Hack, Smash or Swindle on your Multi-Vibe.'],
      ['tool_c', 'PLAY THE NUMBERS', 'Roll 3 tool D10s. Closest to the paper\'s number wins (over or under). Exact = 3 moves!'],
      ['dirty_red', 'ROLL & MOVE', 'Roll your Dirty Die and move. Land on a rival\'s turf = CREW WAR!'],
      ['obj_safe', 'CRACK THE VAULT', 'Your 3 tool dice also crack the security. Enough cracks and it opens.'],
      ['act_betray', 'DIRTY DEEDS', 'Grab, Lift, Frame or Double-Cross. Then race the cops in THE GETAWAY.'],
      ['act_ghostpower', 'GHOST BOSSES', 'Lowest chimps each round becomes a ghost with powers. Most chimps after 5 rounds wins.']
    ];
    steps.forEach(function (s, i) {
      var y = -150 + i * 72;
      spr(s[0], -270, y, 52);
      txt(s[1], -228, y - 14, { size: 26, align: 'left', fill: '#c41020', stroke: 0 });
      C.wrap(s[2], -228, y + 16, 530, 18, { size: 16, font: 'b', fill: '#222', stroke: 0, align: 'left' });
    });
    ctx.restore();
    if (Math.floor(t / 600) % 2) txt('PRESS ENTER OR TAP', 360, 690, { size: 26, fill: '#ffd21f' });
  };

  R.intro = function (t, d) {
    bgCity(t, 0.55);
    var e = E.back(k(t, 0, 700));
    C.rays(360, 250, 600, t / 3000, 'rgba(255,210,31,0.10)');
    ctx.save(); ctx.translate(360, 230); ctx.scale(e, e); ctx.rotate(-0.06);
    C.burst(0, 0, 175, { fill: '#c41020', n: 16 });
    txt('ROUND', 0, -50, { size: 52 });
    txt(String(d.info.round), 0, 30, { size: 130, grad: ['#fff4b0', '#ffb300'] });
    ctx.restore();
    var a = k(t, 800, 1300);
    C.panel(90, 430, 540, 150, { fill: '#1c0f33', r: 14, alpha: a, glow: '#ffd21f' });
    txt('ANTE UP!', 360, 465, { size: 44, fill: '#ffd21f', alpha: a });
    txt('Every boss puts ' + DD.CFG.ante + ' Poker Chimps in the VAULT', 360, 510, { size: 22, font: 'b', alpha: a });
    txt('(the pile in the middle of the table)', 360, 540, { size: 17, font: 'b', fill: '#bbb', alpha: a, stroke: 3 });
    spr('obj_safe', 360, 610, 70 + sin(t, 0.01, 3));
    once(d, 'fly', function () {
      C.wait(1600).then(function () {
        d.info.ante.forEach(function (x, i) { var pc = plateCenter(x.seat); C.flyChimp(pc.x, pc.y, 360, 610, COL[x.seat - 1], i * 120); C.flyChimp(pc.x, pc.y, 360, 610, COL[x.seat - 1], i * 120 + 60); });
      });
    });
  };

  /* ---- CASE THE JOINT: casino exterior at night ---- */
  function casino(t) {
    var g = ctx.createLinearGradient(0, 0, 0, 450); g.addColorStop(0, '#05030f'); g.addColorStop(1, '#2a0d3d');
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, 450);
    C.cover('m_city', 0, 60, W, 300, { zoom: 1.6, ay: 0.1, alpha: 0.45, filter: 'blur(3px)' });
    /* searchlights */
    for (var s = 0; s < 2; s++) {
      var a = -Math.PI / 2 + Math.sin(t / 1400 + s * 2) * 0.6;
      ctx.save(); ctx.translate(s ? 560 : 160, 170); ctx.rotate(a);
      var lg = ctx.createLinearGradient(0, 0, 500, 0); lg.addColorStop(0, 'rgba(255,255,200,0.35)'); lg.addColorStop(1, 'rgba(255,255,200,0)');
      ctx.fillStyle = lg; ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(520, -50); ctx.lineTo(520, 50); ctx.closePath(); ctx.fill(); ctx.restore();
    }
    /* building */
    ctx.fillStyle = '#3b0b16'; ctx.fillRect(90, 160, 540, 300);
    ctx.fillStyle = '#5a1222'; for (var c = 0; c < 6; c++) ctx.fillRect(110 + c * 92, 250, 30, 210);
    ctx.fillStyle = '#d4a017'; ctx.fillRect(90, 240, 540, 8); ctx.fillRect(80, 150, 560, 14);
    /* windows */
    for (var wx = 0; wx < 5; wx++) for (var wy = 0; wy < 2; wy++) {
      var lit = ((wx * 7 + wy * 3 + Math.floor(t / 900)) % 5) !== 0;
      ctx.fillStyle = lit ? '#ffcf5a' : '#2a0a12'; ctx.fillRect(152 + wx * 92, 290 + wy * 70, 34, 44);
      ctx.strokeStyle = '#000'; ctx.lineWidth = 3; ctx.strokeRect(152 + wx * 92, 290 + wy * 70, 34, 44);
    }
    /* door */
    ctx.fillStyle = '#ffde7a'; ctx.shadowColor = '#ffb300'; ctx.shadowBlur = 30; ctx.fillRect(320, 360, 80, 100); ctx.shadowBlur = 0;
    ctx.fillStyle = '#7a1020'; ctx.fillRect(326, 366, 32, 94); ctx.fillRect(362, 366, 32, 94);
    /* marquee */
    C.panel(150, 82, 420, 92, { fill: '#7a0016', r: 14, lw: 5, glow: '#ff2b3a' });
    for (var b = 0; b < 28; b++) {
      var bxx = 162 + b * 14.6, on = (b + Math.floor(t / 120)) % 3 === 0;
      ctx.fillStyle = on ? '#fff6b0' : '#7a5b00'; ctx.beginPath(); ctx.arc(bxx, 90, 3.5, 0, 7); ctx.arc(bxx, 166, 3.5, 0, 7); ctx.fill();
    }
    txt('CASINO BANANAS', 360, 128, { size: 50, grad: ['#fff4b0', '#ffb300'], glow: '#ffb300' });
    /* camera */
    ctx.save(); ctx.translate(612, 200); ctx.rotate(0.4 + Math.sin(t / 1100) * 0.35);
    ctx.fillStyle = '#ccc'; ctx.fillRect(-6, -9, 40, 18); ctx.strokeStyle = '#000'; ctx.lineWidth = 3; ctx.strokeRect(-6, -9, 40, 18);
    ctx.fillStyle = Math.floor(t / 400) % 2 ? '#ff2b3a' : '#400'; ctx.beginPath(); ctx.arc(2, 0, 3, 0, 7); ctx.fill();
    ctx.fillStyle = 'rgba(255,40,40,0.12)'; ctx.beginPath(); ctx.moveTo(34, 0); ctx.lineTo(260, -70); ctx.lineTo(260, 70); ctx.fill();
    ctx.restore();
    /* sidewalk */
    var sg = ctx.createLinearGradient(0, 450, 0, 650); sg.addColorStop(0, '#3a3046'); sg.addColorStop(1, '#120c1a');
    ctx.fillStyle = sg; ctx.fillRect(0, 450, W, 200);
    ctx.fillStyle = '#d4a017'; ctx.fillRect(0, 455, W, 4);
  }
  R.case = function (t, d) {
    casino(t);
    var S = G.S, L = DD.living(S), Gh = DD.ghosts(S);
    var n = L.length, gap = Math.min(118, 660 / n);
    L.forEach(function (p, i) {
      var x = 360 - (n - 1) * gap / 2 + i * gap, y = 560 + sin(t + i * 300, 0.004, 3);
      spr('lead_' + p.color + '_idle', x, y, 120, { flip: i >= n / 2 });
      txt(p.short, x, 632, { size: 20, fill: p.hex });
      var done = G.done[p.seat];
      var by = 470 + sin(t + i * 500, 0.005, 4);
      C.panel(x - 30, by - 26, 60, 46, { fill: done ? '#1aa83a' : '#fff', r: 20, lw: 3 });
      ctx.fillStyle = done ? '#1aa83a' : '#fff'; ctx.beginPath(); ctx.moveTo(x - 6, by + 18); ctx.lineTo(x + 6, by + 18); ctx.lineTo(x, by + 30); ctx.fill();
      txt(done ? 'SET' : '?', x, by - 2, { size: done ? 24 : 34, fill: done ? '#fff' : '#111', stroke: done ? 3 : 0 });
    });
    Gh.forEach(function (p, i) {
      var x = 80 + i * 140, y = 250 + sin(t + i * 700, 0.003, 14);
      spr('lead_' + p.color + '_command', x, y, 100, { alpha: 0.55, filter: 'grayscale(1) brightness(1.7) drop-shadow(0 0 10px #4cf)' });
      spr('act_ghostpower', x + 34, y - 40, 34, { alpha: 0.9 });
      txt(G.done[p.seat] ? 'HAUNTING SET' : 'HAUNTING...', x, y + 60, { size: 16, fill: '#8ff', stroke: 3 });
    });
    C.panel(160, 186, 400, 46, { fill: 'rgba(0,0,0,0.75)', r: 10, lw: 3, alpha: 0.95 });
    txt('PICK YOUR APPROACH IN SECRET', 360, 210, { size: 28, fill: '#ffd21f' });
  };

  /* ---- THE DIRTY DAILY: newspaper with the target number ---- */
  var PAPER_BOX = [[74, 149], [153, 227], [231, 307]]; /* digit boxes in the paper art (324x243) */
  R.paper = function (t, d) {
    var g = ctx.createRadialGradient(360, 330, 50, 360, 330, 520); g.addColorStop(0, '#5a3418'); g.addColorStop(1, '#170a03');
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    C.halftone(0, 0, W, H, 0.25);
    var e = E.out(k(t, 0, 1400));
    var sc = 0.15 + 1.85 * e, rot = (1 - e) * Math.PI * 4 - 0.03;
    ctx.save(); ctx.translate(360, 320); ctx.rotate(rot); ctx.scale(sc, sc);
    ctx.shadowColor = 'rgba(0,0,0,0.7)'; ctx.shadowBlur = 30; ctx.shadowOffsetY = 12;
    C.cover('m_paper', -162, -121, 324, 243);
    ctx.shadowColor = 'transparent';
    /* cover the printed number + corner box, print ours */
    ctx.fillStyle = '#ece3cf';
    ctx.fillRect(247 - 162, 12 - 121, 64, 32);
    txt('ROUND ' + d.round, 279 - 162, 22 - 121, { size: 11, fill: '#111', stroke: 0, font: 'b' });
    txt('OF ' + DD.CFG.rounds, 279 - 162, 36 - 121, { size: 12, fill: '#111', stroke: 0, font: 'b' });
    ctx.fillStyle = '#ebe1cb';
    ctx.fillRect(92 - 162, 175 - 121, 200, 40);
    txt('CLOSEST TO THE NUMBER WINS!', 30, 186 - 121, { size: 12, fill: '#111', stroke: 0, font: 'b' });
    txt('OVER OR UNDER - EXACT HIT = 3 MOVES', 30, 202 - 121, { size: 10, fill: '#111', stroke: 0, font: 'b' });
    var digits = G.pad3(d.target).split('');
    PAPER_BOX.forEach(function (bx, i) {
      var x0 = bx[0] - 162, x1 = bx[1] - 162, y0 = 91 - 121, y1 = 169 - 121;
      ctx.fillStyle = '#f4efe2'; ctx.fillRect(x0, y0, x1 - x0, y1 - y0);
      ctx.strokeStyle = '#111'; ctx.lineWidth = 2; ctx.strokeRect(x0 + 1, y0 + 1, x1 - x0 - 2, y1 - y0 - 2);
      var fl = k(t, 1500 + i * 350, 1800 + i * 350);
      if (fl > 0) {
        ctx.save(); ctx.translate((x0 + x1) / 2, (y0 + y1) / 2 + 2); ctx.scale(1, E.back(fl));
        ctx.font = '700 66px ' + C.FONT_B; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#111';
        ctx.fillText(digits[i], 0, 0); ctx.restore();
      }
    });
    ctx.restore();
    if (t > 2700) {
      var a = k(t, 2700, 3100);
      C.panel(100, 568, 520, 70, { fill: '#c41020', r: 12, alpha: a, glow: '#ff2b3a', rot: -0.01 });
      txt(d.entering ? 'ROLL YOUR 3 TOOL DICE!' : 'GET READY...', 360, 594, { size: 34, alpha: a });
      txt('Closest wins - over OR under - exact hit = 3 moves', 360, 624, { size: 18, font: 'b', alpha: a, stroke: 3 });
      if (d.entering) for (var i = 0; i < 3; i++) spr(['tool_a', 'tool_b', 'tool_c'][i], 60 + i * 18, 600 + sin(t + i * 200, 0.02, 6), 40, { rot: t / 200 + i });
    }
  };

  /* ---- NUMBERS IN! ---- */
  R.numbers = function (t, d) {
    bgCity(t, 0.72);
    txt('NUMBERS IN!', 300, 82, { size: 54, grad: ['#fff4b0', '#ffb300'], rot: -0.02 });
    C.panel(560, 56, 140, 66, { fill: '#f1e6c8', r: 6, rot: 0.04 });
    txt('TARGET', 630, 72, { size: 16, fill: '#111', stroke: 0, font: 'b' });
    txt(G.pad3(d.target), 630, 100, { size: 38, fill: '#111', stroke: 0, font: 'b' });
    var rows = d.rows, n = rows.length, y0 = 140, step = Math.min(70, 340 / Math.max(1, n) + 14);
    var res = d.res, tr = res ? t - d.tRes : -1;
    rows.forEach(function (r, i) {
      var revealAt = 1100 + (n - 1 - i) * 650;
      var a = k(t, revealAt, revealAt + 300);
      if (a <= 0) return;
      var p = P(r.seat), y = y0 + i * step, x = 40 + (1 - E.back(a)) * -600;
      var win = res && res.winner === r.seat, pays = res && res.payers.indexOf(r.seat) >= 0;
      C.panel(x, y, 640, step - 8, { grad: [shade(p.hex, win ? 0.8 : 0.45), '#120a1c'], r: 10, lw: 3, glow: win ? '#ffd21f' : null, stroke: win ? '#ffd21f' : '#000' });
      face(r.seat, x + 34, y + (step - 8) / 2, step - 18);
      txt(p.name, x + 70, y + (step - 8) / 2, { size: 24, align: 'left', maxW: 250 });
      txt(G.pad3(r.number), x + 410, y + (step - 8) / 2, { size: 40, font: 'b' });
      txt(r.dist === 0 ? 'EXACT!' : (r.number > d.target ? '+' : '-') + r.dist, x + 500, y + (step - 8) / 2, { size: 20, font: 'b', fill: r.dist === 0 ? '#5dff8a' : '#ccc' });
      if (win) { spr('ui_rank', x + 590, y + 6, 36, { rot: 0.2 }); txt('WINNER!', x + 590, y + (step - 8) / 2 + 6, { size: 22, fill: '#ffd21f' }); }
      else if (pays) { txt('PAYS 1', x + 590, y + (step - 8) / 2, { size: 22, fill: '#ff6b6b' }); }
      if (r.dist === 0 && res) {
        var ba = E.back(k(tr, 200, 600));
        ctx.save(); ctx.translate(x + 300, y + 4); ctx.scale(ba, ba); ctx.rotate(-0.1);
        C.burst(0, 0, 44, { fill: '#5dff8a', n: 12 }); txt('3 MOVES!', 0, 0, { size: 18, fill: '#000', stroke: 0 }); ctx.restore();
      }
    });
    /* ghosts */
    var gy = y0 + n * step + 4;
    d.ghosts.forEach(function (r, i) {
      var a = k(t, 1100 + n * 650, 1500 + n * 650); if (a <= 0) return;
      var x = 60 + i * 150;
      C.panel(x, gy, 140, 42, { fill: '#203040', r: 8, alpha: a * 0.9 });
      face(r.seat, x + 22, gy + 21, 30);
      txt(G.pad3(r.number), x + 92, gy + 21, { size: 24, font: 'b', fill: '#9ff', alpha: a });
    });
    if (res) {
      once(d, 'pay', function () {
        res.pays.forEach(function (pp, i) {
          var fi = rows.map(function (r) { return r.seat; }).indexOf(pp.from);
          var ti = pp.to === 'vault' ? -1 : rows.map(function (r) { return r.seat; }).indexOf(pp.to);
          C.wait(500 + i * 200).then(function () { C.flyChimp(560, y0 + fi * step + 25, ti < 0 ? 650 : 560, ti < 0 ? 23 : y0 + ti * step + 25, COL[pp.from - 1]); });
        });
        if (res.rows.some(function (r) { return r.exact; })) C.money(360, 200, 50, 8);
      });
      if (res.ghostBeat) {
        var ga = E.back(k(tr, 800, 1300));
        ctx.save(); ctx.translate(560, 560); ctx.scale(ga, ga); ctx.rotate(0.06);
        C.panel(-150, -70, 300, 140, { fill: '#0b1a2a', glow: '#4cf', r: 12 });
        C.cover('m_bossback', -145, -65, 90, 130);
        txt('THE BOSS IS BACK!', 50, -30, { size: 24, fill: '#8ff' });
        C.wrap(nameOf(res.ghostBeat) + '\'s ghost beat everyone. The payoff goes to the vault!', 50, 20, 180, 20, { size: 15, font: 'b', stroke: 3 });
        ctx.restore();
      }
    }
  };

  /* ---- decision coin ---- */
  R.coin = function (t, d) {
    bgNoir('#13202e', '#04060a');
    C.rays(360, 200, 600, t / 5000, 'rgba(255,210,31,0.08)');
    txt(d.title, 360, 80, { size: 50, fill: '#ffd21f', rot: -0.02 });
    /* coin */
    var sx = Math.cos(t / 160);
    ctx.save(); ctx.translate(360, 210); ctx.scale(sx, 1);
    ctx.beginPath(); ctx.arc(0, 0, 60, 0, 7); ctx.fillStyle = sx > 0 ? '#ffd21f' : '#c49000'; ctx.fill(); ctx.lineWidth = 6; ctx.strokeStyle = '#6a4a00'; ctx.stroke();
    txt('A', 0, 4, { size: 64, fill: '#6a4a00', stroke: 0 });
    ctx.restore();
    txt(d.sub, 360, 310, { size: 24, font: 'b' });
    var n = d.tied.length, gap = Math.min(200, 640 / n);
    d.tied.forEach(function (s, i) {
      var x = 360 - (n - 1) * gap / 2 + i * gap, y = 450;
      var sel = (d.sel || 0) === i && d.chosen === undefined;
      if (sel) C.rays(x, y, 110, t / 900, 'rgba(255,255,255,0.15)', 12);
      face(s, x, y, 140, { glow: sel || d.chosen === s, gray: d.chosen !== undefined && d.chosen !== s });
      txt(DD.NAMES[s - 1], x, y + 92, { size: 20, maxW: gap - 10, fill: HEX[COL[s - 1]] });
      txt('PRESS ' + s, x, y + 118, { size: 16, font: 'b', stroke: 3, fill: '#aaa' });
      G.hit(x - 70, y - 70, 140, 200, function () { G.pickCoin(s); });
      if (d.chosen === s) { ctx.save(); ctx.translate(x, y); ctx.rotate(-0.2); ctx.scale(E.back(k(C.now() - d.t1, 0, 300)), E.back(k(C.now() - d.t1, 0, 300))); C.panel(-80, -24, 160, 48, { fill: '#c41020', r: 6 }); txt('CHOSEN!', 0, 0, { size: 32 }); ctx.restore(); }
    });
    txt('Tap a face, or press its number', 360, 630, { size: 18, font: 'b', fill: '#bbb', stroke: 3 });
  };

  /* ---- CITY BOARD ---- */
  var TS = 84, BX = 66, BY = 56;
  function tilePos(i) {
    if (i <= 6) return { x: BX + i * TS, y: BY };
    if (i <= 12) return { x: BX + 6 * TS, y: BY + (i - 6) * TS };
    if (i <= 18) return { x: BX + (18 - i) * TS, y: BY + 6 * TS };
    return { x: BX, y: BY + (24 - i) * TS };
  }
  G.tilePos = tilePos;
  var SPACE_ICON = { safe: 'act_defend', docks: 'act_stealcrew', roof: 'act_ambush', casino: 'ui_jackpot', ware: 'act_recruit', train: 'act_getaway', club: 'act_swap' };
  var SPACE_COL = { safe: '#0f6b38', docks: '#0d3a7a', roof: '#6a1a5e', casino: '#8a6a00', ware: '#5a3a1a', train: '#3a3a4a', club: '#3b1170' };
  function board(t, d) {
    bgNoir('#120820', '#05020a');
    /* centre: city */
    ctx.save(); C.rr(BX + TS, BY + TS, TS * 5, TS * 5, 10); ctx.clip();
    C.cover('m_city', BX + TS, BY + TS, TS * 5, TS * 5, { zoom: 1.05, ax: 0.5 + Math.sin(t / 8000) * 0.3, filter: 'saturate(1.08)' });
    ctx.fillStyle = 'rgba(5,2,15,0.18)'; ctx.fillRect(BX + TS, BY + TS, TS * 5, TS * 5);
    C.cover('m_title', 230, 470, 260, 150, { alpha: 0.35 });
    ctx.restore();
    for (var i = 0; i < 24; i++) {
      var sp = DD.BOARD[i], tp = tilePos(i), x = tp.x + 2, y = tp.y + 2, s = TS - 4;
      if (sp.t === 'turf') {
        var c = COL[sp.c], owner = G.S.players[sp.c];
        C.panel(x, y, s, s, { grad: [HEX[c], shade(HEX[c], 0.35)], r: 8, lw: 3 });
        ctx.save(); ctx.beginPath(); ctx.arc(x + s / 2, y + s / 2 - 6, 24, 0, 7); ctx.clip();
        C.cover('face_' + c, x + s / 2 - 24, y + s / 2 - 30, 48, 48, { filter: !owner.active ? 'grayscale(1) brightness(0.4)' : owner.ghost ? 'grayscale(1) brightness(1.2)' : '' });
        ctx.restore();
        txt(owner.ghost ? 'HAUNTED' : 'TURF', x + s / 2, y + s - 11, { size: 15, fill: c === 'white' || c === 'yellow' ? '#111' : '#fff', stroke: c === 'white' || c === 'yellow' ? 0 : 3 });
      } else {
        var corner = i % 6 === 0;
        C.panel(x, y, s, s, { grad: [SPACE_COL[sp.t], '#08040f'], r: 8, lw: 3, inner: corner ? '#ffd21f' : null });
        spr(SPACE_ICON[sp.t], x + s / 2, y + s / 2 - 8, corner ? 50 : 44);
        txt(DD.SPACE_INFO[sp.t].name.split(' ')[0], x + s / 2, y + s - 11, { size: corner ? 16 : 14, maxW: s - 6 });
      }
    }
    /* tokens */
    var at = {};
    DD.living(G.S).forEach(function (p) { (at[p.pos] = at[p.pos] || []).push(p.seat); });
    var hop = d.hop;
    DD.living(G.S).forEach(function (p) {
      var list = at[p.pos], idx = list.indexOf(p.seat), cnt = list.length;
      var ox = cnt > 1 ? ((idx % 3) - (Math.min(cnt, 3) - 1) / 2) * 22 : 0, oy = cnt > 1 ? (Math.floor(idx / 3) - (cnt > 3 ? 0.5 : 0)) * 26 : 0;
      var tp = tilePos(p.pos), x = tp.x + TS / 2 + ox, y = tp.y + TS / 2 + oy + 2, lift = 0;
      if (hop && hop.seat === p.seat) {
        var el = C.now() - hop.t0, stepI = Math.min(hop.path.length - 1, Math.floor(el / 170)), f = Math.min(1, (el - stepI * 170) / 170);
        var a = tilePos(stepI === 0 ? hop.from : hop.path[stepI - 1]), b = tilePos(hop.path[stepI]);
        if (el < hop.path.length * 170) { x = C.lerp(a.x, b.x, f) + TS / 2; y = C.lerp(a.y, b.y, f) + TS / 2; lift = Math.sin(f * Math.PI) * 26; }
      }
      if (d.active === p.seat) {
        ctx.save(); ctx.globalAlpha = 0.6 + sin(t, 0.008, 0.3); ctx.beginPath(); ctx.arc(x, y + 14, 24, 0, 7); ctx.fillStyle = p.hex; ctx.shadowColor = p.hex; ctx.shadowBlur = 20; ctx.fill(); ctx.restore();
      }
      spr('chimp_' + p.color, x, y - lift, d.active === p.seat ? 50 : 40);
    });
  }
  R.board = function (t, d) {
    board(t, d);
    var cx = 360, cy = 350;
    if (d.active && !d.ev && !d.dice) {
      var p = P(d.active);
      C.panel(cx-170,cy-112,340,246,{fill:'rgba(9,17,30,0.94)',r:16,lw:2,stroke:p.hex,glow:p.hex});
      C.cover('face_'+p.color,cx-49,cy-96,98,108);
      txt(p.short + ' IS UP', cx, cy + 55, { size: 34, fill: p.hex });
      txt(d.label || 'Roll your Dirty Die', cx, cy + 101, { size: 21, font: 'b' });
    }
    if (d.dice) {
      var el = C.now() - d.dice.t0, e = Math.min(1, el / 900);
      var x = C.lerp(160, cx, E.out(e)), y = cy - Math.abs(Math.sin(e * Math.PI * 3)) * 80 * (1 - e) - 10;
      spr('dirty_' + d.dice.col, x, y, 120, { rot: (1 - E.out(e)) * 12 });
      if (e >= 1) { var b = E.back(k(el, 900, 1150)); ctx.save(); ctx.translate(cx, cy + 105); ctx.scale(b, b); C.burst(0, 0, 54, { fill: HEX[d.dice.col] }); txt(String(d.dice.v), 0, 2, { size: 56 }); ctx.restore(); }
    }
    if (d.ev) {
      var ev = d.ev, ea = E.back(k(C.now() - ev.t0, 0, 380));
      ctx.save(); ctx.translate(cx, cy); ctx.scale(ea, ea); ctx.rotate(-0.02);
      C.panel(-200, -110, 400, 220, { grad: [shade(ev.col, 0.7), '#120a1c'], r: 14, lw: 5, glow: ev.col });
      if (ev.card) C.halftone(-195, -105, 390, 210, 0.15);
      spr(ev.icon, -130, -10, 96, { rot: sin(t, 0.005, 0.08) });
      txt(ev.title, 50, -60, { size: 36, maxW: 270, grad: ['#fff4b0', '#ffb300'] });
      C.wrap(ev.text, 50, 10, 250, 26, { size: 21, font: 'b', stroke: 4 });
      ctx.restore();
      if (ev.from && ev.to) once(ev, 'fly', function () { var a = plateCenter(ev.from), b = plateCenter(ev.to); C.flyChimp(a.x, a.y, b.x, b.y, COL[ev.from - 1]); });
    }
  };

  /* ---- CREW WAR ---- */
  R.war = function (t, d) {
    var war = d.war, A = P(war.a), D = P(war.d);
    var g = ctx.createLinearGradient(0, 0, W, H); g.addColorStop(0, shade(A.hex, 0.6)); g.addColorStop(0.5, '#120018'); g.addColorStop(1, shade(D.hex, 0.6));
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    C.rays(360, 330, 700, t / 2500, 'rgba(255,255,255,0.05)', 20);
    if (Math.random() < 0.04) { ctx.strokeStyle = '#fff'; ctx.lineWidth = 3; ctx.beginPath(); var lx = 300 + Math.random() * 120; ctx.moveTo(lx, 120); for (var j = 0; j < 6; j++) ctx.lineTo(lx + (Math.random() - 0.5) * 60, 120 + j * 50); ctx.stroke(); }
    var e = E.back(k(t, 0, 600));
    var shakeA = d.phase === 'show' && d.cur && d.cur.r === 'd' ? sin(t, 0.08, 4) : 0, shakeD = d.phase === 'show' && d.cur && d.cur.r === 'a' ? sin(t, 0.08, 4) : 0;
    cardAt('m_card_' + A.color, 150 - (1 - e) * 300 + shakeA, 300, -0.08, A, 'ATTACKER');
    cardAt('m_card_' + D.color, 570 + (1 - e) * 300 + shakeD, 300, 0.08, D, 'DEFENDER');
    var vs = E.elastic(k(t, 300, 1100));
    ctx.save(); ctx.translate(360, 300); ctx.scale(vs, vs); C.cover('m_vs', -80, -54, 160, 108); ctx.restore();
    ctx.save(); ctx.translate(360, 82); ctx.rotate(-0.03); ctx.scale(e, e);
    C.burst(0, 0, 66, { fill: '#c41020', n: 18, inner: 0.85 });
    ctx.restore();
    txt(d.title, 360, 80, { size: 52, grad: ['#fff4b0', '#ffb300'], rot: -0.03 });
    txt(war.stake + ' CHIMPS ON THE LINE' + (war.last ? ' - BEST 2 OF 3' : ''), 360, 130, { size: 22, font: 'b' });
    if (war.last) for (var r = 0; r < 3; r++) {
      var rr = war.rounds.filter(function (x) { return x.r !== 'tie'; })[r];
      ctx.beginPath(); ctx.arc(320 + r * 40, 160, 14, 0, 7); ctx.fillStyle = rr ? (rr.r === 'a' ? A.hex : D.hex) : '#333'; ctx.fill(); ctx.lineWidth = 3; ctx.strokeStyle = '#000'; ctx.stroke();
      txt(String(r + 1), 320 + r * 40, 161, { size: 14, stroke: 0, fill: rr && (rr.r === 'a' ? A : D).color === 'white' ? '#000' : '#fff' });
    }
    if (d.phase === 'roll' || d.phase === 'intro') {
      C.panel(120, 470, 480, 70, { fill: 'rgba(0,0,0,0.75)', r: 12 });
      txt(G.S.warDice === 'rps' ? 'ROLL YOUR ROSHAMBOMOWO DIE!' : 'ROLL YOUR DIRTY DIE!', 360, 495, { size: 32, fill: '#ffd21f' });
      txt('Attacker ' + (G.done[war.a] ? 'LOCKED' : '...') + '      Defender ' + (G.done[war.d] ? 'LOCKED' : '...'), 360, 525, { size: 18, font: 'b' });
      if (G.S.warDice === 'rps') ['rock', 'paper', 'monkey', 'scissors', 'ghost', 'wild'].forEach(function (f, i) { spr('rps_' + f, 160 + i * 80, 590, 54, { alpha: 0.9 }); txt(DD.RPS[i + 1], 160 + i * 80, 628, { size: 14, stroke: 3 }); });
    }
    if (d.cur && (d.phase === 'show' || d.phase === 'result')) {
      var el = C.now() - d.tCur, a1 = E.back(k(el, 0, 400));
      dieFace(d.cur.af, 150, 520, 120 * a1, A.color);
      dieFace(d.cur.df, 570, 520, 120 * a1, D.color);
      if (el > 800) {
        var w = d.cur.r, bt = E.back(k(el, 800, 1100));
        ctx.save(); ctx.translate(360, 560); ctx.scale(bt, bt);
        if (w === 'tie') { C.burst(0, 0, 70, { fill: '#888' }); txt('TIE! ROLL AGAIN', 0, 0, { size: 26, fill: '#fff' }); }
        else { C.burst(0, 0, 80, { fill: w === 'a' ? A.hex : D.hex }); txt(d.cur.verb || 'WINS!', 0, 0, { size: 22, maxW: 150, fill: (w === 'a' ? A : D).color === 'white' || (w === 'a' ? A : D).color === 'yellow' ? '#000' : '#fff', stroke: 0 }); }
        ctx.restore();
      }
    }
    if (d.phase === 'result') {
      var re = C.now() - d.tRes, rb = E.back(k(re, 0, 450));
      var win = war.winner === 'a' ? A : D, lose = war.winner === 'a' ? D : A;
      ctx.fillStyle = 'rgba(0,0,0,' + (0.55 * k(re, 0, 300)) + ')'; ctx.fillRect(0, 0, W, H);
      ctx.save(); ctx.translate(360, 300); ctx.scale(rb, rb); ctx.rotate(-0.04);
      C.rays(0, 0, 400, re / 1500, 'rgba(255,210,31,0.15)');
      C.panel(-300, -150, 600, 300, { grad: [shade(win.hex, 0.75), '#140820'], r: 16, lw: 6, glow: win.hex });
      txt(war.winner === 'a' ? (war.stake >= 6 ? 'DOUBLE TAKEOVER!' : 'CREW TAKEOVER!') : 'COUNTERATTACK!', 0, -100, { size: 56, grad: ['#fff4b0', '#ffb300'] });
      spr('lead_' + win.color + '_celebrate', -190, 30, 170);
      C.cover('m_lastcrew', -60, -40, 260, 100, { alpha: 0.95 });
      txt(win.short + ' TAKES ' + war.moved + ' FROM ' + lose.short, 70, 100, { size: 28, maxW: 330 });
      ctx.restore();
      once(d, 'fly', function () {
        var a = plateCenter(lose.seat), b = plateCenter(win.seat);
        for (var i = 0; i < war.moved; i++) C.flyChimp(a.x, a.y, b.x, b.y, lose.color, i * 140);
        C.money(360, 300, 30, 7);
      });
    }
  };
  function cardAt(name, x, y, rot, p, label) {
    ctx.save(); ctx.translate(x, y); ctx.rotate(rot);
    C.panel(-118, -160, 236, 320, { fill: '#000', r: 12, lw: 5, glow: p.hex, stroke: p.hex });
    ctx.save(); C.rr(-113, -155, 226, 310, 9); ctx.clip(); C.cover(name, -113, -155, 226, 310, { ay: 0.15 }); ctx.restore();
    C.panel(-70, 140, 140, 32, { fill: p.hex, r: 8, lw: 3 });
    txt(label, 0, 156, { size: 20, fill: p.color === 'white' || p.color === 'yellow' ? '#000' : '#fff', stroke: 0 });
    ctx.restore();
  }
  function dieFace(v, x, y, size, color) {
    if (size <= 1) return;
    if (G.S.warDice === 'rps') { C.panel(x - size / 2 - 6, y - size / 2 - 6, size + 12, size + 12, { fill: '#fff', r: 14 }); spr('rps_' + DD.RPS[v].toLowerCase(), x, y, size); txt(DD.RPS[v], x, y + size / 2 + 22, { size: 24 }); }
    else { spr('dirty_' + color, x, y, size); txt(String(DD.dieVal(v)), x, y + size / 2 + 22, { size: 30 }); }
  }

  /* ---- THE VAULT ---- */
  R.vault = function (t, d) {
    var c = d.crack, n = c.rows.length;
    var g = ctx.createLinearGradient(0, 0, 0, H); g.addColorStop(0, '#2b2f3a'); g.addColorStop(1, '#0c0e14');
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    C.cover('env_casino', 0, 50, W, 300, { alpha: 0.25 });
    for (var rx = 0; rx < 12; rx++) for (var ry = 0; ry < 2; ry++) { ctx.fillStyle = '#555c6b'; ctx.beginPath(); ctx.arc(30 + rx * 60, 70 + ry * 290, 4, 0, 7); ctx.fill(); }
    /* security room */
    C.panel(18, 64, 230, 210, { fill: '#10161c', r: 10, inner: '#2f7bff' });
    txt('SECURITY ROOM', 133, 82, { size: 18, fill: '#8fc8ff', stroke: 3 });
    for (var m = 0; m < 4; m++) {
      var mx = 32 + (m % 2) * 104, my = 98 + Math.floor(m / 2) * 64;
      ctx.fillStyle = '#0a2a14'; ctx.fillRect(mx, my, 96, 56); ctx.strokeStyle = '#000'; ctx.lineWidth = 3; ctx.strokeRect(mx, my, 96, 56);
      for (var sl = 0; sl < 10; sl++) { ctx.fillStyle = 'rgba(120,255,150,' + (Math.random() * 0.25) + ')'; ctx.fillRect(mx + 2, my + 2 + sl * 5.4, 92, 2); }
      var who = c.rows[(m + Math.floor(t / 1500)) % Math.max(1, n)];
      if (who) spr('lead_' + COL[who.seat - 1] + '_run', mx + 48, my + 30, 44, { alpha: 0.6, filter: 'sepia(1) hue-rotate(70deg)' });
    }
    var guardOk = !(c.ok === false && t > 1600 + n * 900);
    spr('crew_bruiser_neutral', 200, 250, 70, { flip: true, rot: guardOk ? Math.sin(t / 300) * 0.05 : 0 });
    if (guardOk && c.ok) txt('Z z z', 225, 205, { size: 18, fill: '#ccc', stroke: 3, alpha: 0.5 + sin(t, 0.004, 0.5) });
    /* vault door */
    var cracks = 0, shown = Math.min(n, Math.floor(k(t, 1600, 1600 + n * 900) * n + 0.001));
    for (var i = 0; i < shown; i++) cracks += c.rows[i].s;
    var done = t > 1600 + n * 900 + 300, open = done && c.ok;
    var op = open ? E.io(k(t, 1600 + n * 900 + 300, 1600 + n * 900 + 1500)) : 0;
    var vx = 500, vy = 190;
    if (op > 0) {
      ctx.save(); ctx.beginPath(); ctx.arc(vx, vy, 120, 0, 7); ctx.clip();
      var lg = ctx.createRadialGradient(vx, vy, 10, vx, vy, 140); lg.addColorStop(0, '#fff3b0'); lg.addColorStop(1, '#a86b00'); ctx.fillStyle = lg; ctx.fillRect(vx - 130, vy - 130, 260, 260);
      spr('ui_jackpot', vx - 40, vy + 20, 90); spr('obj_stashbag', vx + 50, vy + 30, 80); spr('chimp_yellow', vx, vy - 40, 70);
      ctx.restore();
    }
    ctx.save(); ctx.translate(vx + op * 230, vy); ctx.scale(1 - op * 0.75, 1);
    ctx.beginPath(); ctx.arc(0, 0, 128, 0, 7); var dg = ctx.createRadialGradient(-40, -40, 10, 0, 0, 130); dg.addColorStop(0, '#d9dde5'); dg.addColorStop(1, '#5d6472'); ctx.fillStyle = dg; ctx.fill(); ctx.lineWidth = 8; ctx.strokeStyle = '#000'; ctx.stroke();
    ctx.beginPath(); ctx.arc(0, 0, 100, 0, 7); ctx.lineWidth = 4; ctx.strokeStyle = '#3a404c'; ctx.stroke();
    for (var b = 0; b < 12; b++) { var ba = b / 12 * 6.283; ctx.fillStyle = '#2b2f3a'; ctx.beginPath(); ctx.arc(Math.cos(ba) * 114, Math.sin(ba) * 114, 6, 0, 7); ctx.fill(); }
    ctx.rotate(cracks * 0.6 + (done && c.ok ? t / 200 : 0));
    ctx.lineWidth = 12; ctx.strokeStyle = '#1b1e26'; ctx.lineCap = 'round';
    for (var s = 0; s < 3; s++) { ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(Math.cos(s * 2.094) * 70, Math.sin(s * 2.094) * 70); ctx.stroke(); }
    ctx.beginPath(); ctx.arc(0, 0, 24, 0, 7); ctx.fillStyle = '#ffd21f'; ctx.fill(); ctx.lineWidth = 4; ctx.strokeStyle = '#000'; ctx.stroke();
    ctx.restore();
    /* counter */
    C.panel(270, 60, 120, 76, { fill: '#000', r: 10, glow: cracks >= c.security ? '#5dff8a' : '#ff2b3a' });
    txt(cracks + '/' + c.security, 330, 92, { size: 40, font: 'b', fill: cracks >= c.security ? '#5dff8a' : '#ff6b6b' });
    txt('CRACKS', 330, 124, { size: 16, font: 'b', stroke: 2 });
    /* laser corridor */
    ctx.fillStyle = '#070910'; ctx.fillRect(0, 330, W, 120);
    ctx.fillStyle = '#1b1f2a'; ctx.fillRect(0, 440, W, 10);
    for (var l = 0; l < c.security; l++) {
      var lx = 70 + l * (580 / Math.max(1, c.security - 1 || 1)), off = l < cracks;
      if (!off) {
        ctx.save(); ctx.strokeStyle = 'rgba(255,0,40,' + (0.7 + Math.random() * 0.3) + ')'; ctx.shadowColor = '#ff0030'; ctx.shadowBlur = 16; ctx.lineWidth = 4;
        ctx.beginPath(); ctx.moveTo(lx, 335); ctx.lineTo(lx + 30, 440); ctx.stroke(); ctx.restore();
      } else { ctx.strokeStyle = 'rgba(80,80,80,0.5)'; ctx.lineWidth = 2; ctx.setLineDash([4, 6]); ctx.beginPath(); ctx.moveTo(lx, 335); ctx.lineTo(lx + 30, 440); ctx.stroke(); ctx.setLineDash([]); }
      ctx.fillStyle = '#333'; ctx.fillRect(lx - 8, 330, 16, 8); ctx.fillRect(lx + 22, 438, 16, 6);
    }
    /* runners + rows */
    c.rows.forEach(function (r, i) {
      var ts = 1600 + i * 900, el = t - ts; if (el < 0) return;
      var col = COL[r.seat - 1];
      if (el < 1400) spr('lead_' + col + '_run', -60 + el / 1400 * 840, 400, 90);
      once(d, 'snd' + i, function () { C.sfx(r.s ? 'laser' : 'click'); if (r.s) C.spark(70 + Math.min(c.security - 1, cracks) * 40, 380, 12, '#ff4060'); });
      var x = 12 + (i % 3) * 236, y = 462 + Math.floor(i / 3) * 90, a = E.back(k(el, 0, 300));
      ctx.save(); ctx.translate(x + 114, y + 40); ctx.scale(a, a);
      C.panel(-112, -38, 224, 80, { grad: [shade(HEX[col], 0.6), '#0d0d15'], r: 10 });
      face(r.seat, -84, -6, 50);
      spr(APPROACH_ICON[r.approach], -84, 26, 34);
      txt(r.approach.toUpperCase(), 10, -24, { size: 20, fill: '#ffd21f' });
      r.digits.forEach(function (dg, j) {
        var ok = DD.dieVal(dg) >= r.min;
        C.panel(-36 + j * 46, -8, 40, 40, { fill: ok ? '#5dff8a' : '#e8e8e8', r: 8, lw: 3 });
        txt(String(dg), -16 + j * 46, 13, { size: 26, font: 'b', fill: '#111', stroke: 0 });
      });
      txt(r.min + '+', 92, -24, { size: 16, font: 'b', stroke: 3, fill: '#ccc' });
      ctx.restore();
    });
    if (c.inside.length && t > 900) {
      var ia = E.back(k(t, 900, 1300));
      ctx.save(); ctx.translate(560, 380); ctx.scale(ia, ia); ctx.rotate(0.05);
      C.panel(-110, -40, 220, 80, { fill: '#0b1a2a', glow: '#4cf' });
      txt('INSIDE JOB!', 0, -14, { size: 28, fill: '#8ff' }); txt('Ghost lowers security by ' + c.inside.length, 0, 16, { size: 15, font: 'b', stroke: 3 });
      ctx.restore();
    }
    if (done) {
      var re = t - (1600 + n * 900 + 300);
      if (!c.ok) {
        ctx.fillStyle = 'rgba(255,0,30,' + (0.18 + 0.18 * Math.sin(t / 90)) + ')'; ctx.fillRect(0, 0, W, H);
        spr('fx_alarm2', 120, 300, 90, { rot: t / 200 }); spr('fx_alarm1', 610, 330, 80, { rot: -t / 250 });
        for (var gi = 0; gi < 3; gi++) spr('crew_bruiser_neutral', 760 - Math.min(1, re / 1200) * (260 - gi * 70), 400, 80, { flip: true });
      }
      var bb = E.back(k(re, 0, 400));
      ctx.save(); ctx.translate(360, 300); ctx.scale(bb, bb); ctx.rotate(-0.05);
      C.burst(0, 0, 120, { fill: c.ok ? '#ffd21f' : '#c41020', n: 16 });
      txt(c.ok ? 'VAULT OPEN!' : 'ALARM!', 0, -10, { size: 46, fill: c.ok ? '#000' : '#fff', stroke: c.ok ? 0 : 6 });
      txt(c.ok ? c.vault + ' CHIMPS INSIDE' : 'THE VAULT HOLDS', 0, 32, { size: 20, fill: c.ok ? '#000' : '#fff', stroke: c.ok ? 0 : 3 });
      ctx.restore();
      if (c.ok) once(d, 'money', function () { C.money(500, 190, 40, 8); });
    }
  };

  /* ---- DIRTY DEEDS ---- */
  function deedPos(i, n) { var a = Math.PI * (0.92 - 0.84 * (n === 1 ? 0.5 : i / (n - 1))); return { x: 360 + Math.cos(a) * 285, y: 440 - Math.sin(a) * 150 }; }
  R.deeds = function (t, d) {
    var g = ctx.createRadialGradient(360, 380, 40, 360, 380, 560); g.addColorStop(0, '#5c4210'); g.addColorStop(1, '#0d0904');
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    for (var s = 0; s < 3; s++) { ctx.fillStyle = '#2b1e08'; ctx.fillRect(0, 90 + s * 70, W, 8); for (var b = 0; b < 12; b++) spr('obj_stashbag', 30 + b * 60 + (s % 2) * 25, 70 + s * 70, 38, { alpha: 0.35 }); }
    C.halftone(0, 0, W, H, 0.15);
    var L = DD.living(G.S), n = L.length;
    /* loot pile */
    var vaultNow = G.S.vault - (d.res ? 0 : 0);
    spr('ui_jackpot', 330, 455, 120); spr('obj_stashbag', 410, 470, 90); spr('chimp_yellow', 370, 420, 60, { alpha: 0.9 });
    C.panel(290, 520, 140, 44, { fill: '#000', r: 10, glow: '#ffd21f' });
    txt('VAULT ' + vaultNow, 360, 542, { size: 26, fill: '#ffd21f' });
    if (d.res) txt('FAIR SHARE ' + d.res.share, 360, 586, { size: 20, font: 'b' });
    var stepIdx = -1, stepT = 0;
    if (d.res && d.phase === 'reveal') { var rt = t - d.tReveal - 2200; stepIdx = Math.floor(rt / 1700); stepT = rt - stepIdx * 1700; }
    var curStep = d.res && stepIdx >= 0 && stepIdx < d.res.steps.length ? d.res.steps[stepIdx] : null;
    L.forEach(function (p, i) {
      var pos = deedPos(i, n), focus = curStep && (curStep.seat === p.seat || curStep.target === p.seat);
      var pose = 'idle';
      if (d.res && stepIdx >= 0) {
        var mine = d.res.steps.filter(function (s2, j) { return j <= stepIdx && s2.seat === p.seat && !s2.ghost; });
        var hit = d.res.steps.filter(function (s2, j) { return j <= stepIdx && s2.target === p.seat && s2.ok && (s2.deed === 'lift' || s2.deed === 'frame' || s2.ghost); });
        pose = hit.length ? 'angry' : mine.length ? (mine[mine.length - 1].ok ? 'celebrate' : 'angry') : 'idle';
      }
      spr('lead_' + p.color + '_' + pose, pos.x, pos.y + (focus ? sin(t, 0.02, 4) : 0), focus ? 128 : 110, { flip: pos.x > 360 });
      txt(p.short, pos.x, pos.y + 66, { size: 20, fill: p.hex });
      /* deed card */
      var cy = pos.y - 96, rev = d.phase === 'reveal' ? k(t - d.tReveal, 200 + i * 200, 600 + i * 200) : 0;
      ctx.save(); ctx.translate(pos.x, cy); ctx.scale(Math.abs(Math.cos(rev * Math.PI)) || 0.02, 1);
      if (rev < 0.5) {
        C.panel(-36, -30, 72, 60, { fill: '#7a0016', r: 8, lw: 3, inner: '#ffd21f' });
        txt(G.done[p.seat] || d.phase === 'roll' ? 'SET' : '?', 0, 0, { size: 26, fill: '#ffd21f' });
      } else {
        C.panel(-46, -34, 92, 68, { fill: '#fff4d6', r: 8, lw: 3 });
        spr(DEED_ICON[p.deed], -16, -2, 44);
        if (p.deedTarget) face(p.deedTarget, 26, -14, 26);
        C.panel(10, 2, 30, 28, { fill: p.hex, r: 6, lw: 2 });
        txt(String(DD.dieVal(p.deedRoll)), 25, 16, { size: 20, fill: p.color === 'white' || p.color === 'yellow' ? '#000' : '#fff', stroke: 0 });
      }
      ctx.restore();
      if (p.hot > 0 || (d.res && stepIdx >= 0)) {
        var hot = hotAt(d, p.seat, stepIdx);
        if (hot > 0) { spr('obj_stashbag', pos.x + 46, pos.y + 30, 34); txt(String(hot), pos.x + 46, pos.y + 34, { size: 18 }); }
      }
    });
    if (d.phase !== 'reveal') {
      C.panel(110, 600, 500, 40, { fill: 'rgba(0,0,0,0.8)', r: 10 });
      txt(d.phase === 'roll' ? 'EVERYONE ROLL YOUR DIRTY DIE' : 'GRAB  -  LIFT  -  FRAME  -  DOUBLE-CROSS', 360, 620, { size: 24, fill: '#ffd21f' });
    }
    if (curStep) {
      var actor = P(curStep.seat), ap = deedPos(L.indexOf(actor) < 0 ? 0 : L.indexOf(actor), n);
      var tg = curStep.target ? P(curStep.target) : null, tpI = tg ? L.indexOf(tg) : -1, tpos = tpI >= 0 ? deedPos(tpI, n) : null;
      var e2 = E.out(k(stepT, 0, 500));
      if (curStep.ghost) {
        spr('act_ghostpower', C.lerp(360, tpos ? tpos.x : 360, e2), C.lerp(150, tpos ? tpos.y - 30 : 300, e2), 80, { alpha: 0.85 });
        once(d, 'g' + stepIdx, function () { C.sfx('ghost'); });
      } else if (curStep.deed === 'grab' || curStep.deed === 'dcross') {
        if (curStep.n > 0) C.arrow(360, 440, C.lerp(360, ap.x, e2), C.lerp(440, ap.y, e2), curStep.deed === 'dcross' ? '#ff3fd0' : '#5dff8a', 7, 0.15);
        once(d, 's' + stepIdx, function () { C.sfx(curStep.ok ? 'cash' : 'bad'); if (curStep.deed === 'dcross' && curStep.ok) C.money(ap.x, ap.y - 40, 40, 8); });
        sticker(curStep.ok ? (curStep.deed === 'dcross' ? 'ui_haha' : 'ui_nice') : 'ui_oops', ap.x, ap.y - 160, stepT);
      } else if (tpos) {
        if (curStep.deed === 'lift') {
          if (curStep.ok) spr('fx_slash', C.lerp(ap.x, tpos.x, e2), C.lerp(ap.y, tpos.y, e2) - 20, 70, { rot: Math.atan2(tpos.y - ap.y, tpos.x - ap.x) });
          C.arrow(curStep.ok ? tpos.x : ap.x, (curStep.ok ? tpos.y : ap.y) - 10, C.lerp(curStep.ok ? tpos.x : ap.x, curStep.ok ? ap.x : tpos.x, e2), C.lerp(curStep.ok ? tpos.y : ap.y, curStep.ok ? ap.y : tpos.y, e2) - 10, '#ff2b3a', 6, 0.3);
          if (curStep.ok) sticker('ui_betrayal', tpos.x, tpos.y - 150, stepT); else sticker('ui_busted', ap.x, ap.y - 150, stepT);
        } else {
          spr(curStep.ok ? 'ui_target' : 'ui_oops', curStep.ok ? tpos.x : ap.x, (curStep.ok ? tpos.y : ap.y) - 10, 80 + sin(t, 0.02, 6));
          if (curStep.ok) spr('ui_heat', tpos.x + 40, tpos.y - 50, 50);
        }
        once(d, 's' + stepIdx, function () { C.sfx(curStep.ok ? 'hit' : 'bad'); });
      }
      C.panel(60, 612, 600, 34, { fill: 'rgba(0,0,0,0.85)', r: 10, glow: curStep.ghost ? '#4cf' : actor.hex });
      txt(actor.short + (curStep.ghost ? '\'S GHOST: ' : ': ') + curStep.text, 360, 629, { size: 22, maxW: 580, fill: curStep.ok === false ? '#ff8a8a' : '#fff' });
    }
  };
  function hotAt(d, seat, stepIdx) {
    if (!d.res) return 0;
    var hot = 0;
    d.res.steps.forEach(function (s, j) {
      if (j > stepIdx) return;
      if (!s.ghost && s.seat === seat && (s.deed === 'grab' || s.deed === 'dcross' || s.deed === 'frame')) hot += s.n || 0;
      if (!s.ghost && s.deed === 'lift' && s.ok) { if (s.seat === seat) hot += 0; }
      if (s.ghost && s.target === seat) hot -= s.n;
    });
    return Math.max(0, hot);
  }
  function sticker(name, x, y, el) { var s = E.back(k(el, 0, 300)); spr(name, x, y, 90 * s, { rot: -0.15 }); }

  /* ---- THE GETAWAY ---- */
  function police(x, y, t) {
    ctx.save(); ctx.translate(x, y);
    ctx.fillStyle = '#111'; C.rr(-50, -14, 100, 28, 8); ctx.fill();
    ctx.fillStyle = '#f2f2f2'; C.rr(-44, -24, 60, 16, 6); ctx.fill(); ctx.fillRect(-50, -6, 100, 10);
    ctx.lineWidth = 3; ctx.strokeStyle = '#000'; C.rr(-50, -24, 100, 38, 8); ctx.stroke();
    var on = Math.floor(t / 150) % 2;
    ctx.fillStyle = on ? '#ff1030' : '#2050ff'; ctx.shadowColor = ctx.fillStyle; ctx.shadowBlur = 25; ctx.fillRect(-22, -32, 12, 8);
    ctx.fillStyle = on ? '#2050ff' : '#ff1030'; ctx.shadowColor = ctx.fillStyle; ctx.fillRect(-8, -32, 12, 8); ctx.shadowBlur = 0;
    ctx.fillStyle = '#000'; ctx.beginPath(); ctx.arc(-28, 16, 10, 0, 7); ctx.arc(30, 16, 10, 0, 7); ctx.fill();
    ctx.fillStyle = '#888'; ctx.beginPath(); ctx.arc(-28, 16, 4, 0, 7); ctx.arc(30, 16, 4, 0, 7); ctx.fill();
    txt('POLICE', -6, 4, { size: 12, fill: '#111', stroke: 0, font: 'b' });
    ctx.restore();
  }
  function street(t, speed) {
    var g = ctx.createLinearGradient(0, 0, 0, 260); g.addColorStop(0, '#0a0420'); g.addColorStop(1, '#3a0d4a');
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, 270);
    ctx.fillStyle = '#fff'; for (var s = 0; s < 30; s++) { ctx.globalAlpha = 0.3 + (s % 3) * 0.2; ctx.fillRect((s * 97) % W, 60 + (s * 53) % 120, 2, 2); } ctx.globalAlpha = 1;
    [[0.15, 160, '#1b0f2e', 90], [0.35, 200, '#120a20', 70]].forEach(function (L, li) {
      var off = (t * speed * L[0]) % 1000;
      for (var b = -1; b < 12; b++) {
        var bx = b * 90 - off % 90 * 1, h = L[1] - ((b * 37 + li * 11 + Math.floor((t * speed * L[0]) / 90)) % 5) * 22;
        ctx.fillStyle = L[2]; ctx.fillRect(bx, 270 - h, L[3], h);
        for (var wy = 270 - h + 12; wy < 260; wy += 20) for (var wx = bx + 10; wx < bx + L[3] - 10; wx += 18) { if (((wx + wy) * 7 | 0) % 3) { ctx.fillStyle = li ? '#ffcf5a' : '#ff5fd8'; ctx.globalAlpha = 0.6; ctx.fillRect(wx, wy, 8, 10); ctx.globalAlpha = 1; } }
      }
    });
    ctx.fillStyle = '#2a2a33'; ctx.fillRect(0, 270, W, 18);
    ctx.fillStyle = '#1a1a20'; ctx.fillRect(0, 288, W, 360);
    var off2 = (t * speed) % 80;
    ctx.fillStyle = '#d8c060';
    for (var ln = 1; ln < 6; ln++) for (var dx = -80; dx < W + 80; dx += 80) ctx.fillRect(dx - off2, 288 + ln * 60 - 2, 40, 4);
  }
  R.getaway = function (t, d) {
    var chase = d.phase === 'chase', ct = chase ? t - d.tChase : 0;
    var speed = chase ? 0.9 : 0.25;
    street(t, speed);
    var L = d.res ? d.res.rows.map(function (r) { return P(r.seat); }) : DD.living(G.S);
    L.forEach(function (p, i) {
      var y = 318 + i * 60, row = d.res ? d.res.rows[i] : null;
      var x = 330, alpha = 1, rot = 0, extra = null;
      var rs = 1300 + i * 650; /* outcome start */
      if (chase && row) {
        var el = ct - rs;
        if (row.esc && row.route !== 'low') { x = 330 + Math.max(0, el) * Math.max(0, el) * 0.00045; if (el > 0) once(d, 'e' + i, function () { C.sfx('whoosh'); C.puff(300, y, 4); }); }
        else if (row.route === 'low') { if (el > 0) { x = 330 - Math.min(1, el / 900) * 80; alpha = 1 - Math.min(0.6, el / 1500); } }
        else {
          if (el > 0) { var cr = Math.min(1, el / 700); x = 330 + cr * 120; rot = el > 700 ? Math.min(1, (el - 700) / 300) * 0.6 : 0; }
          if (el > 700) once(d, 'c' + i, function () { C.sfx('hit'); C.spark(470, y, 16, '#ffd21f'); C.puff(470, y, 5, true); });
          extra = 'crash';
        }
      }
      if (!chase) x = 330 + sin(t + i * 200, 0.05, 2);
      /* police */
      var px = chase ? (row && !row.esc && ct > rs ? 120 + Math.min(1, (ct - rs) / 700) * 210 : 90 + sin(t + i * 300, 0.003, 30)) : -40 + sin(t + i * 300, 0.002, 20);
      if (!(row && row.esc && ct > rs + 1500)) police(px, y + 4, t + i * 50);
      if (extra === 'crash') spr('veh_roadblock', 520, y + 2, 44);
      var vname = VEH[p.color], filt = p.color === 'white' ? 'grayscale(1) brightness(2.4) contrast(0.9)' : '';
      if (row && row.route === 'low' && ct > rs) spr('veh_dumpster', 260, y - 4, 46);
      spr(vname, x, y + sin(t + i * 100, 0.06, 1.5), 56, { rot: rot, alpha: alpha, filter: filt });
      if (chase) for (var sl = 0; sl < 3; sl++) { ctx.strokeStyle = 'rgba(255,255,255,0.25)'; ctx.lineWidth = 2; ctx.beginPath(); var sx = x - 70 - ((t * 0.8 + sl * 40 + i * 13) % 120); ctx.moveTo(sx, y - 12 + sl * 12); ctx.lineTo(sx - 40, y - 12 + sl * 12); ctx.stroke(); }
      /* lane tag */
      C.panel(4, y - 26, 176, 52, { fill: 'rgba(10,6,20,0.88)', r: 10, lw: 2 });
      face(p.seat, 28, y, 40);
      var tagT = row ? (row.route === 'low' ? 'LAY LOW' : (DD.ROUTES[row.route] || DD.ROUTES.alley).name) : (p.route ? 'SET' : '...');
      txt(tagT, 54, y - 12, { size: 15, font: 'b', stroke: 3, fill: '#ddd', align: 'left' });
      if (row && row.total !== null) txt('ROLL ' + row.total + ' / NEED ' + row.need, 54, y + 10, { size: 14, font: 'b', stroke: 3, fill: '#ffd21f', align: 'left' });
      else if (row) txt('SAFE IN THE ALLEY', 54, y + 10, { size: 14, font: 'b', stroke: 3, fill: '#9cf', align: 'left' });
      else txt('NEEDS ' + DD.getawayNeed(G.S, p) + '+', 54, y + 10, { size: 14, font: 'b', stroke: 3, fill: '#ffd21f', align: 'left' });
      if (chase && row && ct > rs + 600) {
        var b = E.back(k(ct, rs + 600, rs + 900));
        ctx.save(); ctx.translate(620, y); ctx.scale(b, b);
        if (row.esc) {
          C.panel(-90, -22, 180, 44, { fill: row.route === 'low' ? '#2a4a7a' : '#1aa83a', r: 10 });
          txt(row.route === 'low' ? 'LAID LOW +' + (row.got || 0) : 'ESCAPED +' + (row.got || 0), 0, 1, { size: 22 });
        } else {
          C.panel(-90, -22, 180, 44, { fill: '#c41020', r: 10 });
          spr('ui_busted', -64, 0, 36);
          txt('BUSTED! -' + (row.bail || 0), 14, 1, { size: 22 });
        }
        ctx.restore();
      }
    });
    if (!chase) {
      C.panel(120, 64, 480, 90, { fill: 'rgba(0,0,0,0.8)', r: 14, glow: '#2050ff' });
      txt(d.phase === 'roll' ? 'ROLL YOUR DIRTY DIE TO ESCAPE!' : 'PICK YOUR ROUTE!', 360, 96, { size: 34, fill: '#ffd21f' });
      txt('FLOOR IT +3   -   BACK ALLEYS   -   LAY LOW (safe, drop half)', 360, 132, { size: 17, font: 'b' });
    }
    if (d.fx && d.fx.length && !chase) {
      d.fx.forEach(function (f, i) {
        C.panel(150, 170 + i * 44, 420, 38, { fill: '#0b1a2a', glow: '#4cf', r: 8 });
        txt((f.power === 'fakeid' ? 'FAKE ID! ' + nameOf(f.target) + ' heat +3' : 'GHOST GETAWAY! ' + nameOf(f.target) + ' +3 to escape') + ' (' + nameOf(f.seat) + '\'s ghost)', 360, 189 + i * 44, { size: 17, font: 'b', fill: '#8ff', maxW: 400 });
      });
    }
  };

  /* ---- END OF ROUND ---- */
  R.roundend = function (t, d) {
    bgCity(t, 0.75);
    txt('END OF ROUND ' + d.re.round, 360, 84, { size: 50, grad: ['#fff4b0', '#ffb300'] });
    txt('MAKE SURE YOUR POKER CHIMPS MATCH!', 360, 124, { size: 20, font: 'b' });
    var rows = d.re.standings.slice().sort(function (a, b) { return (a.ghost - b.ghost) || b.chimps - a.chimps; });
    var tied = d.re.tied || [];
    var max = Math.max.apply(null, rows.map(function (r) { return r.chimps; }).concat([1]));
    rows.forEach(function (r, i) {
      var p = P(r.seat), y = 150 + i * 76, a = E.out(k(t, i * 150, i * 150 + 400));
      var low = tied.indexOf(r.seat) >= 0;
      C.panel(40, y, 640, 66, { grad: [r.ghost ? '#203040' : shade(p.hex, 0.45), '#0d0815'], r: 10, alpha: a, glow: low ? '#ff2b3a' : null });
      face(r.seat, 76, y + 33, 54);
      txt(p.name, 116, y + 20, { size: 22, align: 'left', maxW: 230, alpha: a });
      if (r.ghost) txt('GHOST BOSS', 116, y + 46, { size: 16, align: 'left', fill: '#8ff', font: 'b', stroke: 3 });
      else {
        var delta = r.chimps - (G.roundStart ? G.roundStart[r.seat] : r.chimps);
        txt((delta >= 0 ? '+' : '') + delta + ' this round', 116, y + 46, { size: 16, align: 'left', font: 'b', stroke: 3, fill: delta >= 0 ? '#5dff8a' : '#ff8a8a' });
        var bw = 220 * (r.chimps / max) * E.out(k(t, 400 + i * 150, 1400 + i * 150));
        ctx.fillStyle = '#000'; ctx.fillRect(360, y + 22, 224, 24); ctx.fillStyle = p.hex; ctx.fillRect(362, y + 24, bw, 20);
      }
      spr('chimp_' + p.color, 612, y + 33, 44);
      txt(String(r.chimps), 652, y + 34, { size: 32 });
      if (low && !r.ghost && t > 2000) { ctx.save(); ctx.translate(300, y + 33); ctx.rotate(-0.12); C.panel(-60, -16, 120, 32, { fill: '#c41020', r: 6 }); txt('LOWEST', 0, 1, { size: 20 }); ctx.restore(); }
    });
  };

  R.ghost = function (t, d) {
    bgNoir('#071a26', '#020509');
    C.rays(360, 320, 600, t / 3000, 'rgba(80,220,255,0.08)');
    var e = E.back(k(t, 0, 600)), p = P(d.seat);
    ctx.save(); ctx.translate(360, 300); ctx.scale(e, e); ctx.rotate(-0.02);
    C.panel(-210, -215, 420, 430, { fill: '#000', glow: '#4cf', r: 14 });
    C.cover('m_ghostjail', -205, -210, 410, 420);
    ctx.restore();
    txt(p.name, 360, 560, { size: 44, fill: p.hex, maxW: 660 });
    txt('IS NOW A GHOST BOSS', 360, 604, { size: 32, fill: '#8ff' });
    txt('No more points - but every round you pick one GHOST POWER on your Multi-Vibe', 360, 638, { size: 16, font: 'b', stroke: 3 });
    if (Math.random() < 0.2) C.emit({ k: 'spark', x: Math.random() * W, y: H, vx: 0, vy: -2 - Math.random() * 2, g: 0, life: 2000, c: '#7ff' });
  };

  /* ---- THE BIG REVEAL ---- */
  R.final = function (t, d) {
    var fr = d.fr, S = G.S, page = d.done ? 5 : Math.min(5, Math.floor(t / 4600));
    var pt = d.done ? t : t - page * 4600;
    if (page === 0) {
      bgNoir('#3a2410', '#120a04');
      var e = E.out(k(pt, 0, 900));
      ctx.save(); ctx.translate(360, 340); ctx.rotate((1 - e) * 6 - 0.03); ctx.scale(e, e);
      C.panel(-300, -260, 600, 520, { fill: '#f1e6c8', r: 4 });
      txt('THE DIRTY DAILY', 0, -210, { size: 56, fill: '#111', stroke: 0 });
      ctx.fillStyle = '#111'; ctx.fillRect(-280, -175, 560, 5);
      txt('EXTRA! EXTRA!', 0, -130, { size: 34, fill: '#c41020', stroke: 0 });
      txt('CITY ROCKED BY', 0, -60, { size: 60, fill: '#111', stroke: 0 });
      txt('DIRTY DEEDS', 0, 10, { size: 84, fill: '#111', stroke: 0 });
      C.cover('m_endcrowd', -250, 60, 500, 170, { filter: 'grayscale(1) contrast(1.3)' });
      ctx.restore();
      return;
    }
    bgCity(t, 0.78);
    if (page === 1) {
      txt('WHO GOT AWAY?', 360, 70, { size: 54, grad: ['#fff4b0', '#ffb300'] });
      fr.ranking.forEach(function (r, i) {
        var p = P(r.seat), y = 120 + i * 84, a = E.back(k(pt, i * 250, i * 250 + 400));
        C.panel(60, y, 600, 72, { grad: [shade(p.hex, 0.45), '#0d0815'], r: 10, alpha: a });
        face(r.seat, 100, y + 36, 56);
        txt(p.short, 140, y + 36, { size: 28, align: 'left', alpha: a });
        spr('act_getaway', 330, y + 36, 50, { alpha: a }); txt('x' + r.escaped, 380, y + 38, { size: 30, alpha: a });
        spr('ui_busted', 480, y + 36, 46, { alpha: a }); txt('x' + r.caught, 528, y + 38, { size: 30, alpha: a });
      });
      return;
    }
    if (page === 2) {
      txt('FINAL LOOT', 360, 70, { size: 54, grad: ['#fff4b0', '#ffb300'] });
      var max = Math.max.apply(null, fr.ranking.map(function (r) { return r.chimps; }).concat([1]));
      fr.ranking.forEach(function (r, i) {
        var p = P(r.seat), y = 120 + i * 84, g = E.out(k(pt, 300, 2600));
        face(r.seat, 80, y + 34, 56);
        ctx.fillStyle = '#000'; ctx.fillRect(120, y + 14, 480, 40);
        ctx.fillStyle = r.ghost ? '#456' : p.hex; ctx.fillRect(122, y + 16, 476 * r.chimps / max * g, 36);
        txt(r.ghost ? 'GHOST (R' + r.ghostRound + ')' : p.short, 130, y + 34, { size: 22, align: 'left', fill: r.ghost ? '#9cf' : '#fff' });
        txt(String(Math.round(r.chimps * g)), 650, y + 34, { size: 34 });
      });
      return;
    }
    if (page === 3) {
      txt('WHO BETRAYED WHO?', 360, 70, { size: 54, grad: ['#ff9a9a', '#ff2b3a'] });
      var A = DD.actives(S), n = A.length, pos = {};
      A.forEach(function (p, i) { var a = -Math.PI / 2 + i / n * 6.283; pos[p.seat] = { x: 360 + Math.cos(a) * 210, y: 370 + Math.sin(a) * 210 }; });
      var counts = {};
      fr.betrayals.forEach(function (b) { var key = b.from + '>' + b.to; counts[key] = (counts[key] || 0) + 1; });
      var keys = Object.keys(counts), shown = Math.floor(k(pt, 400, 3200) * keys.length + 0.999);
      keys.slice(0, shown).forEach(function (key) {
        var ab = key.split('>'), a = pos[ab[0]], b = pos[ab[1]]; if (!a || !b) return;
        var col = HEX[COL[ab[0] - 1]];
        C.arrow(a.x, a.y, C.lerp(a.x, b.x, 0.82), C.lerp(a.y, b.y, 0.82), col, 3 + counts[key] * 2, 0.15);
      });
      A.forEach(function (p) { face(p.seat, pos[p.seat].x, pos[p.seat].y, 84, { glow: true }); txt(p.short, pos[p.seat].x, pos[p.seat].y + 56, { size: 20, fill: p.hex }); });
      if (!keys.length) txt('NOBODY? SUSPICIOUS.', 360, 370, { size: 40, fill: '#ffd21f' });
      spr('ui_betrayal', 360, 370, 90 + sin(t, 0.01, 6));
      return;
    }
    if (page === 4) {
      txt('BIGGEST DISASTER', 360, 80, { size: 56, grad: ['#ff9a9a', '#ff2b3a'] });
      if (fr.disaster) {
        var p2 = P(fr.disaster.seat), e2 = E.back(k(pt, 200, 700));
        ctx.save(); ctx.translate(360, 340); ctx.scale(e2, e2); ctx.rotate(0.03);
        C.panel(-280, -170, 560, 340, { fill: '#1a0810', glow: '#ff2b3a' });
        spr('lead_' + p2.color + '_angry', -170, 10, 230);
        spr('ui_oops', 150, -90, 130, { rot: 0.15 });
        txt(p2.short + ' LOST ' + fr.disaster.n, 90, 30, { size: 40, maxW: 340 });
        C.wrap(fr.disaster.why.toUpperCase() + ' (ROUND ' + fr.disaster.round + ')', 90, 100, 320, 26, { size: 20, font: 'b' });
        ctx.restore();
      } else txt('A SUSPICIOUSLY CLEAN GAME', 360, 340, { size: 40 });
      return;
    }
    /* page 5: the winner */
    var W2 = P(fr.winner);
    C.rays(360, 330, 760, t / 2500, 'rgba(255,210,31,0.14)', 20);
    var e3 = E.back(k(pt, 0, 700));
    ctx.save(); ctx.translate(210, 330); ctx.rotate(-0.07); ctx.scale(e3, e3);
    C.panel(-140, -190, 280, 380, { fill: '#000', glow: W2.hex, stroke: W2.hex, lw: 6, r: 14 });
    ctx.save(); C.rr(-134, -184, 268, 368, 10); ctx.clip(); C.cover('m_card_' + W2.color, -134, -184, 268, 368, { ay: 0.1 }); ctx.restore();
    ctx.restore();
    spr('boss_' + W2.color, 530, 340 - Math.abs(sin(t, 0.008, 14)), 240);
    spr('ui_winner', 530, 165, 90, { rot: sin(t, 0.004, 0.1) });
    txt('THE WINNER IS', 360, 78, { size: 34 });
    var nm = W2.name.split(' ');
    txt(nm[0] + ' "' + fr.title + '" ' + nm.slice(1).join(' '), 360, 545, { size: 32, maxW: 690, grad: ['#fff4b0', '#ffb300'] });
    spr('chimp_' + W2.color, 300, 598, 50);
    txt(W2.chimps + ' POKER CHIMPS', 400, 600, { size: 34, fill: W2.hex });
    if (d.done) {
      if (Math.random() < 0.08) C.money(Math.random() * 720, -10, 4, 3);
      C.panel(90, 640, 260, 52, { fill: '#1aa83a', r: 12 }); txt('PLAY AGAIN', 220, 667, { size: 32 });
      C.panel(370, 640, 260, 52, { fill: '#c41020', r: 12 }); txt('EXIT', 500, 667, { size: 32 });
      G.hit(90, 640, 260, 52, function () { G.advance(); });
      G.hit(370, 640, 260, 52, function () { G.exitGame(); });
    }
  };

  /* ================= RENDER LOOP ================= */
  var HUD_SCENES = { intro: 1, case: 1, paper: 1, numbers: 1, board: 1, war: 1, vault: 1, deeds: 1, getaway: 1, roundend: 1, ghost: 1, coin: 1 };
  function frame(now) {
    var dt = C.tick(now);
    C.musicTick();
    ctx.setTransform(C.scale * C.dpr, 0, 0, C.scale * C.dpr, 0, 0);
    ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = 'high';
    G.hits = [];
    var sc = G.scene, t = C.now() - sc.t0;
    try {
      (R[sc.name] || R.boot)(t, sc.d);
      

      C.drawParts(dt);
    } catch (e) { if (!G._err) { G._err = 1; console.error(e); } }
    if (G.paused) {
      G.hits = [];
      ctx.fillStyle = 'rgba(0,0,0,0.75)'; ctx.fillRect(0, 0, W, H);
      txt('PAUSED', 360, 240, { size: 80, fill: '#ffd21f' });
      ['RESUME', 'EXIT TO ARCADIUM'].forEach(function (s, i) {
        var y = 340 + i * 90;
        C.panel(180, y, 360, 70, { fill: G.menu === i ? '#c41020' : '#222', r: 12, glow: G.menu === i ? '#ff2b3a' : null });
        txt(s, 360, y + 35, { size: 34 });
        G.hit(180, y, 360, 70, function () { if (i === 0) G.setPause(false); else G.exitGame(); });
      });
      txt('P / ESC resume  -  M music  -  N sound  -  F auto-answer stuck seats', 360, 560, { size: 16, font: 'b', stroke: 3 });
    }
    requestAnimationFrame(frame);
  }
  G.R = R;
  requestAnimationFrame(frame);
})();

