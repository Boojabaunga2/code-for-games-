
/* DIRTY DEEDS big screen: canvas, clock, assets, drawing helpers, particles, audio. */
(function () {
  'use strict';
  var W = 720, H = 720;
  var cv = document.getElementById('cv');
  var ctx = cv.getContext('2d');
  var C = window.C = { W: W, H: H, cv: cv, ctx: ctx, img: {}, scale: 1, ox: 0, oy: 0 };

  /* ---------- sizing: 720x720 logical, letterboxed to any window ---------- */
  function resize() {
    var dpr = Math.min(window.devicePixelRatio || 1, 2);
    var box=document.getElementById('scene-stage').getBoundingClientRect();var vw=box.width,vh=box.height;
    var s = Math.min(vw / W, vh / H);
    cv.style.width = Math.floor(W * s) + 'px';
    cv.style.height = Math.floor(H * s) + 'px';
    cv.style.left = Math.floor(box.left + (vw - W * s) / 2) + 'px';
    cv.style.top = Math.floor(box.top + (vh - H * s) / 2) + 'px';
    cv.width = Math.floor(W * s * dpr);
    cv.height = Math.floor(H * s * dpr);
    C.scale = s; C.dpr = dpr; C.ox = box.left+(vw-W*s)/2; C.oy=box.top+(vh-H*s)/2;
  }
  window.addEventListener('resize', resize);
  resize();
  C.toLogical = function (cx, cy) { return { x: (cx - C.ox) / C.scale, y: (cy - C.oy) / C.scale }; };

  /* ---------- game clock (stops while paused) ---------- */
  var clock = { t: 0, last: 0, paused: false, waits: [] };
  C.clock = clock;
  C.now = function () { return clock.t; };
  C.wait = function (ms) {
    return new Promise(function (res) { clock.waits.push({ at: clock.t + ms, res: res }); });
  };
  C.tick = function (realNow) {
    var dt = clock.last ? Math.min(100, realNow - clock.last) : 16;
    clock.last = realNow;
    if (!clock.paused) clock.t += dt * (clock.speed || 1);
    var keep = [];
    for (var i = 0; i < clock.waits.length; i++) {
      var w = clock.waits[i];
      if (clock.t >= w.at) w.res(); else keep.push(w);
    }
    clock.waits = keep;
    return dt;
  };

  /* ---------- assets ---------- */
  C.load = function (onProgress) {
    var A = window.DD_ASSETS || {};
    var names = Object.keys(A), done = 0;
    return new Promise(function (resolve) {
      if (!names.length) resolve();
      names.forEach(function (n) {
        var im = new Image();
        im.onload = im.onerror = function () {
          done++;
          if (onProgress) onProgress(done / names.length);
          if (done === names.length) resolve();
        };
        im.src = A[n];
        C.img[n] = im;
      });
    });
  };
  function ok(im) { return im && im.complete && im.naturalWidth > 0; }
  C.ok = function (n) { return ok(C.img[n]); };

  /* draw sprite centred at (x,y) with height h (keeps aspect). opts: flip, alpha, rot, filter, w */
  C.spr = function (name, x, y, h, o) {
    var im = C.img[name];
    if (!ok(im)) return;
    o = o || {};
    var w = o.w || h * im.naturalWidth / im.naturalHeight;
    if (o.w && !h) h = w * im.naturalHeight / im.naturalWidth;
    ctx.save();
    ctx.translate(x, y);
    if (o.rot) ctx.rotate(o.rot);
    if (o.flip) ctx.scale(-1, 1);
    if (o.alpha !== undefined) ctx.globalAlpha *= o.alpha;
    if (o.filter) ctx.filter = o.filter;
    ctx.drawImage(im, -w / 2, -h / 2, w, h);
    ctx.restore();
  };
  /* draw image to cover a rect */
  C.cover = function (name, x, y, w, h, o) {
    var im = C.img[name];
    if (!ok(im)) return;
    o = o || {};
    var s = Math.max(w / im.naturalWidth, h / im.naturalHeight) * (o.zoom || 1);
    var sw = w / s, sh = h / s;
    var sx = (im.naturalWidth - sw) * (o.ax === undefined ? 0.5 : o.ax), sy = (im.naturalHeight - sh) * (o.ay === undefined ? 0.5 : o.ay);
    ctx.save();
    if (o.alpha !== undefined) ctx.globalAlpha *= o.alpha;
    if (o.filter) ctx.filter = o.filter;
    ctx.drawImage(im, sx, sy, sw, sh, x, y, w, h);
    ctx.restore();
  };

  /* ---------- easing ---------- */
  var E = C.ease = {
    lin: function (t) { return t; },
    out: function (t) { return 1 - Math.pow(1 - t, 3); },
    inn: function (t) { return t * t * t; },
    io: function (t) { return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2; },
    back: function (t) { var c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2); },
    elastic: function (t) { if (t === 0 || t === 1) return t; return Math.pow(2, -10 * t) * Math.sin((t * 10 - 0.75) * (2 * Math.PI / 3)) + 1; }
  };
  C.k = function (t, a, b) { return Math.max(0, Math.min(1, (t - a) / (b - a))); }; /* progress of t between a and b */
  C.lerp = function (a, b, t) { return a + (b - a) * t; };

  /* ---------- text ---------- */
  C.FONT_H = 'Bangers, Impact, sans-serif';
  C.FONT_B = 'Oswald, "Arial Narrow", sans-serif';
  C.txt = function (s, x, y, o) {
    o = o || {};
    var size = o.size || 24;
    ctx.save();
    ctx.font = (o.bold === false ? '' : (o.font === 'b' ? '700 ' : '')) + size + 'px ' + (o.font === 'b' ? C.FONT_B : C.FONT_H);
    ctx.textAlign = o.align || 'center';
    ctx.textBaseline = o.base || 'middle';
    if (o.alpha !== undefined) ctx.globalAlpha *= o.alpha;
    if (o.maxW) {
      var mw = ctx.measureText(s).width;
      if (mw > o.maxW) { size = Math.floor(size * o.maxW / mw); ctx.font = (o.font === 'b' ? '700 ' : '') + size + 'px ' + (o.font === 'b' ? C.FONT_B : C.FONT_H); }
    }
    if (o.rot) { ctx.translate(x, y); ctx.rotate(o.rot); x = 0; y = 0; }
    if (o.ls) { try { ctx.letterSpacing = o.ls + 'px'; } catch (e) { } }
    if (o.glow) { ctx.shadowColor = o.glow; ctx.shadowBlur = o.glowB || 18; }
    var sw = o.stroke === undefined ? Math.max(3, size * 0.16) : o.stroke;
    if (sw) {
      ctx.lineJoin = 'round';
      ctx.lineWidth = sw;
      ctx.strokeStyle = o.sc || '#000';
      if (o.shadow !== false) { ctx.save(); ctx.translate(size * 0.06, size * 0.08); ctx.strokeText(s, x, y); ctx.fillStyle = o.sc || '#000'; ctx.fillText(s, x, y); ctx.restore(); }
      ctx.strokeText(s, x, y);
    }
    ctx.shadowBlur = 0;
    if (o.grad) {
      var g = ctx.createLinearGradient(0, y - size / 2, 0, y + size / 2);
      g.addColorStop(0, o.grad[0]); g.addColorStop(1, o.grad[1]);
      ctx.fillStyle = g;
    } else ctx.fillStyle = o.fill || '#fff';
    ctx.fillText(s, x, y);
    ctx.restore();
    return size;
  };
  C.wrap = function (s, x, y, maxW, lh, o) {
    o = o || {};
    ctx.save();
    ctx.font = (o.font === 'b' ? '700 ' : '') + (o.size || 18) + 'px ' + (o.font === 'b' ? C.FONT_B : C.FONT_H);
    var words = String(s).split(' '), lines = [], cur = '';
    words.forEach(function (w) {
      var t = cur ? cur + ' ' + w : w;
      if (ctx.measureText(t).width > maxW && cur) { lines.push(cur); cur = w; } else cur = t;
    });
    if (cur) lines.push(cur);
    ctx.restore();
    var y0 = y - (lines.length - 1) * lh / 2;
    lines.forEach(function (l, i) { C.txt(l, x, y0 + i * lh, o); });
    return lines.length;
  };

  /* ---------- shapes ---------- */
  C.rr = function (x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
  };
  /* comic panel: thick black outline, offset shadow, optional colour glow */
  C.panel = function (x, y, w, h, o) {
    o = o || {};
    ctx.save();
    if (o.rot) { ctx.translate(x + w / 2, y + h / 2); ctx.rotate(o.rot); x = -w / 2; y = -h / 2; }
    if (o.alpha !== undefined) ctx.globalAlpha *= o.alpha;
    var r = o.r === undefined ? 10 : o.r;
    C.rr(x + 5, y + 6, w, h, r); ctx.fillStyle = 'rgba(0,0,0,0.55)'; ctx.fill();
    if (o.glow) { ctx.shadowColor = o.glow; ctx.shadowBlur = o.glowB || 22; }
    C.rr(x, y, w, h, r);
    if (o.grad) {
      var g = ctx.createLinearGradient(0, y, 0, y + h);
      g.addColorStop(0, o.grad[0]); g.addColorStop(1, o.grad[1]); ctx.fillStyle = g;
    } else ctx.fillStyle = o.fill || '#1b1230';
    ctx.fill();
    ctx.shadowBlur = 0;
    ctx.lineWidth = o.lw || 4; ctx.strokeStyle = o.stroke || '#000'; ctx.stroke();
    if (o.inner) { C.rr(x + 5, y + 5, w - 10, h - 10, Math.max(2, r - 4)); ctx.lineWidth = 2; ctx.strokeStyle = o.inner; ctx.stroke(); }
    ctx.restore();
  };
  /* star burst ("POW!" shape) */
  C.burst = function (x, y, r, o) {
    o = o || {};
    var n = o.n || 14, rot = o.rot || 0;
    ctx.save(); ctx.translate(x, y); ctx.rotate(rot);
    if (o.alpha !== undefined) ctx.globalAlpha *= o.alpha;
    ctx.beginPath();
    for (var i = 0; i < n * 2; i++) {
      var rr = i % 2 ? r * (o.inner || 0.62) : r * (0.92 + 0.16 * ((i * 7) % 3) / 2);
      var a = i / (n * 2) * Math.PI * 2;
      ctx[i ? 'lineTo' : 'moveTo'](Math.cos(a) * rr, Math.sin(a) * rr);
    }
    ctx.closePath();
    ctx.fillStyle = o.fill || '#ffd21f'; ctx.fill();
    ctx.lineWidth = o.lw || 5; ctx.strokeStyle = o.stroke || '#000'; ctx.stroke();
    ctx.restore();
  };
  C.rays = function (x, y, r, t, col, n) {
    ctx.save(); ctx.translate(x, y); ctx.rotate(t);
    ctx.fillStyle = col || 'rgba(255,210,31,0.18)';
    n = n || 16;
    for (var i = 0; i < n; i++) {
      ctx.beginPath(); ctx.moveTo(0, 0);
      var a = i / n * Math.PI * 2, b = a + Math.PI / n;
      ctx.lineTo(Math.cos(a) * r, Math.sin(a) * r); ctx.lineTo(Math.cos(b) * r, Math.sin(b) * r); ctx.closePath(); ctx.fill();
    }
    ctx.restore();
  };
  C.vignette = function (a) {
    var g = ctx.createRadialGradient(W / 2, H / 2, W * 0.25, W / 2, H / 2, W * 0.75);
    g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(0,0,0,' + (a || 0.75) + ')');
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
  };
  /* halftone dot overlay */
  var ht = document.createElement('canvas'); ht.width = ht.height = 12;
  (function () { var c = ht.getContext('2d'); c.fillStyle = 'rgba(0,0,0,0.35)'; c.beginPath(); c.arc(3, 3, 1.8, 0, 7); c.arc(9, 9, 1.8, 0, 7); c.fill(); })();
  var htPat = null;
  C.halftone = function (x, y, w, h, a) {
    if (!htPat) htPat = ctx.createPattern(ht, 'repeat');
    ctx.save(); ctx.globalAlpha = a || 0.5; ctx.fillStyle = htPat; ctx.fillRect(x, y, w, h); ctx.restore();
  };
  C.arrow = function (x1, y1, x2, y2, col, wdt, bend) {
    var mx = (x1 + x2) / 2 - (y2 - y1) * (bend || 0.2), my = (y1 + y2) / 2 + (x2 - x1) * (bend || 0.2);
    ctx.save();
    ctx.lineCap = 'round';
    [['#000', wdt + 6], [col, wdt]].forEach(function (s) {
      ctx.strokeStyle = s[0]; ctx.lineWidth = s[1];
      ctx.beginPath(); ctx.moveTo(x1, y1); ctx.quadraticCurveTo(mx, my, x2, y2); ctx.stroke();
    });
    var a = Math.atan2(y2 - my, x2 - mx);
    ctx.translate(x2, y2); ctx.rotate(a);
    ctx.beginPath(); ctx.moveTo(6, 0); ctx.lineTo(-wdt * 2.4, -wdt * 1.8); ctx.lineTo(-wdt * 2.4, wdt * 1.8); ctx.closePath();
    ctx.fillStyle = col; ctx.fill(); ctx.lineWidth = 3; ctx.strokeStyle = '#000'; ctx.stroke();
    ctx.restore();
  };
  C.chip = function (x, y, n, col, size) { /* small chimp + count */
    size = size || 28;
    C.spr('chimp_' + col, x, y, size);
    C.txt(String(n), x + size * 0.55, y + size * 0.3, { size: size * 0.6, align: 'left' });
  };

  /* ---------- particles ---------- */
  var parts = [];
  C.parts = parts;
  C.emit = function (p) { p.t0 = clock.t; parts.push(p); };
  C.money = function (x, y, n, spread) {
    for (var i = 0; i < n; i++) {
      var a = Math.random() * Math.PI * 2, v = 2 + Math.random() * (spread || 6);
      C.emit({ k: Math.random() < 0.5 ? 'bill' : 'coin', x: x, y: y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 5, g: 0.25, life: 1600 + Math.random() * 900, rot: Math.random() * 6, vr: (Math.random() - 0.5) * 0.3 });
    }
  };
  C.confetti = function (n) {
    var cols = ['#ff2b3a', '#2f7bff', '#22d14a', '#ffd21f', '#ff3fd0', '#ffffff'];
    for (var i = 0; i < n; i++) C.emit({ k: 'conf', x: Math.random() * W, y: -20 - Math.random() * 200, vx: (Math.random() - 0.5) * 2, vy: 2 + Math.random() * 3, g: 0.02, life: 5000, rot: Math.random() * 6, vr: (Math.random() - 0.5) * 0.4, c: cols[i % 6] });
  };
  C.puff = function (x, y, n, dark) {
    for (var i = 0; i < n; i++) C.emit({ k: 'puff', x: x + (Math.random() - 0.5) * 30, y: y + (Math.random() - 0.5) * 20, vx: (Math.random() - 0.5) * 2, vy: -Math.random() * 1.5, g: 0, life: 900 + Math.random() * 500, s: 40 + Math.random() * 40, dark: dark, f: 1 + (i % 4) });
  };
  C.spark = function (x, y, n, col) {
    for (var i = 0; i < n; i++) { var a = Math.random() * 7, v = 3 + Math.random() * 6; C.emit({ k: 'spark', x: x, y: y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, g: 0.15, life: 500 + Math.random() * 400, c: col || '#ffd21f' }); }
  };
  C.flyChimp = function (x1, y1, x2, y2, col, delay) { C.emit({ k: 'fly', x1: x1, y1: y1, x2: x2, y2: y2, col: col, life: 900, delay: delay || 0 }); };
  C.drawParts = function (dt) {
    var f = dt / 16.7;
    for (var i = parts.length - 1; i >= 0; i--) {
      var p = parts[i], age = clock.t - p.t0;
      if (age > p.life + (p.delay || 0)) { parts.splice(i, 1); continue; }
      var lt = age / p.life;
      ctx.save();
      if (p.k === 'fly') {
        var u = C.k(age - (p.delay || 0), 0, p.life);
        if (u <= 0) { ctx.restore(); continue; }
        var e = E.io(u);
        var x = C.lerp(p.x1, p.x2, e), y = C.lerp(p.y1, p.y2, e) - Math.sin(e * Math.PI) * 90;
        C.spr('chimp_' + p.col, x, y, 34, { rot: e * 6 });
        ctx.restore(); continue;
      }
      p.vy += p.g * f; p.x += p.vx * f; p.y += p.vy * f; if (p.rot !== undefined) p.rot += (p.vr || 0) * f;
      ctx.globalAlpha = Math.min(1, (1 - lt) * 2);
      if (p.k === 'bill') { ctx.translate(p.x, p.y); ctx.rotate(p.rot); ctx.fillStyle = '#2bb34a'; ctx.fillRect(-11, -6, 22, 12); ctx.strokeStyle = '#0b4d1c'; ctx.lineWidth = 2; ctx.strokeRect(-11, -6, 22, 12); ctx.fillStyle = '#bff5c9'; ctx.fillRect(-3, -3, 6, 6); }
      else if (p.k === 'coin') { ctx.translate(p.x, p.y); ctx.scale(Math.abs(Math.cos(p.rot * 2)), 1); ctx.beginPath(); ctx.arc(0, 0, 7, 0, 7); ctx.fillStyle = '#ffd21f'; ctx.fill(); ctx.lineWidth = 2; ctx.strokeStyle = '#8a5b00'; ctx.stroke(); }
      else if (p.k === 'conf') { ctx.translate(p.x, p.y); ctx.rotate(p.rot); ctx.fillStyle = p.c; ctx.fillRect(-5, -3, 10, 6); }
      else if (p.k === 'spark') { ctx.fillStyle = p.c; ctx.beginPath(); ctx.arc(p.x, p.y, 3 * (1 - lt) + 1, 0, 7); ctx.fill(); }
      else if (p.k === 'puff') { C.spr(p.dark ? 'fx_smokeblack' : 'fx_dust' + p.f, p.x, p.y, p.s * (0.6 + lt), { alpha: 1 - lt }); }
      ctx.restore();
    }
  };

  /* ---------- audio (synthesised, no files) ---------- */
  var A = C.audio = { ctx: null, on: true, music: true, master: null, mus: null };
  A.init = function () {
    if (A.ctx) { if (A.ctx.state === 'suspended') A.ctx.resume(); return; }
    try {
      A.ctx = new (window.AudioContext || window.webkitAudioContext)();
      A.master = A.ctx.createGain(); A.master.gain.value = 0.55; A.master.connect(A.ctx.destination);
      A.mus = A.ctx.createGain(); A.mus.gain.value = 0.22; A.mus.connect(A.master);
      var len = A.ctx.sampleRate;
      A.noiseBuf = A.ctx.createBuffer(1, len, A.ctx.sampleRate);
      var d = A.noiseBuf.getChannelData(0); for (var i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    } catch (e) { A.ctx = null; }
  };
  function tone(type, f1, f2, dur, vol, when, dest) {
    if (!A.ctx || !A.on) return;
    var t = A.ctx.currentTime + (when || 0);
    var o = A.ctx.createOscillator(), g = A.ctx.createGain();
    o.type = type; o.frequency.setValueAtTime(f1, t);
    if (f2) o.frequency.exponentialRampToValueAtTime(f2, t + dur);
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + 0.01); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(dest || A.master); o.start(t); o.stop(t + dur + 0.05);
  }
  function noise(dur, vol, f, q, when, type) {
    if (!A.ctx || !A.on) return;
    var t = A.ctx.currentTime + (when || 0);
    var s = A.ctx.createBufferSource(); s.buffer = A.noiseBuf;
    var bf = A.ctx.createBiquadFilter(); bf.type = type || 'bandpass'; bf.frequency.value = f || 1000; bf.Q.value = q || 1;
    var g = A.ctx.createGain(); g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(bf); bf.connect(g); g.connect(A.master); s.start(t, Math.random() * 0.5); s.stop(t + dur + 0.05);
  }
  C.sfx = function (n) {
    if (!A.ctx) return;
    switch (n) {
      case 'click': tone('square', 900, 600, 0.05, 0.08); break;
      case 'dice': for (var i = 0; i < 5; i++) noise(0.05, 0.4, 2500 + i * 300, 3, i * 0.06 + Math.random() * 0.03); break;
      case 'hop': tone('triangle', 300, 520, 0.09, 0.2); break;
      case 'cash': tone('square', 1318, 0, 0.08, 0.12); tone('square', 1760, 0, 0.25, 0.12, 0.07); noise(0.15, 0.25, 6000, 1, 0.05); break;
      case 'whoosh': noise(0.4, 0.4, 800, 0.8, 0, 'lowpass'); tone('sine', 200, 900, 0.35, 0.05); break;
      case 'boom': tone('sine', 120, 30, 0.6, 0.6); noise(0.5, 0.6, 300, 0.5, 0, 'lowpass'); break;
      case 'hit': tone('square', 220, 60, 0.18, 0.25); noise(0.15, 0.5, 1200, 1); break;
      case 'siren': for (var j = 0; j < 3; j++) { tone('sawtooth', 640, 940, 0.45, 0.07, j * 0.9); tone('sawtooth', 940, 640, 0.45, 0.07, j * 0.9 + 0.45); } break;
      case 'alarm': for (var k = 0; k < 6; k++) tone('square', 880, 0, 0.18, 0.1, k * 0.32); break;
      case 'good': [523, 659, 784, 1046].forEach(function (f, x) { tone('triangle', f, 0, 0.25, 0.18, x * 0.08); }); break;
      case 'bad': [392, 370, 349, 262].forEach(function (f, x) { tone('sawtooth', f, f * 0.97, 0.3, 0.1, x * 0.22); }); break;
      case 'drum': for (var m = 0; m < 14; m++) noise(0.06, 0.18 + m * 0.02, 1800, 1, m * 0.07); break;
      case 'stamp': noise(0.12, 0.7, 500, 0.7, 0, 'lowpass'); tone('sine', 90, 40, 0.2, 0.5); break;
      case 'laser': tone('sawtooth', 1400, 200, 0.2, 0.08); break;
      case 'ghost': tone('sine', 300, 600, 0.8, 0.12); tone('sine', 450, 900, 0.8, 0.08, 0.1); break;
      case 'lock': tone('square', 500, 0, 0.05, 0.1); tone('square', 750, 0, 0.08, 0.1, 0.06); break;
      case 'screech': noise(0.6, 0.35, 3000, 6); tone('sawtooth', 1200, 900, 0.5, 0.04); break;
    }
  };
  /* noir walking-bass loop */
  var mus = { on: false, next: 0, step: 0 };
  var BASS = [55, 65.4, 73.4, 82.4, 87.3, 82.4, 73.4, 65.4, 49, 58.3, 65.4, 73.4, 77.8, 73.4, 65.4, 58.3];
  C.musicTick = function () {
    if (!A.ctx || !A.on || !A.music || clock.paused) return;
    var t = A.ctx.currentTime;
    if (mus.next < t) mus.next = t + 0.05;
    while (mus.next < t + 0.3) {
      var f = BASS[mus.step % 16];
      var o = A.ctx.createOscillator(), g = A.ctx.createGain();
      o.type = 'triangle'; o.frequency.value = f * 2;
      g.gain.setValueAtTime(0.0001, mus.next); g.gain.exponentialRampToValueAtTime(0.5, mus.next + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, mus.next + 0.32);
      o.connect(g); g.connect(A.mus); o.start(mus.next); o.stop(mus.next + 0.4);
      var s = A.ctx.createBufferSource(); s.buffer = A.noiseBuf;
      var hp = A.ctx.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = 7000;
      var hg = A.ctx.createGain(); var hv = mus.step % 2 ? 0.12 : 0.22;
      hg.gain.setValueAtTime(hv, mus.next); hg.gain.exponentialRampToValueAtTime(0.0001, mus.next + 0.06);
      s.connect(hp); hp.connect(hg); hg.connect(A.mus); s.start(mus.next, Math.random() * 0.5); s.stop(mus.next + 0.08);
      mus.step++; mus.next += mus.step % 2 ? 0.24 : 0.13; /* swing */
    }
  };
})();

