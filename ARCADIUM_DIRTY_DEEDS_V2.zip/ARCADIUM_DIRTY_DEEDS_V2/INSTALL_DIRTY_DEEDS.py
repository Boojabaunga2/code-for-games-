from pathlib import Path
import json,tkinter as tk
from tkinter import filedialog
from update_dirty_deeds import install,rollback
ui=tk.Tk();ui.title('Arcadium / Dirty Deeds: The Numbers Racket');ui.geometry('750x430');status=tk.StringVar(value='Dirty Deeds: private Mini Vibe plans, real D10 entry, Poker Chimp transfers and Ghost Boss powers. Existing shared controller app. No new APK. Select Arcadium_OS_COMPACT.')
tk.Label(ui,text='DIRTY DEEDS / PRIVATE PLANS. REAL DICE.',font=('Segoe UI',15,'bold')).pack(pady=20);tk.Label(ui,textvariable=status,wraplength=700,justify='left',font=('Segoe UI',12)).pack(padx=20,pady=20)
def run():
 folder=filedialog.askdirectory(title='Select your existing Arcadium_OS_COMPACT folder')
 if not folder:return
 try:
  backup=install(Path(folder));Path(__file__).with_name('DIRTY_DEEDS_RECEIPT.json').write_text(json.dumps({'backup':str(backup)},indent=2));status.set('Installed. Backup: '+str(backup)+'\n\nRestart Windows once, then launch Dirty Deeds. Ready each Mini Vibe; turn unused seats OFF or explicitly CPU in the lobby. Enter real D10 results. D-pad navigates and edits digits; A selects/reviews/confirms, B corrects. Physical Poker Chimp moves stay visible in the ledger. Ghosts choose a private power each round. No APK or separate relay.\n\nReal Mini Vibe / LAN acceptance still needed.')
 except Exception as e:status.set('Stopped: '+str(e))
def undo():
 folder=filedialog.askdirectory(title='Select the dirty_deeds_v1_* backup')
 if not folder:return
 try:rollback(Path(folder));status.set('Previous Dirty Deeds: The Numbers Racket restored. Restart Windows once.')
 except Exception as e:status.set('Rollback stopped: '+str(e))
tk.Button(ui,text='INSTALL DIRTY DEEDS',command=run,padx=20,pady=12).pack(pady=8);tk.Button(ui,text='Rollback this update',command=undo).pack();ui.mainloop()
