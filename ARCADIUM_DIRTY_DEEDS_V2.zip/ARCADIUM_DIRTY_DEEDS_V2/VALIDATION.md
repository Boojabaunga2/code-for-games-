# Validation

Pure rules/private decisions: `node integrations/dirty-deeds/tests/engine.test.cjs`.
Build: `python integrations/dirty-deeds/build_package.py`.
Installer/contracts/transport: `python -m unittest discover -s integrations/dirty-deeds/tests -p 'test_*.py'`.
Harness: `python integrations/dirty-deeds/tests/harness.py --server-reference PATH_TO_ORIGINAL_arcadium_server.py`.
Browser: `NODE_PATH=/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules node integrations/dirty-deeds/tests/browser.cjs`.

Rules tests run 50 seeded five-round heists and assert conservation of all 120 Poker Chimps, zero/ten interpretation, fresh round inputs, RPS antisymmetry, crew wars, vault/deeds/getaways, ghost plans/protection/security/heat, final rankings and private review/correction. Original engine bytes and native reader are checked against the supplied game/prior shared platform.

The browser harness loads the original physical controller receiver and sends synthetic I1/reliable-action packets through the actual HTTP paths. Six separate private pages render real personal JPEG views. Checks include continuous/released D-pad menus, double-channel action safety, touch selection, review/correction/locking, no early table reveal, explicit tool dice, pause and lost-heartbeat stopping. Full five-round director coverage accelerates the clock and supplies deterministic, clearly labelled test-only physical roll/coin/choice fixtures via the existing answer validator. It does not claim actual physical dice were rolled. Ghost choice targets/review and replay are checked. Public/private rendering must complete without script errors, and the lease hands off to seven preceding games.

Python tests exercise exact extracted ZIP installation, checksums/corruption rejection, repeat install/rollback/later-edit protection, original rules and shared reader preservation, unrelated catalogue/art/pairing/files preservation, six private frame routes, scoped touch tokens, stale frames, per-question epochs and owner handoff.

Windows-only CI verifies the actual CMD launcher with existing Python/Tk from a path containing spaces and an ampersand, and scans the exact archive plus extracted files with enabled Microsoft Defender. No exclusions or disabled protections are used. Successful runner scans do not guarantee another PC's antivirus acceptance. Real physical Mini Vibes/LAN, seat reconnect behavior, device rendering latency, physical Poker Chimp accounting and balance remain venue acceptance work. review/delivery.json records final hashes and CI results.

V2 security validation corrects the known default-runner gap: all relevant protections must be verified on before scanning, including cloud. V1's prior scan claims are inconclusive, not evidence against the recipient detection. V2 also exercises Windows IAttachmentExecute policy/Save scanning without calling Execute. This is an automated Windows Server comparison, not a manual Microsoft review verdict or a recipient Windows-client test. User explicitly authorized Microsoft analysis during the investigation.
