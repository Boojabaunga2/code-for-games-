# Dirty Deeds: The Numbers Racket — Arcadium overhaul

Extract the whole ZIP. Double-click **START_INSTALL.cmd**, select the existing **Arcadium_OS_COMPACT**, then restart Windows once. Launch Dirty Deeds from its carousel card. Keep your existing universal Mini Vibe app and pairing: **no new APK**. Existing Python/Tk and Shared Mini Vibe Controls PC platform are required. This update downloads no software, changes no Windows security setting and runs no separate relay server.

## This is a physical tabletop heist

Three to six bosses play five rounds. Each starts with **20 actual Poker Chimps**, three tool D10s and a colored Dirty Die. Crew wars can use the physical **RoshamboMoWo die** or a D10; choose the table's war die in the PC lobby. Enter what you actually rolled. D10 **0 counts as 10** for movement, successes, fights and escape, but remains the digit **0** when arranging a three-digit number. Decision-coin tie-breaks are flipped in real life and the host selects the actual winner/loser on the TV.

The new dashboard replaces the old square-only presentation with six boss dossiers, a central animated heist stage, vault bank, colored heat indicators, connection/lock status and a persistent ledger. Follow the ledger and each Mini Vibe's payment notice to move the real Poker Chimps. The engine conserves every chimp between players and vault.

## Getting the crew ready

All six seats initially require human readiness. A / START on a connected Mini Vibe advances the title; select and confirm READY on each active player's screen. Use **CHANGE SEAT** on a TV boss card to cycle HUMAN → explicitly labelled CPU DEMO → OFF. Set unused seats OFF. At least three active seats are required. The host's LAUNCH HEIST button enables only after every human seat is ready. CONTINUE skips the instructions or starts the next match when available; it never auto-fills a human's dice or skips unresolved choices.

CPU seats explicitly simulate choices and rolls for demonstration. The original human auto-answer shortcut and URL-based automatic test play are disabled. Human dice are never generated for a disconnected or waiting seat.

## Each Mini Vibe is a private dossier

- Hold the D-pad to navigate menus with repeat; release stops. Up/down changes the selected digit, left/right chooses a digit column. Native input freshness and touch heartbeats expire after 650 ms, preventing a stuck direction.
- **A** selects, opens review, then locks the reviewed choice. **B** backs up for correction before locking. No touch option can silently commit a secret without review.
- **Shoulders** choose previous/next digit or menu option. **X** enters zero in the selected digit.
- For three tool D10s, enter all three using the number keypad or D-pad. Each value must be explicitly entered/acknowledged. Live number, target distance and vault-crack count help you arrange the physical dice. Review before confirming.
- **START** pauses/resumes an active heist; it advances the title and eligible host screens. SELECT also pauses. PC keyboard/pointer host controls and standard USB gamepads remain available.
- Touch supports choices, review/correction and held D-pad controls. Reconnection restores this player's current question. Touch tokens are bound to seat, IP, host owner and the individual question epoch; a different player's answer does not invalidate your pending touch.

Each player sees only their own choices, secret plan, crew/heat and transfer notices. The TV shows who is waiting or locked without revealing individual secret selections early.

## Five-round flow and Ghost Bosses

The supplied rules are preserved: case the joint with Sneak/Hack/Smash/Swindle, roll and arrange three D10s closest to the target, move around 24 city spaces, fight crew wars, crack the vault, secretly Grab/Lift/Frame/Double-Cross, then choose Floor It/Back Alleys/Lay Low for the getaway. Original heat, alarm, security, special spaces, last-crew battles, payoffs and end-game awards remain.

The poorest surviving crew becomes a **Ghost Boss** after a round while more than two living bosses remain. Ties use the actual decision coin. Ghosts still play the numbers and privately choose one plan each round:

- **Inside Job:** reduce vault security by one.
- **Fake ID:** add three heat to a living target before escape.
- **Phantom Fingers:** send up to two of a target's hot loot back to the vault.
- **Smoke Bomb:** protect a boss from crew wars and steals for that round.
- **Ghost Getaway:** add three to a target's escape result.

Powers fire at their original phase. A ghost may pass. Targets must be active living bosses. The final crown goes to a surviving boss after round five, with original tie-breaks, rankings and character awards.

## Preservation and validation

Installer adds only this game directory, its route helper, a recognized bridge wrapper and its own catalogue entry/art. Home, the main server, shared controller receiver, pairing and other games/cards remain. Backup: `arcadium_backups/dirty_deeds_v1_*`. Installer rollback refuses to overwrite later changes. Reinstallation is supported.

Original pure rules are byte-for-byte preserved as `js/engine.js`. Embedded source assets/fonts were extracted to ordinary local files. New illustrated cover/city art, TV layout, private controller renderer and current shared transport replace legacy presentation/relay packaging. Gumpy duplicates, old relay launchers and Python bytecode are not shipped.

See VALIDATION.md and repository review/ for automated evidence. Real Mini Vibes, LAN latency, physical dice/chimp reconciliation and venue play acceptance still require testing on your hardware. Windows runner Defender scans cannot guarantee acceptance on another PC: leave a locally blocked file blocked.

## V2 installer and antivirus investigation

V1 was withdrawn after recipient Wacatac/Sabisk-family alerts. Its earlier scan assurance was retracted: the hosted runner had script/archive/real-time/cloud protections disabled. Corrected scans verified these protections and cloud connectivity active, then scanned the original archives, extracted members and Windows attachment-save path without detecting a threat. That does not establish the recipient alert's cause or a Microsoft false-positive ruling.

V2 replaces directory-wide Python discovery/probing with the installed command-line interpreter or standard Python launcher, retains the Python/Tk preflight and exact payload checks, and downloads no dependencies. No game rules, graphics, shared input reader, Mini Vibe app or pairing changed. The release pipeline requires active script/archive/real-time/download/first-seen/cloud protections, fresh signatures and a working Microsoft connection. Archive, extracted-file and attachment-save checks are recorded for the exact V2 hash. Recipient acceptance is still unverified; keep Defender on and leave any blocked file blocked.
