# Validation

Rebuild: python integrations/barrel-bash/build_package.py

Unit/integration checks: python -m unittest discover -s integrations/barrel-bash/tests -p test_barrel_bash.py

Browser acceptance: run tests/harness.py with the exact original server-reference file, then tests/browser.cjs with Playwright Chromium. Checks use synthetic native/reliable packets through the existing full route chain; they are not physical-controller evidence. Cover six canonical colors, joining/launching, one throw per press, pause, real scoring collisions, unlimited throws, five rounds, ranking/ties/replay, six personal images, touch button routing, stale/replayed action rejection, game handoff and local assets. Original decoded artwork and the common native reader are hash-checked.

Exact ZIP installation/repeat/rollback, corrupt extraction, later-edit refusal, preserving other game files/card/custom metadata, scoped tokens, stale frames and bridge compatibility are also checked. Windows CMD launcher and enabled Defender archive/extracted/Internet-attachment checks are separate CI gates before delivery.

Limits: no six physical Mini Vibes or venue Wi-Fi available. Windows runner scans do not guarantee recipient antivirus acceptance or constitute a manual Microsoft verdict. Never bypass a block or add security exclusions.
