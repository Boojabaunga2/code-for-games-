from pathlib import Path
import json,tkinter as tk
from tkinter import filedialog
from update_barrel_bash import install,rollback
ui=tk.Tk();ui.title('Arcadium / Barrel Bash');ui.geometry('750x430');status=tk.StringVar(value='Barrel Bash: six spinning targets, five rounds and personal Mini Vibe crosshairs. Existing shared controller app. No new APK. Select Arcadium_OS_COMPACT.')
tk.Label(ui,text='BARREL BASH / TIME IT. THROW IT. OWN IT.',font=('Segoe UI',15,'bold')).pack(pady=20);tk.Label(ui,textvariable=status,wraplength=700,justify='left',font=('Segoe UI',12)).pack(padx=20,pady=20)
def run():
 folder=filedialog.askdirectory(title='Select your existing Arcadium_OS_COMPACT folder')
 if not folder:return
 try:
  backup=install(Path(folder));Path(__file__).with_name('BARREL_BASH_RECEIPT.json').write_text(json.dumps({'backup':str(backup)},indent=2));status.set('Installed. Backup: '+str(backup)+'\n\nRestart Windows once, then launch Barrel Bash. Press A or START on each Mini Vibe to join. Once joined, START launches. A throws once per press at your moving crosshair. START pauses and resumes. B shows your rules. Empty seats are CPU opponents. Highest total after five rounds wins. No APK or separate relay.\n\nReal Mini Vibe / LAN acceptance still needed.')
 except Exception as e:status.set('Stopped: '+str(e))
def undo():
 folder=filedialog.askdirectory(title='Select the barrel_bash_v1_* backup')
 if not folder:return
 try:rollback(Path(folder));status.set('Previous Barrel Bash restored. Restart Windows once.')
 except Exception as e:status.set('Rollback stopped: '+str(e))
tk.Button(ui,text='INSTALL BARREL BASH',command=run,padx=20,pady=12).pack(pady=8);tk.Button(ui,text='Rollback this update',command=undo).pack();ui.mainloop()
