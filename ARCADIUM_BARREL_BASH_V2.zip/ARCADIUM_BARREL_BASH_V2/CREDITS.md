Based on the user-supplied barrel-bash.zip. Original artwork, scoring geometry, wheel/aim timing, CPU logic, sounds and five-round rules retained. Embedded image assets are extracted byte-for-byte for offline use; tests/source-assets.json records their original hashes. Shared-controller integration, six personal simulation views, color mapping, pause/replay/lobby corrections and guarded packaging by Codex. No new APK or compiled installer.

V2: transparent append-only registration and standard Python launcher; no dynamic code compilation or interpreter discovery.
