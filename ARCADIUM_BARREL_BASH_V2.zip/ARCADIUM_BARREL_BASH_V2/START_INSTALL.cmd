@echo off
setlocal EnableExtensions DisableDelayedExpansion
title Arcadium Barrel Bash Setup
cd /d "%~dp0"
if not exist "INSTALL_BARREL_BASH.py" goto incomplete
if not exist "CHECKSUMS.json" goto incomplete
if not exist "games\barrel-bash\index.html" goto incomplete
rem Use the standard installed Python launcher. No searches, downloads or inline code.
py -3 "%~dp0INSTALL_BARREL_BASH.py"
if errorlevel 1 goto failed
exit /b 0
:incomplete
echo Extract the WHOLE ZIP first, then run START_INSTALL.cmd.
pause
exit /b 1
:failed
echo Setup stopped. Read the error above. Python 3.9+ with Tkinter is required.
echo You can also open INSTALL_BARREL_BASH.py with your installed Python.
pause
exit /b 1
