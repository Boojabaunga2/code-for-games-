import base64,importlib.util,json,sys,tempfile,threading,time,unittest,urllib.request,urllib.error,zipfile
from pathlib import Path
from http.server import ThreadingHTTPServer
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));import update_riotball as updater;import riotball_routes as routes
spec=importlib.util.spec_from_file_location('color_shared_reference',ROOT.parent/'universal-mini-vibe-input/tests/harness.py');ref=importlib.util.module_from_spec(spec);spec.loader.exec_module(ref)
class Install(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);r=self.root;(r/'data').mkdir()
  (r/'data/arcadium.json').write_text(json.dumps({'games':[{'id':'riotball','name':'Riotball','custom':'KEEP'},{'id':'sniper-kitty','image':'kitty.png','controls':'KEEP'},{'id':'final-cut','image':'final.png','controls':'KEEP VOTING'},{'id':'rc-trigger-racing','controls':'KEEP TEN LAPS'},{'id':'color-rush','controls':'IRL GHOSTS','image':'APPROVED'},{'id':'blocky-frogger','controls':'SHARED HOPS','image':'frog-approved.jpg'}],'activity':[]}))
  (r/'arcadium_server.py').write_text('import arcadium_game_bridge\n# server and pairing stay untouched\n')
  (r/'arcadium_game_bridge.py').write_text('import threading\nfrom e3mi_routes import wrap_e3mi_handler\nfrom universal_input_routes import wrap_native_input_handler\nfrom final_cut_routes import wrap_final_cut_handler\nfrom color_rush_routes import wrap_color_rush_handler\nfrom blocky_frogger_routes import wrap_blocky_frogger_handler\nfrom sniper_kitty_routes import wrap_sniper_kitty_handler\nACTIVE_WEB_GAME={"game":None,"until":0}\nACTIVE_LOCK=threading.RLock()\ndef bridge(Base):\n    class GameBridge(Base):pass\n    return wrap_blocky_frogger_handler(wrap_color_rush_handler(wrap_final_cut_handler(wrap_sniper_kitty_handler(wrap_native_input_handler(wrap_e3mi_handler(GameBridge))))))\n')
  (r/'e3mi_routes.py').write_text('def wrap_e3mi_handler(Base):return Base\n')
  for source,name in [('universal-mini-vibe-input','universal_input_routes.py'),('sniper-kitty','sniper_kitty_routes.py'),('final-cut','final_cut_routes.py'),('color-rush','color_rush_routes.py'),('blocky-frogger','blocky_frogger_routes.py')]:(r/name).write_bytes((ROOT.parent/source/name).read_bytes())
  for name,data in [('HOME.html',b'HOME'),('data/pink_vibe_device.json',b'PAIRING'),('games/wormaldeon/index.html',b'TENNIS'),('games/rc-trigger-racing/engine.mjs',b'TEN LAPS'),('games/sniper-kitty/shared-controller.js',b'WORKING KITTY'),('games/final-cut/shared-controller.js',b'WORKING VOTING')]:
   p=r/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 def tearDown(self):self.tmp.cleanup()
 def snap(self):return {p.relative_to(self.root).as_posix():p.read_bytes() for p in self.root.rglob('*') if p.is_file() and 'arcadium_backups' not in p.parts}
 def test_install_repeat_preserve_every_other_game_and_rollback(self):
  before=self.snap();one=updater.install(self.root);first=(self.root/'arcadium_game_bridge.py').read_bytes();two=updater.install(self.root);self.assertEqual(first,(self.root/'arcadium_game_bridge.py').read_bytes());cat=json.loads((self.root/'data/arcadium.json').read_text());old=json.loads(before['data/arcadium.json']);self.assertEqual(cat['games'][1:],old['games'][1:]);self.assertEqual(len(cat['games']),6);self.assertEqual(cat['games'][0]['custom'],'KEEP');self.assertEqual(cat['games'][0]['image'],'/games/riotball/card.svg');self.assertEqual(cat['games'][0]['miniVibeUrl'],'/games/riotball/personal-v1/vibe.html');updater.rollback(two);updater.rollback(one)
  for n,b in before.items():
   if n=='data/arcadium.json':self.assertEqual(json.loads((self.root/n).read_text()),json.loads(b))
   else:self.assertEqual((self.root/n).read_bytes(),b,n)
 def test_catalog_and_platform_guards(self):
  existing={'games':[{'id':'riotball','image':'APPROVED-existing.png'}]};updater.registration(existing);self.assertEqual(existing['games'][0]['image'],'APPROVED-existing.png');c={'games':[{'id':'other'}]};updater.registration(c);self.assertEqual(c['games'][1]['id'],'riotball');c['games'].append({'id':'copy','title':'Riotball'});self.assertRaises(RuntimeError,updater.registration,c)
  (self.root/'universal_input_routes.py').unlink();self.assertRaises(RuntimeError,updater.install,self.root);self.assertFalse((self.root/'games/riotball').exists())
 def test_exact_zip_repeat_and_later_edit_guard(self):
  path=ROOT.parents[1]/'downloads/ARCADIUM_RIOTBALL_V1.zip'
  with tempfile.TemporaryDirectory() as d:
   with zipfile.ZipFile(path) as z:self.assertFalse(any(n.endswith('.apk') for n in z.namelist()));self.assertIsNone(z.testzip());z.extractall(d)
   package=Path(d)/path.stem;spec=importlib.util.spec_from_file_location('color_exact',package/'update_riotball.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);one=m.install(self.root);two=m.install(self.root);m.rollback(two);m.rollback(one);(package/'games/riotball/shared-controller.js').write_text('corrupt');self.assertRaises(RuntimeError,m.install,self.root)
  one=updater.install(self.root);(self.root/'games/riotball/shared-controller.js').write_text('later work');self.assertRaises(RuntimeError,updater.rollback,one)
class Routes(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  bridge,Parent=ref.ref.harness.modules();cls.H=routes.wrap_riotball_handler(Parent)
  class Quiet(cls.H):
   def log_message(self,*args):pass
  cls.server=ThreadingHTTPServer(('127.0.0.1',0),Quiet);cls.server.events={'latest':0,'events':[],'slots':[]};cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True);cls.thread.start();cls.base='http://127.0.0.1:'+str(cls.server.server_port)
 @classmethod
 def tearDownClass(cls):cls.server.shutdown();cls.server.server_close();cls.thread.join()
 def req(self,path,data=None):
  try:
   with urllib.request.urlopen(urllib.request.Request(self.base+path,data=None if data is None else json.dumps(data).encode(),headers={'Content-Type':'application/json'})) as r:return r.status,r.read()
  except urllib.error.HTTPError as e:return e.code,e.read()
 def test_six_personal_routes_stale_frames_and_lease_handoff(self):
  self.req('/arcadium-vibe/activate/riotball',{'owner':'first'})
  for i,color in enumerate(routes.COLORS):
   mode=json.loads(self.req('/api/vibe/mode?color='+color)[1]);self.assertEqual(mode['page'],'/games/riotball/personal-v1/vibe.html');self.assertEqual(mode['nativeState'],1);image=b'\xff\xd8'+color.encode();self.assertEqual(self.req('/arcadium-riotball/riotball/frame',{'owner':'first','seat':i+1,'image':base64.b64encode(image).decode()})[0],200);self.assertEqual(self.req('/arcadium-riotball/riotball/frame?color='+color),(200,image))
  for path in ['index.html','shared-controller.js','shared-state.js','native-input.js','personal-v1/vibe.html','card.svg']:self.assertEqual(self.req('/games/riotball/'+path)[0],200,path)
  self.assertEqual(self.req('/games/riotball/%2e%2e/%2e%2e/update_riotball.py')[0],404);routes.FRAMES[1]=(time.monotonic()-4,b'old');self.assertEqual(self.req('/arcadium-riotball/riotball/frame?color=red')[0],503)
  self.req('/arcadium-vibe/activate/riotball',{'owner':'second'});self.assertEqual(self.req('/arcadium-riotball/riotball/frame?color=blue')[0],503);self.req('/arcadium-vibe/activate/riotball',{'owner':'first','active':False});self.assertEqual(json.loads(self.req('/api/vibe/mode?color=red')[1])['game'],'riotball');self.assertEqual(self.req('/arcadium-vibe/activate/riotball',{'owner':'first','renew':True})[0],409)
  self.req('/arcadium-vibe/activate/rc-trigger-racing',{});self.assertEqual(self.req('/arcadium-vibe/activate/riotball',{'owner':'second','renew':True})[0],409);self.req('/arcadium-vibe/activate/riotball',{'owner':'second','active':False});self.assertEqual(json.loads(self.req('/api/vibe/mode?color=red')[1])['game'],'rc-trigger-racing')
 def test_touch_color_token_sequence_stale_epoch_and_invalid_input(self):
  self.req('/arcadium-vibe/activate/riotball',{'owner':'touch'})
  def frame(pause=False):return self.req('/arcadium-riotball/riotball/frame',{'owner':'touch','seat':1,'image':base64.b64encode(b'\xff\xd8test').decode(),'state':{'phase':'play','turnId':'one','pause':pause}})
  self.assertEqual(frame()[0],200);base='/arcadium-riotball/riotball/touch/';token=json.loads(self.req(base+'session?color=green')[1])['token']
  def key(n=1,value='A',turn='one',tok=token):return self.req(base+'key',{'token':tok,'seq':n,'key':value,'turnId':turn})[0]
  self.assertEqual(key(tok='bad'),403);self.assertEqual(key(turn='old'),409);self.assertEqual(key(value='<script>'),400);self.assertEqual(key(n=True),400);self.assertEqual(key(value='M010'),200);self.assertEqual(key(value='M010'),200);events=json.loads(self.req(base+'events?after=0')[1])['events'];self.assertEqual(len(events),1);self.assertEqual(events[0]['color'],'green')
  frame(True);self.assertEqual(key(2,'START'),200,'Resume must remain available from touch');routes.UI_STATE['at']=time.monotonic()-3;self.assertEqual(key(3),409);self.req('/arcadium-vibe/activate/riotball',{'owner':'new'});self.assertEqual(key(4),403)
if __name__=='__main__':unittest.main()
