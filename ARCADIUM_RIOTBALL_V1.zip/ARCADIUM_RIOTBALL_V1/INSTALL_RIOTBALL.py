from pathlib import Path
import json,tkinter as tk
from tkinter import filedialog
from update_riotball import install,rollback
ui=tk.Tk();ui.title('Arcadium / Riotball');ui.geometry('750x430');status=tk.StringVar(value='Riotball shared held controls, charged shots and six personal player dashboards. Select your existing Arcadium_OS_COMPACT folder. Keep the current universal Mini Vibe app and pairing. No new APK.')
tk.Label(ui,text='RIOTBALL / SIX LIVE PLAYER DASHBOARDS',font=('Segoe UI',16,'bold')).pack(pady=20);tk.Label(ui,textvariable=status,wraplength=700,justify='left',font=('Segoe UI',12)).pack(padx=20,pady=20)
def run():
 folder=filedialog.askdirectory(title='Select your existing Arcadium_OS_COMPACT folder')
 if not folder:return
 try:
  backup=install(Path(folder));Path(__file__).with_name('RIOTBALL_RECEIPT.json').write_text(json.dumps({'backup':str(backup)},indent=2));status.set('Installed. Backup: '+str(backup)+'\n\nRestart Windows once, then launch Riotball. A enters/joins; START fills CPU seats. Hold D-pad to run. A taps a pass or holds/releases a charged shot; B tackles; X uses your special. B/X activates Poltergeist while knocked down. START pauses. No new APK.\n\nPhysical Mini Vibe acceptance is still needed.')
 except Exception as e:status.set('Stopped: '+str(e))
def undo():
 folder=filedialog.askdirectory(title='Select the riotball_v1_* backup')
 if not folder:return
 try:rollback(Path(folder));status.set('Previous Riotball restored. Restart Windows once.')
 except Exception as e:status.set('Rollback stopped: '+str(e))
tk.Button(ui,text='INSTALL RIOTBALL',command=run,padx=20,pady=12).pack(pady=8);tk.Button(ui,text='Rollback this update',command=undo).pack();ui.mainloop()
