# Riotball — Shared Mini Vibe Edition

Extract the entire ZIP. Double-click **START_INSTALL.cmd**, select **Arcadium_OS_COMPACT**, restart Windows once. Open Riotball in the carousel. Keep your existing universal Mini Vibe v16 app and pairing. **No APK included or required.** Requires the existing Shared Mini Vibe Controls PC platform.

## Same game, working shared controls

Preserves the supplied 3-vs-3 game, three 90-second matches, team reshuffles, individual Riot Points, special shots, riot events and brief knocked-down ghost powers. Characters and embedded artwork are retained. The pitch receives cleaner shaded turf in place of tiled grass. Existing carousel artwork is preserved; a self-contained original-logo fallback card is included for new registrations.

- A or START enters the lobby. A/X joins, B leaves. START fills unready slots with CPU.
- Hold D-pad to run, release to stop steering. Normal acceleration/braking and the ice/mud event physics still apply; no 260ms artificial nudge timer remains. Diagonal input is normalized.
- A taps a pass/quick kick. Hold A to charge; RELEASE fires. The raw universal reader retains even a fast press/release pair between render frames. Repeated held heartbeats do not fire duplicate kicks.
- B tackles; X/Y uses the color's special when energy is available.
- While knocked down/frozen, B/X/Y activates the existing Poltergeist power: brief stun of the nearest standing opponent, 24-second cooldown. This is a temporary downed ability, not elimination. Standing players cannot trigger it.
- START or Escape pauses/resumes in play/countdown. Tab changes pause and clear held inputs. Lost state heartbeat expires after 650ms; an expired A charge is cancelled instead of auto-firing a shot.

## Personal Mini Vibe dashboard

Real player close-up, ball radar and off-camera ball arrow; actual current team and attack direction; charge meter and named special-energy meter; tackle cooldown and session stats. New teams automatically update the personal display after each scramble.

During a knockdown, the dashboard switches to Poltergeist. A fast state-based B/X prompt appears independently of the camera refresh, using the real PC cooldown/state. It disappears after standing or using the power. No cosmetic ghost toggle or fake local simulation is used.

Touch can hold directions and A simultaneously with multiple pointers. B/X buttons are discrete actions. Release/cancel/blur stops held input, with a 650ms heartbeat expiry as backup. Touch controls and physical controls affect the same PC game.

## Preservation

Targeted installer backs up the old Riotball files, updates only its registration/game helper and adds one wrapper around the current shared bridge. Home, main server, native input platform, pairing, Color Rush IRL, Frogger and all other games are preserved. Reinstall is idempotent. Rollback checks for later work rather than overwriting it. Select the riotball_v1_* backup in the installer to undo.

Original keyboard keypads and USB gamepads remain supported. F2 opens the original developer tools; physical shared controllers do not need LuaMacros. No external runtime audio/art downloads are used.

Automated tests are described in VALIDATION.md. Acceptance with six real Mini Vibes and your venue LAN still remains.
