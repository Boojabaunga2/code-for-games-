# Credits

User-supplied riotball.zip provides the original single-file Riotball V2, six characters, sprite atlas, logo, game rules and original synthesis/audio. Artwork is retained byte-for-byte. The fallback card reuses the supplied logo. New code adds shared universal held controls, real charging, targeted integration and telemetry dashboards; no Android app code is changed.

No new third-party runtime libraries, movie/game databases or remote assets are introduced.
