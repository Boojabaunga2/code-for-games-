# Validation

State adapter: `node integrations/riotball/tests/state.test.cjs`.
Package: `python integrations/riotball/build_package.py`.
Python: `python -m unittest discover -s integrations/riotball/tests -p 'test_*.py'`.
Exact receiver: `python integrations/riotball/tests/harness.py --server-reference PATH_TO_ORIGINAL_arcadium_server.py`.
Browser: `NODE_PATH=/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules node integrations/riotball/tests/browser.cjs`.

Adapter checks all six held/released seats, direction changes/diagonal normalization, real A hold/release edges, fast taps, no repeated-heartbeat firing, lost-heartbeat charge cancellation, touch state and discrete impulses. Python tests check six feeds, game leases, stale frames, token/sequence validation, complete ZIP install/reinstall/rollback and preservation of prior games/pairing/artwork. Browser tests use the exact original PC input receiver and unchanged universal I1 reader, not six physical devices.

Physical Mini Vibe/LAN acceptance remains. Automated tests do not establish actual hardware latency, Bluetooth or antivirus results. Windows launcher and verified public ZIP results are recorded in repository review/delivery.json.

Completed: adapter PASS; original-gameplay contract hashes PASS; five Python route/installer tests PASS; full six-page Chromium suite PASS. Browser coverage includes all six held D-pads, real full-charge hold/release shot, touch movement, pause, live downed ghost prompt and cooldown, tackle/special, lost-heartbeat cancellation, all three original match transitions and team reshuffles (fixture-accelerated clocks), champion and handoff to four previous games. Ghost screenshots use a controlled extended knockdown fixture; they do not change the original short knockdown duration.
