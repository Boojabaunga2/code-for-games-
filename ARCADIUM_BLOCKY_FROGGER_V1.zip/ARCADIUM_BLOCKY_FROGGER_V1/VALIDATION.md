# Validation

Engine: `node integrations/blocky-frogger/tests/engine.test.cjs`.
Package: `python integrations/blocky-frogger/build_package.py`.
Python: `python -m unittest discover -s integrations/blocky-frogger/tests -p 'test_*.py'`.
Exact native-receiver harness: `python integrations/blocky-frogger/tests/harness.py --server-reference PATH_TO_ORIGINAL_arcadium_server.py`.
Browser: `NODE_PATH=/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules node integrations/blocky-frogger/tests/browser.cjs`.

Engine checks six held/released seats, direction changes, ghost movement and real slap, shield powers, revenge values and five-round elimination/champion. Route/installer checks include six individual feeds, stale frames, lease handoff, touch token/sequence validation, extracted ZIP installs/reinstalls/rollback and preservation of Home, pairing, Color Rush IRL and previous games. Browser tests use the exact original PC button receiver and unchanged raw native feed, not physical Mini Vibes.

Physical acceptance still required: six Mini Vibes, actual D-pad/shoulders/A/B/START, LAN frame delivery, GoDice Bluetooth pairing/roll/pivot and original Revenge Roll behavior. No physical-hardware or antivirus scan result is claimed. Windows launcher CI and exact public ZIP download results are recorded in repository review/delivery.json.

Completed local results: engine PASS; five Python route/installer tests PASS; complete Chromium six-page input/view suite PASS after the terrain rendering update. Screenshots and browser.log in review/ are actual browser captures. Ghost and GoDice test scenes are explicitly controlled fixtures, not a physical Bluetooth or six-device acceptance result.
