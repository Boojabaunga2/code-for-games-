/* BLOCKY FROGGER - game core. Pure logic, no DOM. Runs in the browser and in Node tests.
   Ranking model: ONE number per frog per round = ADJUSTED TIME (seconds, lower is better).
     finished frog : raw finish time
     unfinished    : roundLen + dnfRowPenalty x rows still to go
     then          : + hazardPenalty per hazard hit
                     - fly credits (capped)  - combat credits (capped)  - first-home credit
                     + Revenge Roll seconds (dice total) if chosen as victim
   Points (PTS) are a display-only style score; they never decide elimination. */
(function (root) {
  'use strict';

  var CFG = {
    roundLen: 60, rounds: 5, countdown: 3,
    cols: 30, rows: 13,
    hopDur: 0.14, hopGap: 0.05, turboHopDur: 0.08, turboGap: 0.01,
    respawnDelay: 1.0, respawnInvuln: 1.0,
    windup: 0.36, ghostWindup: 0.5, tongueRange: 3.4, tongueWidth: 0.55, extendShow: 0.2,
    atkCd: 0.7, ghostAtkCd: 3.0, defendCd: 0.35,
    blockWin: 0.32, blockLate: 0.06, perfectWin: 0.10, clashWin: 0.2,
    hitInvuln: 1.2, hitsToStun: 3, stunDur: 1.6, ghostBanish: 4.0,
    megaLife: 12, shieldLife: 8, turboLife: 5, tornadoRadius: 1.6,
    // time credits (seconds)
    dnfRowPenalty: 3, hazardPenalty: 2, flyCredit: 0.5, flyCreditCap: 4,
    slapCredit: 1.5, blockCredit: 0.5, counterCredit: 2.0, combatCreditCap: 6, firstHomeCredit: 3,
    diminish: [1, 0.5, 0.25, 0],
    // style points (display only)
    pts: { safe: 300, first: 150, slap: 35, counter: 50, fly: 20, hazard: -50, combatCap: 300 },
    flySpawnEvery: 0.8, flyMax: 14, flyLife: 14, powerSpawnEvery: 4, powerMax: 4, slapSideBias: 0.7, powerSlapBias: 0.65
  };

  var COLORS = ['red', 'blue', 'green', 'yellow', 'pink', 'white'];
  var COLOR_HEX = { red: '#ff3b3b', blue: '#2f7bff', green: '#3fd13f', pink: '#ff5fc8', yellow: '#ffd21f', white: '#f2f4ff' };
  var POWERS = ['mega', 'shield', 'turbo', 'tornado'];
  var POWER_NAME = { mega: 'MEGA SLAP', shield: 'BUBBLE SHIELD', turbo: 'TURBO HOP', tornado: 'TONGUE TORNADO' };

  // row layout, top (0) to bottom (12)
  var ROW = ['goal', 'hedge', 'bank', 'river', 'river', 'river', 'river', 'median', 'road', 'road', 'road', 'road', 'start'];
  var CHECKPOINT = { 12: true, 7: true, 2: true };
  var DIVIDER_ROWS = {}; // no centre wall
  var GAP_COLS = [5, 9, 20, 24];
  var SIDES = [{ x0: 0, x1: 30, name: 'FIELD' }];
  var SPAN_PAD = 4;
  var START_X = [11.5, 18.5, 12.5, 17.5, 13.5, 16.5]; // bunched at the crossover: chaos from the first hop

  // lanes: [row, side, kind, speed, len, count, sprites]
  // one open battlefield: every lane runs the full width
  var LANE_DEFS = [
    [11, 0, 'car', 3.0, 1.5, 7, ['car_red', 'car_blue', 'car_yellow', 'car_green']],
    [10, 0, 'car', -1.8, 2.8, 6, ['truck']],
    [9, 0, 'car', 3.6, 1.5, 7, ['car_green', 'car_red', 'car_blue', 'car_yellow']],
    [8, 0, 'car', -2.4, 2.0, 6, ['van_blue']],
    [6, 0, 'log', 1.6, 2.8, 6, ['log']],
    [5, 0, 'pad', -2.0, 2, 5, ['lilypad']],
    [4, 0, 'log', 2.2, 2.6, 5, ['log']],
    [3, 0, 'log', -1.7, 2.2, 5, ['log']]
  ];

  function mulberry(a) { return function () { a |= 0; a = a + 0x6D2B79F5 | 0; var t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
  function mod(a, n) { return ((a % n) + n) % n; }
  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
  function r2(v) { return Math.round(v * 100) / 100; }

  function buildLanes() {
    var lanes = [];
    for (var i = 0; i < LANE_DEFS.length; i++) {
      var d = LANE_DEFS[i], side = SIDES[d[1]], span = (side.x1 - side.x0) + SPAN_PAD;
      var objs = [];
      for (var k = 0; k < d[5]; k++) objs.push({ off: (k * span / d[5]) + (k % 2 ? 0.6 : 0), len: d[4], spr: d[6][k % d[6].length] });
      lanes.push({ row: d[0], side: d[1], kind: d[2], speed: d[3], objs: objs, span: span, x0: side.x0 - SPAN_PAD, sx0: side.x0, sx1: side.x1 });
    }
    return lanes;
  }
  var LANES = buildLanes();
  function lanesFor(row, side) { var o = []; for (var i = 0; i < LANES.length; i++) if (LANES[i].row === row && (side === undefined || LANES[i].side === side)) o.push(LANES[i]); return o; }
  function objX(l, o, t) { return l.x0 + mod(o.off + l.speed * t, l.span); }
  function sideOf(x) { return 0; }
  function laneAt(row, x) { var ls = lanesFor(row, sideOf(x)); return ls[0] || null; }

  // what is under x on row at time t. returns {hazard:bool, carry:speed}
  function groundAt(row, x, t) {
    var kind = ROW[row];
    if (kind === 'road') {
      var l = laneAt(row, x); if (!l) return { hazard: false, carry: 0 };
      for (var i = 0; i < l.objs.length; i++) { var ox = objX(l, l.objs[i], t); if (x + 0.32 > ox + 0.1 && x - 0.32 < ox + l.objs[i].len - 0.1) return { hazard: true, kind: 'car', carry: 0 }; }
      return { hazard: false, carry: 0 };
    }
    if (kind === 'river') {
      var lr = laneAt(row, x); if (!lr) return { hazard: true, kind: 'water', carry: 0 };
      var sd = SIDES[lr.side];
      if (x < sd.x0 + 0.25 || x > sd.x1 - 0.25) return { hazard: true, kind: 'water', carry: 0 };
      for (var j = 0; j < lr.objs.length; j++) { var px = objX(lr, lr.objs[j], t); if (x >= px + 0.12 && x <= px + lr.objs[j].len - 0.12) return { hazard: false, carry: lr.speed }; }
      return { hazard: true, kind: 'water', carry: 0 };
    }
    return { hazard: false, carry: 0 };
  }

  function passable(x, row, ghost) {
    if (row < 0 || row >= CFG.rows) return false;
    if (x < 0.3 || x > CFG.cols - 0.3) return false;
    if (ghost) return true;
    var col = Math.floor(x);
    if (row === 1 || row === 0) return GAP_COLS.indexOf(col) >= 0 && Math.abs(x - (col + 0.5)) < 0.2;
    return true;
  }
  function isGroundRow(row) { var k = ROW[row]; return k !== 'river'; }

  // ------------------------------------------------------------------ state
  function Core(opts) {
    opts = opts || {};
    this.cfg = CFG;
    this.seed = opts.seed || 12345;
    this.rng = mulberry(this.seed);
    this.events = [];
    this.frogs = [];
    for (var i = 0; i < 6; i++) this.frogs.push(this._newFrog(i, opts.cpu ? opts.cpu[i] : null));
    this.round = 0; this.phase = 'lobby'; this.t = 0; this.phaseT = 0;
    this.attacks = []; this.flies = []; this.flyId = 1; this.flyClock = 0; this.powerClock = 0;
    this.elimOrder = []; this.history = []; this.revenge = null; this.champion = -1; this.firstHome = -1;
  }
  var P = Core.prototype;

  P._newFrog = function (i, cpu) {
    return { seat: i, color: COLORS[i], cpu: cpu || null, alive: true, matchPts: 0, roundsWon: 0, eliminatedRound: 0 };
  };
  P.emit = function (type, o) { o = o || {}; o.type = type; o.t = this.t; this.events.push(o); };
  P.drain = function () { var e = this.events; this.events = []; return e; };
  P.activeFrogs = function () { return this.frogs.filter(function (f) { return f.alive; }); };
  P.setCpu = function (seat, personality) { this.frogs[seat].cpu = personality; };

  P.newMatch = function () {
    for (var i = 0; i < 6; i++) { var f = this.frogs[i]; f.alive = true; f.matchPts = 0; f.eliminatedRound = 0; }
    this.round = 0; this.elimOrder = []; this.history = []; this.champion = -1;
    this.startRound();
  };

  P.startRound = function () {
    this.round++; this.t = 0; this.phase = 'countdown'; this.phaseT = CFG.countdown;
    this.attacks = []; this.flies = []; this.flyClock = 0.5; this.powerClock = 2.5; this.revenge = null; this.firstHome = -1;
    this.lanePhase = this.rng() * 50; // lanes keep moving between rounds, different look each round
    for (var i = 0; i < 6; i++) {
      var f = this.frogs[i], ghost = !f.alive;
      f.ghost = ghost; f.x = START_X[i]; f.row = ghost ? 7 : 12; f.cp = f.row;
      f.hop = null; f.hopCd = 0; f.facing = { dx: 0, dy: -1 }; f.queued = null;
      f.safe = false; f.finishTime = null; f.dead = 0; f.deadKind = ''; f.hits = 0; f.stunT = 0; f.invulnT = 0;
      f.atkCd = 0; f.defCd = 0; f.defendT = 0; f.power = null; f.megaT = 0; f.shieldT = 0; f.turboT = 0; f.banishT = 0;
      f.flies = 0; f.cFly = 0; f.cCombat = 0; f.cFirst = 0; f.hazards = 0; f.revengePen = 0; f.pts = 0; f.ptsCombat = 0;
      f.slapLog = {}; f.anim = ghost ? 'ghost' : 'idle'; f.animT = 0; f.bubble = null; f.slaps = 0; f.blocks = 0; f.counters = 0;
      f.tieCoin = this.rng(); f.ai = { next: 0, plan: null, defend: {} }; f.carry = 0; f.bestRow = f.row;
    }
    this.emit('roundStart', { round: this.round });
  };

  // world time used for lanes
  P.lt = function (t) { return (t === undefined ? this.t : t) + this.lanePhase; };

  P.input = function (seat, btn) {
    var f = this.frogs[seat]; if (!f) return;
    if (this.phase !== 'play') return;
    if (btn === 'up') return this._move(f, 0, -1);
    if (btn === 'down') return this._move(f, 0, 1);
    if (btn === 'left') return this._move(f, -1, 0);
    if (btn === 'right') return this._move(f, 1, 0);
    if (btn === 'tongue') return this._tongue(f);
    if (btn === 'power') return this._power(f);
    if (btn === 'taunt') return this._taunt(f);
  };

  P._canAct = function (f) { return !f.safe && f.dead <= 0 && f.stunT <= 0 && f.banishT <= 0; };

  P._move = function (f, dx, dy) {
    if (!this._canAct(f)) { if (f.safe) this._taunt(f); return; }
    if (f.hop || f.hopCd > 0) { f.queued = { dx: dx, dy: dy }; return; }
    this._startHop(f, dx, dy, false);
  };

  P._startHop = function (f, dx, dy, forced, dur) {
    f.facing = { dx: dx, dy: dy };
    var nr = f.row + dy, nx = f.x + dx;
    if (dy !== 0 && isGroundRow(nr)) nx = Math.floor(nx) + 0.5;
    if (dy === 0 && isGroundRow(f.row)) nx = Math.floor(f.x) + 0.5 + dx;
    if (!passable(nx, nr, f.ghost)) { if (!forced) this.emit('bump', { seat: f.seat }); return false; }
    var turbo = f.turboT > 0;
    f.hop = { fx: f.x, fr: f.row, tx: nx, tr: nr, t: 0, dur: dur || (turbo ? CFG.turboHopDur : CFG.hopDur), forced: !!forced };
    f.anim = f.ghost ? 'ghost' : (forced ? 'knockback' : 'hop'); f.animT = 0;
    if (!forced) this.emit('hop', { seat: f.seat });
    return true;
  };

  P._land = function (f) {
    var h = f.hop; f.x = h.tx; f.row = h.tr; f.hop = null;
    f.hopCd = f.turboT > 0 ? CFG.turboGap : CFG.hopGap;
    if (f.ghost) return;
    if (f.anim === 'hop') { f.anim = 'land'; f.animT = 0; }
    if (f.row < f.bestRow) f.bestRow = f.row;
    if (CHECKPOINT[f.row]) f.cp = f.row;
    if (f.row === 0) return this._finish(f);
    this._checkHazard(f);
    this._touchFlies(f);
  };

  P._finish = function (f) {
    f.safe = true; f.finishTime = r2(this.t); f.anim = 'celebrate'; f.animT = 0;
    f.pts += CFG.pts.safe;
    if (this.firstHome < 0) { this.firstHome = f.seat; f.cFirst = CFG.firstHomeCredit; f.pts += CFG.pts.first; }
    f.power = null; f.shieldT = 0; f.turboT = 0; f.megaT = 0;
    this.emit('safe', { seat: f.seat, time: f.finishTime, first: this.firstHome === f.seat });
  };

  P._checkHazard = function (f) {
    if (f.ghost || f.safe || f.dead > 0 || f.hop) return;
    var g = groundAt(f.row, f.x, this.lt());
    f.carry = g.carry;
    if (g.hazard) this._hazard(f, g.kind);
  };

  P._hazard = function (f, kind) {
    f.dead = CFG.respawnDelay; f.deadKind = kind; f.hazards++; f.pts += CFG.pts.hazard; f.carry = 0; f.hop = null; f.queued = null;
    f.anim = 'defeat'; f.animT = 0; f.stunT = 0;
    this.emit('hazard', { seat: f.seat, kind: kind, x: f.x, row: f.row });
  };

  P._respawn = function (f) {
    f.row = f.cp; var x = Math.floor(f.x) + 0.5;
    x = clamp(x, 0.5, CFG.cols - 0.5);
    f.x = x; f.dead = 0; f.invulnT = CFG.respawnInvuln; f.anim = 'recover'; f.animT = 0; f.hits = 0;
    this.emit('respawn', { seat: f.seat });
  };

  // visual / logical position
  P.pos = function (f) {
    if (f.hop) { var k = clamp(f.hop.t / f.hop.dur, 0, 1); return { x: f.hop.fx + (f.hop.tx - f.hop.fx) * k, y: f.hop.fr + (f.hop.tr - f.hop.fr) * k, air: Math.sin(k * Math.PI) }; }
    return { x: f.x, y: f.row, air: 0 };
  };

  P._targetable = function (o) { return o && !o.ghost && !o.safe && o.dead <= 0; };

  P._lineScan = function (f, dir, range) {
    var me = this.pos(f), best = null, bd = 1e9;
    for (var i = 0; i < 6; i++) {
      var o = this.frogs[i]; if (o === f || !this._targetable(o)) continue;
      var p = this.pos(o), rx = p.x - me.x, ry = p.y - me.y;
      var along = rx * dir.dx + ry * dir.dy, perp = dir.dx ? Math.abs(ry) : Math.abs(rx);
      if (along > 0.05 && along <= range && perp <= CFG.tongueWidth && along < bd) { bd = along; best = o; }
    }
    return best ? { frog: best, dist: bd } : null;
  };
  P._flyScan = function (f, dir, range) {
    var me = this.pos(f), best = null, bd = 1e9;
    for (var i = 0; i < this.flies.length; i++) {
      var fl = this.flies[i], rx = fl.x - me.x, ry = fl.row - me.y;
      var along = rx * dir.dx + ry * dir.dy, perp = dir.dx ? Math.abs(ry) : Math.abs(rx);
      if (along > -0.2 && along <= range && perp <= CFG.tongueWidth && along < bd) { bd = along; best = fl; }
    }
    return best ? { fly: best, dist: Math.max(0.3, bd) } : null;
  };
  var DIRS = [{ dx: 0, dy: -1 }, { dx: 1, dy: 0 }, { dx: -1, dy: 0 }, { dx: 0, dy: 1 }];

  // facing first, then aim-assist to nearest frog in any direction, then flies
  P._aim = function (f) {
    var range = CFG.tongueRange, hit = this._lineScan(f, f.facing, range);
    if (hit) return { dir: f.facing, frog: hit.frog };
    var best = null;
    for (var d = 0; d < 4; d++) { var h = this._lineScan(f, DIRS[d], range); if (h && (!best || h.dist < best.h.dist)) best = { dir: DIRS[d], h: h }; }
    if (best) return { dir: best.dir, frog: best.h.frog };
    if (!f.ghost) {
      var fb = null;
      var ff = this._flyScan(f, f.facing, range); if (ff) return { dir: f.facing, fly: ff.fly };
      for (var e = 0; e < 4; e++) { var fh = this._flyScan(f, DIRS[e], range); if (fh && (!fb || fh.dist < fb.h.dist)) fb = { dir: DIRS[e], h: fh }; }
      if (fb) return { dir: fb.dir, fly: fb.h.fly };
    }
    return { dir: f.facing };
  };

  P._tongue = function (f) {
    if (!this._canAct(f)) { if (f.safe) this._taunt(f); return; }
    // defence first: an attack on me is about to land
    if (f.defCd <= 0) {
      for (var i = 0; i < this.attacks.length; i++) {
        var a = this.attacks[i];
        if (a.done || a.result || a.target !== f.seat) continue;
        var dt = a.impactAt - this.t;
        if (dt <= CFG.blockWin && dt >= -CFG.blockLate) {
          a.result = Math.abs(dt) <= CFG.perfectWin ? 'counter' : 'block';
          f.defCd = CFG.defendCd; f.defendT = 0.35; f.anim = a.result === 'counter' ? 'counter' : 'block'; f.animT = 0;
          return;
        }
      }
    }
    if (f.atkCd > 0) return;
    var aim = this._aim(f);
    f.facing = aim.dir;
    var wind = f.ghost ? CFG.ghostWindup : CFG.windup;
    var atk = { id: this.t + '_' + f.seat, atk: f.seat, dir: aim.dir, start: this.t, impactAt: this.t + wind, target: aim.frog ? aim.frog.seat : -1, flyId: aim.fly ? aim.fly.id : 0, ghost: f.ghost, mega: f.megaT > 0, result: null, done: false, len: CFG.tongueRange, showUntil: 0 };
    this.attacks.push(atk);
    f.atkCd = f.ghost ? CFG.ghostAtkCd : CFG.atkCd;
    f.anim = f.ghost ? 'ghost_slap' : 'tongue_windup'; f.animT = 0;
    this.emit('windup', { seat: f.seat, target: atk.target, ghost: f.ghost });
  };

  P._knock = function (f, dir, n) {
    // slaps are setbacks: vertical knockback always pushes toward the start line
    var dx = dir.dx, dy = dir.dy; if (dy !== 0) { dy = 1; dx = 0; }
    var moved = 0;
    if (f.hop) { f.x = f.hop.tx; f.row = f.hop.tr; f.hop = null; }
    var tx = f.x, tr = f.row;
    for (var i = 0; i < n; i++) {
      var nx = tx + dx, nr = tr + dy;
      if (dy && isGroundRow(nr)) nx = Math.floor(nx) + 0.5;
      if (!passable(nx, nr, f.ghost) || nr === 0) break;
      tx = nx; tr = nr; moved++;
    }
    if (moved) { f.hop = { fx: f.x, fr: f.row, tx: tx, tr: tr, t: 0, dur: 0.12 + 0.06 * moved, forced: true }; f.anim = 'knockback'; f.animT = 0; }
    return moved;
  };

  P._credit = function (f, kind, amount, pts) {
    if (kind === 'combat') {
      var room = Math.max(0, CFG.combatCreditCap - f.cCombat); f.cCombat += Math.min(room, amount);
      var proom = Math.max(0, CFG.pts.combatCap - f.ptsCombat), add = Math.min(proom, pts); f.ptsCombat += add; f.pts += add;
    } else if (kind === 'fly') {
      f.cFly = Math.min(CFG.flyCreditCap, f.cFly + amount); f.pts += pts;
    }
  };

  P._resolveAttack = function (a) {
    a.done = true; a.showUntil = this.t + CFG.extendShow;
    var A = this.frogs[a.atk];
    if (A.dead > 0 || A.banishT > 0 || A.safe) { a.result = 'cancel'; return; }
    A.anim = A.ghost ? 'ghost_slap' : 'tongue_slap'; A.animT = 0;
    var T = a.target >= 0 ? this.frogs[a.target] : null;
    if (a.result === 'counter') {
      a.len = T ? Math.max(0.4, this._dist(A, T)) : 1;
      if (A.ghost) { A.banishT = CFG.ghostBanish; this.emit('banish', { seat: A.seat, by: T.seat }); }
      else { this._knock(A, { dx: -a.dir.dx, dy: -a.dir.dy }, 1); A.invulnT = 0.6; }
      T.counters++; this._credit(T, 'combat', CFG.counterCredit, CFG.pts.counter);
      this.emit('counter', { seat: T.seat, atk: A.seat, x: this.pos(T).x, y: this.pos(T).y });
      return;
    }
    if (a.result === 'block') {
      a.len = T ? Math.max(0.4, this._dist(A, T)) : 1;
      T.blocks++; this._credit(T, 'combat', CFG.blockCredit, 0);
      this.emit('block', { seat: T.seat, atk: A.seat, x: this.pos(T).x, y: this.pos(T).y });
      return;
    }
    // clash: target was simultaneously attacking the attacker
    if (T) {
      for (var i = 0; i < this.attacks.length; i++) {
        var b = this.attacks[i];
        if (b === a || b.result || b.atk !== T.seat || b.target !== A.seat) continue;
        if (Math.abs(b.impactAt - a.impactAt) <= CFG.clashWin) {
          b.result = 'clash'; b.done = true; b.showUntil = this.t + CFG.extendShow; a.result = 'clash';
          var d = this._dist(A, T); a.len = d / 2; b.len = d / 2;
          if (!A.ghost) this._knock(A, { dx: -a.dir.dx, dy: -a.dir.dy }, 1);
          if (!T.ghost) this._knock(T, { dx: -b.dir.dx, dy: -b.dir.dy }, 1);
          A.anim = 'tongue_clash'; T.anim = 'tongue_clash'; A.animT = T.animT = 0;
          A.invulnT = Math.max(A.invulnT, 0.5); T.invulnT = Math.max(T.invulnT, 0.5);
          var pa = this.pos(A), pt = this.pos(T);
          this.emit('clash', { a: A.seat, b: T.seat, x: (pa.x + pt.x) / 2, y: (pa.y + pt.y) / 2 });
          return;
        }
      }
    }
    // re-check reach at impact (hopping away during the windup dodges)
    var reach = this._lineScan(A, a.dir, CFG.tongueRange);
    if (reach) T = reach.frog; else T = null;
    if (T && T.invulnT > 0) { a.result = 'whiff'; a.len = reach.dist; this.emit('whiff', { seat: A.seat }); return; }
    if (T) {
      a.len = reach.dist; a.target = T.seat;
      if (T.shieldT > 0) { T.shieldT = 0; a.result = 'shield'; this.emit('shieldPop', { seat: T.seat, atk: A.seat, x: this.pos(T).x, y: this.pos(T).y }); if (!A.ghost) A.megaT = 0; return; }
      var mega = !A.ghost && A.megaT > 0; if (mega) A.megaT = 0;
      this._knock(T, a.dir, mega ? 2 : 1);
      T.invulnT = CFG.hitInvuln;
      var pt2 = this.pos(T);
      if (!A.ghost) {
        T.hits++;
        var n = A.slapLog[T.seat] || 0; A.slapLog[T.seat] = n + 1;
        var mult = CFG.diminish[Math.min(n, CFG.diminish.length - 1)];
        A.slaps++; this._credit(A, 'combat', CFG.slapCredit * mult, CFG.pts.slap * mult);
        if (T.hits >= CFG.hitsToStun) { T.stunT = CFG.stunDur; T.hits = 0; T.queued = null; this.emit('stun', { seat: T.seat }); }
      }
      if (T.stunT <= 0) { T.anim = 'hit'; T.animT = 0; }
      a.result = 'hit';
      this.emit('slap', { seat: A.seat, target: T.seat, ghost: A.ghost, mega: mega, x: pt2.x, y: pt2.y });
      return;
    }
    // fly snatch
    if (!A.ghost) {
      var fs = this._flyScan(A, a.dir, CFG.tongueRange);
      if (fs) { a.len = fs.dist; a.result = 'fly'; this._catchFly(A, fs.fly, true); return; }
    }
    a.result = 'miss'; a.len = CFG.tongueRange;
  };

  P._dist = function (a, b) { var p = this.pos(a), q = this.pos(b); return Math.sqrt((p.x - q.x) * (p.x - q.x) + (p.y - q.y) * (p.y - q.y)); };

  P._power = function (f) {
    if (f.safe) return this._taunt(f);
    if (!this._canAct(f) || f.ghost || !f.power) return;
    var p = f.power; f.power = null;
    if (p === 'mega') f.megaT = CFG.megaLife;
    else if (p === 'shield') f.shieldT = CFG.shieldLife;
    else if (p === 'turbo') f.turboT = CFG.turboLife;
    else if (p === 'tornado') {
      var me = this.pos(f), hitAny = 0;
      for (var i = 0; i < 6; i++) {
        var o = this.frogs[i]; if (o === f || !this._targetable(o) || o.invulnT > 0) continue;
        var q = this.pos(o), rx = q.x - me.x, ry = q.y - me.y;
        if (Math.max(Math.abs(rx), Math.abs(ry)) > CFG.tornadoRadius) continue;
        if (o.shieldT > 0) { o.shieldT = 0; this.emit('shieldPop', { seat: o.seat, atk: f.seat, x: q.x, y: q.y }); continue; }
        var dir = { dx: rx === 0 ? (this.rng() < 0.5 ? -1 : 1) : (rx > 0 ? 1 : -1), dy: 0 };
        this._knock(o, dir, 1); o.invulnT = CFG.hitInvuln; o.hits++;
        var n = f.slapLog[o.seat] || 0; f.slapLog[o.seat] = n + 1;
        this._credit(f, 'combat', CFG.slapCredit * CFG.diminish[Math.min(n, 3)], CFG.pts.slap * CFG.diminish[Math.min(n, 3)]);
        if (o.hits >= CFG.hitsToStun) { o.stunT = CFG.stunDur; o.hits = 0; this.emit('stun', { seat: o.seat }); } else { o.anim = 'hit'; o.animT = 0; }
        hitAny++;
      }
      this.emit('tornado', { seat: f.seat, x: me.x, y: me.y, hits: hitAny });
    }
    this.emit('power', { seat: f.seat, power: p });
  };

  var TAUNTS = ['HA!', 'EZ!', 'STILL DOWN THERE?!', 'RIBBIT!', 'CATCH ME!', 'TOO SLOW!', 'HOP HARDER!'];
  var GHOST_TAUNTS = ['BOO!', 'OOOOH!', 'GET EVEN!', 'I SEE YOU!'];
  P._taunt = function (f) {
    if (f.bubble && f.bubble.t > 0.6) return;
    var list = f.ghost ? GHOST_TAUNTS : TAUNTS;
    f.bubble = { text: list[Math.floor(this.rng() * list.length)], t: 1.6 };
    if (f.safe) { f.anim = 'celebrate'; f.animT = 0; }
    this.emit('taunt', { seat: f.seat, text: f.bubble.text });
  };

  // -------------------------------------------------------------- flies
  P._spawnFly = function (power) {
    var sd = SIDES[0];
    for (var tries = 0; tries < 12; tries++) {
      var row = this.rng() < 0.45 ? (this.rng() < 0.5 ? 2 : 7) : 2 + Math.floor(this.rng() * 10); // shared rows are fly-rich: frogs meet there
      var x = sd.x0 + 0.5 + Math.floor(this.rng() * (sd.x1 - sd.x0));
      var ok = true;
      for (var i = 0; i < 6; i++) { var f = this.frogs[i]; if (!f.ghost && Math.abs(f.x - x) < 1.6 && Math.abs(f.row - row) < 1.5) ok = false; }
      for (var j = 0; j < this.flies.length; j++) if (Math.abs(this.flies[j].x - x) < 1 && this.flies[j].row === row) ok = false;
      if (!ok) continue;
      var type = power ? POWERS[Math.floor(this.rng() * 4)] : 'fly';
      this.flies.push({ id: this.flyId++, x: x, row: row, type: type, born: this.t, life: CFG.flyLife + (power ? 4 : 0), ph: this.rng() * 6 });
      return true;
    }
    return false;
  };
  P._touchFlies = function (f) {
    if (f.ghost || f.safe || f.dead > 0) return;
    for (var i = this.flies.length - 1; i >= 0; i--) { var fl = this.flies[i]; if (fl.row === f.row && Math.abs(fl.x - f.x) < 0.6) this._catchFly(f, fl, false); }
  };
  P._catchFly = function (f, fl, tongue) {
    var i = this.flies.indexOf(fl); if (i < 0) return; this.flies.splice(i, 1);
    f.flies++; this._credit(f, 'fly', CFG.flyCredit, CFG.pts.fly);
    var gotPower = false;
    if (fl.type !== 'fly' && !f.power && f.megaT <= 0 && f.shieldT <= 0 && f.turboT <= 0) { f.power = fl.type; gotPower = true; }
    this.emit('fly', { seat: f.seat, kind: fl.type, power: gotPower, tongue: tongue, x: fl.x, y: fl.row });
  };

  // -------------------------------------------------------------- step
  P.step = function (dt) {
    if (this.phase === 'countdown') {
      this.phaseT -= dt;
      if (this.phaseT <= 0) { this.phase = 'play'; this.t = 0; this.emit('go'); }
      this._ai(dt, true);
      return;
    }
    if (this.phase !== 'play') return;
    this.t += dt;
    var lt = this.lt(), i, f;
    for (i = 0; i < 6; i++) {
      f = this.frogs[i];
      f.animT += dt;
      if (f.bubble) { f.bubble.t -= dt; if (f.bubble.t <= 0) f.bubble = null; }
      f.atkCd -= dt; f.defCd -= dt; f.hopCd -= dt; f.invulnT -= dt; f.defendT -= dt;
      if (f.megaT > 0) f.megaT -= dt; if (f.shieldT > 0) f.shieldT -= dt; if (f.turboT > 0) f.turboT -= dt;
      if (f.banishT > 0) { f.banishT -= dt; continue; }
      if (f.safe) continue;
      if (f.dead > 0) { f.dead -= dt; if (f.dead <= 0) this._respawn(f); continue; }
      if (f.stunT > 0) { f.stunT -= dt; f.anim = 'dizzy'; if (f.stunT <= 0) { f.anim = 'recover'; f.animT = 0; } }
      if (f.hop) {
        f.hop.t += dt;
        if (f.hop.t >= f.hop.dur) this._land(f);
      } else if (!f.ghost) {
        // ride logs / pads
        var g = groundAt(f.row, f.x, lt);
        if (ROW[f.row] === 'river' && !g.hazard) f.x += g.carry * dt;
        this._checkHazard(f);
        if (f.dead <= 0) this._touchFlies(f);
      }
      if (!f.hop && f.queued && f.hopCd <= 0 && this._canAct(f)) { var q = f.queued; f.queued = null; this._startHop(f, q.dx, q.dy, false); }
      if (!f.hop && f.anim !== 'idle' && f.animT > 0.55 && f.stunT <= 0 && f.dead <= 0 && !f.safe) { f.anim = f.ghost ? 'ghost' : 'idle'; f.animT = 0; }
    }
    // attacks
    for (i = 0; i < this.attacks.length; i++) { var a = this.attacks[i]; if (!a.done && this.t >= a.impactAt) this._resolveAttack(a); }
    this.attacks = this.attacks.filter(function (a) { return !a.done || this.t < a.showUntil; }, this);
    // flies
    this.flies = this.flies.filter(function (fl) { return this.t - fl.born < fl.life; }, this);
    this.flyClock -= dt; this.powerClock -= dt;
    var nFly = 0, nPow = 0; for (i = 0; i < this.flies.length; i++) { if (this.flies[i].type === 'fly') nFly++; else nPow++; }
    if (this.flyClock <= 0) { this.flyClock = CFG.flySpawnEvery; if (nFly < CFG.flyMax) this._spawnFly(false); }
    if (this.powerClock <= 0) { this.powerClock = CFG.powerSpawnEvery; if (nPow < CFG.powerMax) this._spawnFly(true); }
    this._ai(dt, false);
    // end of round
    var activeLeft = 0; for (i = 0; i < 6; i++) if (this.frogs[i].alive && !this.frogs[i].safe) activeLeft++;
    if (this.t >= CFG.roundLen || activeLeft === 0) this._freeze();
  };

  P._freeze = function () {
    this.phase = 'frozen'; this.t = Math.min(this.t, CFG.roundLen);
    for (var i = 0; i < 6; i++) { var f = this.frogs[i]; if (f.hop) { f.x = f.hop.tx; f.row = f.hop.tr; f.hop = null; } }
    this.attacks = [];
    this.emit('freeze', { standings: this.standings() });
  };

  // -------------------------------------------------------------- ranking
  P.rowsToGo = function (f) { return f.dead > 0 ? f.cp : (f.hop ? f.hop.tr : f.row); };
  P.adjusted = function (f) {
    var base = f.finishTime !== null ? f.finishTime : CFG.roundLen + CFG.dnfRowPenalty * this.rowsToGo(f);
    var adj = base + f.hazards * CFG.hazardPenalty - f.cFly - f.cCombat - f.cFirst + f.revengePen;
    return { base: r2(base), adj: r2(Math.max(0, adj)), finished: f.finishTime !== null };
  };
  P.standings = function () {
    var self = this, list = [];
    for (var i = 0; i < 6; i++) { var f = this.frogs[i]; if (!f.alive) continue; var a = this.adjusted(f); list.push({ seat: i, adj: a.adj, base: a.base, finished: a.finished, hazards: f.hazards, coin: f.tieCoin, pts: f.pts, pen: f.revengePen }); }
    list.sort(function (a, b) {
      if (a.adj !== b.adj) return a.adj - b.adj;
      if (a.finished !== b.finished) return a.finished ? -1 : 1;
      if (a.base !== b.base) return a.base - b.base;
      if (a.hazards !== b.hazards) return a.hazards - b.hazards;
      return a.coin - b.coin;
    });
    for (var k = 0; k < list.length; k++) list[k].rank = k + 1;
    return list;
  };

  // -------------------------------------------------------------- revenge roll
  P.beginRevenge = function () {
    if (this.phase !== 'frozen') return null;
    var st = this.standings(), roller = st[st.length - 1].seat, cands = [];
    for (var i = 0; i < st.length - 1; i++) cands.push(st[i].seat);
    this.revenge = { roller: roller, candidates: cands, cursor: 0, dice: [], sum: 0, victim: -1, locked: false, before: st, after: null, eliminated: -1, virtual: false };
    this.phase = 'revenge';
    this.emit('revenge', { roller: roller });
    return this.revenge;
  };
  P.revengeDie = function (v) {
    var R = this.revenge; if (!R || R.dice.length >= 2) return;
    v = Math.round(v); if (!(v >= 1 && v <= 6)) return;
    R.dice.push(v); R.sum = R.dice.reduce(function (s, x) { return s + x; }, 0);
    this.emit('die', { value: v, n: R.dice.length });
  };
  P.revengeMove = function (step) {
    var R = this.revenge; if (!R || R.locked) return;
    var n = R.candidates.length; R.cursor = mod(R.cursor + (step || 1), n);
    this.emit('cursor', { seat: R.candidates[R.cursor] });
  };
  P.revengeConfirm = function () {
    var R = this.revenge; if (!R || R.locked || R.dice.length < 2) return false;
    R.locked = true; R.victim = R.candidates[R.cursor];
    this.frogs[R.victim].revengePen += R.sum;
    R.after = this.standings();
    var last = R.after[R.after.length - 1].seat;
    R.eliminated = last;
    this.emit('revengeHit', { victim: R.victim, sum: R.sum, eliminated: last });
    return true;
  };
  P.finishRound = function () {
    // apply elimination, record history, advance
    var R = this.revenge, st = R && R.after ? R.after : this.standings();
    var out = R && R.eliminated >= 0 ? R.eliminated : st[st.length - 1].seat;
    var fo = this.frogs[out];
    for (var i = 0; i < 6; i++) { var f = this.frogs[i]; f.matchPts += f.alive ? f.pts : 0; }
    if (st.length) this.frogs[st[0].seat].roundsWon++;
    fo.alive = false; fo.eliminatedRound = this.round; this.elimOrder.push(out);
    this.history.push({ round: this.round, standings: st, eliminated: out, revenge: R ? { roller: R.roller, victim: R.victim, sum: R.sum, dice: R.dice.slice() } : null });
    var alive = this.activeFrogs();
    if (alive.length <= 1 || this.round >= CFG.rounds) { this.champion = alive.length ? alive[0].seat : -1; this.phase = 'over'; this.emit('champion', { seat: this.champion }); }
    else this.phase = 'between';
    return out;
  };

  // -------------------------------------------------------------- CPU
  // personalities: 'racer' (speed run, avoids fights) / 'brawler' (slap run, hunts flies + frogs)
  P._safeAt = function (x, row, t0, dwell) {
    if (ROW[row] === 'road') { for (var s = 0; s <= 4; s++) if (groundAt(row, x, this.lt(t0 + dwell * s / 4)).hazard) return false; return true; }
    if (ROW[row] === 'river') {
      var g = groundAt(row, x, this.lt(t0)); if (g.hazard) return false;
      var xx = x; for (var k = 1; k <= 4; k++) { xx += g.carry * dwell / 4; if (groundAt(row, xx, this.lt(t0 + dwell * k / 4)).hazard) return false; }
      return true;
    }
    return true;
  };

  P._ai = function (dt, countdownOnly) {
    for (var i = 0; i < 6; i++) {
      var f = this.frogs[i]; if (!f.cpu) continue;
      if (countdownOnly) continue;
      f.ai.next -= dt;
      this._aiDefend(f);
      if (f.ai.next > 0) continue;
      f.ai.next = 0.16 + this.rng() * 0.2;
      if (f.ghost) { this._aiGhost(f); continue; }
      if (!this._canAct(f)) { if (f.safe && this.rng() < 0.01) this._taunt(f); continue; }
      this._aiActive(f);
    }
  };
  P._aiDefend = function (f) {
    if (f.ghost || !this._canAct(f)) return;
    var skill = f.cpu === 'brawler' ? 0.6 : 0.4;
    for (var i = 0; i < this.attacks.length; i++) {
      var a = this.attacks[i]; if (a.done || a.result || a.target !== f.seat) continue;
      var plan = f.ai.defend[a.id];
      if (plan === undefined) { plan = this.rng() < skill ? a.impactAt - (0.02 + this.rng() * 0.26) : -1; f.ai.defend[a.id] = plan; }
      if (plan > 0 && this.t >= plan) { f.ai.defend[a.id] = -1; this._tongue(f); }
    }
  };
  P._aiGhost = function (f) {
    if (f.banishT > 0) return;
    var best = null, bd = 1e9, me = this.pos(f);
    for (var i = 0; i < 6; i++) { var o = this.frogs[i]; if (!this._targetable(o) || o === f) continue; var p = this.pos(o), d = Math.abs(p.x - me.x) + Math.abs(p.y - me.y); if (d < bd) { bd = d; best = o; } }
    if (!best) return;
    if (f.atkCd <= 0 && this._lineScanAny(f) && this.rng() < 0.5) return this._tongue(f);
    if (f.hop || f.hopCd > 0) return;
    var p2 = this.pos(best), dx = p2.x - me.x, dy = p2.y - me.y;
    if (this.rng() < 0.35) return; // ghosts drift lazily
    if (Math.abs(dy) > 0.6) this._startHop(f, 0, dy > 0 ? 1 : -1, false);
    else if (Math.abs(dx) > 1.6) this._startHop(f, dx > 0 ? 1 : -1, 0, false);
  };
  P._lineScanAny = function (f) { for (var d = 0; d < 4; d++) if (this._lineScan(f, DIRS[d], CFG.tongueRange - 0.3)) return true; return false; };

  P._aiActive = function (f) {
    var brawler = f.cpu === 'brawler';
    // power use
    if (f.power) {
      if (f.power === 'turbo' || f.power === 'shield' || f.power === 'mega') { if (this.rng() < 0.3) this._power(f); }
      else if (f.power === 'tornado') { var near = 0, me0 = this.pos(f); for (var j = 0; j < 6; j++) { var o0 = this.frogs[j]; if (o0 !== f && this._targetable(o0)) { var q0 = this.pos(o0); if (Math.max(Math.abs(q0.x - me0.x), Math.abs(q0.y - me0.y)) <= 1.5) near++; } } if (near) this._power(f); }
    }
    // attack
    if (f.atkCd <= 0 && !f.hop) {
      var inLine = this._lineScanAny(f), flyLine = null; for (var fd = 0; fd < 4 && !flyLine; fd++) flyLine = this._flyScan(f, DIRS[fd], brawler ? 3 : 2);
      if ((inLine && this.rng() < (brawler ? 0.85 : 0.25)) || (flyLine && this.rng() < (brawler ? 0.8 : 0.45))) return this._tongue(f);
    }
    if (f.hop || f.hopCd > 0) return;
    // movement planning
    var t0 = this.t, land = CFG.hopDur, dwell = 0.42;
    var opts = [{ dx: 0, dy: -1 }, { dx: -1, dy: 0 }, { dx: 1, dy: 0 }, { dx: 0, dy: 1 }, null];
    var best = null, bs = -1e9;
    var hereSafe = ROW[f.row] === 'river' || ROW[f.row] === 'road' ? this._safeAt(f.x, f.row, t0, dwell) : true;
    for (var k = 0; k < opts.length; k++) {
      var o = opts[k], nx = f.x, nr = f.row;
      if (o) {
        nr = f.row + o.dy; nx = f.x + o.dx;
        if (o.dy !== 0 && isGroundRow(nr)) nx = Math.floor(nx) + 0.5;
        if (o.dy === 0 && isGroundRow(f.row)) nx = Math.floor(f.x) + 0.5 + o.dx;
        if (!passable(nx, nr, false)) continue;
      }
      var safe = o ? this._safeAt(nx, nr, t0 + land, dwell + this.rng() * 0.25) : hereSafe;
      var s = safe ? 0 : ((o ? this._safeAt(nx, nr, t0 + land, 0.12) : this._safeAt(f.x, f.row, t0, 0.15)) ? -300 : -1000);
      s += (12 - nr) * 10; // progress
      if (o && o.dy === 1) s -= 14;
      if (!o) s += 4;
      // prefer standing where the next hop up is actually open (dividers / hedge)
      if (isGroundRow(nr) && nr > 0 && !passable(Math.floor(nx) + 0.5, nr - 1, false)) s -= 9;
      if (nr === 2) { var gx = this._nearestGap(nx); s -= Math.abs(gx - nx) * 3; }
      // stay away from river side edges
      if (ROW[nr] === 'river') { var sd = SIDES[sideOf(nx)]; if (nx < sd.x0 + 1.2 || nx > sd.x1 - 1.2) s -= 5; }
      // flies
      for (var m = 0; m < this.flies.length; m++) { var fl = this.flies[m]; var dd = Math.abs(fl.x - nx) + Math.abs(fl.row - nr); if (dd < 3) s += (brawler ? (fl.type === 'fly' ? 5 : 9) : (fl.type === 'fly' ? 1 : 3)) * (3 - dd); }
      // brawlers hunt: like being lined up next to an active frog
      { for (var h = 0; h < 6; h++) { var ho = this.frogs[h]; if (ho === f || !this._targetable(ho)) continue; var hp = this.pos(ho), hd = Math.abs(hp.x - nx) + Math.abs(hp.y - nr) * 1.5; if (hd < 3 && hd > 0.4) s += brawler ? 6 : 3; } }
      s += this.rng() * 2;
      if (s > bs) { bs = s; best = o; }
    }
    if (hereSafe && this.rng() < 0.22) return; // human-ish hesitation
    if (best && this.rng() > 0.04) this._startHop(f, best.dx, best.dy, false);
  };
  P._nearestGap = function (x) { var b = 0, bd = 1e9; for (var i = 0; i < GAP_COLS.length; i++) { var g = GAP_COLS[i] + 0.5, d = Math.abs(g - x); if (d < bd) { bd = d; b = g; } } return b; };

  var API = {
    Core: Core, CFG: CFG, COLORS: COLORS, COLOR_HEX: COLOR_HEX, POWERS: POWERS, POWER_NAME: POWER_NAME,
    ROW: ROW, LANES: LANES, SIDES: SIDES, GAP_COLS: GAP_COLS, DIVIDER_ROWS: DIVIDER_ROWS, CHECKPOINT: CHECKPOINT,
    objX: objX, groundAt: groundAt, passable: passable, sideOf: sideOf
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = API; else root.BFCore = API;
})(this);
