# Credits

User-supplied blocky-frogger.zip contains the original game, embedded frog/traffic/effects art and approved Arcadium cover. Those art assets and the original gameplay engine are retained; the source's yellow/pink seat ordering is corrected to match the shared platform. The original monolithic source is adapted with shared held input, live player telemetry, ghost/cooldown dashboards and environmental lighting. No new third-party asset or remote runtime dependency is added.

The raw I1 reader is copied unchanged from the existing Arcadium universal controller platform. No Android app files are changed.
