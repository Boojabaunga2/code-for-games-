from pathlib import Path
import json,tkinter as tk
from tkinter import filedialog
from update_blocky_frogger import install,rollback
ui=tk.Tk();ui.title('Arcadium / Blocky Frogger');ui.geometry('750x430');status=tk.StringVar(value='Held/released D-pad, six live personal frog cameras and real ghost-state displays. Select the existing Arcadium_OS_COMPACT folder. Keep the universal Mini Vibe app and pairing. No new APK.')
tk.Label(ui,text='BLOCKY FROGGER / SIX LIVE FROG CAMS',font=('Segoe UI',17,'bold')).pack(pady=20);tk.Label(ui,textvariable=status,wraplength=700,justify='left',font=('Segoe UI',12)).pack(padx=20,pady=20)
def run():
 folder=filedialog.askdirectory(title='Select your existing Arcadium_OS_COMPACT folder')
 if not folder:return
 try:
  backup=install(Path(folder));Path(__file__).with_name('BLOCKY_FROGGER_RECEIPT.json').write_text(json.dumps({'backup':str(backup)},indent=2));status.set('Installed. Backup: '+str(backup)+'\n\nRestart Windows once, then open Blocky Frogger from its carousel card. A joins; START begins. Hold D-pad to hop; release stops new hops. A tongue/counter, B power, START pause. Eliminated players get real ghost views. GoDice support preserved. No new APK.\n\nPhysical-device acceptance is still needed.')
 except Exception as e:status.set('Stopped: '+str(e))
def undo():
 folder=filedialog.askdirectory(title='Select the blocky_frogger_v1_* backup')
 if not folder:return
 try:rollback(Path(folder));status.set('Previous game restored. Restart Windows once.')
 except Exception as e:status.set('Rollback stopped: '+str(e))
tk.Button(ui,text='INSTALL BLOCKY FROGGER',command=run,padx=20,pady=12).pack(pady=8);tk.Button(ui,text='Rollback this update',command=undo).pack();ui.mainloop()
