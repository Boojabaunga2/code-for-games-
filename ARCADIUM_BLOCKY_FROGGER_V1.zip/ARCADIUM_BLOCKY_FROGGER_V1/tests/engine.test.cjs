const fs=require('fs'),path=require('path');const assert=require('assert/strict'),B=require('../games/blocky-frogger/core.cjs'),Held=require('../games/blocky-frogger/held-hop.js');
assert.equal(fs.readFileSync(path.join(__dirname,'../games/blocky-frogger/index.html'),'utf8').match(/<script id="bf-core">([\s\S]*?)<\/script>/)[1],fs.readFileSync(path.join(__dirname,'../games/blocky-frogger/core.cjs'),'utf8'),'Tested engine must equal shipped inline engine');
function world(){const c=new B.Core({cpu:Array(6).fill(null)});c.newMatch();while(c.phase==='countdown')c.step(1/120);return c;}
function drive(c,h,i,mask,t){for(let k=0;k<Math.ceil(t*120);k++){h.apply(c,i,mask);c.step(1/120);}}
assert.deepEqual(B.COLORS,['red','blue','green','yellow','pink','white']);assert.equal(B.CFG.rounds,5);assert.equal(B.CFG.roundLen,60);
for(let i=0;i<6;i++){
 const c=world(),h=Held.create(),f=c.frogs[i];f.x=10.5;const x=f.x;drive(c,h,i,8,.65);assert(f.x>x+1,'Hold must hop repeatedly for seat '+i);const target=f.hop?.tx??f.x;drive(c,h,i,0,.5);assert.equal(f.x,target,'Release completes only current hop');assert.equal(f.queued,null);drive(c,h,i,4,.35);assert(f.x<target,'Changing direction must immediately steer next hop');h.clear(c);drive(c,h,i,0,.3);assert.equal(f.queued,null);
}
{
 const c=world(),h=Held.create(),f=c.frogs[0];f.alive=false;f.ghost=true;f.row=7;f.x=10.5;drive(c,h,0,8,.7);assert(f.x>12,'Ghost uses the same held controls');drive(c,h,0,0,.2);c.input(0,'tongue');assert(c.attacks.some(a=>a.ghost),'Ghost slap remains real gameplay');
}
{
 const c=world(),f=c.frogs[0];f.power='shield';c.input(0,'power');assert(f.shieldT>0);assert.equal(f.power,null);f.atkCd=0;c.input(0,'tongue');assert(c.attacks.some(a=>a.atk===0));
}
// Run the unchanged ranking/elimination engine through all five rounds with real revenge values.
{
 const c=world();for(let n=1;n<=5;n++){for(let k=0;k<61*120&&c.phase==='play';k++)c.step(1/120);assert.equal(c.phase,'frozen');const R=c.beginRevenge();assert(R);c.revengeDie(2);c.revengeDie(4);assert.equal(c.revenge.sum,6);c.revengeConfirm();c.finishRound();if(n<5){c.startRound();while(c.phase==='countdown')c.step(1/120);assert.equal(c.frogs.filter(f=>f.ghost).length,n);}else assert.equal(c.phase,'over');}assert(c.champion>=0);assert.equal(c.elimOrder.length,5);
}
console.log('PASS six held/released directions, direction change, ghost movement/slap, powers, physical revenge values, five-round elimination/champion and standard color mapping');
