# Blocky Frogger — Shared Mini Vibe Edition

Extract the complete ZIP. Double-click **START_INSTALL.cmd**. Select your existing **Arcadium_OS_COMPACT** folder. Restart Windows once. Launch the existing Blocky Frogger carousel card. **Keep your current universal Mini Vibe app and pairing. No APK included or needed.** The already installed Shared Mini Vibe Controls PC platform is required.

## Controls and personal screens

A joins a frog in the lobby; START starts. Unjoined seats remain CPU, as before. D-pad held in a direction hops continuously; releasing completes the current hop and stops subsequent hops. Changing direction steers the next hop. Missing shared heartbeat expires after 650ms. Keyboard and standard USB gamepads also support held/released directions. Characters, vehicles, sprites, cover art, scoring and original gameplay rules are retained. Checkerboard terrain is replaced with shaded roads, grass and animated water; headlights, reflections, fireflies and goal lighting add depth.

A is tongue slap / timed block-counter; B uses the stored fly power; X/Y or shoulders taunt. START pauses/resumes during play. The PC also has pause, return-to-Arcadium and Pair GoDice buttons. Switching away pauses the PC game and clears movement.

Each Mini Vibe shows the real player's frog camera with nearby cars/logs, actual tongue/power status, combat-hit hearts, fly count and distance. The camera is cropped from the genuine PC scene, not an independent animation. The lane forecast uses the actual next-row landing time and is guidance, not an invincibility promise: hazards keep moving.

Eliminated frogs return as ghosts next round under the existing rules. Their personal view switches to ghost sabotage, displays haunt-slap cooldown and banishment status, and uses the same D-pad/A controls. Players cannot turn themselves into ghosts with a cosmetic button.

Touch controls mirror physical input: hold LEFT/UP/DOWN/RIGHT; A/B/START are shown next to them. Touch cancellation/release and a 650ms expiry prevent a stuck direction if a view disconnects. All player views use the standard order red, blue, green, yellow, pink, white; the old source swapped yellow and pink internally.

## Original match and dice rules

Five 60-second rounds; adjusted-time scoring determines elimination. Preserve tongue combat, power flies, checkpoint respawns, one eliminated player becoming a ghost each round, and last frog champion. Physical GoDice Revenge Roll pairing/roll/pivot support is retained. The uploaded game's existing virtual-roll fallback remains available if no dice are connected; this build does not impose Color Rush's separate physical-coin rules on Frogger.

## Installation and rollback

Only this game's files and helper, its carousel registration and one wrapper call are added/updated. The installer checks payload hashes and the existing shared bridge. Home, main server, shared input platform, pairing and other games (including Color Rush IRL) are preserved. Reinstall is idempotent. Each install creates a blocky_frogger_v1_* backup. Use the rollback button to restore it; later edits are guarded against accidental overwriting.

Automated results and physical test limits: see VALIDATION.md. Six real Mini Vibes and GoDice on your actual LAN still need a physical acceptance check.
