"""Derive offline title/year facts only from the cited Wikipedia movie dataset."""
import json,re,hashlib,argparse
from pathlib import Path
ROOT=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('source',type=Path);a=p.parse_args();raw=a.source.read_bytes();movies=json.loads(raw);rows=[];seen=set();excluded=0
for m in movies:
 title=str(m.get('title') or '').strip();extract=str(m.get('extract') or '')
 key=(title,m.get('year'));intro=extract[:550].lower()
 if not title or key in seen or not m.get('href') or not extract or not re.search(r'\bfilm\b',intro) or re.search(r'^(untitled|tba)\b',title,re.I) or re.search(r'\b(upcoming|unreleased|cancelled|unproduced|never completed)\b',intro):excluded+=1;continue
 seen.add(key);rows.append([title,m.get('year'),'wiki:'+str(m['href'])])
# No descriptions, cast, poster URLs or third-party images are redistributed.
out=ROOT/'games/final-cut/movies.json';out.write_text(json.dumps(rows,ensure_ascii=False,separators=(',',':')))
meta={'source':'https://github.com/servant-42/wikipedia-movie-data','original_repository':'https://github.com/prust/wikipedia-movie-data','dataset':'American movie lists from Wikipedia, 1900–2023','source_sha256':hashlib.sha256(raw).hexdigest(),'derived_records':len(rows),'excluded_records':excluded,'fields':['title','year','Wikipedia article identity'],'limitations':'Not a complete world film database. Host verification handles missing titles. Planned/untitled/unreleased entries and entries lacking film descriptions excluded.'}
(ROOT/'CATALOG_PROVENANCE.json').write_text(json.dumps(meta,indent=2));print(meta)
