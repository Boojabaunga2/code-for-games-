from pathlib import Path
import json,tkinter as tk
from tkinter import filedialog
from update_final_cut import install,rollback
ui=tk.Tk();ui.title('Arcadium / Final Cut');ui.geometry('750x430');status=tk.StringVar(value='Install Final Cut into your existing Arcadium_OS_COMPACT folder. Requires the Shared Mini Vibe Controls PC platform and universal v16 app already installed. This game needs NO new APK. Existing Home, pairing and other games stay in place.')
tk.Label(ui,text='SNIPER KITTY / SIX PLAYERS / MOVIE MAYHEM',font=('Segoe UI',16,'bold')).pack(pady=20);tk.Label(ui,textvariable=status,wraplength=700,justify='left',font=('Segoe UI',12)).pack(padx=20,pady=20)
def run():
 folder=filedialog.askdirectory(title='Select your existing Arcadium_OS_COMPACT folder')
 if not folder:return
 try:
  root=Path(folder);helper=root/'final_cut_routes.py';before=helper.read_bytes() if helper.exists() else None;backup=install(root);Path(__file__).with_name('FINAL_CUT_RECEIPT.json').write_text(json.dumps({'backup':str(backup)},indent=2));status.set('Installed. Backup: '+str(backup)+'\n\n'+('Restart Windows once to load the Final Cut route.' if before!=helper.read_bytes() else 'Refresh Arcadium with Ctrl+F5 and reopen Final Cut.')+'\n\nKeep your existing universal v16 Mini Vibe app. A joins, START launches. On your turn D-pad selects keys, A types and START submits. You can also tap your Mini Vibe keyboard. Physical-device acceptance is still required.')
 except Exception as e:status.set('Stopped: '+str(e))
def undo():
 folder=filedialog.askdirectory(title='Select this game’s final_cut_v1_* backup')
 if not folder:return
 try:rollback(Path(folder));status.set('Previous Final Cut files restored. Restart Windows once if the loaded route changed.')
 except Exception as e:status.set('Rollback stopped: '+str(e))
tk.Button(ui,text='INSTALL SNIPER KITTY',command=run,padx=20,pady=12).pack(pady=8);tk.Button(ui,text='Rollback this game update',command=undo).pack();ui.mainloop()
