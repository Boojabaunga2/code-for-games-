# Credits

Game concept and direction: the user’s six-player movie-chain game and approved FINAL CUT clapperboard concept.

Game rules engine, canvas interface, seven-segment timers, animated boards, keyboard, original carousel SVG, shared-controller integration, PC route/installer and synthesized sound: original implementation for this build. The cinema curtain/reel backdrop is original AI-generated art made for this game. No movie posters or licensed character artwork are used.

Offline title/year/article-identity facts are derived from Peter Rust’s wikipedia-movie-data project, now hosted at https://github.com/servant-42/wikipedia-movie-data (original https://github.com/prust/wikipedia-movie-data). The repository’s MIT licence is included as DATASET-LICENSE.txt. Original facts were collected from Wikipedia’s American-film lists. CATALOG_PROVENANCE.json records the exact upstream file hash, filter and scope. No plot extracts, poster images, thumbnail URLs or cast descriptions are redistributed.

The universal native-input reader is copied unchanged from the existing Arcadium shared-input platform. The Android app, receiver and other installed game adapters are not replaced. Concept imagery and staged presentation captures are identified separately from live controller/route verification in README.md and review evidence.
