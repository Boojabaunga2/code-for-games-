# ARCADIUM / FINAL CUT

Keep the movie chain alive. Two to six players, a cinema clapperboard on the TV, six personal Mini Vibe movie boards and keyboards, a fifteen-second clock, no repeated movies and three strikes to elimination. Last player standing wins. Original gold/crimson cinema artwork, digital board timers, clapper animation, coloured strike tickets, filmstrip history, local sound cues and carousel art follow the approved concept.

## Install — PC only

Requires the existing Shared Mini Vibe Controls PC platform and universal v16 Mini Vibe app already used by Kitty. **No new APK is included or needed.**

1. Exit the current game and extract the complete ZIP.
2. Double-click **START_INSTALL.cmd** on the PC.
3. Select the existing **Arcadium_OS_COMPACT** folder.
4. Restart Windows once to load the additive Final Cut route. Open Arcadium normally, choose FINAL CUT, select two to six seats and start.

The installer preserves Home, main server, pairing, native receiver, previous controller repairs, Kitty, other games and their custom carousel art. It adds one game, one scoped helper and one carousel entry. Known current wrapper chains are retained in order; unknown chains and duplicate registrations stop before writes. A checksummed targeted backup is saved under arcadium_backups/final_cut_v1_*. Installer rollback restores this game only and refuses later conflicting edits.

## Play

Player 1 names any movie. Each following player must name a real movie whose title starts with the previous accepted title’s final letter. For example: JAWS → SCREAM → MOANA → ALIEN → NOPE. Each turn has fifteen seconds, preceded by a short handoff cue. A wrong starting letter, repeated movie, empty submission or timeout costs exactly one strike and passes the turn without changing the required letter. Three strikes eliminate that player; future turns skip them. The last survivor wins. Replay clears the chain and strikes.

- Articles count: THE GODFATHER starts with T.
- Case, punctuation, spacing and Latin accents are ignored for matching. The displayed accepted title sets the next letter.
- A numbered sequel uses its final alphabetic letter: TOY STORY 3 ends on Y. Purely numeric 1917 requires a title beginning with 7.
- A title may be used only once per match, including remakes sharing the title. Known alternate names sharing an article identity cannot be used twice. E.T. is accepted as the familiar short title and ends on T.
- A short clapperboard result cue separates turns. The clock stops during host pause, title review and feedback. Hiding the PC game pauses the match rather than silently striking players.

## Mini Vibe controls

On your turn, **tap the on-screen keyboard** or use the existing physical controls:

| Control | Action |
|---|---|
| Hold D-pad | Move keyboard selection; release stops it |
| A | Type the selected key |
| B or L1 | Delete one character |
| X | Clear your entry |
| Y | Toggle letters and numbers/punctuation |
| R1 | Add a space |
| START | Submit the movie |

In the lobby A joins/readies your colour, B leaves, and START launches. Only the active player can type or submit during a turn. Waiting players see the shared last movie, required letter, timer and their own status. Eliminated players can watch the chain. There are no bots.

PC fallback: type into the active-player text field and press Enter. When the field is not focused, letter keys type directly; arrows move the on-screen selection and Enter submits. The host can pause/resume, verify a missing title, change seats and replay. Standard local gamepads use D-pad/stick and A/B/X/Y/LB/RB/START.

Physical directions use the unchanged universal I1 feed; reliable action impulses use the unchanged ordinary action stream, following the same contract as Kitty. Raw A/START levels never cause a duplicate action. Nothing is added to the Android game/page list. Touch keys use a separate bounded game keyboard queue, with short-lived game/colour/IP-bound sessions, ordered sequence numbers, current-turn validation and host-only consumption. Stale turns and off-turn input are rejected. Touch support lives entirely in the PC-served game page.

## Real movie checking

The offline catalogue contains **33,493 title/year records**, derived from the cited American-film Wikipedia dataset covering 1900–2023. Planned/untitled/unreleased entries and records lacking a film description were filtered. Only title, year and article identity are bundled, not posters, plots or cast text. See CATALOG_PROVENANCE.json and DATASET-LICENSE.txt.

**This is not a complete worldwide or current-release film database.** Missing titles do not automatically count as fake: the clock pauses and the PC host must verify that the film is real and has not appeared under another title. The review panel lists the match’s used movies. Explicit acceptance adds a locally remembered verified title; rejection gives one strike. Host-reviewed alternate names require the host’s duplicate check. No API key, subscription or Internet access is required during play. A missing/corrupt catalogue produces a clear loading error rather than accepting arbitrary titles.

## Verification boundary

Engine tests cover all rules, exact deadlines, pause, keyboard navigation, off-turn/old-turn isolation, review, elimination/replay and the real catalogue. Browser tests exercise the actual inspected authenticated OS receiver with synthetic invitations, six device colours, ordinary actions alongside raw states, real Mini Vibe touch keys, six personal frame routes, host review, results and handoff to the unchanged Kitty route. Install/route tests cover exact ZIP integrity, no APK, guarded repeat/rollback, prior-platform preservation, traversal, stale views, owner handoff and touch session/turn/sequence checks.

Review captures are from the real executable. Presentation screenshots stage the four accepted example titles using the actual submission engine, then freeze the clock and stage strike counts to mirror the concept. The earlier generated mockup is not runtime evidence. Physical handheld behaviour, six-device Wi-Fi throughput, the venue’s running process and antivirus acceptance still need testing on the Arcadium hardware.
