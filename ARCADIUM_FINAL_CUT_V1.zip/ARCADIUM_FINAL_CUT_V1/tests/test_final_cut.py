import base64,hashlib,importlib.util,json,sys,tempfile,threading,time,unittest,urllib.request,urllib.error,zipfile
from pathlib import Path
from http.server import ThreadingHTTPServer
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));import update_final_cut as updater;import final_cut_routes as routes
spec=importlib.util.spec_from_file_location('final_cut_shared_reference',ROOT.parent/'universal-mini-vibe-input/tests/harness.py');ref=importlib.util.module_from_spec(spec);spec.loader.exec_module(ref)
class Install(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);r=self.root;(r/'data').mkdir()
  (r/'data/arcadium.json').write_text(json.dumps({'games':[{'id':'final-cut','name':'FINAL CUT','image':'approved-final-cut.png','custom':'KEEP'},{'id':'sniper-kitty','image':'approved-kitty.png','controls':'KEEP'},{'id':'rc-trigger-racing','controls':'KEEP TEN LAPS'}],'activity':[]}))
  (r/'arcadium_server.py').write_text('import arcadium_game_bridge\n# main server / pairing unchanged\n')
  (r/'arcadium_game_bridge.py').write_text('import threading\nfrom e3mi_routes import wrap_e3mi_handler\nfrom universal_input_routes import wrap_native_input_handler\nfrom sniper_kitty_routes import wrap_sniper_kitty_handler\nfrom ghost_bubble_routes import wrap_ghost_bubble_handler\nfrom boop_routes import wrap_boop_handler\nACTIVE_WEB_GAME={"game":None,"until":0}\nACTIVE_LOCK=threading.RLock()\ndef bridge(Base):\n    class GameBridge(Base):pass\n    return wrap_sniper_kitty_handler(wrap_native_input_handler(wrap_boop_handler(wrap_ghost_bubble_handler(wrap_e3mi_handler(GameBridge)))))\n')
  (r/'e3mi_routes.py').write_text('def wrap_e3mi_handler(Base):return Base\n')
  for source,name in [('universal-mini-vibe-input','universal_input_routes.py'),('sniper-kitty','sniper_kitty_routes.py'),('ghost-bubble','ghost_bubble_routes.py'),('boop','boop_routes.py')]:(r/name).write_bytes((ROOT.parent/source/name).read_bytes())
  for name,data in [('HOME.html',b'HOME'),('data/pink_vibe_device.json',b'PAIRING'),('games/wormaldeon/index.html',b'TENNIS'),('games/rc-trigger-racing/engine.mjs',b'TEN LAPS'),('games/sniper-kitty/main.mjs',b'WORKING KITTY'),('games/arcadium-boop/index.html',b'WORKING BOOP')]:
   p=r/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 def tearDown(self):self.tmp.cleanup()
 def snap(self):return {p.relative_to(self.root).as_posix():p.read_bytes() for p in self.root.rglob('*') if p.is_file() and 'arcadium_backups' not in p.parts}
 def test_targeted_install_repeat_catalog_and_rollback(self):
  before=self.snap();one=updater.install(self.root);first=(self.root/'arcadium_game_bridge.py').read_bytes();two=updater.install(self.root);self.assertEqual(first,(self.root/'arcadium_game_bridge.py').read_bytes());cat=json.loads((self.root/'data/arcadium.json').read_text());self.assertEqual(len(cat['games']),3);self.assertEqual(cat['games'][0]['image'],'approved-final-cut.png');self.assertEqual(cat['games'][1]['image'],'approved-kitty.png');self.assertEqual(cat['games'][0]['custom'],'KEEP');self.assertEqual(cat['games'][0]['miniVibeUrl'],'/games/final-cut/personal/vibe.html');updater.rollback(two);updater.rollback(one)
  for name,data in before.items():
   if name=='data/arcadium.json':self.assertEqual(json.loads((self.root/name).read_text()),json.loads(data))
   else:self.assertEqual((self.root/name).read_bytes(),data,name)
 def test_guards_and_unique_new_registration(self):
  c={'games':[{'id':'other'}]};updater.registration(c);self.assertEqual(len(c['games']),2);self.assertEqual(c['games'][1]['id'],'final-cut');c['games'].append({'id':'copy','title':'Final Cut'});self.assertRaises(RuntimeError,updater.registration,c)
  before=self.snap();(self.root/'universal_input_routes.py').unlink();self.assertRaises(RuntimeError,updater.install,self.root);self.assertFalse((self.root/'games/final-cut').exists());(self.root/'universal_input_routes.py').write_bytes(before['universal_input_routes.py']);(self.root/'arcadium_game_bridge.py').write_text('def bridge(Base):return Base\n');self.assertRaises(RuntimeError,updater.install,self.root)
 def test_exact_zip_no_apk_checksums_and_later_edit_guard(self):
  path=ROOT.parents[1]/'downloads/ARCADIUM_FINAL_CUT_V1.zip'
  with tempfile.TemporaryDirectory() as d:
   with zipfile.ZipFile(path) as z:self.assertFalse(any(n.endswith('.apk') for n in z.namelist()));self.assertIsNone(z.testzip());z.extractall(d)
   package=Path(d)/path.stem;spec=importlib.util.spec_from_file_location('final_cut_exact',package/'update_final_cut.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);one=m.install(self.root);two=m.install(self.root);m.rollback(two);m.rollback(one);(package/'games/final-cut/main.mjs').write_text('corrupt');self.assertRaises(RuntimeError,m.install,self.root)
  one=updater.install(self.root);(self.root/'games/final-cut/main.mjs').write_text('later work');self.assertRaises(RuntimeError,updater.rollback,one)
class Routes(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  bridge,Parent=ref.ref.harness.modules();cls.H=routes.wrap_final_cut_handler(Parent)
  class Quiet(cls.H):
   def log_message(self,*args):pass
  cls.server=ThreadingHTTPServer(('127.0.0.1',0),Quiet);cls.server.events={'latest':0,'events':[],'slots':[]};cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True);cls.thread.start();cls.base='http://127.0.0.1:'+str(cls.server.server_port)
 @classmethod
 def tearDownClass(cls):cls.server.shutdown();cls.server.server_close();cls.thread.join()
 def req(self,path,data=None):
  try:
   with urllib.request.urlopen(urllib.request.Request(self.base+path,data=None if data is None else json.dumps(data).encode(),headers={'Content-Type':'application/json'})) as r:return r.status,r.read()
  except urllib.error.HTTPError as e:return e.code,e.read()
 def frame(self,owner='first',turn=0,turnId='turn-one',phase='turn',pause=False):
  return self.req('/arcadium-final-cut/final-cut/frame',{'owner':owner,'seat':1,'image':base64.b64encode(b'\xff\xd8test').decode(),'state':{'phase':phase,'turn':turn,'turnId':turnId,'pause':pause,'numbers':[False]*6}})
 def session(self,color):return json.loads(self.req('/arcadium-final-cut/final-cut/touch/session?color='+color)[1])
 def test_six_personal_routes_static_stale_and_safe_owner_handoff(self):
  self.assertEqual(self.req('/arcadium-vibe/activate/final-cut',{'owner':'first'})[0],200)
  for i,color in enumerate(routes.COLORS):
   mode=json.loads(self.req('/api/vibe/mode?color='+color)[1]);self.assertEqual(mode['game'],'final-cut');self.assertEqual(mode['nativeState'],1);image=b'\xff\xd8'+color.encode();self.assertEqual(self.req('/arcadium-final-cut/final-cut/frame',{'owner':'first','seat':i+1,'image':base64.b64encode(image).decode()})[0],200);self.assertEqual(self.req('/arcadium-final-cut/final-cut/frame?color='+color),(200,image))
  for path in ['index.html','main.mjs','engine.mjs','render.mjs','native-input.js','personal/vibe.html','assets/cinema.png','movies.json','card.svg']:self.assertEqual(self.req('/games/final-cut/'+path)[0],200,path)
  self.assertEqual(self.req('/games/final-cut/%2e%2e/%2e%2e/update_final_cut.py')[0],404);routes.FRAMES[1]=(time.monotonic()-4,b'old');self.assertEqual(self.req('/arcadium-final-cut/final-cut/frame?color=red')[0],503)
  self.req('/arcadium-vibe/activate/final-cut',{'owner':'second'});self.assertEqual(self.req('/arcadium-final-cut/final-cut/frame?color=blue')[0],503);self.req('/arcadium-vibe/activate/final-cut',{'owner':'first','active':False});self.assertEqual(json.loads(self.req('/api/vibe/mode?color=red')[1])['game'],'final-cut');self.assertEqual(self.req('/arcadium-vibe/activate/final-cut',{'owner':'first','renew':True})[0],409)
  self.req('/arcadium-vibe/activate/rc-trigger-racing',{});self.assertEqual(self.req('/arcadium-vibe/activate/final-cut',{'owner':'second','renew':True})[0],409);self.req('/arcadium-vibe/activate/final-cut',{'owner':'second','active':False});self.assertEqual(json.loads(self.req('/api/vibe/mode?color=red')[1])['game'],'rc-trigger-racing')
 def test_touch_keyboard_colour_turn_sequence_tokens_and_validation(self):
  self.req('/arcadium-vibe/activate/final-cut',{'owner':'first'});self.assertEqual(self.frame()[0],200);red=self.session('red');blue=self.session('blue');base='/arcadium-final-cut/final-cut/touch/'
  def key(token,n=1,value='A',turn='turn-one'):return self.req(base+'key',{'token':token,'seq':n,'key':value,'turnId':turn})[0]
  self.assertEqual(key('invalid'),403);self.assertEqual(key(blue['token']),409);self.assertEqual(key(red['token'],turn='old-turn'),409);self.assertEqual(key(red['token'],value='<script>'),400);self.assertEqual(key(red['token'],n=True),400)
  self.assertEqual(key(red['token']),200);self.assertEqual(key(red['token']),200);events=json.loads(self.req(base+'events?after=0')[1]);self.assertEqual(len(events['events']),1);self.assertEqual(events['events'][0]['color'],'red');self.assertEqual(events['events'][0]['key'],'A');self.assertEqual(key(red['token'],2,'SPACE'),200)
  self.frame(pause=True);self.assertEqual(key(red['token'],3),409);self.frame(turn=1,turnId='turn-two');self.assertEqual(key(red['token'],4,turn='turn-two'),409);self.assertEqual(key(blue['token'],2,'B','turn-two'),200)
  routes.UI_STATE['at']=time.monotonic()-3;self.assertEqual(key(blue['token'],3,'C','turn-two'),409);routes.UI_STATE['at']=time.monotonic();self.req('/arcadium-vibe/activate/final-cut',{'owner':'second'});self.assertEqual(key(blue['token'],4,'D','turn-two'),403)
  nonhost=type('Peer',(),{'client_address':('192.168.1.9',5),'connection':type('Connection',(),{'getsockname':lambda self:('192.168.1.1',8787)})()})();self.assertFalse(self.H._final_cut_host(nonhost))
if __name__=='__main__':unittest.main()
