# Haunt & Seek V2 validation

V2 reduces normal ghosts, adds delayed respawns and a hunter stun gun, and retains all five castles, captain powers, art and the same shared controller reader.

- All 13 original engine tests remain, with one fixture explicitly spawning its far-away test ghost because capture no longer respawns immediately.
- Nine additional scarcity/stun tests cover round budgets, delayed respawns, close-range lock theft, stun recovery, recharge/immunity, aim/range/line-of-sight restrictions, captain immunity, pause and reset behavior.
- Fresh six-screen Chromium checks exercise the unchanged shared native receiver, native R shoulder, radar, held START/release, stolen capture scoring, stunned movement, personal touch R1 and delayed respawns. The bridge is a minimal contract fixture, not the user's full OS. See review/v2-browser.json and V2 screenshots.
- Extracted-ZIP tests cover preservation, checksums, backups/idempotency and launching the original installed server from a path containing spaces and ampersands.
- The V2 Windows workflow records exact archive/extracted Defender scans and Internet attachment checks for the actual V2 package. Read its result before treating those scans as complete. V1 review files are historical evidence only.

Not physically verified: real Mini Vibe hardware, venue Wi-Fi, the user's full installed OS or recipient antivirus acceptance. A Windows runner scan does not guarantee acceptance on the recipient PC. Keep protection enabled and leave flagged downloads blocked. No manual Microsoft-review verdict is claimed.
