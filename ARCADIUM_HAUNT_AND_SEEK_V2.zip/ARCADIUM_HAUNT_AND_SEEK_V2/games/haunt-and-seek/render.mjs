import { CASTLES, COLORS, HEX, POWERS, clamp, dist } from "./engine.mjs";
export const buttons = [
  { key: "LEFT", label: "◀", x: 25, y: 653, w: 48, h: 44 },
  { key: "UP", label: "▲", x: 77, y: 607, w: 48, h: 43 },
  { key: "DOWN", label: "▼", x: 77, y: 653, w: 48, h: 44 },
  { key: "RIGHT", label: "▶", x: 129, y: 653, w: 48, h: 44 },
  { key: "L1", label: "‹ POWER", x: 205, y: 653, w: 82, h: 44 },
  { key: "R1", label: "POWER ›", x: 293, y: 653, w: 82, h: 44 },
  { key: "START", label: "START / PAUSE", x: 205, y: 610, w: 170, h: 35 },
  { key: "B", label: "B / PULSE", x: 393, y: 631, w: 108, h: 66 },
  { key: "A", label: "A / CAPTURE", x: 513, y: 613, w: 183, h: 84 },
];
export function text(
  g,
  s,
  x,
  y,
  size = 22,
  color = "#e6edff",
  align = "left",
  weight = 800,
) {
  g.font = weight + " " + size + "px Arial";
  g.textAlign = align;
  g.textBaseline = "middle";
  g.fillStyle = color;
  g.fillText(String(s), x, y);
}
export function panel(
  g,
  x,
  y,
  w,
  h,
  stroke = "#315267",
  fill = "#0b1729",
  r = 12,
) {
  g.beginPath();
  g.roundRect(x, y, w, h, r);
  g.fillStyle = fill;
  g.fill();
  if (stroke) {
    g.strokeStyle = stroke;
    g.lineWidth = 2;
    g.stroke();
  }
}
function poly(g, points, fill, stroke) {
  g.beginPath();
  points.forEach((p, i) => (i ? g.lineTo(p.x, p.y) : g.moveTo(p.x, p.y)));
  g.closePath();
  g.fillStyle = fill;
  g.fill();
  if (stroke) {
    g.strokeStyle = stroke;
    g.lineWidth = 1;
    g.stroke();
  }
}
function glow(g, x, y, r, color) {
  const gr = g.createRadialGradient(x, y, 0, x, y, r);
  gr.addColorStop(0, color);
  gr.addColorStop(1, "#00000000");
  g.fillStyle = gr;
  g.fillRect(x - r, y - r, r * 2, r * 2);
}
export class Renderer {
  constructor(atlas, rooms) {
    this.atlas = atlas;
    this.roomsAtlas = rooms;
    this.bg = null;
    this.castle = null;
    this.tw = 46;
    this.th = 24;
  }
  sprite(g, id, x, y, size = 72, alpha = 1, flip = false) {
    if (!this.atlas.complete || !this.atlas.naturalWidth) return;
    const w = this.atlas.naturalWidth / 4,
      h = this.atlas.naturalHeight / 4;
    g.save();
    g.globalAlpha = alpha;
    g.translate(x, y);
    if (flip) g.scale(-1, 1);
    g.drawImage(
      this.atlas,
      (id % 4) * w,
      Math.floor(id / 4) * h,
      w,
      h,
      -size / 2,
      -size * 0.93,
      size,
      size,
    );
    g.restore();
  }
  iso(x, y) {
    return {
      x: 960 + ((x - y) * this.tw) / 2,
      y: 207 + ((x + y) * this.th) / 2,
    };
  }
  tile(g, x, y, fill, stroke) {
    poly(
      g,
      [
        this.iso(x, y),
        this.iso(x + 1, y),
        this.iso(x + 1, y + 1),
        this.iso(x, y + 1),
      ],
      fill,
      stroke,
    );
  }
  bake(game) {
    const c = game.castle;
    this.castle = c;
    this.bg = Object.assign(document.createElement("canvas"), {
      width: 1920,
      height: 1080,
    });
    const g = this.bg.getContext("2d");
    const grad = g.createRadialGradient(960, 430, 20, 960, 450, 1000);
    grad.addColorStop(0, "#20223e");
    grad.addColorStop(0.65, "#0c1428");
    grad.addColorStop(1, "#030914");
    g.fillStyle = grad;
    g.fillRect(0, 0, 1920, 1080);
    this.tw = Math.min(42, (1450 / (c.width + c.height)) * 2);
    this.th = this.tw * 0.52;
    for (let i = 0; i < 110; i++) {
      const x = (i * 163 + 47) % 1900,
        y = (i * 281 + 71) % 880;
      g.fillStyle = i % 3 ? "#4c5a7433" : "#a99df055";
      g.fillRect(x, y, 2, 2);
    }
    const tiles = [...c.floor]
      .map((k) => k.split(",").map(Number))
      .sort((a, b) => a[0] + a[1] - b[0] - b[1]);
    for (const [x, y] of tiles) {
      const r = c.rooms.find(
        (r) => x >= r.x && x < r.x + r.w && y >= r.y && y < r.y + r.h,
      );
      const carpet =
        r &&
        x > r.x + 1 &&
        x < r.x + r.w - 1 &&
        y > r.y + 1 &&
        y < r.y + r.h - 1;
      const shade = (x * 11 + y * 7 + c.index) % 4;
      this.tile(
        g,
        x,
        y,
        carpet ? ["#493159", "#51365e", "#4e355d", "#563b67"][shade] : c.floor,
        "#7c71852a",
      );
      if (!c.floor.has(x + "," + (y + 1))) {
        const a = this.iso(x, y + 1),
          b = this.iso(x + 1, y + 1);
        poly(
          g,
          [a, b, { x: b.x, y: b.y + 9 }, { x: a.x, y: a.y + 9 }],
          "#171528",
          "#5a4d69",
        );
      }
      if (!c.floor.has(x + 1 + "," + y)) {
        const a = this.iso(x + 1, y),
          b = this.iso(x + 1, y + 1);
        poly(
          g,
          [a, b, { x: b.x, y: b.y + 9 }, { x: a.x, y: a.y + 9 }],
          "#101321",
          "#3b3c59",
        );
      }
    }
    for (const [x, y] of tiles) {
      if (!c.floor.has(x + "," + (y - 1))) {
        const a = this.iso(x, y),
          b = this.iso(x + 1, y);
        poly(
          g,
          [{ x: a.x, y: a.y - 25 }, { x: b.x, y: b.y - 25 }, b, a],
          c.wall,
          "#8b75926b",
        );
        g.strokeStyle = c.accent + "55";
        g.beginPath();
        g.moveTo(a.x, a.y - 25);
        g.lineTo(b.x, b.y - 25);
        g.stroke();
      }
      if (!c.floor.has(x - 1 + "," + y)) {
        const a = this.iso(x, y),
          b = this.iso(x, y + 1);
        poly(
          g,
          [{ x: a.x, y: a.y - 25 }, { x: b.x, y: b.y - 25 }, b, a],
          c.wall,
          "#8b75926b",
        );
      }
    }
    for (const r of c.rooms) {
      if (this.roomsAtlas?.complete) {
        const im = this.roomsAtlas,
          cw = im.naturalWidth / 3,
          ch = im.naturalHeight / 3,
          q = this.iso(r.x, r.y),
          ex = { x: (r.w * this.tw) / 2, y: (r.w * this.th) / 2 },
          ey = { x: (-r.h * this.tw) / 2, y: (r.h * this.th) / 2 },
          ax = (ex.x - ey.x) / (0.96 * cw),
          ay = (ex.y - ey.y) / (0.96 * cw),
          bx = (ex.x + ey.x) / (0.44 * ch),
          by = (ex.y + ey.y) / (0.44 * ch);
        g.save();
        g.filter = "hue-rotate(" + [0, -130, -40, 70, 25][c.index] + "deg)";
        g.transform(
          ax,
          ay,
          bx,
          by,
          q.x - ax * cw * 0.5 - bx * ch * 0.52,
          q.y - ay * cw * 0.5 - by * ch * 0.52,
        );
        g.drawImage(
          im,
          (r.id % 3) * cw,
          Math.floor(r.id / 3) * ch,
          cw,
          ch,
          0,
          0,
          cw,
          ch,
        );
        g.restore();
      }
    }
  }
  map(g, game, x, y, w, h, player, radar = false) {
    const c = game.castle,
      scale = Math.min((w - 20) / c.width, (h - 20) / c.height),
      ox = x + (w - c.width * scale) / 2,
      oy = y + (h - c.height * scale) / 2;
    for (const d of c.doors) {
      const a = c.rooms[d.a],
        b = c.rooms[d.b];
      g.strokeStyle = d.closed > 0 ? "#ff807e" : "#3c6073";
      g.lineWidth = Math.max(2, scale * 0.28);
      g.beginPath();
      g.moveTo(ox + a.cx * scale, oy + a.cy * scale);
      g.lineTo(ox + b.cx * scale, oy + b.cy * scale);
      g.stroke();
    }
    for (const r of c.rooms) {
      const selected = player.room === r.id;
      panel(
        g,
        ox + r.x * scale,
        oy + r.y * scale,
        r.w * scale,
        r.h * scale,
        selected ? HEX[player.i] : c.accent + "66",
        selected ? "#264848" : "#15273a",
        3,
      );
      if (scale > 6)
        text(
          g,
          r.name.split(" ")[0].slice(0, 3).toUpperCase(),
          ox + r.cx * scale,
          oy + r.cy * scale,
          Math.min(15, scale * 1.2),
          selected ? "#d4fff3" : "#829bb6",
          "center",
        );
    }
    if (player.role === "captain" || player.reveal > 0) {
      for (const q of game.ghosts) {
        if (player.role !== "captain" && dist(player, q) > 16) continue;
        g.fillStyle =
          q.kind === "rare"
            ? "#ffe18a"
            : q.kind === "decoy"
              ? "#ed8cda"
              : "#7de9ff";
        g.beginPath();
        g.arc(
          ox + q.x * scale,
          oy + q.y * scale,
          Math.max(2, scale * 0.18),
          0,
          Math.PI * 2,
        );
        g.fill();
      }
    }
    for (const p of game.players) {
      if (p.role === "captain" && p.i !== player.i) continue;
      g.fillStyle = HEX[p.i];
      g.beginPath();
      g.arc(
        ox + p.x * scale,
        oy + p.y * scale,
        p.i === player.i ? 5 : 2.5,
        0,
        Math.PI * 2,
      );
      g.fill();
      if (p.i === player.i) {
        g.strokeStyle = "#fff";
        g.lineWidth = 1;
        g.stroke();
      }
    }
  }
  main(g, game) {
    if (this.castle !== game.castle) this.bake(game);
    g.drawImage(this.bg, 0, 0);
    const t = game.time;
    for (const p of game.players) {
      const a = this.iso(p.x, p.y);
      glow(g, a.x, a.y, 48, HEX[p.i] + "25");
      if (p.reveal > 0) {
        g.strokeStyle = HEX[p.i] + "55";
        g.lineWidth = 2;
        g.beginPath();
        g.ellipse(
          a.x,
          a.y,
          60 + p.reveal * 12,
          28 + p.reveal * 6,
          0,
          0,
          Math.PI * 2,
        );
        g.stroke();
      }
    }
    const objects = [
      ...game.castle.props.map((o) => ({ ...o, type: "prop" })),
      ...game.castle.doors.map((o) => ({ ...o, type: "door" })),
      ...game.ghosts.map((o) => ({ ...o, type: "spirit" })),
      ...game.players.map((o) => ({ ...o, type: "player" })),
    ].sort((a, b) => a.x + a.y - b.x - b.y);
    for (const o of objects) {
      const q = this.iso(o.x, o.y);
      if (o.type === "prop") {
        this.sprite(g, o.kind, q.x, q.y + 5, 80);
        continue;
      }
      if (o.type === "door") {
        const a = this.iso(
            o.x - (o.horizontal ? 0 : 1),
            o.y - (o.horizontal ? 1 : 0),
          ),
          b = this.iso(
            o.x + (o.horizontal ? 0 : 1),
            o.y + (o.horizontal ? 1 : 0),
          );
        g.strokeStyle = o.closed > 0 ? "#ff9d83" : "#c6b09055";
        g.lineWidth = o.closed > 0 ? 5 : 2;
        g.beginPath();
        g.moveTo(a.x, a.y);
        g.lineTo(b.x, b.y);
        g.stroke();
        if (o.closed > 0) {
          for (let n = 0; n < 5; n++) {
            const x = a.x + ((b.x - a.x) * n) / 4,
              y = a.y + ((b.y - a.y) * n) / 4;
            g.beginPath();
            g.moveTo(x, y);
            g.lineTo(x, y - 34);
            g.stroke();
          }
          text(
            g,
            Math.ceil(o.closed) + "s",
            q.x,
            q.y - 43,
            16,
            "#ffe2d6",
            "center",
          );
        }
        continue;
      }
      if (o.type === "spirit") {
        const hunters = game.players.filter((p) => p.role === "hunter");
        const revealed = hunters.some((p) => p.reveal > 0 && dist(p, o) < 16);
        if (
          !revealed &&
          !hunters.some((p) => dist(p, o) < 4.2 && game.lineClear(p, o))
        )
          continue;
        glow(
          g,
          q.x,
          q.y - 12,
          33,
          o.kind === "rare"
            ? "#ffd25c35"
            : o.kind === "decoy" && revealed
              ? "#f678db26"
              : "#45dfff28",
        );
        this.sprite(
          g,
          o.kind === "rare" ? 7 : o.kind === "decoy" && revealed ? 9 : 6,
          q.x,
          q.y - 4 + Math.sin(t * 2.7 + o.phase) * 4,
          43,
          0.9,
        );
        continue;
      }
      const p = game.players[o.i],
        captain = p.role === "captain";
      g.fillStyle = "#00000055";
      g.beginPath();
      g.ellipse(q.x, q.y + 3, 16, 7, 0, 0, Math.PI * 2);
      g.fill();
      this.sprite(
        g,
        captain ? 8 : p.i,
        q.x,
        q.y + (p.move ? Math.sin(t * 15) * 2 : 0),
        captain ? 65 : 68,
        captain ? 0.8 : 1,
        Math.cos(p.heading) < 0,
      );
      panel(
        g,
        q.x - 24,
        q.y + 7,
        48,
        19,
        HEX[p.i],
        captain ? "#3d1755" : "#111e32",
        5,
      );
      text(g, "P" + (p.i + 1), q.x, q.y + 17, 13, HEX[p.i], "center");
      if (!p.human) text(g, "CPU", q.x, q.y + 35, 10, "#a9bed0", "center");
      if (!captain && (p.stun > 0 || p.stunImmune > 0)) {
        g.save(); g.strokeStyle=p.stun>0?"#8af9ff":"#9cb4e9"; g.lineWidth=p.stun>0?4:2;
        g.setLineDash(p.stun>0?[8,5]:[3,9]);g.beginPath();g.ellipse(q.x,q.y-25,35,48,t*2,0,Math.PI*2);g.stroke();g.restore();
        if(p.stun>0)text(g,"ZAPPED!",q.x,q.y-83,16,"#a9faff","center");
      }
      const target = game.ghosts.find((s) => s.id === p.target);
      if (target && p.progress > 0) {
        const b = this.iso(target.x, target.y);
        g.save();
        g.strokeStyle = HEX[p.i];
        g.shadowBlur = 14;
        g.shadowColor = HEX[p.i];
        g.lineWidth = 3 + Math.sin(t * 15);
        g.beginPath();
        g.moveTo(q.x, q.y - 29);
        g.quadraticCurveTo(
          (q.x + b.x) / 2 + Math.sin(t * 10) * 10,
          (q.y + b.y) / 2 - 48,
          b.x,
          b.y - 18,
        );
        g.stroke();
        g.lineWidth = 3;
        g.beginPath();
        g.ellipse(
          b.x,
          b.y - 16,
          20,
          13,
          0,
          -Math.PI / 2,
          -Math.PI / 2 + Math.PI * 2 * clamp(p.progress, 0, 1),
        );
        g.stroke();
        g.restore();
      }
    }
    for (const f of game.fx) {
      const q = this.iso(f.x, f.y),
        u = f.t / f.life;
      g.save();
      g.globalAlpha = 1 - u;
      if (f.type === "stunshot") {
        const b=this.iso(f.tx,f.ty);g.strokeStyle="#a3fbff";g.shadowColor="#54deff";g.shadowBlur=20;g.lineWidth=5;g.beginPath();g.moveTo(q.x,q.y-30);
        for(let k=1;k<=8;k++){const z=k/8;g.lineTo(q.x+(b.x-q.x)*z+(k%2?9:-9),q.y+(b.y-q.y)*z-30);}g.stroke();
      } else if (f.type === "capture") {
        for (let k = 0; k < 12; k++) {
          const a = (k * Math.PI) / 6 + u * 3;
          g.fillStyle = HEX[f.i];
          g.fillRect(
            q.x + Math.cos(a) * u * 55,
            q.y - 20 + Math.sin(a) * u * 30,
            4,
            4,
          );
        }
        text(g, "+" + f.value, q.x, q.y - 55 - u * 24, 24, HEX[f.i], "center");
      } else {
        g.strokeStyle = HEX[f.i];
        g.lineWidth = 3;
        g.beginPath();
        g.ellipse(q.x, q.y, 20 + u * 170, 10 + u * 80, 0, 0, Math.PI * 2);
        g.stroke();
      }
      g.restore();
    }
    for (const r of game.castle.rooms) {
      const a = this.iso(r.cx, r.y + r.h * 0.9);
      g.font = "bold 15px Arial";
      const title = r.id + 1 + " / " + r.name.toUpperCase(),
        width = g.measureText(title).width + 16;
      panel(
        g,
        a.x - width / 2,
        a.y - 11,
        width,
        23,
        game.castle.accent + "55",
        "#0c1429cc",
        5,
      );
      text(g, title, a.x, a.y, 15, "#e5dbf7", "center");
    }
    panel(g, 25, 18, 1870, 93, "#7f67ac", "#0b1225ed", 18);
    text(g, "△ ARCADIUM", 48, 46, 18, "#d3bbff");
    text(g, "HAUNT & SEEK", 48, 82, 36, "#fff");
    text(
      g,
      game.castle.name.toUpperCase(),
      963,
      52,
      27,
      game.castle.accent,
      "center",
    );
    text(
      g,
      "CASTLE " + (game.round + 1) + " / 5  ·  9 CONNECTED ROOMS",
      963,
      85,
      17,
      "#a6bdd0",
      "center",
    );
    const clock =
      game.phase === "countdown"
        ? Math.ceil(3 - game.phaseTime)
        : Math.ceil(game.remaining);
    text(
      g,
      game.phase === "lobby"
        ? "READY?"
        : game.paused
          ? "PAUSED"
          : Math.floor(clock / 60) + ":" + String(clock % 60).padStart(2, "0"),
      1867,
      64,
      48,
      clock <= 10 ? "#ffb296" : "#79f7da",
      "right",
    );
    for (const p of game.players) {
      const x = 25 + p.i * 314;
      panel(
        g,
        x,
        924,
        302,
        126,
        HEX[p.i],
        p.role === "captain" ? "#271839ed" : "#0c1729ed",
        14,
      );
      this.sprite(g, p.role === "captain" ? 8 : p.i, x + 47, 1014, 78);
      text(
        g,
        "P" +
          (p.i + 1) +
          " " +
          COLORS[p.i].toUpperCase() +
          (p.human ? "" : " / CPU"),
        x + 92,
        949,
        18,
        HEX[p.i],
      );
      text(
        g,
        p.role === "captain" ? "GHOST CAPTAIN" : p.score + " PTS",
        x + 92,
        980,
        22,
        "#fff",
      );
      text(
        g,
        p.role === "captain"
          ? Math.floor(p.energy) + " ENERGY / " + p.casts + " HAUNTS"
          : p.stun > 0 ? "ZAPPED! LOCK LOST" : p.captures + " GHOSTS / R-SHOULDER STUN",
        x + 92,
        1011,
        12,
        "#bdcde2",
      );
      g.fillStyle = p.role === "captain" ? "#a06ef0" : HEX[p.i];
      g.fillRect(
        x + 17,
        1035,
        (p.role === "captain" ? p.energy / 100 : clamp(p.progress, 0, 1)) * 268,
        4,
      );
    }
    if (game.phase === "play" && !game.paused) {
      const captains = game.players.filter((p) => p.role === "captain").length;
      text(
        g,
        captains
          ? "GHOST CAPTAINS ARE HAUNTING THE CASTLE"
          : "SCARCE GHOSTS / R-SHOULDER STUN / BREAK RIVAL LOCKS AND STEAL THE CAPTURE",
        960,
        889,
        17,
        captains ? "#ddb2ff" : "#b4c8df",
        "center",
      );
    }
    if (game.phase === "countdown" || game.paused) {
      panel(g, 645, 360, 630, 180, "#a58ada", "#09152bef", 22);
      text(
        g,
        game.paused ? "PAUSED" : Math.ceil(3 - game.phaseTime),
        960,
        423,
        66,
        "#fff",
        "center",
      );
      text(
        g,
        game.paused ? "START TO RESUME" : "NINE ROOMS. FOLLOW YOUR TRACKER.",
        960,
        496,
        21,
        "#97efdc",
        "center",
      );
    }
  }
  mini(g, game, i) {
    const p = game.players[i],
      c = HEX[i],
      captain = p.role === "captain",
      dash = game.dashboard(i),
      time = Math.ceil(game.remaining);
    g.fillStyle = "#081221";
    g.fillRect(0, 0, 720, 720);
    panel(g, 9, 9, 702, 702, c, "#0a1729", 17);
    text(g, "△ ARCADIUM / HAUNT & SEEK", 25, 37, 20, "#cfb8ff");
    text(
      g,
      "P" + (i + 1) + " " + COLORS[i].toUpperCase(),
      695,
      37,
      18,
      c,
      "right",
    );
    text(g, captain ? "GHOST CAPTAIN" : "HUNTER TRACKER", 25, 79, 32, c);
    text(
      g,
      game.phase === "lobby"
        ? "READY"
        : Math.floor(time / 60) + ":" + String(time % 60).padStart(2, "0"),
      695,
      79,
      33,
      "#7ef7d8",
      "right",
    );
    text(
      g,
      game.castle.name + " / Castle " + (game.round + 1) + " of 5",
      25,
      114,
      17,
      "#b6c4dc",
    );
    if (captain) {
      this.sprite(g, 8, 93, 305, 150);
      text(
        g,
        Math.floor(p.energy) + " ENERGY",
        99,
        330,
        19,
        "#b6ffb2",
        "center",
      );
      panel(g, 190, 143, 505, 270, "#5d618b", "#101b32");
      this.map(g, game, 200, 152, 485, 248, p);
      text(
        g,
        game.castle.rooms[p.room].name.toUpperCase(),
        442,
        425,
        21,
        "#c1ffdf",
        "center",
      );
      for (let k = 0; k < 3; k++) {
        const x = 23 + k * 227,
          selected = p.power === k,
          power = POWERS[k],
          ready = p.energy >= power.cost && p.powerCd[k] <= 0;
        panel(
          g,
          x,
          446,
          220,
          118,
          selected ? "#c9ffbf" : "#634e85",
          selected ? "#244131" : "#211932",
        );
        text(
          g,
          power.id,
          x + 110,
          467,
          17,
          selected ? "#d5ffbc" : "#eee1ff",
          "center",
        );
        text(g, power.cost + " ENERGY", x + 110, 500, 18, "#abefb0", "center");
        text(
          g,
          p.powerCd[k] > 0
            ? Math.ceil(p.powerCd[k]) + "s COOLDOWN"
            : ready
              ? "READY"
              : "RECHARGING",
          x + 110,
          535,
          14,
          ready ? "#acffbf" : "#b2a4c9",
          "center",
        );
      }
      text(
        g,
        "TARGET: P" +
          (p.victim + 1) +
          " " +
          COLORS[p.victim].toUpperCase() +
          " / B TO CHANGE",
        360,
        584,
        16,
        "#dabaff",
        "center",
      );
    } else {
      panel(g, 23, 144, 674, 315, "#2a6c76", "#091d29");
      const cx = 196,
        cy = 305,
        r = 137;
      g.save();
      g.beginPath();
      g.arc(cx, cy, r, 0, Math.PI * 2);
      g.clip();
      const gr = g.createRadialGradient(cx, cy, 0, cx, cy, r);
      gr.addColorStop(0, "#16494a");
      gr.addColorStop(1, "#071929");
      g.fillStyle = gr;
      g.fillRect(cx - r, cy - r, r * 2, r * 2);
      g.strokeStyle = "#4acebe44";
      g.lineWidth = 1;
      for (let k = 1; k < 5; k++) {
        g.beginPath();
        g.arc(cx, cy, (r * k) / 4, 0, Math.PI * 2);
        g.stroke();
      }
      g.beginPath();
      g.moveTo(cx - r, cy);
      g.lineTo(cx + r, cy);
      g.moveTo(cx, cy - r);
      g.lineTo(cx, cy + r);
      g.stroke();
      const a = game.time * 1.5;
      g.fillStyle = "#56ffd318";
      g.beginPath();
      g.moveTo(cx, cy);
      g.arc(cx, cy, r, a, a + 0.75);
      g.closePath();
      g.fill();
      if (p.jam > 0 && p.reveal <= 0) {
        for (let n = 0; n < 9; n++) {
          const x = cx + Math.sin(game.time * (n + 1) + i) * r * 0.85,
            y = cy + Math.cos(game.time * 0.8 + n) * r * 0.85;
          glow(g, x, y, 9, "#fa69e988");
        }
        for (let y = cy - r; y < cy + r; y += 12) {
          g.fillStyle = "#ff8cca15";
          g.fillRect(cx - r, y, r * 2, 4);
        }
      } else
        for (const q of game.ghosts) {
          const d = dist(p, q),
            range = p.reveal > 0 ? 30 : 9;
          if (d > range) continue;
          const dx = (q.x - p.x - (q.y - p.y)) / Math.SQRT2,
            dy = (q.x - p.x + q.y - p.y) / Math.SQRT2,
            scale = (r / range) * 0.9,
            x = cx + dx * scale,
            y = cy + dy * scale;
          const col =
            q.kind === "rare"
              ? "#ffdc7b"
              : q.kind === "decoy" && p.reveal > 0
                ? "#f890dd"
                : "#66f5ed";
          glow(g, x, y, 13, col + "44");
          g.fillStyle = col;
          g.beginPath();
          g.arc(x, y, q.kind === "rare" ? 5 : 4, 0, Math.PI * 2);
          g.fill();
        }
      g.restore();
      g.strokeStyle = "#79efdf";
      g.lineWidth = 3;
      g.beginPath();
      g.arc(cx, cy, r, 0, Math.PI * 2);
      g.stroke();
      g.fillStyle = c;
      g.beginPath();
      g.moveTo(cx, cy - 11);
      g.lineTo(cx - 8, cy + 9);
      g.lineTo(cx + 8, cy + 9);
      g.closePath();
      g.fill();
      for (const [s, x, y] of [
        ["N", cx, cy - r - 11],
        ["S", cx, cy + r + 12],
        ["W", cx - r - 14, cy],
        ["E", cx + r + 14, cy],
      ])
        text(g, s, x, y, 14, "#9bc9d3", "center");
      this.map(g, game, 360, 158, 320, 238, p);
      text(
        g,
        game.castle.rooms[p.room].name.toUpperCase(),
        520,
        421,
        19,
        c,
        "center",
      );
      text(
        g,
        p.jam > 0 && p.reveal <= 0
          ? "SIGNAL JAMMED"
          : dash.signal > 0.7
            ? "GHOST VERY CLOSE"
            : dash.signal > 0.35
              ? "SIGNAL STRONG"
              : "SEARCH THE ROOMS",
        360,
        479,
        18,
        p.jam > 0 ? "#fa8ddd" : "#8ef6d8",
        "center",
      );
      panel(g, 25, 497, 670, 55, c, "#142d36");
      g.fillStyle = c;
      g.fillRect(30, 502, 660 * clamp(p.progress, 0, 1), 45);
      text(
        g,
        p.target
          ? "CAPTURE LOCK " + Math.floor(p.progress * 100) + "%"
          : p.stun > 0 ? "ZAPPED! " + p.stun.toFixed(1) + "s" : "HOLD A / B PULSE / R STUN",
        360,
        525,
        21,
        p.progress > 0.45 ? "#041223" : "#ddfff3",
        "center",
      );
      text(g, p.captures + " GHOSTS / " + p.score + " PTS", 25, 578, 23, c);
      text(
        g,
        p.pulse > 0 ? "PULSE " + Math.ceil(p.pulse) + "s" : "PULSE READY",
        695,
        578,
        17,
        "#ffe18b",
        "right",
      );
    }
    if (game.phase === "lobby") {
      panel(g, 82, 261, 556, 128, c, "#07182bf5");
      text(
        g,
        p.human ? "YOU ARE IN" : "CPU SEAT / A TO JOIN",
        360,
        304,
        30,
        c,
        "center",
      );
      text(
        g,
        "START TO LAUNCH / NINE ROOMS PER CASTLE",
        360,
        352,
        17,
        "#dae7ff",
        "center",
      );
    }
    if (game.phase === "countdown") {
      panel(g, 125, 270, 470, 120, c, "#07182bf5");
      text(
        g,
        "GET READY / " + Math.ceil(3 - game.phaseTime),
        360,
        310,
        35,
        c,
        "center",
      );
      text(g, "FOLLOW YOUR TRACKER", 360, 357, 20, "#cfdef4", "center");
    }
    if (!p.human && (game.phase === "play" || game.phase === "countdown")) {
      panel(g, 85, 267, 550, 126, c, "#101d32f5");
      text(g, "CPU SEAT / JOIN NEXT MATCH", 360, 307, 26, c, "center");
      text(
        g,
        "PRESS A IN THE LOBBY BEFORE THE HOST STARTS",
        360,
        353,
        16,
        "#d1e5f5",
        "center",
      );
    }
    if (game.phase === "results") {
      panel(g, 83, 245, 554, 135, c, "#102039f5");
      text(
        g,
        game.roundResult?.loser === i
          ? "YOU ARE NOW A GHOST CAPTAIN"
          : "CASTLE COMPLETE",
        360,
        284,
        25,
        c,
        "center",
      );
      text(
        g,
        "NEXT CASTLE IN " + Math.ceil(8 - game.phaseTime) + "s",
        360,
        339,
        22,
        "#ddedff",
        "center",
      );
    }
    if (game.phase === "finished") {
      panel(g, 80, 245, 560, 142, c, "#102039f5");
      const rank = game.winner === i ? 1 : 6 - p.eliminatedRound;
      text(
        g,
        game.winner === i
          ? "YOU ARE THE CHAMPION!"
          : "FINISHED / PLACE " + rank,
        360,
        289,
        28,
        c,
        "center",
      );
      text(
        g,
        p.total + " TOTAL POINTS / START: NEW MATCH",
        360,
        346,
        19,
        "#d2e4ff",
        "center",
      );
    }
    if (game.paused) {
      panel(g, 100, 273, 520, 114, c, "#07182bf5");
      text(g, "PAUSED", 360, 310, 37, c, "center");
      text(g, "START TO RESUME", 360, 353, 20, "#cfdef4", "center");
    }
    if (!captain) {
      text(g,p.stun>0?"STUNNED / "+p.stun.toFixed(1)+"s":p.stunCd>0?"STUN RECHARGING / "+Math.ceil(p.stunCd)+"s":dash.stunTarget?"STUN TARGET / "+dash.stunTarget.toUpperCase():"STUN READY / FACE A RIVAL",360,602,15,p.stun>0?"#ffb4c7":"#92f5ff","center");
      if (p.noticeTime>0)text(g,p.notice,360,585,12,"#ffe5a5","center");
    } else if (p.noticeTime > 0) text(g, p.notice, 360, 603, 13, "#ffe5a5", "center");
    for (const b of buttons) {
      panel(g, b.x, b.y, b.w, b.h, c, b.key === "A" ? "#234639" : "#17273d", 8);
      let label = b.label;
      if (b.key === "A")
        label =
          game.phase === "lobby"
            ? p.human
              ? "A / READY"
              : "A / JOIN"
            : game.phase === "finished"
              ? "A / LOBBY"
              : captain
                ? "A / DEPLOY"
                : "HOLD A / CAPTURE";
      if (b.key === "B") label = captain ? "B / TARGET" : "B / PULSE";
      if (!captain && b.key === "L1") label = "—";
      if (!captain && b.key === "R1") label = p.stunCd>0?Math.ceil(p.stunCd)+"s":"STUN!";
      text(
        g,
        label,
        b.x + b.w / 2,
        b.y + b.h / 2,
        b.key === "A" ? 18 : b.key.length > 3 ? 12 : 15,
        "#e9fff6",
        "center",
      );
    }
    text(
      g,
      "LIVE PERSONAL TRACKER / SHARED CONTROLLER",
      360,
      706,
      10,
      "#8fa9bd",
      "center",
    );
  }
}
