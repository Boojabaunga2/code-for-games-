# Shared Mini Vibe controls / native app v16

This is a shared controller update, not a new game-specific app. The Mini Vibe sends physical held state for all twelve controls as soon as it is connected to the PC. It does not need a game name, a capability download or an enabled game-mode flag to capture/send it. New compatible games set their own mappings on the PC using native-input.js; adding a D-pad, shoulder or held-button mapping to a game does not require editing/rebuilding the Android app.

## Install

1. Extract the entire ZIP. On the PC double-click **START_INSTALL.cmd** and select **Arcadium_OS_COMPACT**. Only the Ghost Bubble and Boop adapters and their existing registrations/helpers are updated. Other games, Home, the main server and pairing remain untouched. The installer reports whether a Windows restart is needed; if both existing helpers are unchanged, Ctrl+F5 and reopen the game is sufficient.
2. On each Mini Vibe install **Mini Vibe/Arcadium-Universal-Controller.apk (v16)** as an update. Keep app data/pairing; do not uninstall. This does replace the Arcadium Home application code with the accumulated source plus the shared input layer. It does not install over separately packaged games. The APK signing identity and all 45 bundled Home asset bytes are checked against previous releases.
3. Ghost Bubble: hold D-pad LEFT/RIGHT to aim, release to stop. A fire/cast; B swap/power. Boop: hold L1/R1 to move; A laser, B target, X sabotage. These mappings now live entirely in their PC adapters.

## Compatibility

The existing ordinary button messages and legacy H held-direction stream remain available. Existing RC trigger mappings, athletics shoulders, tennis/NPC/Crater/Price held controls, auction keys, ordered bids and START+SELECT Home shortcut retain their previous paths. Generic motion still forwards to the WebView on older pages where it did so previously. No manifest permissions or bundled Home files change.

The extra raw I state is ignored by old readers. The shared reader accepts both protocols through each game's adapter, preferring I once present. Impulse actions continue using the established A/B/X/Y messages exactly once; the extra level-state packet does not fire another action. Focus loss clears physical states; packet heartbeats continue while connected. Disconnect/old-session/replay/stale-state guards prevent stuck movement.

This preserves source and software contracts; it does not establish that every older game has been tested on physical devices. A hardware acceptance checklist is included. This protocol is intended to remove per-game D-pad/shoulder APK changes, not to promise the app will never need maintenance.
