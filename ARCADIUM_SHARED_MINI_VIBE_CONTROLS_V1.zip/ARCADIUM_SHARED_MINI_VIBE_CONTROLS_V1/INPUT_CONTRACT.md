# Arcadium Native Input V1

Existing authenticated POST /api/vibe/input, existing pairing token, existing port8787 and numbered event stream. No extra service or listener. button value: I + six hex session digits + six hex sequence digits + three hex mask digits (16 characters, below the existing 20-character limit).

Bits: UP1, DOWN2, LEFT4, RIGHT8, A16, B32, X64, Y128, START256, SELECT512, L1=1024, R1=2048. Physical key, touch-direction and hat/stick-direction states are combined without repurposing shoulder bits. No game identity appears in NativeInputState.java.

State changes send immediately when transport is available; one in-flight state request coalesces to the latest state under congestion. Idle heartbeats target 250ms on the existing 80ms timer (at most about320ms without scheduling delays). Use the ordinary action messages for reliable discrete A/B/start impulses; I provides held levels and continuous-control state, not a durable event queue. The raw level packet must not cause a second impulse action.

Copy native-input.js into the PC game and create one reader per canonical colour. receive(event.button) consumes I packets. read() returns the actual 12-bit mask; a stale reader returns zero after650ms. clear() releases state. seen indicates an I session has been observed. Rejects replay/old sequence, retired sessions and malformed packets; supports 24-bit sequence wrap. Do not synthesize held movement from ordinary direction taps.

Game mappings belong on the PC: Ghost Bubble uses mask&4/mask&8; Boop uses L1/R1 bits1024/2048; another game can interpret those same physical controls differently without an Android change. No hardcoded game/page list may be added to the raw state sender. Existing H protocol remains a compatibility path, not the future integration contract.
