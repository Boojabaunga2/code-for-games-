from pathlib import Path
import json,tkinter as tk
from tkinter import filedialog
from install_shared import install,rollback
ui=tk.Tk();ui.title('Arcadium / Shared Mini Vibe Controls');ui.geometry('760x460');status=tk.StringVar(value='This adds the common input route to the existing PC server and installs the shared reader in Ghost Bubble and Boop. Home, pairing, the main server and other games are preserved. Install the included universal v16 APK as an update on each Mini Vibe. Future games can map these controls on the PC.')
tk.Label(ui,text='ARCADIUM / SHARED MINI VIBE CONTROLS',font=('Segoe UI',16,'bold')).pack(pady=18);tk.Label(ui,textvariable=status,wraplength=700,justify='left',font=('Segoe UI',12)).pack(padx=20,pady=16)
def run():
 folder=filedialog.askdirectory(title='Select your existing Arcadium_OS_COMPACT folder')
 if not folder:return
 try:
  result=install(Path(folder));Path(__file__).with_name('SHARED_INPUT_RECEIPT.json').write_text(json.dumps(result,indent=2));status.set('Installed with backups for the common route, Ghost Bubble and Boop.\n\n'+('Restart Windows once to load the added game route.' if result['restart_required'] else 'No Windows restart needed. Refresh Arcadium with Ctrl+F5 and reopen the game.')+'\n\nUpdate each Mini Vibe using Mini Vibe/Arcadium-Universal-Controller.apk (v16). Keep pairing and app data.\n\nFuture D-pad/shoulder game mappings belong on the PC, using the included shared reader.')
 except Exception as e:status.set('Stopped: '+str(e))
def undo():
 try:r=json.loads(Path(__file__).with_name('SHARED_INPUT_RECEIPT.json').read_text());rollback(r);status.set('Restored the previous PC game adapters. Restart Windows if a loaded route changed. The Mini Vibe update stays installed and retains the legacy control paths.')
 except Exception as e:status.set('Rollback stopped: '+str(e))
tk.Button(ui,text='INSTALL SHARED PC CONTROLS',command=run,padx=18,pady=12).pack(pady=8);tk.Button(ui,text='Rollback this PC update',command=undo).pack();ui.mainloop()
