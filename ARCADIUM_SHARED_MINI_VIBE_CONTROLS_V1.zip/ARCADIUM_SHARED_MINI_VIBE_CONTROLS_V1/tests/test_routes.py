import importlib.util,json,tempfile,threading,unittest,urllib.request,urllib.error
from pathlib import Path
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from types import SimpleNamespace
p=Path(__file__).resolve().parents[1]/'universal_input_routes.py';spec=importlib.util.spec_from_file_location('shared_native_routes_test',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class Routes(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  class Legacy(BaseHTTPRequestHandler):
   def log_message(self,*args):pass
   def reply(self,obj):
    b=json.dumps(obj).encode();self.send_response(200);self.send_header('Content-Length',str(len(b)));self.end_headers();self.wfile.write(b)
   def do_GET(self):self.reply(self.server.legacy)
   def do_POST(self):
    self.server.legacy.append(json.loads(self.rfile.read(int(self.headers['Content-Length']))));self.reply({'legacy':True})
  cls.H=m.wrap_native_input_handler(Legacy);cls.server=ThreadingHTTPServer(('127.0.0.1',0),cls.H);cls.server.legacy=[];cls.server.native_app=SimpleNamespace(VIBE_PAIR_TOKEN='existing-invitation-token',PINK_DEVICE_IP=None);cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True);cls.thread.start();cls.base='http://127.0.0.1:'+str(cls.server.server_port)
 @classmethod
 def tearDownClass(cls):cls.server.shutdown();cls.server.server_close();cls.thread.join()
 def req(self,path,body=None):
  try:
   with urllib.request.urlopen(urllib.request.Request(self.base+path,data=None if body is None else json.dumps(body).encode(),headers={'Content-Type':'application/json'})) as r:return r.status,json.loads(r.read())
  except urllib.error.HTTPError as e:return e.code,json.loads(e.read())
 def test_isolated_authenticated_stream_and_unchanged_legacy_routes(self):
  self.req('/api/vibe/input',{'pair':'old-path','color':'red','button':'A'});before=list(self.server.legacy)
  data={'pair':'existing-invitation-token','color':'red','button':'Iabcdef000001008'}
  self.assertEqual(self.req('/api/vibe/native-input',data)[0],200);events=self.req('/api/vibe/native-events?after=0')[1];self.assertEqual(events['events'][-1]['button'],data['button']);self.assertEqual(self.req('/api/vibe/events')[1],before);self.assertEqual(self.server.legacy,before)
  latest=events['latest'];data['pair']='wrong';self.assertEqual(self.req('/api/vibe/native-input',data)[0],403);self.assertEqual(self.req('/api/vibe/native-events')[1]['latest'],latest)
  data['pair']='existing-invitation-token';data['button']='A';self.assertEqual(self.req('/api/vibe/native-input',data)[0],400);self.assertEqual(self.server.legacy,before)
  self.server.native_app.PINK_DEVICE_IP='127.0.0.1';data['button']='Iabcdef000002004';data['color']='white';self.assertEqual(self.req('/api/vibe/native-input',data)[0],200);self.assertEqual(self.req('/api/vibe/native-events')[1]['events'][-1]['color'],'pink');self.server.native_app.PINK_DEVICE_IP=None
  local=SimpleNamespace(client_address=('192.168.1.1',5),connection=SimpleNamespace(getsockname=lambda:('192.168.1.1',8787)));remote=SimpleNamespace(client_address=('192.168.1.2',5),connection=local.connection);self.assertTrue(self.H._native_host(local));self.assertFalse(self.H._native_host(remote));self.assertEqual(self.req('/api/vibe/native-events?after=bad')[0],400)
if __name__=='__main__':unittest.main()
