import hashlib,importlib.util,json,tempfile,unittest,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];REPO=ROOT.parents[1];ARCHIVE=REPO/'downloads/ARCADIUM_SHARED_MINI_VIBE_CONTROLS_V1.zip'
class Shared(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.dir=Path(self.tmp.name)
  with zipfile.ZipFile(ARCHIVE) as z:z.extractall(self.dir)
  self.pkg=self.dir/ARCHIVE.stem;spec=importlib.util.spec_from_file_location('shared_exact_installer',self.pkg/'install_shared.py');self.m=importlib.util.module_from_spec(spec);spec.loader.exec_module(self.m);self.root=self.dir/'OS';self.root.mkdir();(self.root/'data').mkdir()
  (self.root/'data/arcadium.json').write_text(json.dumps({'games':[{'id':'arcadium-ghost-bubble','name':'Ghost Bubble','image':'approved-ghost.png','custom':'keep'},{'id':'arcadium-boop','name':'BOOP','image':'approved-boop.png'},{'id':'rc-trigger-racing','controls':'existing triggers','launchUrl':'keep-racing'}]}))
  (self.root/'arcadium_server.py').write_text('import arcadium_game_bridge\n# earlier fixes and all native receiver methods unchanged\n')
  (self.root/'arcadium_game_bridge.py').write_text('import threading\nfrom e3mi_routes import wrap_e3mi_handler\nfrom ghost_bubble_routes import wrap_ghost_bubble_handler\nfrom boop_routes import wrap_boop_handler\nACTIVE_WEB_GAME={"game":None,"until":0}\nACTIVE_LOCK=threading.RLock()\ndef bridge(Base):\n    class GameBridge(Base):pass\n    return wrap_boop_handler(wrap_ghost_bubble_handler(wrap_e3mi_handler(GameBridge)))\n')
  (self.root/'e3mi_routes.py').write_text('def wrap_e3mi_handler(Base):return Base\n')
  for folder,name in [('Ghost Bubble','ghost_bubble_routes.py'),('Boop','boop_routes.py')]:(self.root/name).write_bytes((self.pkg/folder/name).read_bytes())
  for name,data in [('HOME.html',b'HOME FIXES'),('pairing.json',b'PAIRING'),('games/wormaldeon/index.html',b'TENNIS FIXES'),('games/npcs/index.html',b'NPC FIXES'),('games/rc-trigger-racing/engine.mjs',b'RC TRIGGER FIXES'),('data/auction.json',b'AUCTION DATA')]:
   p=self.root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 def tearDown(self):self.tmp.cleanup()
 def before(self):return {p.relative_to(self.root).as_posix():p.read_bytes() for p in self.root.rglob('*') if p.is_file()}
 def assert_restored(self,before):
  for n,b in before.items():
   if n=='data/arcadium.json':self.assertEqual(json.loads((self.root/n).read_text()),json.loads(b))
   else:self.assertEqual((self.root/n).read_bytes(),b,n)
 def test_install_repeat_rollback_preserves_accumulated_fixes(self):
  before=self.before();r=self.m.install(self.root);self.assertTrue(r['restart_required']);cat=json.loads((self.root/'data/arcadium.json').read_text());self.assertEqual(len(cat['games']),3);self.assertEqual(cat['games'][0]['image'],'approved-ghost.png');self.assertEqual(cat['games'][0]['custom'],'keep');self.assertEqual(cat['games'][2]['controls'],'existing triggers')
  for folder in ['arcadium-ghost-bubble','arcadium-boop']:self.assertEqual((self.root/'games'/folder/'native-input.js').read_bytes(),(self.pkg/'native-input.js').read_bytes())
  for n in ['HOME.html','pairing.json','arcadium_server.py','games/wormaldeon/index.html','games/npcs/index.html','games/rc-trigger-racing/engine.mjs','data/auction.json']:self.assertEqual((self.root/n).read_bytes(),before[n])
  again=self.m.install(self.root);self.m.rollback(again);self.m.rollback(r);self.assert_restored(before);self.assertFalse((self.root/'universal_input_routes.py').exists())
 def test_both_preparations_checked_before_first_write(self):
  before=self.before();cat=json.loads((self.root/'data/arcadium.json').read_text());cat['games'].append({'id':'duplicate','name':'BOOP'});(self.root/'data/arcadium.json').write_text(json.dumps(cat));failed_before=self.before();self.assertRaises(RuntimeError,self.m.install,self.root);self.assertEqual(self.before(),failed_before)
 def test_second_failure_rolls_back_first(self):
  before=self.before();ghost=self.m.module('Ghost Bubble','update_ghost_bubble.py');boop=self.m.module('Boop','update_boop.py')
  def fail(root):raise RuntimeError('simulated second-install failure')
  boop.install=fail;self.m.module=lambda folder,name:ghost if folder=='Ghost Bubble' else boop
  self.assertRaises(RuntimeError,self.m.install,self.root);self.assert_restored(before)
 def test_payload_and_signed_app_integrity(self):
  checks=json.loads((self.pkg/'CHECKSUMS.json').read_text())
  for n,h in checks.items():self.assertEqual(hashlib.sha256((self.pkg/n).read_bytes()).hexdigest(),h,n)
  meta=json.loads((self.pkg/'APP_BUILD.json').read_text());self.assertEqual(meta['versionCode'],16);self.assertEqual(hashlib.sha256((self.pkg/'Mini Vibe/Arcadium-Universal-Controller.apk').read_bytes()).hexdigest(),meta['sha256']);self.assertEqual(meta['previous_home_assets_byte_identical'],45)
  (self.pkg/'native-input.js').write_text('changed');self.assertRaises(RuntimeError,self.m.install,self.root)
if __name__=='__main__':unittest.main()
