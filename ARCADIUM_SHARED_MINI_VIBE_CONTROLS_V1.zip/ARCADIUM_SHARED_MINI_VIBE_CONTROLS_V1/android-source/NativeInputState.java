package com.arcadium.og9;

/** Game-independent physical state. No page names, game mappings or negotiation. */
public final class NativeInputState {
    private final HeldDpad directions;
    private final int session;
    private int sequence;
    private int keys;
    public NativeInputState(int session) { this.session=session&0xffffff; directions=new HeldDpad(session); }
    public void key(int bit, boolean down) {
        if(bit<0||bit>11)return;
        if(down)keys|=1<<bit;else keys&=~(1<<bit);
    }
    public void touch(int mask) { directions.touch(mask); }
    public void axes(float hx,float hy,float x,float y,float fx,float fy) { directions.axes(hx,hy,x,y,fx,fy); }
    public int mask() { return (keys|directions.mask())&0xfff; }
    public void clear() { keys=0;directions.clear(); }
    public String packet() {
        sequence=(sequence+1)&0xffffff;
        return String.format(java.util.Locale.ROOT,"I%06x%06x%03x",session,sequence,mask());
    }
}
