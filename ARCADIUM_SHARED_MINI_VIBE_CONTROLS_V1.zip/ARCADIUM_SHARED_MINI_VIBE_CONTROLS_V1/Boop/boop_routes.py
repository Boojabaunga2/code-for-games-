"""Boop on the existing Arcadium 8787 lease and server; no new listener."""
import base64,binascii,importlib,json,mimetypes,threading,time
from pathlib import Path
from urllib.parse import urlsplit,parse_qs,unquote
SLUG='arcadium-boop';COLORS=('red','blue','green','yellow','pink','white')
BASE=Path(__file__).resolve().parent;LOCK=threading.RLock();FRAMES={}
def wrap_boop_handler(Parent):
 class BoopHandler(Parent):
  def _boop_shared(self):
   bridge=importlib.import_module('arcadium_game_bridge');return bridge.ACTIVE_WEB_GAME,bridge.ACTIVE_LOCK
  def _boop_active(self):
   state,lock=self._boop_shared()
   with lock:return state['game']==SLUG and time.time()<state['until']
  def _boop_send(self,data,mime='application/json',status=200):
   self.send_response(status);self.send_header('Content-Type',mime);self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
  def do_POST(self):
   path=urlsplit(self.path).path;activate=path=='/arcadium-vibe/activate/'+SLUG;frame=path=='/arcadium-bubble/'+SLUG+'/frame'
   if not activate and not frame:return super().do_POST()
   if self.client_address[0] not in ('127.0.0.1','::1','::ffff:127.0.0.1'):return self.send_error(403)
   try:
    size=int(self.headers.get('Content-Length','0'))
    if size<0 or size>(1024 if activate else 300000):return self.send_error(413)
    body=json.loads(self.rfile.read(size) or b'{}')
    if not isinstance(body,dict):raise ValueError()
    if activate:
     enabled=body.get('active',True)
     if not isinstance(enabled,bool):raise ValueError()
     state,lock=self._boop_shared()
     with lock:
      if enabled:
       if state['game']!=SLUG or time.time()>=state['until']:
        with LOCK:FRAMES.clear()
       state.update(game=SLUG,until=time.time()+7)
      elif state['game']==SLUG:
       state.update(game=None,until=0)
       with LOCK:FRAMES.clear()
    else:
     if not self._boop_active():return self.send_error(409)
     seat=body['seat'];image=base64.b64decode(body['image'],validate=True)
     if type(seat) is not int or seat not in range(1,7) or len(image)>200000 or not image.startswith(b'\xff\xd8'):raise ValueError()
     with LOCK:FRAMES[seat]=(time.monotonic(),image)
    return self._boop_send(b'{"ok":true}')
   except (ValueError,TypeError,KeyError,UnicodeError,binascii.Error):return self.send_error(400)
  def do_GET(self):
   path=urlsplit(self.path).path
   if path in ('/api/vibe/mode','/api/vibe/launch') and self._boop_active():
    page='/games/'+SLUG+'/personal/vibe.html';return self._boop_send(json.dumps(dict(mode='web-game',game=SLUG,page=page,url=page,active=True)).encode())
   prefix='/games/'+SLUG+'/'
   if path.startswith(prefix):
    relative=unquote(path[len(prefix):]);relative='vibe.html' if relative=='personal/vibe.html' else relative
    folder=(BASE/'games'/SLUG).resolve();file=(folder/relative).resolve()
    if not file.is_relative_to(folder) or not file.is_file():return self.send_error(404)
    return self._boop_send(file.read_bytes(),('application/javascript' if file.suffix=='.mjs' else mimetypes.guess_type(file.name)[0]) or 'application/octet-stream')
   if path=='/arcadium-bubble/'+SLUG+'/status':
    with LOCK:seats=[COLORS[i-1] for i,p in FRAMES.items() if time.monotonic()-p[0]<2.5]
    return self._boop_send(json.dumps(dict(build='boop-deluxe-v1',game=SLUG,active=self._boop_active(),liveSeats=seats)).encode())
   if path!='/arcadium-bubble/'+SLUG+'/frame':return super().do_GET()
   color=parse_qs(urlsplit(self.path).query).get('color',[''])[0].lower()
   if color not in COLORS:return self.send_error(400)
   if not self._boop_active():return self.send_error(503)
   with LOCK:
    packet=FRAMES.get(COLORS.index(color)+1)
    if not packet or time.monotonic()-packet[0]>2.5:return self.send_error(503)
    return self._boop_send(packet[1],'image/jpeg')
 return BoopHandler
