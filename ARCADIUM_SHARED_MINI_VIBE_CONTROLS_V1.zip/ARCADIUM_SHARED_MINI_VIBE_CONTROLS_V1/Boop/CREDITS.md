# Credits

Original BOOP game, ghost sprites, power icons, splash and logo: supplied by the user in arcadium-boop.zip. All 24 embedded PNG assets and the splash JPEG were extracted without changing their image bytes. The original backup HTML variants are archival input, not runtime files.

New arena environment: original AI-generated background created for this build. Actual paddles, ball physics, laser projectiles, interfaces and Mini Vibe views are rendered by the game; the environment image is not a screenshot or a playable mockup. New carousel card combines that environment, the supplied red ghost and original type/layout. Existing approved OS carousel art is preserved by the installer.
