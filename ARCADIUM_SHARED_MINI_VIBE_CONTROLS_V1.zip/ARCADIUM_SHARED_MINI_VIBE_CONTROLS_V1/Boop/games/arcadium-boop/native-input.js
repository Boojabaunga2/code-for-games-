/* Arcadium Native Input V1: physical state, independent of every game/page. */
(function(root){'use strict';
 const bits=Object.freeze({UP:1,DOWN:2,LEFT:4,RIGHT:8,A:16,B:32,X:64,Y:128,START:256,SELECT:512,L1:1024,R1:2048});
 function create(now){now=now||(()=>performance.now());let session=null,sequence=-1,mask=0,at=-Infinity;const retired=[];
  return {receive(button){const m=/^I([0-9a-f]{6})([0-9a-f]{6})([0-9a-f]{3})$/i.exec(String(button));if(!m)return false;const id=m[1].toLowerCase(),next=parseInt(m[2],16);if(session!==id){if(retired.includes(id))return true;if(session!==null){retired.push(session);if(retired.length>8)retired.shift();}session=id;sequence=-1;}if(sequence>=0){const delta=(next-sequence+0x1000000)%0x1000000;if(delta===0||delta>=0x800000)return true;}sequence=next;mask=parseInt(m[3],16);at=now();return true;},read(){return now()-at<=650?mask:0;},clear(){mask=0;at=-Infinity;},get seen(){return session!==null;}};
 }
 const api={create,bits,version:1};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.ArcadiumInputState=api;
})(typeof window!=='undefined'?window:globalThis);
