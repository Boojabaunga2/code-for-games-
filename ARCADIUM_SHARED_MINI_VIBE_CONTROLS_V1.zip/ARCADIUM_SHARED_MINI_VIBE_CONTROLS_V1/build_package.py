from pathlib import Path
import argparse,hashlib,importlib.util,json,zipfile
ROOT=Path(__file__).resolve().parent;REPO=ROOT.parents[1]
def load(path):
 spec=importlib.util.spec_from_file_location('payload_'+path.parent.name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def build(apk):
 files={p.name:p.read_bytes() for p in ROOT.iterdir() if p.is_file() and p.name not in ('CHECKSUMS.json','.gitignore')}
 for folder,integration in [('Ghost Bubble','ghost-bubble'),('Boop','boop')]:
  payload=load(REPO/'integrations'/integration/'build_package.py').payload()
  payload={n:b for n,b in payload.items() if n.startswith('games/') or n in ('update_ghost_bubble.py','ghost_bubble_routes.py','update_boop.py','boop_routes.py','CREDITS.md')}
  # The shared root README/APK metadata is authoritative; avoid stale per-game APK instructions.
  for name in ('APP_BUILD.json',):payload.pop(name,None)
  payload['CHECKSUMS.json']=json.dumps({n:hashlib.sha256(b).hexdigest() for n,b in payload.items()},indent=2).encode()
  files.update({folder+'/'+n:b for n,b in payload.items()})
 with zipfile.ZipFile(apk) as z:
  for p in (REPO/'app/src/main/assets').rglob('*'):
   if p.is_file():assert z.read('assets/'+p.relative_to(REPO/'app/src/main/assets').as_posix())==p.read_bytes()
 files['Mini Vibe/Arcadium-Universal-Controller.apk']=apk.read_bytes()
 for p in (REPO/'app/src/main/java').rglob('*.java'):files['android-source/'+p.name]=p.read_bytes()
 files['android-source/build.gradle']=(REPO/'app/build.gradle').read_bytes()
 files['CHECKSUMS.json']=json.dumps({n:hashlib.sha256(b).hexdigest() for n,b in files.items()},indent=2).encode()
 for p in (ROOT/'tests').glob('*'):
  if p.is_file():files['tests/'+p.name]=p.read_bytes()
 target=REPO/'downloads/ARCADIUM_SHARED_MINI_VIBE_CONTROLS_V1.zip'
 with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
  for name,b in files.items():z.writestr(target.stem+'/'+name,b)
 print(target,target.stat().st_size,hashlib.sha256(target.read_bytes()).hexdigest());return target
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--apk',type=Path,required=True);args=ap.parse_args();build(args.apk)
