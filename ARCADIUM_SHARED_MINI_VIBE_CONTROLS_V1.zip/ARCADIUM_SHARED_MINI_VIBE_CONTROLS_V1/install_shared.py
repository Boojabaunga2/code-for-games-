"""Update only Ghost Bubble/Boop PC adapters; preserve all other OS files."""
import hashlib,importlib.util,json
from pathlib import Path
SOURCE=Path(__file__).resolve().parent

def module(folder,name):
 path=SOURCE/folder/name;spec=importlib.util.spec_from_file_location('shared_'+folder.replace(' ','_'),path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def verify():
 for name,wanted in json.loads((SOURCE/'CHECKSUMS.json').read_text()).items():
  p=(SOURCE/name).resolve()
  if not p.is_relative_to(SOURCE.resolve()) or not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=wanted:raise RuntimeError('Incomplete or changed package: '+name)

def install(root):
 verify();root=Path(root).resolve();ghost=module('Ghost Bubble','update_ghost_bubble.py');boop=module('Boop','update_boop.py')
 # Both preparations must succeed before the first write.
 ghost.prepare(root);boop.prepare(root)
 old={n:(root/n).read_bytes() if (root/n).is_file() else None for n in ('arcadium_game_bridge.py','ghost_bubble_routes.py','boop_routes.py')}
 first=ghost.install(root)
 try:second=boop.install(root)
 except Exception:ghost.rollback(first);raise
 restart=any(old[n]!=(root/n).read_bytes() for n in old)
 return {'root':str(root),'backups':[str(first),str(second)],'restart_required':restart}

def rollback(receipt):
 # Restore in reverse order; each game checks for later edits before restoring.
 module('Boop','update_boop.py').rollback(Path(receipt['backups'][1]));module('Ghost Bubble','update_ghost_bubble.py').rollback(Path(receipt['backups'][0]))
