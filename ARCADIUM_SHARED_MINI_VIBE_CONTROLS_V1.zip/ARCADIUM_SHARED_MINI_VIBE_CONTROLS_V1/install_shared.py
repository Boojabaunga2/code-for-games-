"""Update only Ghost Bubble/Boop PC adapters; preserve all other OS files."""
import ast,hashlib,importlib.util,json,datetime
from pathlib import Path
SOURCE=Path(__file__).resolve().parent

def module(folder,name):
 path=SOURCE/folder/name;spec=importlib.util.spec_from_file_location('shared_'+folder.replace(' ','_'),path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def verify():
 for name,wanted in json.loads((SOURCE/'CHECKSUMS.json').read_text()).items():
  p=(SOURCE/name).resolve()
  if not p.is_relative_to(SOURCE.resolve()) or not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=wanted:raise RuntimeError('Incomplete or changed package: '+name)

def native_bridge(source):
 tree=ast.parse(source);fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='bridge');returns=[n for n in fn.body if isinstance(n,ast.Return)]
 if len(returns)!=1:raise RuntimeError('Unknown bridge return')
 ret=returns[0];names=[n.func.id for n in ast.walk(ret.value) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name)]
 if 'wrap_native_input_handler' in names:return source
 lines=source.splitlines(keepends=True)
 if ret.lineno!=ret.end_lineno:raise RuntimeError('Unknown multiline bridge return')
 indent=lines[ret.lineno-1][:ret.col_offset];lines[ret.lineno-1]=indent+'return wrap_native_input_handler('+ast.unparse(ret.value)+')\n'
 result='from universal_input_routes import wrap_native_input_handler\n'+''.join(lines);compile(result,'arcadium_game_bridge.py','exec');return result

def install(root):
 verify();root=Path(root).resolve();ghost=module('Ghost Bubble','update_ghost_bubble.py');boop=module('Boop','update_boop.py')
 # Both preparations must succeed before the first write.
 ghost.prepare(root);boop.prepare(root)
 compile((SOURCE/'universal_input_routes.py').read_bytes(),'universal_input_routes.py','exec')
 native_bridge((root/'arcadium_game_bridge.py').read_text(encoding='utf-8-sig'))
 old={n:(root/n).read_bytes() if (root/n).is_file() else None for n in ('arcadium_game_bridge.py','ghost_bubble_routes.py','boop_routes.py','universal_input_routes.py')}
 first=ghost.install(root)
 try:second=boop.install(root)
 except Exception:ghost.rollback(first);raise
 native_backup=root/'arcadium_backups'/('shared_native_v1_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
 native_backup.mkdir(parents=True);writes={'universal_input_routes.py':(SOURCE/'universal_input_routes.py').read_bytes(),'arcadium_game_bridge.py':native_bridge((root/'arcadium_game_bridge.py').read_text(encoding='utf-8-sig')).encode()};saved={n:(root/n).read_bytes() if (root/n).exists() else None for n in writes}
 manifest={'root':str(root),'kind':'shared-native-v1','files':{}}
 for n,data in writes.items():
  if saved[n] is not None:(native_backup/n).write_bytes(saved[n])
  manifest['files'][n]={'existed':saved[n] is not None,'installed':hashlib.sha256(data).hexdigest(),'before':hashlib.sha256(saved[n]).hexdigest() if saved[n] is not None else None}
 (native_backup/'manifest.json').write_text(json.dumps(manifest,indent=2))
 try:
  for n,data in writes.items():boop.atomic_write(root/n,data)
 except Exception:
  for n,data in saved.items():
   if data is None:(root/n).unlink(missing_ok=True)
   else:boop.atomic_write(root/n,data)
  boop.rollback(second);ghost.rollback(first);raise
 restart=any(old[n]!=(root/n).read_bytes() for n in old)
 return {'root':str(root),'backups':[str(first),str(second)],'native_backup':str(native_backup),'restart_required':restart}

def rollback(receipt):
 backup=Path(receipt['native_backup']);manifest=json.loads((backup/'manifest.json').read_text());root=Path(manifest['root']).resolve();boop=module('Boop','update_boop.py')
 if manifest.get('kind')!='shared-native-v1' or set(manifest['files'])!={'arcadium_game_bridge.py','universal_input_routes.py'}:raise RuntimeError('Not a shared input backup')
 for n,info in manifest['files'].items():
  p=root/n
  if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=info['installed']:raise RuntimeError('Later changes in '+n+'; refusing rollback')
  if info['existed'] and hashlib.sha256((backup/n).read_bytes()).hexdigest()!=info['before']:raise RuntimeError('Changed backup: '+n)
 for n,info in manifest['files'].items():
  if info['existed']:boop.atomic_write(root/n,(backup/n).read_bytes())
  else:(root/n).unlink()
 boop.rollback(Path(receipt['backups'][1]));module('Ghost Bubble','update_ghost_bubble.py').rollback(Path(receipt['backups'][0]))
