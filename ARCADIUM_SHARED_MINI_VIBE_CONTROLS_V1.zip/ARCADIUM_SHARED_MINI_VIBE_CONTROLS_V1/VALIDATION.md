# Shared controller validation

The user's previous D-pad failure is accepted as real. No software test substitutes for confirming the fix on the physical Mini Vibes.

Passed checks:

- Signed Android v16 build, permanent signing-certificate comparison and actual Java legacy/new input regressions: workflow41889601400, source42c0fead. The raw NativeInputState has no page/game/capability dependencies. All12 physical controls, hat/stick neutral, touch independence and complete releases are tested. Existing PriceInput and legacy H-state/axis/RC/athletics scope tests pass.
- All45 Home assets are byte-identical to the previous signed v15 APK, and independently compared to repository originals during packaging. AndroidManifest.xml, HeldDpad.java and PriceInput.java are byte-identical to v15. Ten earlier discovery/pairing/action/bid/Home/installed-game-launch methods are unchanged, including sendVibeButton, startDiscovery, OG9 and High Noon launchers.
- Shared JS reader: all12 bits, release, duplicate/old sequence rejection, sequence wrap, retired session rejection, stale-link zero and clear. An I packet does not alter an existing H reader.
- Exact reviewed OS authenticated POST receiver, run with synthetic invitation/state only: I packets move/reverse/release all six Ghost Bubble cannons and all six Boop paddles via actual numbered events. No H packets are needed for these tests. Raw A level does not duplicate the ordinary A action; Boop fires once. Stale controls stop.
- Existing full Ghost Bubble and Boop browser suites pass again with the legacy H protocol: six-player controls, ghost powers, live personal feeds, laser deflection/stun, pause, disconnect, results/replay and exit.
- Existing RC engine/input/car regressions pass. Earlier Ghost Bubble five installer/route tests and Boop three installer/route tests pass, including the exact previously delivered archives/APKs.
- Four tests of this exact combined ZIP cover preserving earlier Home, pairing, tennis, NPC, RC and auction files; approved art/custom fields; repeat/rollback; preflight refusal before the first write; simulated second-install failure restoring the first; full payload/APK hashes and corruption refusal.
- Actual Windows CMD launcher test passed in workflow41890674433: spaces/ampersand path, Python3.12/Tkinter and no .py file association required. The native APK in the ZIP is pinned to the earlier successful42c0fead build, whose Java source is identical.

Not established: physical D-pad capture on the user's Mini Vibe, six-device venue Wi-Fi throughput, every older game's hardware acceptance or antivirus acceptance. HARDWARE_CHECK.txt lists the practical acceptance checks. The old source/input paths are retained to avoid intentionally changing earlier games; future mappings belong in PC adapters using INPUT_CONTRACT.md.
