# Ghost Bubble validation

The native Chromium test runs against an isolated existing-wrapper-chain server on 127.0.0.1:8787. It exercises 1–6 canonical seats, native joins/start, actual held direction packets and zero releases, reversal, stale-state stop, loaded/next bubble swapping, own-view selection, elimination, ghost steering, warned Dive, charged Chill and Haunt Pulse, cooldown/immunity, pause/resume, disconnect, six distinct actual 720 views/JPEG feeds, pure rendering, real match completion/replay, responsive fitting and release of only Ghost Bubble's active lease.

A separate mechanics test fires actual simulated shots to verify matching groups pop, a missed colour becomes a matching-colour ghost, matching shots bust falling ghosts, player ghosts can be busted and return after their five-second penalty, and solo START adds one CPU opponent.

Python tests cover targeted install/repeat/selective rollback, unchanged Home/server/previous game files, approved-image/custom-field preservation, duplicate/unknown bridge guards, exact extracted release payload and signed APK hash, corrupted-file refusal, six mode/frame routes, stale frames, capability assets, path traversal rejection and handoff back to RC Racing.

The Android CI runs actual Java held-input tests, compiles/signs version 12 and compares the signing certificate with the existing app. The build packager checks every bundled Home asset against the signed APK byte-for-byte. The new capability probe requires explicit PC opt-in for unknown game pages; it does not enable held input merely because a similarly named helper exists.

Reproduce from the repository root with Python, Chromium and Playwright available:

```
python integrations/ghost-bubble/build_package.py --apk /path/to/Arcadium-Home.apk
python -m unittest discover -s integrations/ghost-bubble/tests -v
python integrations/ghost-bubble/tests/harness.py
# Separate terminal:
node integrations/ghost-bubble/tests/browser.cjs
# Mechanics test: serve the game folder on 8791, then:
node integrations/ghost-bubble/tests/mechanics.cjs
```

The test server and its event-injection endpoint are development-only and are not installed in production. Software tests use mock venue clients, not six real physical devices. Physical button feel/latency, actual Android update/reconnect, six-device throughput, the live user's Windows server/carousel and antivirus acceptance remain unverified. No haptics are claimed.

Final native browser and mechanics suites passed. The signed app build is 41866171470 (source 878afad30c4f8c64ade5ea247cc4e2ad87f26354). Windows launcher CI 41870311960 passed using the actual Ghost Bubble START_INSTALL.cmd in a path containing spaces and an ampersand, without a .py association. The launcher’s missing-runtime winget path remains untested; its existing-Python/Tk path was exercised. The exact release ZIP passed all four Python installer/route tests. Actual browser screenshots and logs are in review/ in the source repository; review files are omitted from the installation ZIP.


## Input Repair V2

- Six-player held aim/release/reversal, ghost steering/powers, six actual feeds, match completion/replay, responsive display and exit passed again.
- Simulated browser hidden/occlusion: game pauses, active held contract and personal frames survive beyond the seven-second lease; renewal cannot steal RC Racing's later lease; focus return restores the contract; real LEFT and RELEASED packets appear in the indicator.
- Host producer identity accepts loopback or the same PC's own local interface, rejects another LAN device. Renew-only requests cannot activate over another game.
- Android Java regression tests verify explicit contract scope, absent/invalid contracts, all existing masks/axes/releases and Boop shoulder scope.
- Actual Windows CMD launcher passed in workflow 41881297097. Signed APK version14 evidence recorded in APP_BUILD.json after completion.
- User report does not prove which input-enablement/lease failure occurred on the device. This repair addresses both source failure paths; hardware retest is required.
