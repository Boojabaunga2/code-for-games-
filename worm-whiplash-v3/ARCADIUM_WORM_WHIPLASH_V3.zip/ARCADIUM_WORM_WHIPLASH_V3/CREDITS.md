# Credits

Worm Whiplash game, renderer, UI and integration: Arcadium development with Codex.
Original worm atlas, backyard, logo and square cover generated for this build with OpenAI image generation; composited by the live renderer. No mockup is substituted for gameplay.

Physics: **Matter.js 0.20.0**, Liam Brummitt and contributors, MIT license. Bundled locally at `games/worm-whiplash/vendor/matter.min.js`; complete license in `vendor/MATTER-LICENSE.txt`. Source: https://github.com/liabru/matter-js/tree/0.20.0 . No CDN needed while playing.

Shared Mini Vibe native input and persistent host integration reuse the existing Arcadium universal controller contract. No game-specific APK.
