# Validation scope

- Node real Matter.js engine: all six distinct single-use abilities, unlimited practice, pause, three complete CPU rounds, cumulative ranking, under-2048-byte personal dashboards (observed maximum 1015 bytes).
- Temporary installed OS fixtures: preserve unrelated Home/games/pairing/settings, idempotent install, exact delivered ZIP normal startup and included launcher, six controller routes, original server bytes unchanged, selective restore with later unrelated edits, stop safely on unknown bridge/edited owned files.
- Generic HTTP host fixtures: scoped private frames and dashboards, replay deduplication, stale turn rejection, token/owner invalidation, path traversal, native input authentication.
- Chromium: missing-host start blocked, six live personal canvases, native held A + D-pad pull, release launches, B ability, heartbeat expiry cancels, touch A hold/release, reconnect, pause, practice reset, 1280×720 layout and other-game handoff.

Screenshots and video are actual browser rendering. The video includes human mouse input followed by the labelled CPU demo; it is not a mockup. Test fixture replaces only the unavailable installed OS bridge, not the gameplay engine or controller adapter.

Remaining: physical Mini Vibes and native Android WebView, exact owner's installed OS, real Wi-Fi/TV, cross-device latency, balance testing with six human players, recipient antivirus acceptance. CI results and runner Defender status are recorded in the review PR; a clean runner scan cannot guarantee the recipient's PC.

## V2 game feel checks

Independent power/angle adjustment, exact pre-contact flight preview at three aim settings (under .001 world-unit error), actual projectile hit on a skill target, two-barrel chain detonation without double scoring, weak support durability, quicker reload, personal best across match reset, precise authenticated Mini aiming, touch cancellation, browser reload persistence and sound enable/toggle/events. V1 artwork/card, shared native input and PC host adapters are retained.

The V2 video captures live browser gameplay and its actual Web Audio output. No staged explosions, score injection or mockup replacement.

V2 installation was also tested over the complete shipped V1 archive. Selective restore returns all prior game bytes, its catalogue metadata and the bridge hook exactly to V1. CPU demos do not overwrite saved human best shots.

V3 adds three physical fish bowls on the top fort platforms in every round. Each contains an animated goldfish; breaking one awards 800 base points plus the break-chain multiplier, with glass, water and fish splash effects. Bowls can fall when their supports collapse.
