"""Create the self-contained game import ZIP; does not replace or sign an APK."""
from pathlib import Path
import hashlib, json, shutil, sys, zipfile
root=Path(__file__).resolve().parents[1]
out=Path(sys.argv[1]).resolve();out.mkdir(parents=True,exist_ok=True)
game=root/'pc-assets/games/ghost-grind'
pack=out/'Ghost-Grind-Approved-Arena-Home-Vibe.zip'
with zipfile.ZipFile(pack,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
 for p in sorted(game.iterdir()):
  if p.is_file():archive.write(p,p.name)
source=out/'Ghost-Grind-Approved-Arena-Complete-Source.zip'
with zipfile.ZipFile(source,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
 for p in sorted(game.iterdir()):
  if p.is_file():archive.write(p,'home-vibe-tablet/pc-assets/games/ghost-grind/'+p.name)
 for name in ['ghost-grind-engine.cjs','ghost-grind-browser.cjs','PcHostHarness.java']:
  archive.write(root/'tests'/name,'home-vibe-tablet/tests/'+name)
 for p in (root/'design-reference/ghost-grind').rglob('*'):
  if p.is_file():archive.write(p,'art-originals/'+p.name)
 for p in (root/'tests/reports/ghost-grind').glob('*'):
  if p.is_file():archive.write(p,'validation/'+p.name)
 archive.write(Path(__file__),'tools/package-ghost-grind.py')
 archive.writestr('SOURCE-NOTES.txt','Complete game source and original artwork. Android host harness tests run in the main source repository with its production Java modules. See README.md inside home-vibe-tablet/pc-assets/games/ghost-grind/ for controls and installation. This is a game pack, not an Android APK.\n')
shutil.copyfile(game/'README.md',out/'INSTALL-AND-CONTROLS.md')
shutil.copyfile(root/'tests/reports/ghost-grind/six-skaters.png',out/'Ghost-Grind-Approved-Arena-preview.png')
(out/'SHA256SUMS.txt').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n' for p in [pack,source]))
print(json.dumps({p.name:p.stat().st_size for p in [pack,source]},indent=2))
