/* Ghost Grind: tablet-authoritative rules, no network or rendering dependencies. */
(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.GhostGrindEngine=factory();})(typeof globalThis!=='undefined'?globalThis:this,()=>{
'use strict';
const COLORS=['red','blue','green','yellow','pink','white'],HEX=['#ff5269','#5aa5ff','#67eaa0','#ffda64','#ff8fce','#f0f3ff'];
const TRICKS=[{bit:32,name:'KICKFLIP',value:120,duration:.24},{bit:64,name:'HEELFLIP',value:150,duration:.3},{bit:128,name:'360 SPIN',value:240,duration:.5},{bit:1024,name:'INDY GRAB',value:90,duration:.2},{bit:2048,name:'MELON GRAB',value:110,duration:.25}];
function create(seed=Date.now()){
 const order=Array.from({length:6},(_,i)=>(i+((seed>>>0)%6))%6);
 return {phase:'LOBBY',round:0,remaining:90,intermission:0,paused:false,pauseReason:'',champion:null,previous:[0,0,0,0,0,0],tieOrder:order,history:[],lastLoser:null,players:COLORS.map((color,i)=>({color,hex:HEX[i],name:color.toUpperCase(),alive:true,eliminated:false,score:0,total:0,best:0,landed:0,pending:0,combo:0,chain:[],jump:0,vy:0,trickTime:0,cooldown:0,target:(i+1)%6,slow:0,haunts:0,ghostStyle:0,bail:0,pop:0,message:'READY TO ROLL'}))};
}
function nextRound(s){s.round++;s.phase='RUNNING';s.remaining=90;s.intermission=0;s.lastLoser=null;s.paused=false;for(const p of s.players){Object.assign(p,{score:0,best:0,landed:0,pending:0,combo:0,chain:[],jump:0,vy:0,trickTime:0,cooldown:0,slow:0,bail:0,pop:0,message:p.alive?'HOLD A DOWN THE WALL / THROUGH THE FLAT':'GHOST • DOWN PUMPS / A HAUNTS'});resetRider(p,s.players.indexOf(p));}}
function start(s,connected){if(s.phase!=='LOBBY'||!connected.every(Boolean)||connected.length!==6)return false;nextRound(s);return true;}
function land(p){if(p.trickTime>.025){p.bail=1.05;p.message='BAIL! COMBO LOST';p.pending=0;p.combo=0;p.chain=[];return;}if(p.pending){const points=Math.round(p.pending*(1+Math.min(4,p.combo-1)*.35));if(p.alive){p.score+=points;p.best=Math.max(p.best,points);p.landed++;}else p.ghostStyle+=points;p.message='+'+points+' • '+p.chain.join(' + ');p.pop=1.5;}p.pending=0;p.combo=0;p.chain=[];}
function finishRound(s){
 const ranked=s.players.map((p,i)=>({p,i})).filter(x=>x.p.alive).sort((a,b)=>a.p.score-b.p.score||a.p.best-b.p.best||a.p.landed-b.p.landed||a.p.total-b.p.total||s.tieOrder.indexOf(a.i)-s.tieOrder.indexOf(b.i));
 const loser=ranked[0],tied=ranked.length>1&&loser.p.score===ranked[1].p.score;
 // The buzzer cancels unlanded combos; ghosts can never be eliminated twice.
 for(const p of s.players){p.total+=p.alive?p.score:0;p.pending=0;p.combo=0;p.chain=[];}
 loser.p.alive=false;loser.p.eliminated=true;loser.p.message='GHOST MODE • KEEP SKATING';s.lastLoser=loser.i;
 s.history.push({round:s.round,loser:loser.i,tied,tiebreak:tied?'Best combo, landed combos, previous total, then announced rotation':'Lowest landed score',scores:s.players.map(p=>p.score)});
 if(s.round===5){s.phase='FINISHED';s.champion=s.players.findIndex(p=>p.alive);}else{s.phase='RESULTS';s.intermission=8;}
}
function chooseTarget(s,p,dir){let n=p.target;for(let k=0;k<6;k++){n=(n+dir+6)%6;if(s.players[n].alive){p.target=n;return;}}}
// One continuous U ramp: six metres of flat, then four-metre quarter pipes.
const RADIUS=4, FLAT=3, LIMIT=FLAT+RADIUS*Math.PI/2, GRAVITY=19;
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
function surface(q){
 const side=Math.sign(q)||1,theta=clamp((Math.abs(q)-FLAT)/RADIUS,0,Math.PI/2);
 return {x:side*(Math.min(Math.abs(q),FLAT)+RADIUS*Math.sin(theta)),y:RADIUS*(1-Math.cos(theta)),angle:side*theta};
}
function floorAt(x){const d=clamp(Math.abs(x)-FLAT,0,RADIUS);return RADIUS-Math.sqrt(Math.max(0,RADIUS*RADIUS-d*d));}
function trackAt(x){return Math.sign(x)*(Math.min(Math.abs(x),FLAT)+RADIUS*Math.asin(clamp((Math.abs(x)-FLAT)/RADIUS,0,1)));}
function resetRider(p,i){
 const q=[-6,-3,-.7,.7,3,6][i],pos=surface(q),direction=i%2?-1:1;
 Object.assign(p,{q,v:direction*Math.sqrt(Math.max(12,130-2*GRAVITY*pos.y)),x:pos.x,y:pos.y,angle:pos.angle,air:false,airTime:0,launchSide:1,launchVy:0,vx:0,vy:0,depth:.12+i*.15,pumping:false,spinAngle:0,bump:0,popBoost:0,airCount:0});
}
function tickPlayer(s,p,i,dt,mask,edge){
 for(const key of ['bail','pop','cooldown','slow','trickTime','bump','popBoost'])p[key]=Math.max(0,(p[key]||0)-dt);
 if(!p.alive){
  if(!s.players[p.target].alive)chooseTarget(s,p,1);
  if(edge&1024)chooseTarget(s,p,-1);
  if(edge&2048)chooseTarget(s,p,1);
  if((edge&16)&&p.cooldown===0){const target=s.players[p.target];target.slow=Math.max(target.slow,1.6);target.message='GHOST GUST • PUMP THROUGH IT';p.cooldown=5;p.haunts++;p.message='HAUNTED '+target.name;p.pop=1.2;}
 }
 // Left/right moves across the WIDTH of this same ramp, never into a separate lane.
 p.depth=clamp(p.depth+((mask&8?1:0)-(mask&4?1:0))*dt*.22,.05,.95);
 if(p.air){
  p.airTime+=dt;p.vy-=GRAVITY*dt;p.x+=p.vx*dt;p.y+=p.vy*dt;
  p.facing=p.vy>0?p.launchSide:-p.launchSide;
  const progress=clamp(p.airTime/(2*p.launchVy/GRAVITY+.25),0,1);
  p.angle=p.launchSide*Math.PI/2*Math.abs(2*progress-1);
  if(p.bail===0&&p.trickTime===0)for(const trick of TRICKS){
   if(!(edge&trick.bit)||(!p.alive&&(trick.bit===1024||trick.bit===2048)))continue;
   const repeated=p.chain.includes(trick.name);
   p.pending+=Math.round(trick.value*(repeated?.2:1));p.combo++;p.chain.push(trick.name);
   p.trickTime=trick.duration;p.trickDuration=trick.duration;p.activeTrick=trick.name;p.message=trick.name+(repeated?' • REPEAT':'');break;
  }
  if(p.vy<0&&p.y<=floorAt(p.x)){
   p.q=trackAt(p.x);const pos=surface(p.q);p.x=pos.x;p.y=pos.y;p.angle=pos.angle;
   const incoming=p.vx*Math.cos(pos.angle)+p.vy*Math.sin(pos.angle);
   p.v=clamp(incoming,-22,22);if(Math.abs(p.v)<3)p.v=-p.launchSide*3;
   p.air=false;p.jump=0;land(p);if(p.bail>0)p.v*=.5;
  }else p.jump=Math.max(0,p.y-floorAt(p.x));
  p.pumping=false;return;
 }
 const pos=surface(p.q),descending=p.q*p.v<0||Math.abs(p.q)<FLAT;
 const pump=!!(mask&(p.alive?18:3));
 p.pumping=pump&&descending&&Math.abs(p.q)<FLAT+2&&p.bail===0;
 let acceleration=-GRAVITY*Math.sin(pos.angle)-p.v*.075;
 if(p.pumping){acceleration+=(Math.sign(p.v)||-Math.sign(p.q)||1)*13*(p.slow>0?.65:1);p.message='PUMP! BUILDING AIR';}
 if(mask&32)acceleration-=p.v*1.6; // B brakes only while on the ramp.
 if(p.bail>0)acceleration-=p.v*.8;
 if((edge&(p.alive?16:1))&&Math.abs(p.q)>LIMIT-1.2)p.popBoost=.6;
 p.v=clamp(p.v+acceleration*dt,-22,22);p.q+=p.v*dt;
 if(Math.abs(p.q)>=LIMIT){
  const side=Math.sign(p.q);p.q=side*LIMIT;p.x=side*(FLAT+RADIUS);p.y=RADIUS;
  if(p.v*side>1.8&&p.bail===0){
   p.air=true;p.airTime=0;p.launchSide=side;p.launchVy=Math.min(12,Math.abs(p.v)*.9+(p.popBoost>0?1.5:0));
   p.vy=p.launchVy;p.vx=-side*.85;p.pending=40;p.combo=1;p.chain=['VERT AIR'];p.airCount++;p.message='ABOVE THE COPING!';p.jump=.001;
  }else p.v=-side*Math.max(1,Math.abs(p.v)*.8);
 }
 const current=surface(p.q);if(!p.air){p.x=current.x;p.y=current.y;p.angle=current.angle;p.facing=Math.sign(p.v)||1;}
}
function bumpRiders(s){
 for(let i=0;i<6;i++)for(let j=i+1;j<6;j++){
  const a=s.players[i],b=s.players[j];
  if(!a.alive||!b.alive||a.air||b.air||a.bump>0||b.bump>0||a.bail>0||b.bail>0)continue;
  if(Math.abs(a.q-b.q)<.48&&Math.abs(a.depth-b.depth)<.085&&Math.abs(a.v-b.v)>2){
   const av=a.v,bv=b.v;a.v=.7*av+.3*bv;b.v=.7*bv+.3*av;a.bump=b.bump=.55;
   a.q=clamp(a.q-.15,-LIMIT,LIMIT);b.q=clamp(b.q+.15,-LIMIT,LIMIT);
   a.message='BUMP! KEEP YOUR FLOW';b.message='BUMP! KEEP YOUR FLOW';
  }
 }
}
function step(s,dt,masks,connected){
 if(!Number.isFinite(dt)||dt<0||dt>1)return;const all=connected.length===6&&connected.every(Boolean),edges=masks.map((v,i)=>v&~s.previous[i]);s.previous=masks.slice(0,6);
 if(s.phase==='LOBBY'){if(edges.some(v=>v&256))start(s,connected);return;}
 if(s.phase==='FINISHED')return;
 if(!all){if(s.pauseReason!=='Reconnect all six phones')s.beforeDisconnect={paused:s.paused,reason:s.pauseReason};s.paused=true;s.pauseReason='Reconnect all six phones';return;}
 if(s.pauseReason==='Reconnect all six phones'){const prior=s.beforeDisconnect||{paused:false,reason:''};s.paused=prior.paused;s.pauseReason=prior.reason;delete s.beforeDisconnect;s.previous=masks.slice();return;}
 if(s.paused)return;
 if(s.phase==='RESULTS'){s.intermission-=dt;if(s.intermission<=0||(s.intermission<5&&edges.some(v=>v&256)))nextRound(s);return;}
 let remaining=Math.min(dt,s.remaining),first=true;while(remaining>1e-8){const slice=Math.min(remaining,1/60);s.players.forEach((p,i)=>tickPlayer(s,p,i,slice,masks[i]||0,first?edges[i]||0:0));bumpRiders(s);first=false;remaining-=slice;}s.remaining=Math.max(0,s.remaining-dt);if(s.remaining===0)finishRound(s);
}
return {COLORS,HEX,TRICKS,create,start,step,surface,floorAt,trackAt,RADIUS,FLAT,LIMIT,GRAVITY};
});
