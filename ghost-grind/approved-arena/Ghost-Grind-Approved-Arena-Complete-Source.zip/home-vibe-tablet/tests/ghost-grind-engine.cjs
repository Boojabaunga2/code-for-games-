const assert=require('node:assert/strict'),E=require('../pc-assets/games/ghost-grind/engine.js');
const all=Array(6).fill(true),none=Array(6).fill(0);
function autopilot(p,i=0){
 if(!p.air)return p.alive?18:(2|(p.cooldown===0?16:0));
 const t=p.airTime;
 if(t>.15&&t<.28)return 32;
 if(t>.49&&t<.62)return 64;
 if(t>.88&&t<1.01)return i%2?1024:128;
 return 0;
}
function run(s,seconds,policy=()=>none){for(let t=0;t<seconds-1e-8;t+=1/60)E.step(s,Math.min(1/60,seconds-t),policy(s,t),all);}
// The continuous U has a flat centre and actual curved walls on BOTH sides.
assert.equal(E.surface(0).y,0);assert.equal(E.surface(2).y,0);
assert.equal(E.surface(E.LIMIT).x,7);assert(Math.abs(E.surface(E.LIMIT).y-4)<1e-9);
assert.equal(E.surface(-E.LIMIT).x,-7);assert(Math.abs(E.surface(-E.LIMIT).y-4)<1e-9);
for(const q of [-9,-6,-3,0,3,6,9])assert(Math.abs(E.trackAt(E.surface(q).x)-q)<1e-8);
let s=E.create(1);assert.equal(E.start(s,all.slice(0,5)),false);assert.equal(E.start(s,[true,true,true,true,true,false]),false);assert(E.start(s,all));assert.equal(s.remaining,90);
// Gravity reverses an unpumped rider; there is no automatic forward-scrolling course.
let minX=100,maxX=-100,positive=false,negative=false;
run(s,12,state=>{const p=state.players[0];minX=Math.min(minX,p.x);maxX=Math.max(maxX,p.x);positive ||=p.v>0;negative ||=p.v<0;return none;});
assert(positive&&negative);assert(minX<-3&&maxX>3);assert.equal(s.players[0].airCount,0);assert.equal(s.players[0].score,0);
// Pump only seat zero: it must rise above coping on both walls, land tricks, and leave others unscored.
s=E.create(2);E.start(s,all);const launchSides=new Set();let peak=0;
run(s,20,state=>{const p=state.players[0];if(p.air)launchSides.add(p.launchSide);peak=Math.max(peak,p.y);return [autopilot(p),0,0,0,0,0];});
assert.deepEqual([...launchSides].sort(),[-1,1]);assert(peak>6,'pumping creates big aerial height');assert(s.players[0].score>0);assert.equal(s.players[1].score,0);
// Points bank at the curved ramp, never in midair; a late flip bails.
let p=s.players[0];Object.assign(p,{air:true,x:5,y:E.floorAt(5)+.001,vy:-4,vx:-.5,pending:500,combo:2,chain:['VERT AIR','KICKFLIP'],trickTime:.4});const bank=p.score;E.step(s,1/60,none,all);assert.equal(p.score,bank);assert.equal(p.pending,0);assert(p.bail>0);assert.equal(p.air,false);
// Shared depth steering and soft collisions interact on the SAME geometry.
s=E.create(3);E.start(s,all);Object.assign(s.players[0],{q:0,v:10,depth:.5});Object.assign(s.players[1],{q:.2,v:-10,depth:.5});E.step(s,.01,none,all);assert(s.players[0].bump>0&&s.players[1].bump>0);assert.equal(s.players[0].bail,0);
const oldDepth=s.players[2].depth;run(s,.5,()=>[0,0,8,0,0,0]);assert(s.players[2].depth>oldDepth);
// A ghost can pass through living skaters; only its cooldown-limited gust affects them.
s.players[0].alive=false;s.players[0].eliminated=true;s.players[0].target=1;s.players[0].cooldown=0;E.step(s,.01,[16,0,0,0,0,0],all);assert.equal(s.players[0].haunts,1);assert(s.players[1].slow>0);E.step(s,.01,none,all);E.step(s,.01,[16,0,0,0,0,0],all);assert.equal(s.players[0].haunts,1);
const frozen=s.remaining;E.step(s,.5,none,[true,false,true,true,true,true]);assert.equal(s.remaining,frozen);assert(s.paused);E.step(s,.5,none,all);assert.equal(s.remaining,frozen);assert(!s.paused);
s.paused=true;s.pauseReason='Paused on tablet';E.step(s,.1,none,[true,false,true,true,true,true]);E.step(s,.1,none,all);assert(s.paused);assert.equal(s.pauseReason,'Paused on tablet');
// Buzzer cancels pending airs, with one deterministic loser on a full tie.
s=E.create(3);E.start(s,all);s.players.forEach(p=>{p.pending=500;p.air=true;p.x=7;p.y=6;p.vy=3;});s.remaining=.001;E.step(s,.001,none,all);assert.equal(s.lastLoser,3);assert(s.history[0].tied);assert(s.players.every(p=>p.score===0&&p.pending===0));
// Full five-round simulation: all six move together, five unique ghosts, one champion.
s=E.create(11);E.start(s,all);let runningSeconds=0,ticks=0;
while(s.phase!=='FINISHED'&&ticks++<60000){const running=s.phase==='RUNNING',dt=1/60,before=s.remaining;E.step(s,dt,s.players.map(autopilot),all);if(running)runningSeconds+=Math.min(dt,before);for(const p of s.players){assert(Number.isFinite(p.x)&&Number.isFinite(p.y));assert(p.x>=-7.01&&p.x<=7.01);assert(p.y>=-.01);}}
assert.equal(s.phase,'FINISHED');assert.equal(s.round,5);assert.equal(s.history.length,5);assert.equal(new Set(s.history.map(h=>h.loser)).size,5);assert.equal(s.players.filter(p=>p.alive).length,1);assert(s.players[s.champion].alive);assert(Math.abs(runningSeconds-450)<.01);assert(s.players.every(p=>p.airCount>0));assert(s.players.some(p=>p.haunts>0));
console.log('PASS shared half-pipe: curved geometry, gravity reversal, two-sided pumping/aerials, landing/bails, depth steering, shared bumps, ghost gusts, reconnect/manual pause and five complete 90-second rounds.');
