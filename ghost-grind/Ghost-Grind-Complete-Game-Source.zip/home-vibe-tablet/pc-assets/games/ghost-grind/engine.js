/* Ghost Grind: tablet-authoritative rules, no network or rendering dependencies. */
(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.GhostGrindEngine=factory();})(typeof globalThis!=='undefined'?globalThis:this,()=>{
'use strict';
const COLORS=['red','blue','green','yellow','pink','white'],HEX=['#ff5269','#5aa5ff','#67eaa0','#ffda64','#ff8fce','#f0f3ff'];
const TRICKS=[{bit:32,name:'KICKFLIP',value:120,duration:.24},{bit:64,name:'HEELFLIP',value:150,duration:.3},{bit:128,name:'180 SHUVIT',value:180,duration:.32},{bit:1024,name:'INDY GRAB',value:90,duration:.2}];
const wrap=x=>(x%1200+1200)%1200;
function create(seed=Date.now()){
 const order=Array.from({length:6},(_,i)=>(i+((seed>>>0)%6))%6);
 return {phase:'LOBBY',round:0,remaining:90,intermission:0,paused:false,pauseReason:'',champion:null,previous:[0,0,0,0,0,0],tieOrder:order,history:[],lastLoser:null,players:COLORS.map((color,i)=>({color,hex:HEX[i],name:color.toUpperCase(),alive:true,eliminated:false,score:0,total:0,best:0,landed:0,pending:0,combo:0,chain:[],jump:0,vy:0,dist:0,speed:135,spin:0,trickTime:0,grind:0,cooldown:0,target:(i+1)%6,slow:0,haunts:0,ghostStyle:0,bail:0,pop:0,message:'READY TO ROLL'}))};
}
function nextRound(s){s.round++;s.phase='RUNNING';s.remaining=90;s.intermission=0;s.lastLoser=null;s.paused=false;for(const p of s.players){Object.assign(p,{score:0,best:0,landed:0,pending:0,combo:0,chain:[],jump:0,vy:0,dist:0,speed:135,spin:0,trickTime:0,grind:0,cooldown:0,slow:0,bail:0,pop:0,message:p.alive?'LAND YOUR TRICKS':'GHOST • A TO HAUNT'});}}
function start(s,connected){if(s.phase!=='LOBBY'||!connected.every(Boolean)||connected.length!==6)return false;nextRound(s);return true;}
function land(p){if(p.trickTime>.025){p.bail=1.05;p.message='BAIL! COMBO LOST';p.pending=0;p.combo=0;p.chain=[];p.speed=85;return;}if(p.pending){const points=Math.round(p.pending*(1+Math.min(4,p.combo-1)*.35));if(p.alive){p.score+=points;p.best=Math.max(p.best,points);p.landed++;}else p.ghostStyle+=points;p.message='+'+points+' • '+p.chain.join(' + ');p.pop=1.5;}p.pending=0;p.combo=0;p.chain=[];}
function finishRound(s){
 const ranked=s.players.map((p,i)=>({p,i})).filter(x=>x.p.alive).sort((a,b)=>a.p.score-b.p.score||a.p.best-b.p.best||a.p.landed-b.p.landed||a.p.total-b.p.total||s.tieOrder.indexOf(a.i)-s.tieOrder.indexOf(b.i));
 const loser=ranked[0],tied=ranked.length>1&&loser.p.score===ranked[1].p.score;
 // The buzzer cancels unlanded combos; ghosts can never be eliminated twice.
 for(const p of s.players){p.total+=p.alive?p.score:0;p.pending=0;p.combo=0;p.chain=[];}
 loser.p.alive=false;loser.p.eliminated=true;loser.p.message='GHOST MODE • KEEP SKATING';s.lastLoser=loser.i;
 s.history.push({round:s.round,loser:loser.i,tied,tiebreak:tied?'Best combo, landed combos, previous total, then announced rotation':'Lowest landed score',scores:s.players.map(p=>p.score)});
 if(s.round===5){s.phase='FINISHED';s.champion=s.players.findIndex(p=>p.alive);}else{s.phase='RESULTS';s.intermission=8;}
}
function chooseTarget(s,p,dir){let n=p.target;for(let k=0;k<6;k++){n=(n+dir+6)%6;if(s.players[n].alive){p.target=n;return;}}}
function tickPlayer(s,p,i,dt,mask,edge){
 p.bail=Math.max(0,p.bail-dt);p.pop=Math.max(0,p.pop-dt);p.cooldown=Math.max(0,p.cooldown-dt);p.slow=Math.max(0,p.slow-dt);p.trickTime=Math.max(0,p.trickTime-dt);
 if(!p.alive){if(!s.players[p.target].alive)chooseTarget(s,p,1);if(edge&1024)chooseTarget(s,p,-1);if(edge&2048)chooseTarget(s,p,1);if((edge&16)&&p.cooldown===0){const target=s.players[p.target];target.slow=Math.max(target.slow,1.6);target.message='GHOST GUST • KEEP YOUR LINE';p.cooldown=5;p.haunts++;p.message='HAUNTED '+target.name;p.pop=1.2;}}
 const desired=(mask&4)?85:(mask&8)?205:150;p.speed+=(desired*(p.slow>0?.72:1)-p.speed)*Math.min(1,dt*4);if(p.bail>0)p.speed=65;
 const before=wrap(p.dist);p.dist+=p.speed*dt;const x=wrap(p.dist),ramp=before<330&&x>=330||before<910&&x>=910;
 if(p.jump===0&&p.bail===0&&(((edge&16)&&p.alive)||(!p.alive&&(edge&1))||ramp)){p.vy=ramp?8.1:7.1;p.jump=.001;p.pending=25;p.combo=1;p.chain=['OLLIE'];p.message=ramp?'RAMP AIR':'OLLIE';}
 if(p.jump>0){p.vy-=15*dt;p.jump+=p.vy*dt;if(p.bail===0&&p.trickTime===0)for(const t of TRICKS){if(!(edge&t.bit)||(!p.alive&&t.bit===1024))continue;const repeated=p.chain.includes(t.name);p.pending+=Math.round(t.value*(repeated?.25:1));p.combo++;p.chain.push(t.name);p.trickTime=t.duration;p.activeTrick=t.name;p.trickDuration=t.duration;p.spin+=Math.PI;p.message=t.name+(repeated?' • REPEAT':'');break;}if(p.jump<=0){p.jump=0;p.vy=0;land(p);}}
 const onRail=x>=550&&x<=735&&p.jump<.8&&p.jump>.06;if(onRail&&(mask&2048)&&p.alive){p.grind+=dt;p.jump=.28;p.vy=0;p.pending+=dt*65;if(!p.chain.includes('50-50 GRIND')){p.chain.push('50-50 GRIND');p.combo++;}p.message='50-50 GRIND';}else p.grind=0;
}
function step(s,dt,masks,connected){
 if(!Number.isFinite(dt)||dt<0||dt>1)return;const all=connected.length===6&&connected.every(Boolean),edges=masks.map((v,i)=>v&~s.previous[i]);s.previous=masks.slice(0,6);
 if(s.phase==='LOBBY'){if(edges.some(v=>v&256))start(s,connected);return;}
 if(s.phase==='FINISHED')return;
 if(!all){if(s.pauseReason!=='Reconnect all six phones')s.beforeDisconnect={paused:s.paused,reason:s.pauseReason};s.paused=true;s.pauseReason='Reconnect all six phones';return;}
 if(s.pauseReason==='Reconnect all six phones'){const prior=s.beforeDisconnect||{paused:false,reason:''};s.paused=prior.paused;s.pauseReason=prior.reason;delete s.beforeDisconnect;s.previous=masks.slice();return;}
 if(s.paused)return;
 if(s.phase==='RESULTS'){s.intermission-=dt;if(s.intermission<=0||(s.intermission<5&&edges.some(v=>v&256)))nextRound(s);return;}
 let remaining=Math.min(dt,s.remaining),first=true;while(remaining>1e-8){const slice=Math.min(remaining,1/60);s.players.forEach((p,i)=>tickPlayer(s,p,i,slice,masks[i]||0,first?edges[i]||0:0));first=false;remaining-=slice;}s.remaining=Math.max(0,s.remaining-dt);if(s.remaining===0)finishRound(s);
}
return {COLORS,HEX,TRICKS,create,start,step,wrap};
});
