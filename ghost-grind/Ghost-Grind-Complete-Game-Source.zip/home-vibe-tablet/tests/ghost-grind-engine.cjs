const assert=require('node:assert/strict'),E=require('../pc-assets/games/ghost-grind/engine.js'),all=Array(6).fill(true),none=Array(6).fill(0);
function run(s,seconds,masks=none){for(let t=0;t<seconds-1e-8;t+=1/60)E.step(s,Math.min(1/60,seconds-t),masks,all);}
let s=E.create(0);assert.equal(E.start(s,all.slice(0,5)),false);assert.equal(E.start(s,[true,true,true,true,true,false]),false);assert(E.start(s,all));assert.equal(s.remaining,90);
// A real ollie -> kickflip -> landing banks points only after touching down.
E.step(s,1/60,[16,0,0,0,0,0],all);assert.equal(s.players[0].score,0);run(s,.12);E.step(s,1/60,[32,0,0,0,0,0],all);assert(s.players[0].pending>25);assert.equal(s.players[0].score,0);run(s,.85);assert(s.players[0].score>100);assert.equal(s.players[1].score,0,'seat input isolation');
// A late trick loses all pending points and never subtracts an earlier bank.
let p=s.players[0],bank=p.score;p.jump=.04;p.vy=-5;p.pending=200;p.combo=2;p.trickTime=.3;run(s,.05);assert.equal(p.score,bank);assert.equal(p.pending,0);assert(p.bail>0);
// Held trick buttons do not fire repeated edges; disconnected phones freeze the timer.
const before=s.remaining;E.step(s,.5,none,[true,false,true,true,true,true]);assert.equal(s.remaining,before);assert(s.paused);E.step(s,.5,none,all);assert.equal(s.remaining,before);assert.equal(s.paused,false);run(s,.5);assert(s.remaining<before);
// Reconnection must not silently resume a deliberate tablet pause.
s.paused=true;s.pauseReason='Paused on tablet';const pausedAt=s.remaining;E.step(s,.1,none,[true,false,true,true,true,true]);E.step(s,.1,none,all);assert(s.paused);assert.equal(s.pauseReason,'Paused on tablet');assert.equal(s.remaining,pausedAt);
// A landing onto the rail adds grind points, which bank only after leaving it.
s=E.create(0);E.start(s,all);p=s.players[0];Object.assign(p,{dist:549,jump:.4,vy:-.1,pending:25,combo:1,chain:['OLLIE']});E.step(s,1/60,[2048,0,0,0,0,0],all);assert(p.grind>0);assert.equal(p.score,0);run(s,1.6,[2048,0,0,0,0,0]);assert(p.score>100,'grind must bank after landing');
// Explicit tie ranking selects exactly one living loser; pre-existing ghosts cannot lose again.
s=E.create(0);E.start(s,all);s.players.forEach((p,i)=>{p.score=i?200:100;p.pending=500;p.jump=2;p.trickTime=.5;});s.remaining=.001;E.step(s,.001,none,all);assert.equal(s.lastLoser,0);assert.equal(s.players[0].score,100,'buzzer cannot cash an airborne combo');assert.equal(s.players.filter(p=>p.alive).length,5);assert.equal(s.phase,'RESULTS');run(s,8.1);assert.equal(s.round,2);assert.equal(s.remaining<90,true);
// Ghost can target only living skaters; gust cooldown cannot be spammed and never forces a crash.
p=s.players[0];p.target=1;E.step(s,.01,[16,0,0,0,0,0],all);assert.equal(p.haunts,1);assert(s.players[1].slow>0);run(s,.1);E.step(s,.01,[16,0,0,0,0,0],all);assert.equal(p.haunts,1);assert.equal(s.players[1].bail,0);E.step(s,.01,none,all);E.step(s,.01,[2048,0,0,0,0,0],all);assert.equal(p.target,2);
// Five complete 90-second rounds using actual physics and deterministic input schedules.
s=E.create(11);E.start(s,all);let runningSeconds=0,resultSeconds=0,ticks=0,round=1,previousRemaining=90;
while(s.phase!=='FINISHED'&&ticks++<60000){const running=s.phase==='RUNNING',dt=1/60;const masks=s.players.map((p,i)=>{const n=(ticks+i*13)%100;if(!p.alive)return n===1?16:n===10?1:0;return n===1?16:n===20?32:n===45?128:8;});E.step(s,dt,masks,all);if(running)runningSeconds+=Math.min(dt,previousRemaining);else resultSeconds+=dt;if(s.round!==round){round=s.round;previousRemaining=90;}else previousRemaining=s.remaining;}
assert.equal(s.phase,'FINISHED');assert.equal(s.round,5);assert.equal(s.history.length,5);assert.equal(new Set(s.history.map(h=>h.loser)).size,5);assert.equal(s.players.filter(p=>p.alive).length,1);assert(s.players[s.champion].alive);assert(Math.abs(runningSeconds-450)<.01,'five real 90s timers: '+runningSeconds);assert(s.players.some(p=>p.total>0));assert(s.players.some(p=>p.haunts>0));
// All-zero ties still produce one deterministic loser and preserve a champion.
s=E.create(3);E.start(s,all);s.remaining=.001;E.step(s,.001,none,all);assert.equal(s.lastLoser,3);assert(s.history[0].tied);
console.log('PASS Ghost Grind: six-seat start gate, land/bail scoring, buzzer, isolated input, reconnect pause, ghost target/cooldown, ties, five 90-second rounds, five unique eliminations and one champion.');
