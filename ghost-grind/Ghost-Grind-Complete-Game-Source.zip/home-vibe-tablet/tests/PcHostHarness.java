import network.arcadium.homevibe.*;
import com.google.gson.*;
import java.io.*;
import java.nio.file.*;
import java.util.*;
public class PcHostHarness {
 public static void main(String[] args)throws Exception {
  Path module=Paths.get(args[0]);ControllerServer server=new ControllerServer(name->{name=PcHtmlAdapter.assetName(name);Path p=module.resolve("app/src/main/assets").resolve(name);if(!Files.isRegularFile(p))p=module.resolve("pc-assets").resolve(name);if(!Files.isRegularFile(p)&&name.startsWith("classic/"))p=module.resolve("../app/src/main/assets").resolve(name.substring(8));if(!Files.isRegularFile(p)&&args.length>1&&name.startsWith("imports/"))p=Paths.get(args[1]).resolve(name.substring(8));if(!Files.isRegularFile(p))throw new FileNotFoundException(name);return PcHtmlAdapter.adapt(name,Files.readAllBytes(p));});PcGameHub hub=new PcGameHub(server);server.start(8789);
  System.out.println(server.port()+" "+server.pairingCode());System.out.flush();BufferedReader in=new BufferedReader(new InputStreamReader(System.in));String line;Gson gson=new Gson();
  while((line=in.readLine())!=null){try{
   if(line.equals("stop")){server.close();break;}
   if(line.startsWith("activate ")){System.out.println(hub.activate(line.substring(9)));}
   else if(line.startsWith("publish ")){hub.publish(line.substring(8));System.out.println("{}");}
   else if(line.equals("inputs")){JsonObject j=new JsonObject();j.add("masks",gson.toJsonTree(server.allHeld()));JsonArray c=new JsonArray();for(int i=0;i<6;i++)c.add(server.connected(i));j.add("connected",c);System.out.println(j);}
   else if(line.equals("state"))System.out.println(server.state());
   else System.out.println("{}");
  }catch(Exception e){System.out.println("{\"error\":\"harness failure\"}");}System.out.flush();}
  server.close();
 }
}
