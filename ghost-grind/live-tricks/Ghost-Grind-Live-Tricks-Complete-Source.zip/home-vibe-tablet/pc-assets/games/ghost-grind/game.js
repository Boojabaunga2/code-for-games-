/* One authoritative simulation on the tablet; phones only submit their own held buttons. */
(()=>{'use strict';const E=GhostGrindEngine,$=id=>document.getElementById(id),canvas=$('park'),ctx=canvas.getContext('2d',{alpha:false}),sprites=new Image(),backdrop=new Image(),airSprites=new Image();sprites.src='skaters.png';backdrop.src='arena-approved.png';airSprites.src='skaters-air.png';let s=E.create(),input={masks:[0,0,0,0,0,0],connected:[false,false,false,false,false,false]},lastInput=0,polling=false,last=performance.now(),lastPub=0,roundShown='',sound=false,audio,helpPaused=false;
const preview=document.createElement('canvas');preview.width=320;const previewCtx=preview.getContext('2d');
function phoneFrame(){preview.height=Math.max(1,Math.round(320*canvas.height/canvas.width));previewCtx.drawImage(canvas,0,0,preview.width,preview.height);return preview.toDataURL('image/jpeg',.4);}
let assetsReady=false,assetError=false;Promise.all([backdrop.decode(),sprites.decode(),airSprites.decode()]).then(()=>{assetsReady=true;updatePortraits();}).catch(()=>assetError=true);
function updatePortraits(){const w=sprites.naturalWidth/3,h=sprites.naturalHeight/2;for(let i=0;i<6;i++){const pic=document.createElement('canvas');pic.width=pic.height=80;pic.getContext('2d').drawImage(sprites,(i%3+.3)*w,(Math.floor(i/3)+.02)*h,w*.65,h*.6,0,0,80,80);const target=$('rider-'+i).querySelector('.portrait');target.style.backgroundImage='url('+pic.toDataURL()+')';target.style.backgroundSize='cover';target.style.backgroundPosition='center';}}
window.__G=s;let bridge=null;try{bridge=window.ArcadiumTablet||parent.ArcadiumTablet;}catch(e){}const gameId=location.pathname.split('/')[2]||'ghost-grind';
function beep(f,d=.08){if(!sound)return;try{audio=audio||new(window.AudioContext||window.webkitAudioContext)();const osc=audio.createOscillator(),gain=audio.createGain();osc.type='sine';osc.frequency.value=f;gain.gain.setValueAtTime(.045,audio.currentTime);gain.gain.exponentialRampToValueAtTime(.001,audio.currentTime+d);osc.connect(gain).connect(audio.destination);osc.start();osc.stop(audio.currentTime+d);}catch(e){}}
async function poll(){if(polling||!bridge?.inputs)return;polling=true;try{const packet=JSON.parse(await bridge.inputs());if(Array.isArray(packet.masks)&&packet.masks.length===6&&Array.isArray(packet.connected)&&packet.connected.length===6){input={masks:packet.masks.map(x=>Number(x)&4095),connected:packet.connected.map(Boolean)};lastInput=performance.now();}}catch(e){}finally{polling=false;}}
function reset(){s=E.create();s.previous=input.masks.slice();window.__G=s;roundShown='';}
function start(){if(!assetsReady)return;if(E.start(s,input.connected)){beep(530);$('lobby').hidden=true;$('arena').hidden=false;}}
$('start').onclick=start;$('sound').onclick=()=>{sound=!sound;$('sound').textContent=sound?'SOUND ON':'SOUND OFF';$('sound').setAttribute('aria-pressed',String(sound));beep(500);};
function exit(){if(!confirm('Leave Ghost Grind and end this match?'))return;parent.postMessage({type:'ARCADIUM_GAME_EXIT'},location.origin);}
$('exit').onclick=exit;$('resultExit').onclick=exit;
$('pause').onclick=()=>{if(s.phase==='RUNNING'){s.paused=!s.paused;s.pauseReason=s.paused?'Paused on tablet':'';}};
$('help').onclick=()=>{helpPaused=!s.paused&&s.phase==='RUNNING';if(helpPaused){s.paused=true;s.pauseReason='How to play';}$('instructions').showModal();};$('closeHelp').onclick=()=>$('instructions').close();$('instructions').addEventListener('close',()=>{if(helpPaused){s.paused=false;s.pauseReason='';helpPaused=false;}});
$('continue').onclick=()=>{if(s.phase==='FINISHED'){reset();start();}else if(s.paused){if(input.connected.every(Boolean)){s.paused=false;s.pauseReason='';s.previous=input.masks.slice();last=performance.now();}}else if(s.phase==='RESULTS'&&s.intermission<=5)s.intermission=0;};
document.addEventListener('visibilitychange',()=>{if(document.hidden&&s.phase==='RUNNING'){s.paused=true;s.pauseReason='Tablet interrupted • tap resume';}});
function text(t,x,y,size=12,color='#e9f4ff',weight=700){ctx.fillStyle=color;ctx.font=weight+' '+size+'px system-ui';ctx.fillText(t,x,y);}
function rect(x,y,w,h,c,r=0){ctx.fillStyle=c;ctx.beginPath();if(ctx.roundRect)ctx.roundRect(x,y,w,h,r);else ctx.rect(x,y,w,h);ctx.fill();}
function board(i,roll,yaw){const cos=Math.cos,si=Math.sin;function p(x,y,z){let yy=y*cos(roll)-z*si(roll),zz=y*si(roll)+z*cos(roll);let xx=x*cos(yaw)+zz*si(yaw),depth=-x*si(yaw)+zz*cos(yaw);return [xx+depth*.35,yy+depth*.28];}function line(points,fill){ctx.beginPath();points.forEach((v,j)=>{let a=p(...v);j?ctx.lineTo(...a):ctx.moveTo(...a)});ctx.closePath();ctx.fillStyle=fill;ctx.fill();ctx.lineWidth=2;ctx.strokeStyle='#f3d2a6';ctx.stroke();}line([[-63,0,-15],[63,0,-15],[69,0,0],[63,0,15],[-63,0,15],[-69,0,0]],Math.cos(roll)>0?'#272b3e':E.HEX[i]);for(const x of [-43,43]){const a=p(x,8,-17),b=p(x,8,17);ctx.strokeStyle='#c7d4e2';ctx.lineWidth=5;ctx.beginPath();ctx.moveTo(...a);ctx.lineTo(...b);ctx.stroke();for(const z of [-18,18]){let q=p(x,13,z);ctx.fillStyle=E.HEX[i];ctx.beginPath();ctx.ellipse(q[0],q[1],7,9,.1,0,7);ctx.fill();ctx.strokeStyle='#f4f4ff';ctx.lineWidth=2;ctx.stroke();}}}
function rider(p,i,x,y,scale,time){
 const spec=p.trickTime>0?p.trickSpec:null,progress=spec?Math.max(0,Math.min(1,1-p.trickTime/p.trickDuration)):0;
 ctx.save();ctx.translate(x,y);ctx.scale(scale,scale);ctx.rotate(-(p.angle||0));ctx.scale((spec?p.trickFacing:p.facing)||1,1);
 if(!p.alive){ctx.globalAlpha=.65;ctx.shadowColor='#8cffff';ctx.shadowBlur=18;}
 if(spec?.body){ctx.translate(0,-44);ctx.rotate(progress*Math.PI*2*spec.body);ctx.translate(0,44);}
 if(spec?.yaw&&!spec.roll)ctx.scale(Math.cos(progress*Math.PI*2*spec.yaw),1);
 if(spec?.grab)ctx.rotate(Math.sin(progress*Math.PI)*.35*spec.grab);
 if(p.bail>0)ctx.rotate(-.65);
 const separate=!!spec?.roll,sheet=p.air&&!separate&&!spec?.body?airSprites:sprites;
 if(sheet.complete&&sheet.naturalWidth){const w=sheet.naturalWidth/3,h=sheet.naturalHeight/2,sx=i%3*w,sy=Math.floor(i/3)*h;
  if(separate){
   const lift=Math.sin(progress*Math.PI)*18;ctx.drawImage(sheet,sx,sy,w,h*.82,-60,-101-lift,120,120*.82);
   ctx.save();ctx.translate(0,4);ctx.scale(.48,.48);board(i,progress*Math.PI*2*spec.roll,progress*Math.PI*2*(spec.yaw||0));ctx.restore();
  }else ctx.drawImage(sheet,sx,sy,w,h,-60,-101,120,120);
 }
 if(spec){ctx.strokeStyle=p.hex+'aa';ctx.lineWidth=2;ctx.beginPath();ctx.ellipse(0,-43,70,58,0,.3,Math.PI*1.7);ctx.stroke();}
 ctx.restore();
}
function draw(time){
 const box=canvas.getBoundingClientRect(),dpr=Math.min(devicePixelRatio||1,1.5),W=box.width,H=box.height;
 if(canvas.width!==Math.round(W*dpr)||canvas.height!==Math.round(H*dpr)){canvas.width=Math.round(W*dpr);canvas.height=Math.round(H*dpr);}
 ctx.setTransform(dpr,0,0,dpr,0,0);canvas.dataset.scene='shared-half-pipe';
 const sky=ctx.createLinearGradient(0,0,0,H);sky.addColorStop(0,'#151331');sky.addColorStop(1,'#101e39');ctx.fillStyle=sky;ctx.fillRect(0,0,W,H);
 if(backdrop.complete&&backdrop.naturalWidth){ctx.globalAlpha=1;ctx.drawImage(backdrop,0,0,W,H);ctx.globalAlpha=1;}
 // Image-based perspective stage matched to the approved inward-facing camera.
 // The same continuous physics surface supplies every skater's ground contact.
 const project=(x,y,depth)=>{
  const z=1-depth, perspective=1/(1+1.7*z);
  const ground=H*(.97-.18*z), wallY=Math.min(y,4)*H*.155*perspective;
  const airY=Math.max(0,y-4)*H*.08*perspective;
  return {x:Math.max(30,Math.min(W-30,W*.5+x*W*.09*perspective)),y:Math.max(H*.23,ground-wallY-airY),perspective};
 };
 // All six skaters occupy this same ramp. Sort by depth, so nearer bodies overlap naturally.
 const poses=s.players.map((p,i)=>({p,i,at:project(p.x,p.y,p.depth)}));
 for(const a of poses)if(!a.p.alive&&a.p.cooldown>4.4){const target=poses[a.p.target];ctx.strokeStyle='#83fff0aa';ctx.lineWidth=3;ctx.setLineDash([8,7]);ctx.beginPath();ctx.moveTo(a.at.x,a.at.y-30);ctx.quadraticCurveTo((a.at.x+target.at.x)/2,Math.min(a.at.y,target.at.y)-100,target.at.x,target.at.y-30);ctx.stroke();ctx.setLineDash([]);}
 poses.sort((a,b)=>a.p.depth-b.p.depth);
 for(const {p,i,at} of poses){
  const floor=project(p.x,E.floorAt(p.x),p.depth);ctx.fillStyle=p.alive?'#24142144':'#7fffff44';ctx.beginPath();ctx.ellipse(floor.x,floor.y,26,6,0,0,Math.PI*2);ctx.fill();
  let scale=Math.max(.55,Math.min(2.25,W/1280*(.8+1.45*p.depth)));if(p.air)scale=Math.min(scale,Math.max(.6,(at.y-20)/110));
  if(p.pumping){ctx.strokeStyle=p.hex+'99';ctx.lineWidth=3;ctx.beginPath();ctx.ellipse(at.x,at.y+4,34*scale,8,0,0,Math.PI*2);ctx.stroke();}
  rider(p,i,at.x,at.y-9,scale,time);
  const labelY=at.y-(Math.cos(p.angle||0)*95+20)*scale;
  ctx.textAlign='center';const badgeY=Math.max(18,labelY);rect(at.x-22,badgeY-18,44,24,p.alive?p.hex:'#88fff0',9);text('P'+(i+1),at.x,badgeY,14,i>=2||!p.alive?'#172338':'#fff');ctx.textAlign='left';
  if(p.pending&&p.air){ctx.textAlign='center';ctx.shadowColor='#000';ctx.shadowBlur=5;text('+'+Math.round(p.pending*(1+Math.min(4,p.combo-1)*.35))+' ×'+(1+Math.min(4,p.combo-1)*.35).toFixed(2),at.x,Math.max(18,labelY-27),14,'#ffedb0',900);if(p.trickTime>0)text(p.activeTrick,at.x,Math.max(38,labelY-47),12,p.hex);ctx.shadowBlur=0;ctx.textAlign='left';}
  if(p.landFx>0&&p.lastLanding){const fade=p.landFx/1.1;ctx.save();ctx.globalAlpha=fade;ctx.strokeStyle='#a2ffd3';ctx.lineWidth=3;ctx.beginPath();ctx.ellipse(floor.x,floor.y,27+(1-fade)*45,7+(1-fade)*8,0,0,Math.PI*2);ctx.stroke();ctx.textAlign='center';ctx.shadowColor='#071329';ctx.shadowBlur=8;text('LANDED +'+p.lastLanding.points,at.x,Math.max(20,at.y-125*scale-(1-fade)*20),15,'#a2ffd3');ctx.restore();}
  if(p.bail>0){ctx.textAlign='center';ctx.shadowColor='#071329';ctx.shadowBlur=8;text('BAIL • COMBO LOST',at.x,Math.max(20,at.y-90*scale),12,'#ff8798');ctx.shadowBlur=0;ctx.textAlign='left';}
 }

 for(let i=0;i<6;i++){const p=s.players[i],card=$('rider-'+i);card.querySelector('b').textContent=(p.alive?p.score:p.ghostStyle).toLocaleString();card.querySelector('small').textContent=p.alive?(p.air?'AIRBORNE':p.pumping?'PUMPING':'RIDING'):'GHOST → '+s.players[p.target].name;card.querySelector('p').textContent=p.message;card.classList.toggle('ghost',!p.alive);}
}
function ui(){const n=input.connected.filter(Boolean).length;$('start').disabled=n!==6||!assetsReady;$('start').textContent=n===6?'LET’S ROLL →':'CONNECT SIX PHONES · '+n+'/6';$('connection').textContent=assetError?'Game artwork could not load. Reopen the game.':!assetsReady?'Loading the arena…':bridge?(n===6?'Ready. Tap Let’s Roll or press START on a phone.':'Join all six colours from Connect Players on the tablet.'):'Open this game inside the Android Home Vibe tablet app.';$('rotation').textContent='Final tie rotation: '+s.tieOrder.map(i=>E.COLORS[i].toUpperCase()).join(' → ');for(let i=0;i<6;i++){$('seats').children[i].classList.toggle('on',input.connected[i]);$('seats').children[i].title=E.COLORS[i]+(input.connected[i]?' connected':' waiting');}
 const live=s.phase!=='LOBBY';document.body.classList.toggle('playing',live);$('lobby').hidden=live;$('arena').hidden=!live;$('pause').hidden=s.phase!=='RUNNING';$('pause').textContent=s.paused?'RESUME':'PAUSE';$('pause').dataset.paused=String(s.paused);$('round').textContent=live?'ROUND '+s.round+' / 5 · '+s.players.filter(p=>p.alive).length+' LIVING':'ONE HALF-PIPE. SIX SKATERS.';const seconds=Math.ceil(s.remaining);$('timer').textContent=String(Math.floor(seconds/60)).padStart(2,'0')+':'+String(seconds%60).padStart(2,'0');
 const modal=s.paused||s.phase==='RESULTS'||s.phase==='FINISHED';$('overlay').hidden=!modal;if(!modal)return;
 const key=s.phase+':'+s.round+':'+s.paused+':'+s.pauseReason;if(key!==roundShown){roundShown=key;$('scores').replaceChildren();for(let i=0;i<6;i++){const p=s.players[i],row=document.createElement('div');row.className='score-row'+(i===s.lastLoser?' loser':'');row.style.color=p.hex;for(const value of [p.name,p.score.toLocaleString(),p.alive?'LIVING':i===s.lastLoser?'NEW GHOST':'GHOST']){const span=document.createElement('span');span.textContent=value;row.append(span);}$('scores').append(row);}if(!s.paused)beep(s.phase==='FINISHED'?740:260,.25);}
 $('resultEyebrow').textContent=s.paused?'MATCH PAUSED':s.phase==='FINISHED'?'LAST SKATER STANDING':'ROUND '+s.round+' COMPLETE';$('resultTitle').textContent=s.paused?'Hold your line.':s.phase==='FINISHED'?s.players[s.champion].name+' WINS!':s.players[s.lastLoser].name+' IS A GHOST';$('resultCopy').textContent=s.paused?s.pauseReason:s.phase==='FINISHED'?'Five rounds. Five ghosts. One champion. Play again for free.':'You’re still in the park. Keep skating, choose a rival with L/R, and tap A to haunt.';
 const entry=s.history.at(-1);$('resultTie').textContent=!s.paused&&entry?.tied?'Tied low score: '+entry.tiebreak+'.':'';$('continue').disabled=s.paused?!input.connected.every(Boolean):s.phase==='RESULTS'&&s.intermission>5;$('continue').textContent=s.paused?'RESUME MATCH':s.phase==='FINISHED'?'REMATCH →':'NEXT ROUND IN '+Math.ceil(s.intermission)+'s';}
for(let i=0;i<6;i++){const card=document.createElement('article');card.id='rider-'+i;card.className='rider-score';card.style.setProperty('--rider',E.HEX[i]);const portrait=document.createElement('span');portrait.className='portrait';portrait.style.backgroundPosition=(i%3)*50+'% '+Math.floor(i/3)*100+'%';const name=document.createElement('strong');name.textContent='P'+(i+1)+' '+['MONKEY','RACCOON','LIZARD','RABBIT','CAT','PANDA'][i];card.append(portrait,name,document.createElement('b'),document.createElement('small'),document.createElement('p'));$('riderScores').append(card);const seat=document.createElement('span');seat.style.setProperty('--seat',E.HEX[i]);seat.textContent=i+1;$('seats').append(seat);}
function frame(now){const dt=(now-last)/1000;last=now;poll();if(now-lastInput>1200)input.connected=Array(6).fill(false);if(dt>.5&&s.phase==='RUNNING'){s.paused=true;s.pauseReason='Tablet interrupted • tap resume';}else if(assetsReady||s.phase!=='LOBBY')E.step(s,Math.min(dt,1),input.masks,input.connected);ui();if(s.phase!=='LOBBY')draw(now/1000);if(now-lastPub>450&&bridge?.publish){lastPub=now;try{bridge.publish(JSON.stringify({id:gameId,game:'ghost-grind',phase:s.phase,round:s.round,paused:s.paused,remaining:s.remaining,hudText:s.paused?s.pauseReason:'Shared half-pipe · hold A to pump · B/X/Y/L/R aerial tricks · ghosts: down pump, A haunt',players:s.players.map(p=>({color:p.color,name:p.name,score:p.alive?p.score:p.ghostStyle,alive:p.alive,eliminated:!p.alive})),frame:s.phase==='LOBBY'?undefined:phoneFrame()}));}catch(e){}}requestAnimationFrame(frame);}
requestAnimationFrame(frame);
})();
