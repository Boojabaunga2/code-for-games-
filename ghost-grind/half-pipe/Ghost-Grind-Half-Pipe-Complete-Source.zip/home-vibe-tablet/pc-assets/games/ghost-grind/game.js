/* One authoritative simulation on the tablet; phones only submit their own held buttons. */
(()=>{'use strict';const E=GhostGrindEngine,$=id=>document.getElementById(id),canvas=$('park'),ctx=canvas.getContext('2d',{alpha:false}),sprites=new Image(),backdrop=new Image();sprites.src='skaters.png';backdrop.src='arena.png';let s=E.create(),input={masks:[0,0,0,0,0,0],connected:[false,false,false,false,false,false]},lastInput=0,polling=false,last=performance.now(),lastPub=0,roundShown='',sound=false,audio,helpPaused=false;
const preview=document.createElement('canvas');preview.width=320;const previewCtx=preview.getContext('2d');
function phoneFrame(){preview.height=Math.max(1,Math.round(320*canvas.height/canvas.width));previewCtx.drawImage(canvas,0,0,preview.width,preview.height);return preview.toDataURL('image/jpeg',.4);}
window.__G=s;let bridge=null;try{bridge=window.ArcadiumTablet||parent.ArcadiumTablet;}catch(e){}const gameId=location.pathname.split('/')[2]||'ghost-grind';
function beep(f,d=.08){if(!sound)return;try{audio=audio||new(window.AudioContext||window.webkitAudioContext)();const osc=audio.createOscillator(),gain=audio.createGain();osc.type='sine';osc.frequency.value=f;gain.gain.setValueAtTime(.045,audio.currentTime);gain.gain.exponentialRampToValueAtTime(.001,audio.currentTime+d);osc.connect(gain).connect(audio.destination);osc.start();osc.stop(audio.currentTime+d);}catch(e){}}
async function poll(){if(polling||!bridge?.inputs)return;polling=true;try{const packet=JSON.parse(await bridge.inputs());if(Array.isArray(packet.masks)&&packet.masks.length===6&&Array.isArray(packet.connected)&&packet.connected.length===6){input={masks:packet.masks.map(x=>Number(x)&4095),connected:packet.connected.map(Boolean)};lastInput=performance.now();}}catch(e){}finally{polling=false;}}
function reset(){s=E.create();s.previous=input.masks.slice();window.__G=s;roundShown='';}
function start(){if(E.start(s,input.connected)){beep(530);$('lobby').hidden=true;$('arena').hidden=false;}}
$('start').onclick=start;$('sound').onclick=()=>{sound=!sound;$('sound').textContent=sound?'SOUND ON':'SOUND OFF';$('sound').setAttribute('aria-pressed',String(sound));beep(500);};
function exit(){if(!confirm('Leave Ghost Grind and end this match?'))return;parent.postMessage({type:'ARCADIUM_GAME_EXIT'},location.origin);}
$('exit').onclick=exit;$('resultExit').onclick=exit;
$('pause').onclick=()=>{if(s.phase==='RUNNING'){s.paused=!s.paused;s.pauseReason=s.paused?'Paused on tablet':'';}};
$('help').onclick=()=>{helpPaused=!s.paused&&s.phase==='RUNNING';if(helpPaused){s.paused=true;s.pauseReason='How to play';}$('instructions').showModal();};$('closeHelp').onclick=()=>$('instructions').close();$('instructions').addEventListener('close',()=>{if(helpPaused){s.paused=false;s.pauseReason='';helpPaused=false;}});
$('continue').onclick=()=>{if(s.phase==='FINISHED'){reset();start();}else if(s.paused){if(input.connected.every(Boolean)){s.paused=false;s.pauseReason='';s.previous=input.masks.slice();last=performance.now();}}else if(s.phase==='RESULTS'&&s.intermission<=5)s.intermission=0;};
document.addEventListener('visibilitychange',()=>{if(document.hidden&&s.phase==='RUNNING'){s.paused=true;s.pauseReason='Tablet interrupted • tap resume';}});
function text(t,x,y,size=12,color='#e9f4ff',weight=700){ctx.fillStyle=color;ctx.font=weight+' '+size+'px system-ui';ctx.fillText(t,x,y);}
function rect(x,y,w,h,c,r=0){ctx.fillStyle=c;ctx.beginPath();if(ctx.roundRect)ctx.roundRect(x,y,w,h,r);else ctx.rect(x,y,w,h);ctx.fill();}
function rider(p,i,x,y,scale,time){ctx.save();ctx.translate(x,y);ctx.scale(scale,scale);ctx.rotate(-(p.angle||0));ctx.scale(p.facing||1,1);if(p.activeTrick==='360 SPIN'&&p.trickTime>0)ctx.rotate((1-p.trickTime/p.trickDuration)*Math.PI*2);if(!p.alive){ctx.globalAlpha=.6+.15*Math.sin(time*3+i);ctx.shadowColor='#8cffff';ctx.shadowBlur=20;for(let k=3;k>0;k--)rect(-55-k*11,5+k*3,35,4,'#93ffff44',3);}
 if(sprites.complete&&sprites.naturalWidth){const w=sprites.naturalWidth/3,h=sprites.naturalHeight/2;ctx.save();if(p.bail>0)ctx.rotate(-.65);else if(p.trickTime>0)ctx.rotate(Math.sin(p.trickTime*12)*.15);const sx=i%3*w,sy=Math.floor(i/3)*h;
 if(p.trickTime>0&&p.bail===0){const progress=1-p.trickTime/(p.trickDuration||.3),split=.84;ctx.drawImage(sprites,sx,sy,w,h*split,-60,-101,120,120*split);ctx.save();ctx.translate(0,4);if(p.activeTrick==='180 SHUVIT')ctx.scale(Math.cos(progress*Math.PI),1);else if(p.activeTrick!=='INDY GRAB')ctx.scale(1,Math.cos(progress*Math.PI*2));else ctx.rotate(-.23);ctx.drawImage(sprites,sx,sy+h*split,w,h*(1-split),-60,-4,120,120*(1-split));ctx.restore();}else ctx.drawImage(sprites,sx,sy,w,h,-60,-101,120,120);ctx.restore();}
 else{ctx.lineWidth=6;ctx.strokeStyle=p.hex;ctx.beginPath();ctx.moveTo(-12,-45);ctx.lineTo(8,-24);ctx.lineTo(-10,-7);ctx.moveTo(8,-24);ctx.lineTo(26,-8);ctx.stroke();rect(-18,-62,34,30,p.hex,13);ctx.fillStyle='#ffd8b1';ctx.beginPath();ctx.arc(5,-65,15,0,Math.PI*2);ctx.fill();rect(-15,-82,37,15,p.hex,9);rect(-29,-5,67,8,p.hex,4);for(const ax of [-15,24]){ctx.fillStyle='#efffff';ctx.beginPath();ctx.arc(ax,8,5,0,7);ctx.fill();}}
 if(p.trickTime>0){ctx.strokeStyle=p.hex;ctx.lineWidth=2;ctx.beginPath();ctx.ellipse(0,-2,44,12,performance.now()/150,0,Math.PI*1.6);ctx.stroke();}if(p.grind>0){for(let k=0;k<7;k++){ctx.strokeStyle=k%2?'#ffbd54':'#fff6bd';ctx.beginPath();ctx.moveTo(-10,-4);ctx.lineTo(-25-k*7,4+Math.sin(time*23+k)*8);ctx.stroke();}}ctx.restore();}
function draw(time){
 const box=canvas.getBoundingClientRect(),dpr=Math.min(devicePixelRatio||1,1.5),W=box.width,H=box.height;
 if(canvas.width!==Math.round(W*dpr)||canvas.height!==Math.round(H*dpr)){canvas.width=Math.round(W*dpr);canvas.height=Math.round(H*dpr);}
 ctx.setTransform(dpr,0,0,dpr,0,0);canvas.dataset.scene='shared-half-pipe';
 const sky=ctx.createLinearGradient(0,0,0,H);sky.addColorStop(0,'#151331');sky.addColorStop(1,'#101e39');ctx.fillStyle=sky;ctx.fillRect(0,0,W,H);
 if(backdrop.complete&&backdrop.naturalWidth){ctx.globalAlpha=.8;ctx.drawImage(backdrop,0,0,W,H);ctx.globalAlpha=1;}
 const sx=W*.79/14,sy=H*.08,dx=W*.12,dy=H*.16,cx=W*.5-dx*.5,base=H*.89;
 const project=(x,y,z)=>({x:cx+x*sx+z*dx,y:base-y*sy-z*dy});
 function polygon(points,color){ctx.beginPath();points.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.closePath();ctx.fillStyle=color;ctx.fill();}
 const front=[],back=[];for(let j=0;j<=120;j++){const p=E.surface(-E.LIMIT+j/120*E.LIMIT*2);front.push(project(p.x,p.y,0));back.push(project(p.x,p.y,1));}
 // A single continuous wooden riding surface, with perspective depth and curved walls.
 polygon([...front,...front.slice().reverse().map(p=>({x:p.x,y:p.y+H*.07}))],'#523530');
 for(let j=0;j<120;j++)polygon([front[j],front[j+1],back[j+1],back[j]],j%4===0?'#b77b4d':j%2?'#d9a574':'#e3b482');
 const shade=ctx.createLinearGradient(0,H*.3,0,H);shade.addColorStop(0,'#120e2b35');shade.addColorStop(.8,'#f6ce9b05');shade.addColorStop(1,'#180e2235');polygon([...front,...back.slice().reverse()],shade);
 for(let z=0;z<=1;z+=.2){ctx.strokeStyle='#74482744';ctx.lineWidth=1;ctx.beginPath();for(let j=0;j<=120;j++){const p=E.surface(-E.LIMIT+j/120*E.LIMIT*2),v=project(p.x,p.y,z);j?ctx.lineTo(v.x,v.y):ctx.moveTo(v.x,v.y);}ctx.stroke();}
 // Coping and broad decks make the complete U silhouette visible at all times.
 for(const side of [-1,1]){
  const inner=project(side*7,4,0),outer=project(side*7,4,1),a=project(side*8.1,4,0),b=project(side*8.1,4,1);
  polygon([inner,outer,b,a],'#2a324b');ctx.strokeStyle=side<0?'#ff799f':'#77eee8';ctx.lineWidth=5;ctx.beginPath();ctx.moveTo(inner.x,inner.y);ctx.lineTo(outer.x,outer.y);ctx.stroke();
  for(const z of [0,1]){const v=project(side*7.9,4,z);ctx.strokeStyle='#8c98b0';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(v.x,v.y);ctx.lineTo(v.x,v.y-H*.08);ctx.stroke();}
 }
 ctx.strokeStyle='#fbd29d';ctx.lineWidth=3;ctx.beginPath();front.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.stroke();
 const logo=project(0,0,.55);ctx.save();ctx.translate(logo.x,logo.y);ctx.transform(1,0,-.6,.55,0,0);ctx.textAlign='center';text('ARCADIUM',0,-5,Math.max(18,W*.035),'#794c3299',900);text('HALF-PIPE HAVOC',0,25,Math.max(9,W*.012),'#794c3277',900);ctx.restore();
 // All six skaters occupy this same ramp. Sort by depth, so nearer bodies overlap naturally.
 const poses=s.players.map((p,i)=>({p,i,at:project(p.x,p.y,p.depth)}));
 for(const a of poses)if(!a.p.alive&&a.p.cooldown>4.4){const target=poses[a.p.target];ctx.strokeStyle='#83fff0aa';ctx.lineWidth=3;ctx.setLineDash([8,7]);ctx.beginPath();ctx.moveTo(a.at.x,a.at.y-30);ctx.quadraticCurveTo((a.at.x+target.at.x)/2,Math.min(a.at.y,target.at.y)-100,target.at.x,target.at.y-30);ctx.stroke();ctx.setLineDash([]);}
 poses.sort((a,b)=>b.p.depth-a.p.depth);
 for(const {p,i,at} of poses){
  const floor=project(p.x,E.floorAt(p.x),p.depth);ctx.fillStyle=p.alive?'#24142144':'#7fffff44';ctx.beginPath();ctx.ellipse(floor.x,floor.y,26,6,0,0,Math.PI*2);ctx.fill();
  const scale=Math.max(.55,Math.min(1.05,W/1280))*(.92+(1-p.depth)*.12);
  if(p.pumping){ctx.strokeStyle=p.hex+'99';ctx.lineWidth=3;ctx.beginPath();ctx.ellipse(at.x,at.y+4,34*scale,8,0,0,Math.PI*2);ctx.stroke();}
  rider(p,i,at.x,at.y-9,scale,time);
  const labelY=at.y-(Math.cos(p.angle||0)*95+20)*scale;
  ctx.textAlign='center';rect(at.x-25,labelY-13,50,19,'#071329dd',6);text(p.name,at.x,labelY,9,p.hex);ctx.textAlign='left';
  if(p.pending&&p.air){ctx.textAlign='center';text('+'+Math.round(p.pending*(1+Math.min(4,p.combo-1)*.35)),at.x,Math.max(18,labelY-24),15,'#ffedb0',900);ctx.textAlign='left';}
 }
 rect(12,12,Math.min(W-24,350),29,'#071329b8',8);text('ONE RAMP · SIX SKATERS · PUMP FOR BIG AIR',24,31,Math.max(8,Math.min(11,W/90)),'#bdfbf3');
 for(let i=0;i<6;i++){const p=s.players[i],card=$('rider-'+i);card.querySelector('b').textContent=(p.alive?p.score:p.ghostStyle).toLocaleString();card.querySelector('small').textContent=p.alive?(p.air?'AIRBORNE':p.pumping?'PUMPING':'RIDING'):'GHOST → '+s.players[p.target].name;card.querySelector('p').textContent=p.message;card.classList.toggle('ghost',!p.alive);}
}
function ui(){const n=input.connected.filter(Boolean).length;$('start').disabled=n!==6;$('start').textContent=n===6?'LET’S ROLL →':'CONNECT SIX PHONES · '+n+'/6';$('connection').textContent=bridge?(n===6?'Ready. Tap Let’s Roll or press START on a phone.':'Join all six colours from Connect Players on the tablet.'):'Open this game inside the Android Home Vibe tablet app.';$('rotation').textContent='Final tie rotation: '+s.tieOrder.map(i=>E.COLORS[i].toUpperCase()).join(' → ');for(let i=0;i<6;i++){$('seats').children[i].classList.toggle('on',input.connected[i]);$('seats').children[i].title=E.COLORS[i]+(input.connected[i]?' connected':' waiting');}
 const live=s.phase!=='LOBBY';$('lobby').hidden=live;$('arena').hidden=!live;$('pause').hidden=s.phase!=='RUNNING';$('pause').textContent=s.paused?'RESUME':'PAUSE';$('round').textContent=live?'ROUND '+s.round+' / 5 · '+s.players.filter(p=>p.alive).length+' LIVING':'ONE HALF-PIPE. SIX SKATERS.';$('timer').innerHTML=Math.ceil(s.remaining)+'<span>s</span>';
 const modal=s.paused||s.phase==='RESULTS'||s.phase==='FINISHED';$('overlay').hidden=!modal;if(!modal)return;
 const key=s.phase+':'+s.round+':'+s.paused+':'+s.pauseReason;if(key!==roundShown){roundShown=key;$('scores').replaceChildren();for(let i=0;i<6;i++){const p=s.players[i],row=document.createElement('div');row.className='score-row'+(i===s.lastLoser?' loser':'');row.style.color=p.hex;for(const value of [p.name,p.score.toLocaleString(),p.alive?'LIVING':i===s.lastLoser?'NEW GHOST':'GHOST']){const span=document.createElement('span');span.textContent=value;row.append(span);}$('scores').append(row);}if(!s.paused)beep(s.phase==='FINISHED'?740:260,.25);}
 $('resultEyebrow').textContent=s.paused?'MATCH PAUSED':s.phase==='FINISHED'?'LAST SKATER STANDING':'ROUND '+s.round+' COMPLETE';$('resultTitle').textContent=s.paused?'Hold your line.':s.phase==='FINISHED'?s.players[s.champion].name+' WINS!':s.players[s.lastLoser].name+' IS A GHOST';$('resultCopy').textContent=s.paused?s.pauseReason:s.phase==='FINISHED'?'Five rounds. Five ghosts. One champion. Play again for free.':'You’re still in the park. Keep skating, choose a rival with L/R, and tap A to haunt.';
 const entry=s.history.at(-1);$('resultTie').textContent=!s.paused&&entry?.tied?'Tied low score: '+entry.tiebreak+'.':'';$('continue').disabled=s.paused?!input.connected.every(Boolean):s.phase==='RESULTS'&&s.intermission>5;$('continue').textContent=s.paused?'RESUME MATCH':s.phase==='FINISHED'?'REMATCH →':'NEXT ROUND IN '+Math.ceil(s.intermission)+'s';}
for(let i=0;i<6;i++){const card=document.createElement('article');card.id='rider-'+i;card.className='rider-score';card.style.setProperty('--rider',E.HEX[i]);const name=document.createElement('strong');name.textContent=E.COLORS[i].toUpperCase();card.append(name,document.createElement('b'),document.createElement('small'),document.createElement('p'));$('riderScores').append(card);const seat=document.createElement('span');seat.style.setProperty('--seat',E.HEX[i]);seat.textContent=i+1;$('seats').append(seat);}
function frame(now){const dt=(now-last)/1000;last=now;poll();if(now-lastInput>1200)input.connected=Array(6).fill(false);if(dt>.5&&s.phase==='RUNNING'){s.paused=true;s.pauseReason='Tablet interrupted • tap resume';}else E.step(s,Math.min(dt,1),input.masks,input.connected);if(s.phase!=='LOBBY')draw(now/1000);ui();if(now-lastPub>450&&bridge?.publish){lastPub=now;try{bridge.publish(JSON.stringify({id:gameId,game:'ghost-grind',phase:s.phase,round:s.round,paused:s.paused,remaining:s.remaining,hudText:s.paused?s.pauseReason:'Shared half-pipe · hold A to pump · B/X/Y/L/R aerial tricks · ghosts: down pump, A haunt',players:s.players.map(p=>({color:p.color,name:p.name,score:p.alive?p.score:p.ghostStyle,alive:p.alive,eliminated:!p.alive})),frame:s.phase==='LOBBY'?undefined:phoneFrame()}));}catch(e){}}requestAnimationFrame(frame);}
requestAnimationFrame(frame);
})();
