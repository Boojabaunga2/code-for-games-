# ARCADIUM · RUIN RUNNERS — FIRST PLAYABLE

A real playable 2.5D jungle platformer for the main Windows Arcadium OS. Six independent PC views and personal Mini Vibe views. This first release contains **one complete Lost Valley course**, not the full multi-world game shown as a concept.

## Start

1. Extract the entire **ARCADIUM_RUIN_RUNNERS_V1.zip**.
2. Close the running Arcadium server console.
3. Double-click **START_INSTALL.cmd**.
4. Select your existing **Arcadium_OS_COMPACT** folder containing `arcadium_server.py`, `arcadium_game_bridge.py`, and `data/arcadium.json`.
5. Choose **EXPLORE IN PRACTICE** first, then **START 90s RACE** when ready.

Normal OS startup also loads the installed shared host. The installer backs up affected files, preserves the existing server/Home/pairing/other games, registers only this game, and adds a removable owned constructor hook to the existing bridge. Its existing source bytes remain above that block; `arcadium_server.py` is unchanged. Unknown bridge constructors stop before writes. If the known Pop-A-Shot shared host is present, the installed adapter reuses it. No APK, additional listener, dependency download or root Home replacement.

## Play

- Hold **Left/Right** to run; release to stop on the ground. Air control retains a short, intentional momentum decay.
- Tap **A** to jump. A also jumps off an attached vine.
- Tap **B** near a vine to grab; B again releases. At the final golden idol, B recovers it.
- Hold **Down** to crouch under temple darts.
- **START** pauses/resumes. Losing browser focus also pauses and clears held input.
- PC: keys **1–6** select a seat, arrows move/duck, Space jumps, B grabs, Enter starts/pauses. A gamepad per seat is also supported.

Collect coins (10 each) and recover the idol (100 plus 10 per remaining heart) before 90 seconds. The same course includes a first jump gap, swinging-vine chasm, dart trap, temple pillars, rolling boulder, crocodile crossing and collapsing rope bridge. Checkpoints save your position. Falls/traps consume a heart and respawn you; three lost hearts ends that explorer's attempt. Coins cannot be farmed by respawning. Treasure ranks first, then finish time, distance, and canonical seat order.

Practice has no time limit or lost hearts. Progress resets before a timed race. Empty seats are not silently automated: choose CPU explicitly, or **WATCH CPU ATTEMPTS** to watch a complete automatic run.

## What is built / what is still a prototype

Built: actual physics, animated run/jump/hang/crouch/idle sprites, treasure, checkpoints, damage, moving vine, darts/boulder collisions, crocodile platforms, player-specific bridge collapse, idol collection, finish/ranking/replay, six simultaneous views, held/released shared native input, touch, normal OS startup and personal screens.

The first playable uses **one eight-pose explorer animation set with six runtime scarf colours**. The distinct six-character cast and additional worlds from the concept are not finished. Background and prop artwork are layered 2D images; this is a working 2.5D sprite game, not a full 3D animated-film renderer. The gameplay video is recorded from the real CPU demo without teleporting the explorers.

## Personal screens

The PC owns all physics and gameplay. Each Mini Vibe receives only its own scoped dashboard, interpolates received positions for smooth display, and draws the same world/animation assets. It does not run an independent game simulation or determine scores. JPEG fallback frames remain available through the existing broker. Existing native A/B/D-pad/START input is retained unchanged.

## Verify / restore

`VERIFY_RUIN_RUNNERS.py` checks actual 8787 routes, artwork and all six mode handoffs after launch. This is HTTP evidence, not physical hardware acceptance.

To restore: close the server, run **RESTORE_RUIN_RUNNERS.py**, select the OS and its `arcadium_backups/ruin_runners_*` backup. Restore affects this game, its entry and its owned bridge block, preserving later unrelated catalogue/bridge edits. It refuses to overwrite later edits to this game's own files or hook.

See VALIDATION.md for automated checks and physical acceptance limits. Keep the server console open while playing.
