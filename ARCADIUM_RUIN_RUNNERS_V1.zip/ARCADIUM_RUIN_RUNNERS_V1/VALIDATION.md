# First-playable validation

## Recorded checks

- 13 engine tests: six independent explorers; held/released movement; actual pit jump/landing; no repeated jump from one press; live vine attachment/momentum release; checkpoint damage/immunity/lives; practice/reset; non-farmable per-seat treasure; crouch/dart collision; boulder clearance; per-player bridge collapse; pause; complete CPU traversal to the idol without teleporting; timer/ranking/scoped dashboard size.
- Exact-ZIP installer tests: original server/Home/pairing/other-game preservation, append-only persistent host, repeat install, Unicode bytes, selective restore preserving later unrelated bridge/catalogue edits, unknown-constructor refusal, edited-hook refusal, normal server startup and included launcher exposing all six mode/native routes.
- Broker tests: six scoped dashboards/frames, tokens, replay/stale-phase rejection, owner handoff and passthrough.
- Browser tests: missing-host blocking, six real personal canvas pages, authenticated held/released movement, jump, touch, reconnect, 650ms input expiry, pause, practice reset, race result/replay and 720p layout. Result score/clock are explicitly arranged as UI fixtures; native and touch actions are real browser/HTTP events.
- Gameplay preview: real-time CPU demo recording from the running game, no position teleports or mockup pan/zoom.

## Delivery checks

Windows/Linux CI tests the exact tracked archive/checksum and extracted launcher, logging actual Defender availability/scan results. Scan success on a runner does not establish recipient PC antivirus acceptance. The public archive is downloaded and its CRC, manifest hashes and full SHA256 verified before delivery.

## Acceptance boundaries

Shared-host and installed-OS tests use fixtures. Six physical Mini Vibes, the user's exact installed OS/carousel, real Wi-Fi latency and device rendering performance still require acceptance on their equipment. The first playable has one complete course and one base explorer animation set with six colour variants. It is not the finished AAA/Pixar-like mockup or a complete multi-world campaign.
