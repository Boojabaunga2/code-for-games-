"""Restore only Ruin Runners, retaining later unrelated catalogue changes."""
import tkinter as tk
from tkinter import filedialog,messagebox
from pathlib import Path
from START_RUIN_RUNNERS import rollback,port_open
ui=tk.Tk();ui.withdraw()
try:
 if port_open():raise RuntimeError('Close the Arcadium server console before restoring.')
 root=filedialog.askdirectory(title='Select your existing Arcadium_OS_COMPACT folder')
 if root:
  backup=filedialog.askdirectory(title='Select its arcadium_backups/ruin_runners_* folder',initialdir=str(Path(root)/'arcadium_backups'))
  if backup:rollback(root,backup);messagebox.showinfo('Restored','Only Ruin Runners was restored. Other games and later unrelated catalogue edits were preserved.')
except Exception as e:messagebox.showerror('Restore stopped',str(e))
finally:ui.destroy()
