import { COLORS } from "./engine.mjs";
import { drawMini, sceneFromDashboard } from "./render.mjs";
const q = new URLSearchParams(location.search),
  color = COLORS.includes(q.get("color")) ? q.get("color") : "red",
  base = "/arcadium-live/ruin-runners/",
  image = document.getElementById("frame"),
  status = document.getElementById("status"),
  touches = new Map();
let token = null,
  seq = 0,
  state = null,
  dashboard = null,
  lastTurn = null,
  busy = false,
  sending = false,
  stopped = false,
  mask = 0,
  queue = [],
  imageAt = 0,
  previousBoard=null,boardAt=0,drawAt=0;
async function req(path, body) {
  const c = new AbortController(),
    t = setTimeout(() => c.abort(), 1800);
  try {
    const r = await fetch(base + path, {
      cache: "no-store",
      signal: c.signal,
      ...(body
        ? {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(body),
          }
        : {}),
    });
    if (!r.ok) throw Error(String(r.status));
    return r.json();
  } finally {
    clearTimeout(t);
  }
}
function release() {
  touches.clear();
  mask = 0;
  document
    .querySelectorAll(".pressed")
    .forEach((b) => b.classList.remove("pressed"));
  queue = [];
  key("M000");
}
async function poll() {
  if (stopped || busy) return;
  busy = true;
  try {
    if (!token) {
      token = (await req("touch/session?color=" + color)).token;
      seq = 0;
      queue = [];
    }
    const d = await req("touch/state?token=" + encodeURIComponent(token));
    if (d.stale || !d.dashboard?.color) throw Error("stale");
    state = d.state;
    previousBoard=dashboard;
    dashboard = d.dashboard;
    boardAt=performance.now();
    if (lastTurn !== state.turnId) {
      lastTurn = state.turnId;
      release();
    }
    status.hidden = true;
    if (
      !document.getElementById("live").getContext("2d") && (image.complete ||
      !image.getAttribute("src") ||
      Date.now() - imageAt > 2200)
    ) {
      image.hidden=false;document.getElementById("live").hidden=true;
      imageAt = Date.now();
      image.src =
        base +
        "frame?color=" +
        color +
        "&token=" +
        encodeURIComponent(token) +
        "&t=" +
        imageAt;
    }
  } catch (e) {
    status.hidden = false;
    status.textContent = "WAITING FOR THE PC ARENA · KEEP YOUR SHARED APP";
    if (e.message === "403" || e.message === "409") token = null;
    state = dashboard = null;
    touches.clear();
    mask = 0;
    queue = [];
  } finally {
    busy = false;
    if (!stopped) setTimeout(poll, 100);
  }
}
function key(k) {
  if (!state || !token || document.hidden || queue.length > 15) return;
  queue.push({ key: k, turnId: state.turnId, at: Date.now() });
  send();
}
async function send() {
  if (sending || stopped) return;
  sending = true;
  try {
    while (queue.length && token && state) {
      const e = queue.shift();
      if (e.turnId !== state.turnId || Date.now() - e.at > 650) continue;
      try {
        await req("touch/key", {
          token,
          seq: ++seq,
          key: e.key,
          turnId: e.turnId,
        });
      } catch (err) {
        if (err.message === "403") token = null;
        queue = [];
        break;
      }
    }
  } finally {
    sending = false;
  }
}
function update() {
  mask = 0;
  for (const bit of touches.values()) mask |= 1 << bit;
  key("M" + mask.toString(16).padStart(3, "0"));
}
for (const b of document.querySelectorAll("[data-bit]")) {
  b.onpointerdown = (e) => {
    e.preventDefault();
    try {
      b.setPointerCapture(e.pointerId);
    } catch {}
    touches.set(e.pointerId, +b.dataset.bit);
    b.classList.add("pressed");
    update();
  };
  const up = (e) => {
    touches.delete(e.pointerId);
    b.classList.remove("pressed");
    update();
  };
  b.onpointerup = b.onpointercancel = b.onlostpointercapture = up;
}
for (const event of ["pointerup", "pointercancel"])
  addEventListener(event, (e) => {
    if (touches.delete(e.pointerId)) {
      for (const b of document.querySelectorAll("[data-bit]"))
        b.classList.toggle(
          "pressed",
          [...touches.values()].includes(+b.dataset.bit),
        );
      update();
    }
  });
const heartbeat = setInterval(() => {
  if (mask) update();
}, 180);
addEventListener("blur", release);
document.addEventListener("visibilitychange", () => {
  release();
  if (document.hidden) {
    state = dashboard = null;
    image.removeAttribute("src");
  }
});
addEventListener("pagehide", () => {
  if (token && state)
    navigator.sendBeacon(
      base + "touch/key",
      new Blob(
        [
          JSON.stringify({
            token,
            seq: ++seq,
            key: "M000",
            turnId: state.turnId,
          }),
        ],
        { type: "application/json" },
      ),
    );
  stopped = true;
  clearInterval(heartbeat);
});
window.RUIN_RUNNERS_VIEW = {
  get dashboard() {
    return dashboard;
  },
  get state() {
    return state;
  },
  key,
  color,
};
const canvas=document.getElementById('live'),ctx=canvas.getContext('2d');
function animate(t){
 if(ctx&&dashboard&&t-drawAt>32){drawAt=t;const d={...dashboard};
  if(previousBoard&&previousBoard.turnId===d.turnId&&!d.paused){const a=Math.min(1,(t-boardAt)/100);d.x=previousBoard.x+(d.x-previousBoard.x)*a;d.y=previousBoard.y+(d.y-previousBoard.y)*a;d.time=previousBoard.time+(d.time-previousBoard.time)*a;}
  drawMini(ctx,sceneFromDashboard(d),d.seat);
 }
 if(!stopped)requestAnimationFrame(animate);
}
requestAnimationFrame(animate);
poll();
