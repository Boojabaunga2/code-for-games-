"""Explicit, installed shared-host adapter for the existing bridge constructor."""
import importlib.util
from pathlib import Path
import sys

def _load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module

def attach(original, root):
    if getattr(original, '_arcadium_ruin_persistent', False) or getattr(original, '_arcadium_pop_persistent', False):
        return original
    folder = Path(__file__).resolve().parent
    live = _load('_arcadium_ruin_installed_live', folder / 'arcadium_live_host.py')
    native = _load('_arcadium_ruin_installed_native', folder / 'arcadium_native_routes.py')
    def upgraded(base):
        return live.wrap_live_handler(native.wrap_native_input_handler(original(base)), Path(root) / 'games')
    upgraded._arcadium_ruin_persistent = True
    return upgraded
