import { RuinGame, COLORS, HEX } from "./engine.mjs";
import { drawScene, drawMini } from "./render.mjs";
const game = new RuinGame(),
  slug = "ruin-runners",
  base = "/arcadium-live/" + slug,
  owner = crypto.randomUUID?.() || String(Date.now()),
  readers = COLORS.map(() => ArcadiumInputState.create()),
  blocked = Array(6).fill(0),
  touch = Array(6).fill(0),
  touchAt = Array(6).fill(-Infinity),
  pads = Array(6).fill(0),
  previous = Array(6).fill(0),
  surfaces = COLORS.map(() =>
    Object.assign(document.createElement("canvas"), {
      width: 720,
      height: 720,
    }),
  );
for (const c of surfaces) c.getContext("2d", { willReadFrequently: true });
const el = (id) => document.getElementById(id),
  timers = [];
let render,
  active = false,
  ever = false,
  displaced = false,
  running = true,
  error = "",
  legacyCursor = null,
  touchCursor = null,
  legacyBusy = false,
  touchBusy = false,
  publishBusy = false,
  nextSeat = 0,
  last = 0,
  lastTurn = "",
  uiKey = "",
  localMask = 0,
  native,
  selectedSeat = 0,
  stageKey = "",
  renderTime = 0,
  viewTime = 0,
  soundOn = false,
  audio = null,
  hostChecked = false,
  hostError = "",
  scoreSnapshot = Array(6).fill(0),
  inputStats = {received:0, lastAge:null}, nextFrame=0;
const fresh = (e, limit = 1000) => {
  let at = Number(e.at);
  if (at < 1e11) at *= 1000;
  return (
    Number.isFinite(at) && Date.now() - at >= -250 && Date.now() - at <= limit
  );
};
function mask(i) {
  return (
    (readers[i].read() & ~blocked[i]) |
    (Date.now() - touchAt[i] < 650 ? touch[i] : 0) |
    pads[i] |
    (i === selectedSeat ? localMask : 0)
  );
}
function clear() {
  for (let i = 0; i < 6; i++) {
    blocked[i] |= readers[i].read();
    readers[i].clear();
    touch[i] = pads[i] = previous[i] = 0;
    touchAt[i] = -Infinity;
  }
  localMask = 0;
}
async function req(path, body) {
  const c = new AbortController(),
    timer = setTimeout(() => c.abort(), 1800);
  try {
    const r = await fetch(path, {
      cache: "no-store",
      priority: body?.image ? "low" : "auto",
      signal: c.signal,
      ...(body
        ? {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(body),
          }
        : {}),
    });
    if (!r.ok) throw Error("HTTP " + r.status);
    return r.json();
  } finally {
    clearTimeout(timer);
  }
}
async function activate() {
  if (!running || displaced || document.hidden) return;
  try {
    const status=await req(base+"/status");
    if(status.protocol!==1)throw Error("Shared host unavailable");
    await req("/arcadium-vibe/activate/" + slug, { owner, renew: ever });
    active = ever = hostChecked = true;
    hostError = "";
    error = "";
  } catch (e) {
    active = false;
    hostChecked = true;
    hostError = e.message;
    error = e.message;
    if (ever) {
      game.paused = true;
      clear();
    }
    if (ever && e.message === "HTTP 409") displaced = true;
  }
}
async function poll(kind) {
  if (
    !running ||
    displaced ||
    document.hidden ||
    (kind === "touch" ? touchBusy : legacyBusy)
  )
    return;
  kind === "touch" ? (touchBusy = true) : (legacyBusy = true);
  try {
    const cursor = kind === "touch" ? touchCursor : legacyCursor,
      d = await req(
        kind === "touch"
          ? base + "/touch/events?after=" + (cursor ?? 0)
          : "/api/vibe/events?after=" + (cursor ?? 0),
      );
    if (cursor !== null && d.latest >= cursor)
      for (const e of d.events
        .filter((e) => e.seq > cursor)
        .sort((a, b) => a.seq - b.seq)) {
        const i = COLORS.indexOf(e.color);
        if (
          i < 0 ||
          !fresh(e, kind === "touch" && e.key?.startsWith("M") ? 650 : 1200)
        )
          continue;
        if (kind === "touch") {
          if (e.turnId !== game.turnId) continue;
          if (/^M[\da-f]{3}$/i.test(e.key)) {
            touch[i] = parseInt(e.key.slice(1), 16);
            touchAt[i] = Date.now();
          } else action(i, e.key);
        } else if (
          !readers[i].seen &&
          ["A", "B", "L1", "R1", "START"].includes(e.button)
        )
          action(i, e.button);
      }
    if (kind === "touch") touchCursor = d.latest;
    else legacyCursor = d.latest;
  } catch (e) {
    error = e.message;
  } finally {
    kind === "touch" ? (touchBusy = false) : (legacyBusy = false);
  }
}
async function publish(){if(!active||!running||publishBusy||displaced||document.hidden)return;publishBusy=true;
 try{const i=nextFrame++%6,c=surfaces[i];drawMini(c.getContext('2d'),game,i);await req(base+'/frame',{owner,seat:i+1,image:c.toDataURL('image/jpeg',.62).split(',')[1],state:{phase:game.phase==='practice'?'play':game.phase,paused:game.paused,turnId:game.turnId,dashboards:COLORS.map((_,n)=>game.dashboard(n))}});}catch(e){error=e.message;}finally{publishBusy=false;}
}
const canvases=[];
for(let i=0;i<6;i++){const box=document.createElement('section');box.id='lane-'+i;box.className='lane';box.style.setProperty('--c',HEX[i]);box.innerHTML=`<div class="lane-head"><strong>P${i+1} ${COLORS[i].toUpperCase()}</strong><button id="type-${i}" class="type">HUMAN</button><span class="hearts" id="hearts-${i}">♥♥♥</span><span class="treasure">◉ <b id="score-${i}">0</b></span></div><canvas width="720" height="410" aria-label="${COLORS[i]} live adventure"></canvas><div class="lane-foot"><span id="place-${i}">THE LOST VALLEY</span><b id="distance-${i}">2m</b></div>`;el('lanes').append(box);canvases.push(box.querySelector('canvas'));box.onclick=()=>{selectedSeat=i;el('pcSeat').value=String(i);};el('type-'+i).onclick=()=>{if(game.phase==='lobby')game.players[i].human=!game.players[i].human;};}
function action(i,key){if(!active||displaced||document.hidden)return false;if(game.phase!=='lobby'&&key!=='START'&&!game.players[i].human)return false;const result=game.action(i,key);if(key==='START')clear();return result;}
function zone(p){return p.finished?'IDOL RECOVERED':p.out?'OUT OF HEARTS':p.attached!==null?'A JUMP OFF · B RELEASE':p.x<9?'A · JUMP THE GAP':p.x<16?'B · GRAB THE VINE':p.x<24?'THE VINE CHASM':p.x<31?'↓ DUCK THE DARTS':p.x<41?'THE TEMPLE PILLARS':p.x<58?'A · JUMP THE BOULDER':p.x<75?'CROCODILE CROSSING':p.x<91?'THE FALLING BRIDGE':'B · TAKE THE IDOL';}
function setStage(){const key=game.turnId+':'+active+':'+hostChecked+':'+displaced;if(stageKey===key)return;stageKey=key;const lobby=game.phase==='lobby';el('stage').hidden=active&&!lobby&&game.phase!=='finished';let html='';
 if(lobby)html=`<div class="stage-card"><div class="intro"><img src="card.png" alt="Ruin Runners cover"><div><small>FIRST PLAYABLE · THE LOST VALLEY</small><h1>RUN. JUMP.<br>GRAB THE IDOL.</h1><p>Collect treasure and bring back the golden idol.<br>Six explorers. One 90-second jungle race.</p></div></div><div class="control-guide"><span><kbd>← →</kbd> MOVE</span><span><kbd>A</kbd> JUMP</span><span><kbd>B</kbd> GRAB / RELEASE</span><span><kbd>↓</kbd> DUCK</span></div><div class="setup">${COLORS.map((c,i)=>`<button id="setup-${i}" style="color:${HEX[i]};border-color:${HEX[i]}">${c.toUpperCase()}<b>HUMAN</b></button>`).join('')}</div><div class="actions"><button id="practice" class="primary">EXPLORE IN PRACTICE</button><button id="start" class="primary gold">START THE RACE →</button></div><div class="secondary"><button id="allHuman">ALL HUMAN</button><button id="demo">WATCH CPU ATTEMPTS</button><span>Practice has no time limit or lost hearts.</span></div></div>`;
 if(game.phase==='finished'){const rank=game.rank();html=`<div class="stage-card results"><small>EXPEDITION COMPLETE</small><h1 style="color:${HEX[game.winner]}">${COLORS[game.winner].toUpperCase()} WINS</h1><div class="ranking">${rank.map((p,j)=>`<div style="--c:${HEX[p.i]}"><b>${j+1}</b><strong>${p.color.toUpperCase()}</strong><span>${p.finished?'IDOL SECURED':Math.floor(p.distance)+'m EXPLORED'}</span><b>◉ ${p.score}</b></div>`).join('')}</div><button id="replay" class="primary">ANOTHER EXPEDITION →</button></div>`;}
 if(!active)html=hostChecked?`<div class="stage-card"><small>MINI VIBE HOST NOT LOADED</small><h1>LET'S CONNECT<br>YOUR EXPLORERS</h1><p>Close the Arcadium server console, extract the complete game ZIP,<br>and run <b>START_INSTALL.cmd</b>. Select your existing<br><b>Arcadium_OS_COMPACT</b> folder. The game waits here until ready.</p><button id="retry" class="primary">CHECK CONNECTION</button></div>`:`<div class="stage-card"><h1>PREPARING<br>THE EXPEDITION…</h1><p>Connecting the existing Mini Vibe host.</p></div>`;
 if(displaced)html=`<div class="stage-card"><h1>ANOTHER GAME<br>IS ACTIVE</h1><p>Return to Arcadium and choose Ruin Runners again.</p></div>`;
 el('stageContent').innerHTML=html;const bind=(id,fn)=>{if(el(id))el(id).onclick=fn;};bind('retry',activate);bind('practice',()=>{if(active){game.practice();clear();}});bind('start',()=>{if(active){game.start();clear();}});bind('allHuman',()=>game.players.forEach(p=>p.human=true));bind('demo',()=>{if(active){game.players.forEach(p=>p.human=false);game.start();clear();}});bind('replay',()=>{game.lobby();clear();});for(let i=0;i<6;i++)bind('setup-'+i,()=>game.players[i].human=!game.players[i].human);
}
function view(){setStage();el('phase').textContent=game.phase==='practice'?'PRACTICE':game.phase==='finished'?'RESULTS':'THE LOST VALLEY';el('clock').textContent=game.phase==='practice'?'∞':game.phase==='lobby'?'01:30':game.phase==='finished'?'FINISH':Math.floor(game.clock/60).toString().padStart(2,'0')+':'+Math.ceil(game.clock%60).toString().padStart(2,'0');el('connection').textContent=displaced?'ANOTHER GAME IS ACTIVE':active?'MINI VIBE HOST READY':'CONNECTING MINI VIBES';el('pause').disabled=['lobby','finished'].includes(game.phase);el('pause').textContent=game.paused?'RESUME':'PAUSE';el('pauseScreen').hidden=!game.paused||!active||displaced;el('beginMatch').hidden=game.phase!=='practice'||!active;
 for(const p of game.players){el('score-'+p.i).textContent=p.score;el('hearts-'+p.i).textContent='♥'.repeat(p.health)+'♡'.repeat(3-p.health);el('type-'+p.i).textContent=p.human?'HUMAN':'CPU';el('type-'+p.i).disabled=game.phase!=='lobby';el('place-'+p.i).textContent=zone(p);el('distance-'+p.i).textContent=Math.floor(p.distance)+'m';el('lane-'+p.i).className='lane'+(p.i===selectedSeat?' selected':'')+(p.out?' out':'');if(el('setup-'+p.i))el('setup-'+p.i).querySelector('b').textContent=p.human?'HUMAN':'CPU';}
}
function logic(time){const dt=Math.min(.05,(time-last)/1000||0);last=time;if(lastTurn!==game.turnId){lastTurn=game.turnId;clear();}const gp=navigator.getGamepads?.()||[];const masks=[];
 for(let i=0;i<6;i++){const p=gp[i];pads[i]=p?((p.axes[0]<-.3||p.buttons[14]?.pressed?4:0)|(p.axes[0]>.3||p.buttons[15]?.pressed?8:0)|(p.axes[1]>.3||p.buttons[13]?.pressed?2:0)|(p.buttons[0]?.pressed?16:0)|(p.buttons[1]?.pressed?32:0)|(p.buttons[9]?.pressed?256:0)):0;const m=mask(i),edge=m&~previous[i];masks.push(m);if(active&&!displaced)for(const[b,k]of[[16,'A'],[32,'B'],[256,'START']])if(edge&b)action(i,k);previous[i]=m;}
 if(active&&!displaced)game.update(dt,masks);if(time-viewTime>80){viewTime=time;view();}
}
render={draw:()=>canvases.forEach((c,i)=>drawScene(c.getContext('2d'),game,i,c.width,c.height))};
function frame(t){if(t-renderTime>48){renderTime=t;render.draw();}if(running)requestAnimationFrame(frame);}
function pause(){if(!['lobby','finished'].includes(game.phase)){game.paused=!game.paused;clear();}}
el('pause').onclick=el('resume').onclick=pause;el('beginMatch').onclick=()=>{if(active){game.start();clear();}};el('pcSeat').onchange=()=>{selectedSeat=+el('pcSeat').value;localMask=0;};
el('new').onclick=()=>{if(['lobby','finished'].includes(game.phase)||confirm('End this expedition and start again?')){game.lobby();clear();}};
el('help').onclick=()=>{if(!['lobby','finished'].includes(game.phase)&&!game.paused)pause();el('rules').showModal();};el('closeHelp').onclick=()=>el('rules').close();
addEventListener('keydown',e=>{if(el('rules').open)return;if(['ArrowLeft','ArrowRight','ArrowDown',' ','Enter'].includes(e.key))e.preventDefault();const bit={ArrowLeft:4,ArrowRight:8,ArrowDown:2}[e.key];if(bit){localMask|=bit;return;}if(e.repeat)return;if(/^[1-6]$/.test(e.key)){selectedSeat=+e.key-1;el('pcSeat').value=String(selectedSeat);}if(e.key===' ')action(selectedSeat,'A');if(e.key.toLowerCase()==='b')action(selectedSeat,'B');if(e.key==='Enter')action(selectedSeat,'START');if(e.key==='Escape')pause();});
addEventListener('keyup',e=>localMask&=~({ArrowLeft:4,ArrowRight:8,ArrowDown:2}[e.key]||0));
function lose(){clear();if(!['lobby','finished'].includes(game.phase))game.paused=true;}
addEventListener('blur',lose);document.addEventListener('visibilitychange',()=>{if(document.hidden)lose();else{legacyCursor=touchCursor=null;activate();}});
function exit(){if(!running)return;running=false;clear();native?.stop();timers.forEach(clearInterval);fetch('/arcadium-vibe/activate/'+slug,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({owner,active:false}),keepalive:true}).catch(()=>{});}
el('exit').onclick=e=>{e.preventDefault();exit();if(parent!==window)parent.postMessage({type:'ARCADIUM_GAME_EXIT',game:slug},'*');else location.href='/';};addEventListener('pagehide',exit);
window.RUIN_RUNNERS={game,action,mask,clear,surfaces,publish,render,exit,get active(){return active},get displaced(){return displaced},get error(){return error}};
native=ArcadiumInputState.connect({onEvent:e=>{const i=COLORS.indexOf(e.color);if(i>=0&&!displaced&&fresh(e,650)){readers[i].receive(e.button);blocked[i]&=readers[i].read();}},onReset:clear,onError:e=>{if(e)error=e;}});
await activate();await poll('legacy');await poll('touch');view();timers.push(setInterval(()=>logic(performance.now()),16),setInterval(activate,2200),setInterval(()=>poll('legacy'),45),setInterval(()=>poll('touch'),45),setInterval(publish,100));requestAnimationFrame(frame);
