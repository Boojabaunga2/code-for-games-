import {COLORS,HEX,STONE,VINES,COINS,platforms,vineAt,COURSE_END} from './engine.mjs';
const load=name=>{const i=new Image();i.src=name;return i;};
const art={background:load('jungle.png'),explorer:load('explorer.png'),atlas:load('props.png')};
const ready=i=>i.complete&&i.naturalWidth;
const backgrounds=new Map(),props=new Map(),outfits=new Map();
// Runtime scarf palette variants preserve the underlying animation sheet and skin.
function explorerFor(seat){if(!ready(art.explorer))return art.explorer;if(outfits.has(seat))return outfits.get(seat);const c=document.createElement('canvas');c.width=art.explorer.naturalWidth;c.height=art.explorer.naturalHeight;const g=c.getContext('2d',{willReadFrequently:true});g.drawImage(art.explorer,0,0);if(seat!==0){const p=g.getImageData(0,0,c.width,c.height),hex=HEX[seat].slice(1),rgb=[0,2,4].map(n=>parseInt(hex.slice(n,n+2),16));for(let k=0;k<p.data.length;k+=4){const r=p.data[k],v=p.data[k+1],b=p.data[k+2];if(p.data[k+3]>80&&r>120&&r>v*2.2&&b>v*.8){const light=r/255;p.data[k]=rgb[0]*light;p.data[k+1]=rgb[1]*light;p.data[k+2]=rgb[2]*light;}}g.putImageData(p,0,0);}outfits.set(seat,c);return c;}

function prop(k){if(props.has(k))return props.get(k);if(!ready(art.atlas))return null;
 const cells=[[0,0,.61,.5],[.61,0,.39,.5],[0,.5,.63,.5],[.63,.5,.37,.5]],cell=cells[k];
 const sw=art.atlas.naturalWidth*cell[2],sh=art.atlas.naturalHeight*cell[3],c=document.createElement('canvas');c.width=sw;c.height=sh;const g=c.getContext('2d',{willReadFrequently:true});g.drawImage(art.atlas,art.atlas.naturalWidth*cell[0],art.atlas.naturalHeight*cell[1],sw,sh,0,0,c.width,c.height);
 const d=g.getImageData(0,0,c.width,c.height).data;let x0=c.width,y0=c.height,x1=0,y1=0;for(let y=0;y<c.height;y++)for(let x=0;x<c.width;x++)if(d[(y*c.width+x)*4+3]>128){x0=Math.min(x0,x);x1=Math.max(x1,x);y0=Math.min(y0,y);y1=Math.max(y1,y);}
 const out=document.createElement('canvas');out.width=Math.max(1,x1-x0+1);out.height=Math.max(1,y1-y0+1);out.getContext('2d').drawImage(c,x0,y0,out.width,out.height,0,0,out.width,out.height);props.set(k,out);return out;
}
function backdrop(ctx,w,h,cam){if(!ready(art.background)){ctx.fillStyle='#27685e';ctx.fillRect(0,0,w,h);return;}
 const key=w+':'+h;if(!backgrounds.has(key)){const c=document.createElement('canvas');c.width=w*1.35;c.height=h;c.getContext('2d').drawImage(art.background,0,0,c.width,h);backgrounds.set(key,c);}
 const bg=backgrounds.get(key),shift=(cam*2)%(bg.width-w);ctx.drawImage(bg,-shift,0);
 const haze=ctx.createLinearGradient(0,h*.55,0,h);haze.addColorStop(0,'#062b2600');haze.addColorStop(1,'#06272bbb');ctx.fillStyle=haze;ctx.fillRect(0,0,w,h);
}
function text(ctx,s,x,y,size,color='#fff',align='center'){ctx.font=`900 ${size}px Arial`;ctx.textAlign=align;ctx.lineJoin='round';ctx.strokeStyle='#071c1edb';ctx.lineWidth=Math.max(2,size*.13);ctx.strokeText(s,x,y);ctx.fillStyle=color;ctx.fillText(s,x,y);}
export function drawScene(ctx,game,i,w,h,{personal=false}={}){
 const p=game.players[i],view=personal?12:14,scale=w/view,cam=Math.max(0,Math.min(COURSE_END-view,p.x-3.4)),base=h*.78;
 const X=x=>(x-cam)*scale,Y=y=>base-y*scale;
 ctx.clearRect(0,0,w,h);backdrop(ctx,w,h,cam);
 const solids=platforms(p,game.time),tile=prop(0),rock=prop(1),croc=prop(2),idol=prop(3);
 // Distant fireflies and drifting waterfall spray are visual only.
 for(let n=0;n<12;n++){const x=((n*87-game.time*8+cam*3)%w+w)%w,y=h*.18+Math.sin(n*2+game.time*.2)*h*.15;ctx.fillStyle='#ffe49b66';ctx.beginPath();ctx.arc(x,y,1.3,0,7);ctx.fill();}
 for(const q of solids){const x=X(q.x),y=Y(q.y),pw=q.w*scale;if(x>w+100||x+pw<-100)continue;
  if(q.bridge){ctx.save();ctx.translate(x,y);ctx.rotate(Math.sin(game.time*3+q.x)*.015);const g=ctx.createLinearGradient(0,0,0,scale*.28);g.addColorStop(0,'#cda667');g.addColorStop(.3,'#9e682f');g.addColorStop(1,'#3c291d');ctx.fillStyle=g;ctx.fillRect(0,0,pw,scale*.25);ctx.strokeStyle='#e4c58c';ctx.lineWidth=2;ctx.strokeRect(0,0,pw,scale*.25);ctx.strokeStyle='#603c20';for(let n=0;n<3;n++){ctx.beginPath();ctx.moveTo(2,scale*(.05+n*.07));ctx.lineTo(pw-2,scale*(.08+n*.06));ctx.stroke();}ctx.restore();}
  else if(q.log&&croc){ctx.drawImage(croc,x-scale*.22,y-scale*.05,pw+scale*.35,scale*.9);}
  else {ctx.fillStyle='#334639';ctx.fillRect(x,y,pw,h);if(tile){ctx.save();ctx.beginPath();ctx.rect(x,y,pw,h-y);ctx.clip();const tw=2.5*scale;for(let tx=x;tx<x+pw;tx+=tw)ctx.drawImage(tile,tx,y,tw,scale*2.3);ctx.restore();}else {const g=ctx.createLinearGradient(0,y,0,y+scale*2);g.addColorStop(0,'#83a355');g.addColorStop(.1,'#867957');g.addColorStop(1,'#253b32');ctx.fillStyle=g;ctx.fillRect(x,y,pw,h-y);}}
 }
 // Rope bridge cables and fallen planks use this player's actual bridge state.
 ctx.strokeStyle='#6b4b2d';ctx.lineWidth=scale*.065;for(const dy of [0,.6]){ctx.beginPath();ctx.moveTo(X(81.8),Y(.7+dy));ctx.quadraticCurveTo(X(86.5),Y(.2+dy),X(91.2),Y(.7+dy));ctx.stroke();}
 for(let k=0;k<7;k++){const v=p.bridge['bridge'+k];if(v>=.85&&v<2.3){ctx.save();ctx.translate(X(82+k*1.27),Y(-Math.pow(v-.85,2)*4));ctx.rotate((v-.85)*2);ctx.fillStyle='#a5773f';ctx.fillRect(0,0,scale*1.1,scale*.2);ctx.restore();}}
 // Live water underneath crocodile crossings.
 if(cam<77&&cam+view>64){ctx.fillStyle='#279caf88';ctx.fillRect(X(64.8),Y(-.65),9.8*scale,h);ctx.strokeStyle='#aff4e777';ctx.lineWidth=2;for(let row=0;row<4;row++){ctx.beginPath();for(let n=0;n<=50;n++){const xx=64.8+n*.2,yy=-.7-row*.24+Math.sin(n*.7+game.time*3+row)*.055;n?ctx.lineTo(X(xx),Y(yy)):ctx.moveTo(X(xx),Y(yy));}ctx.stroke();}}
 for(const v of VINES){if(v.x<cam-5||v.x>cam+view+5)continue;const q=vineAt(v,game.time);ctx.lineCap='round';ctx.strokeStyle='#4c3922';ctx.lineWidth=scale*.085;ctx.beginPath();ctx.moveTo(X(v.x),Y(v.y));ctx.lineTo(X(q.x),Y(q.y));ctx.stroke();ctx.strokeStyle='#c6a864';ctx.lineWidth=scale*.025;ctx.stroke();for(let k=1;k<9;k++){const t=k/10,xx=v.x+(q.x-v.x)*t,yy=v.y+(q.y-v.y)*t;ctx.fillStyle=k%2?'#4c7c37':'#86a64b';ctx.beginPath();ctx.ellipse(X(xx)+(k%2?1:-1)*scale*.06,Y(yy),scale*.11,scale*.04,k%2?-.6:.6,0,7);ctx.fill();}ctx.fillStyle='#c3a25a';ctx.beginPath();ctx.arc(X(q.x),Y(q.y),scale*.1,0,7);ctx.fill();}
 for(const c of COINS){if(p.coins.has(c.id)||c.x<cam-.5||c.x>cam+view+.5)continue;const x=X(c.x),y=Y(c.y+Math.sin(game.time*3+c.id)*.07),r=scale*.19;ctx.save();ctx.translate(x,y);ctx.scale(.55+.45*Math.abs(Math.cos(game.time*2+c.id)),1);const g=ctx.createRadialGradient(-r*.3,-r*.4,0,0,0,r);g.addColorStop(0,'#fff6b0');g.addColorStop(.5,'#ffd049');g.addColorStop(1,'#b66c09');ctx.fillStyle=g;ctx.shadowColor='#ffc744';ctx.shadowBlur=7;ctx.beginPath();ctx.arc(0,0,r,0,7);ctx.fill();ctx.shadowBlur=0;ctx.strokeStyle='#fff1a2';ctx.lineWidth=1;ctx.beginPath();ctx.arc(0,0,r*.7,0,7);ctx.stroke();ctx.restore();}
 // Dart trap is synchronized with actual collision windows.
 if(cam<32&&cam+view>27){ctx.fillStyle='#4e5437';ctx.fillRect(X(30.5),Y(2.2),scale*.65,scale*1.8);if(game.time%2.5<1.1){for(let k=0;k<3;k++){const xx=31.2-(game.time%2.5)*9-k*.8;if(xx<27.5)continue;ctx.strokeStyle='#c6b28d';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(X(xx),Y(1.0+k*.13));ctx.lineTo(X(xx+.55),Y(1.0+k*.13));ctx.stroke();ctx.fillStyle='#a8c5c2';ctx.beginPath();ctx.moveTo(X(xx-.15),Y(1.0+k*.13));ctx.lineTo(X(xx+.05),Y(1.1+k*.13));ctx.lineTo(X(xx+.05),Y(.9+k*.13));ctx.fill();}}}
 const rx=55-((game.time*3)%12);if(rx>cam-2&&rx<cam+view+2&&rock){ctx.save();ctx.translate(X(rx),Y(.83));ctx.rotate(-game.time*3.3);ctx.drawImage(rock,-scale*.9,-scale*.9,scale*1.8,scale*1.8);ctx.restore();}
 if(cam+view>95&&idol){const glow=ctx.createRadialGradient(X(98),Y(1.5),0,X(98),Y(1.5),scale*1.5);glow.addColorStop(0,'#ffdc5c66');glow.addColorStop(1,'#ffdc5c00');ctx.fillStyle=glow;ctx.fillRect(X(96),Y(3.4),scale*4,scale*4);ctx.drawImage(idol,X(97.2),Y(2.2+Math.sin(game.time*2)*.1),scale*1.5,scale*1.7);text(ctx,'B · GRAB IDOL',X(98),Y(3.2),scale*.21,'#fff6b4');}
 // Animated character poses from the real sprite sheets, not a moving mockup panel.
 const sheet=explorerFor(i);
 let frame=p.mode==='run'?Math.floor(game.time*12)%4:p.mode==='jump'?4:p.mode==='swing'?5:p.mode==='duck'?6:7;
 const sx=X(p.x),sy=Y(p.y);ctx.save();ctx.translate(sx,sy);ctx.scale(p.face,1);if(p.invincible>0&&Math.floor(game.time*14)%2)ctx.globalAlpha=.42;
 if(sheet.width>0&&(sheet instanceof HTMLCanvasElement||ready(sheet))){const cw=(sheet.naturalWidth||sheet.width)/4,ch=(sheet.naturalHeight||sheet.height)/2,size=scale*2.2;ctx.drawImage(sheet,(frame%4)*cw,Math.floor(frame/4)*ch,cw,ch,-size*.5,-size*.96,size,size);}else{ctx.fillStyle=HEX[i];ctx.fillRect(-scale*.25,-scale*1.45,scale*.5,scale*1.45);}
 ctx.restore();
 text(ctx,'P'+(i+1),sx,sy-scale*2.15,Math.max(11,scale*.23),HEX[i]);
 // Colour marker stays unambiguous even when explorers share an animation set.
 ctx.fillStyle=HEX[i];ctx.shadowColor='#061c20';ctx.shadowBlur=4;ctx.beginPath();ctx.moveTo(sx-5,sy-scale*2.08);ctx.lineTo(sx+5,sy-scale*2.08);ctx.lineTo(sx,sy-scale*1.98);ctx.fill();ctx.shadowBlur=0;
 if(p.toastTime>0)text(ctx,p.toast,w*.5,h*.12,Math.max(13,h*.045),'#fff2a4');
 if(p.finished||p.out){ctx.fillStyle='#0625229c';ctx.fillRect(0,0,w,h);text(ctx,p.finished?'IDOL RECOVERED':'OUT OF HEARTS',w*.5,h*.48,h*.09,p.finished?'#ffe69a':'#dde8ed');}
 if(game.phase==='countdown'){ctx.fillStyle='#04272844';ctx.fillRect(0,0,w,h);text(ctx,String(Math.ceil(game.clock)),w*.5,h*.55,h*.35);}
 if(game.paused){ctx.fillStyle='#031c1a88';ctx.fillRect(0,0,w,h);text(ctx,'PAUSED',w*.5,h*.5,h*.1);}
}
export function drawMini(ctx,game,i){const p=game.players[i];ctx.fillStyle='#061d1e';ctx.fillRect(0,0,720,720);ctx.fillStyle=HEX[i];ctx.fillRect(0,0,720,5);text(ctx,'RUIN RUNNERS',25,39,26,'#f6dfa2','left');text(ctx,COLORS[i].toUpperCase(),695,39,22,HEX[i],'right');text(ctx,'TREASURE '+p.score,25,77,22,'#ffe485','left');text(ctx,'♥'.repeat(p.health)+'♡'.repeat(3-p.health),695,77,26,'#ff6673','right');ctx.save();ctx.translate(0,96);drawScene(ctx,game,i,720,490,{personal:true});ctx.restore();ctx.fillStyle='#0a2c2a';ctx.fillRect(0,586,720,134);text(ctx,game.phase==='practice'?'PRACTICE':game.phase==='lobby'?'READY':game.phase==='finished'?'EXPEDITION COMPLETE':Math.ceil(game.clock)+'s LEFT',360,616,22,'#f1dca4');text(ctx,'← → MOVE    ↓ DUCK    A JUMP    B GRAB',360,651,20);}
export function sceneFromDashboard(d){const p={...d,coins:new Set(d.coins||[]),bridge:d.bridge||{},toastTime:d.toast?2:0,toast:d.toast||'',face:d.face||1,invincible:d.invincible||0};return{phase:d.phase,paused:d.paused,clock:d.clock,time:d.time,players:Array.from({length:6},(_,i)=>i===d.seat?p:null)};}
