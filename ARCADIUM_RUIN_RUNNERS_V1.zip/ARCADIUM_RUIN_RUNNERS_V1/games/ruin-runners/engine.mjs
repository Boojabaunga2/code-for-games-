export const COLORS=['red','blue','green','yellow','pink','white'];
export const HEX=['#ff4858','#33b4ff','#55df76','#ffd54e','#ff60c9','#e8f6ff'];
export const COURSE_END=100, RUN=5.4, GRAVITY=25, JUMP=10.5;
export const STONE=[{x:-3,w:12,y:0},{x:11.2,w:4.8,y:0},{x:23.2,w:7.8,y:0},{x:31.7,w:3.4,y:.7},{x:36,w:3.4,y:1.1},{x:40.4,w:14.6,y:0},{x:58,w:7,y:0},{x:74.5,w:7.5,y:0},{x:91,w:12,y:0}];
export const VINES=[{x:19.6,y:7.6,length:5.1,phase:0}];
export const CHECKPOINTS=[2,24.5,41.5,59.5,76,93];
export const COINS=Array.from({length:43},(_,i)=>{const x=3+i*2.15;let y=1.15;if(x>8&&x<12)y=2.4;if(x>15&&x<24)y=3.4;if(x>31&&x<40)y=2.9;if(x>64&&x<75)y=1.4;if(x>82)y=1.1;return{id:i,x,y};});
export function vineAt(v,t){const a=Math.sin(t*1.35+v.phase)*.82,rate=Math.cos(t*1.35+v.phase)*1.35*.82;return{x:v.x+Math.sin(a)*v.length,y:v.y-Math.cos(a)*v.length,vx:Math.cos(a)*rate*v.length,vy:Math.sin(a)*rate*v.length,angle:a};}
export function platforms(p,t){
 const list=STONE.map(q=>({...q}));
 for(let i=0;i<3;i++)list.push({x:65.3+i*3.1+Math.sin(t*.8+i)*.35,w:1.85,y:-.18,log:true});
 for(let i=0;i<7;i++){const id='bridge'+i;if((p.bridge[id]??0)<.85)list.push({x:82+i*1.27,w:1.15,y:0,bridge:id});}
 return list;
}
const approach=(a,b,s)=>a<b?Math.min(a+s,b):Math.max(a-s,b);
export class RuinGame{
 constructor(){this.serial=0;this.lobby();}
 setPhase(phase,clock=0){this.phase=phase;this.clock=clock;this.turnId=`${++this.serial}:${phase}`;}
 freshPlayer(i,human=true){return{i,color:COLORS[i],human,x:2,y:0,vx:0,vy:0,face:1,grounded:true,crouch:false,mode:'idle',health:3,score:0,coins:new Set(),bridge:{},checkpoint:2,invincible:0,toast:'',toastTime:0,attached:null,lastGrab:-10,finished:false,out:false,finishTime:Infinity,distance:2,jumpBuffer:0,coyote:.12,cpuHold:i*.2,cpuLand:null};}
 lobby(){this.players=COLORS.map((_,i)=>this.freshPlayer(i));this.paused=false;this.time=0;this.elapsed=0;this.winner=null;this.setPhase('lobby');}
 reset(phase){const types=this.players.map(p=>p.human);this.players=types.map((h,i)=>this.freshPlayer(i,h));this.time=0;this.elapsed=0;this.paused=false;this.winner=null;this.setPhase(phase,phase==='countdown'?3:0);}
 practice(){if(this.phase!=='lobby')return false;this.reset('practice');return true;}
 start(){if(!['lobby','practice'].includes(this.phase))return false;this.reset('countdown');return true;}
 join(i){if(this.phase==='lobby')this.players[i].human=true;}
 canMove(i){const p=this.players[i];return['play','practice'].includes(this.phase)&&!this.paused&&p&&!p.out&&!p.finished;}
 action(i,key){const p=this.players[i];if(!p)return false;if(this.phase==='lobby'){if(key==='A'){this.join(i);return true;}if(key==='START')return this.start();return false;}if(key==='START'&&p.human&&this.phase!=='finished'){this.paused=!this.paused;return true;}if(!p.human||!this.canMove(i))return false;if(key==='A'){p.jumpBuffer=.13;return true;}if(key==='B')return this.grab(i);return false;}
 grab(i){const p=this.players[i];if(!this.canMove(i))return false;if(p.attached!==null){this.detach(p);return true;}if(p.x>96){p.score+=100+p.health*10;p.finished=true;p.finishTime=this.elapsed;p.mode='celebrate';this.message(p,'IDOL RECOVERED!');return true;}if(this.time-p.lastGrab<.25)return false;
  let best=null,d=2.2;VINES.forEach((v,k)=>{const q=vineAt(v,this.time),dist=Math.hypot(p.x-q.x,p.y+1.25-q.y);if(dist<d){d=dist;best=k;}});
  if(best!==null){p.attached=best;p.grounded=false;p.mode='swing';p.lastGrab=this.time;p.cpuLand=null;this.message(p,'A JUMP OFF · B RELEASE');return true;}this.message(p,'JUMP TOWARD A VINE · THEN B');return false;
 }
 detach(p,jump=false){const q=vineAt(VINES[p.attached],this.time);p.attached=null;p.vx=q.vx+(jump?p.face*2:0);p.vy=q.vy+(jump?5:0);p.lastGrab=this.time;p.jumpBuffer=0;p.mode='jump';}
 message(p,text){p.toast=text;p.toastTime=2.2;}
 hurt(p,why){if(p.invincible>0||p.finished||p.out)return false;if(this.phase!=='practice')p.health--;p.attached=null;p.cpuLand=null;p.invincible=1.8;p.x=p.checkpoint;p.y=.2;p.vx=p.vy=0;p.grounded=false;p.jumpBuffer=0;if(p.health<=0){p.health=0;p.out=true;p.mode='out';this.message(p,'OUT OF HEARTS');}else this.message(p,why+' · CHECKPOINT');return true;}
 cpuMask(p){if(!this.canMove(p.i)||p.cpuHold>0)return 0;if(p.attached!==null){const q=vineAt(VINES[p.attached],this.time);if(q.x>22.2&&q.vx>0)p.jumpBuffer=.1;return 8;}
  if(p.x>96){this.grab(p.i);return 0;}const ground=platforms(p,this.time),ahead=p.x+.85;const next=ground.find(q=>ahead>=q.x&&ahead<q.x+q.w);
  if(p.grounded)p.cpuLand=null;
  if(p.grounded&&(!next||next.y>p.y+.2)){p.jumpBuffer=.1;const dest=ground.filter(q=>q.x>p.x+.4).sort((a,b)=>a.x-b.x)[0];if(dest)p.cpuLand=dest.x+Math.min(dest.w*.5,2);}
  if(!p.grounded&&p.cpuLand!==null&&p.x>p.cpuLand-.68)return 0;
  if(p.x>14.5&&p.x<23.2){if(p.grounded)p.jumpBuffer=.1;if(p.attached===null&&this.time-p.lastGrab>.3)this.grab(p.i);}
  const rock=55-((this.time*3)%12);if(p.grounded&&p.x>42&&p.x<55&&rock-p.x>0&&rock-p.x<3.2)p.jumpBuffer=.1;
  return 8|(p.x>27&&p.x<30?2:0);
 }
 update(dt,masks=[]){if(this.paused||['lobby','finished'].includes(this.phase))return;dt=Math.max(0,Math.min(.1,dt));if(this.phase==='countdown'){this.clock=Math.max(0,this.clock-dt);if(this.clock===0)this.setPhase('play',90);return;}
  for(let left=dt;left>1e-8;){const step=Math.min(left,1/120);this.step(step,masks);left-=step;}
 }
 step(dt,masks){this.time+=dt;this.elapsed+=dt;if(this.phase==='play')this.clock=Math.max(0,this.clock-dt);
  for(const p of this.players){p.invincible=Math.max(0,p.invincible-dt);p.toastTime=Math.max(0,p.toastTime-dt);p.cpuHold=Math.max(0,p.cpuHold-dt);if(!this.canMove(p.i))continue;const mask=p.human?(masks[p.i]||0):this.cpuMask(p),dir=Number(!!(mask&8))-Number(!!(mask&4));if(dir)p.face=dir;p.crouch=!!(mask&2)&&p.grounded;p.jumpBuffer=Math.max(0,p.jumpBuffer-dt);p.coyote=p.grounded?.12:Math.max(0,p.coyote-dt);
   if(p.attached!==null){if(p.jumpBuffer>0){this.detach(p,true);}else{const q=vineAt(VINES[p.attached],this.time);p.x=q.x;p.y=q.y-1.95;p.vx=q.vx;p.vy=q.vy;p.mode='swing';p.distance=Math.max(p.distance,p.x);this.pickup(p);continue;}}
   if(p.jumpBuffer>0&&p.coyote>0&&!p.crouch){p.vy=JUMP;p.grounded=false;p.coyote=0;p.jumpBuffer=0;}
   p.vx=p.grounded?dir*RUN*(p.crouch?.45:1):approach(p.vx,dir*RUN,dt*18);
   const oldX=p.x,oldY=p.y;p.vy-=GRAVITY*dt;p.x=Math.max(-1,Math.min(COURSE_END,p.x+p.vx*dt));p.y+=p.vy*dt;p.grounded=false;
   let landing=null;const solids=platforms(p,this.time),height=p.crouch?.72:1.45;
   for(const q of solids){if(p.x+.27<q.x||p.x-.27>q.x+q.w)continue;if(p.vy<=0&&oldY>=q.y-.03&&p.y<=q.y){if(!landing||q.y>landing.y)landing=q;}
    else if(p.y<q.y-.12&&p.y+height>q.y-.7){if(oldX+.27<=q.x&&p.vx>0){p.x=q.x-.28;p.vx=0;}else if(oldX-.27>=q.x+q.w&&p.vx<0){p.x=q.x+q.w+.28;p.vx=0;}}
   }
   if(landing){p.y=landing.y;p.vy=0;p.grounded=true;if(landing.bridge)p.bridge[landing.bridge]=(p.bridge[landing.bridge]||0)+dt;}
   for(const id of Object.keys(p.bridge))if(p.bridge[id]>.01&&p.bridge[id]<1)p.bridge[id]+=dt*.25;
   p.mode=p.crouch?'duck':!p.grounded?'jump':Math.abs(p.vx)>.1?'run':'idle';p.distance=Math.max(p.distance,p.x);
   if(p.grounded)for(const x of CHECKPOINTS)if(p.x>=x&&x>p.checkpoint){p.checkpoint=x;this.message(p,'CHECKPOINT REACHED');}
   this.pickup(p);
   if(p.y<-5){this.hurt(p,'FELL INTO THE PIT');continue;}
   if(p.x>27.8&&p.x<30&&((this.time%2.5)<1.1)&&!p.crouch&&p.y<1.35)this.hurt(p,'DART TRAP · HOLD DOWN TO DUCK');
   const rock=55-((this.time*3)%12);if(p.x>42&&p.x<55&&Math.abs(p.x-rock)<.8&&p.y<1.65)this.hurt(p,'BOULDER · JUMP OVER IT');
   if(p.x>96&&p.grounded&&p.toastTime===0)this.message(p,'B · GRAB THE GOLDEN IDOL');
  }
  if(this.phase==='play'&&(this.clock===0||this.players.every(p=>p.finished||p.out))){this.winner=this.rank()[0].i;this.setPhase('finished');}
 }
 pickup(p){for(const c of COINS)if(!p.coins.has(c.id)&&Math.hypot(p.x-c.x,p.y+.8-c.y)<.85){p.coins.add(c.id);p.score+=10;}}
 rank(){return [...this.players].sort((a,b)=>b.score-a.score||a.finishTime-b.finishTime||b.distance-a.distance||a.i-b.i);}
 dashboard(i){const p=this.players[i];return{seat:i,color:p.color,phase:this.phase,turnId:this.turnId,paused:this.paused,clock:this.clock,score:p.score,health:p.health,x:p.x,y:p.y,mode:p.mode,checkpoint:p.checkpoint,finished:p.finished,out:p.out,winner:this.winner,toast:p.toastTime>0?p.toast:'',time:this.time,vx:p.vx,vy:p.vy,face:p.face,coins:[...p.coins],bridge:{...p.bridge},attached:p.attached,invincible:p.invincible};}
}
