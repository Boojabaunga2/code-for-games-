# Credits

Original Ruin Runners playable prototype for Arcadium, based on the approved owner-supplied jungle-platform concept and animated-family-adventure art direction.

Original generated assets: jungle valley panorama, eight-pose explorer sprite sheet, four-prop atlas, transparent title logo, square cover. Generated with OpenAI image generation for this build. Runtime scarf palette variants identify six seats while preserving the same underlying explorer animation. No film/game franchise characters or affiliation are asserted.

Game physics, course, rendering, animation selection, collisions, controls and UI source are included. Shared native-input.js and generic live/native broker modules reuse the existing Arcadium implementation. No new APK, physical hardware feedback, Home Vibe Android integration or physical-device acceptance is claimed.
