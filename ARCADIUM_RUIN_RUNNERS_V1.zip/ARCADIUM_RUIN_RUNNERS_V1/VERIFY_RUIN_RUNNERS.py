"""Read-only HTTP verification against the running 8787 process."""
import json,urllib.request
BASE='http://127.0.0.1:8787'
def get(path):
 with urllib.request.urlopen(BASE+path,timeout=5) as r:return r.status,r.read()
def main():
 for path in ['/games/ruin-runners/index.html','/games/ruin-runners/engine.mjs','/games/ruin-runners/render.mjs','/games/ruin-runners/vibe.html','/games/ruin-runners/card.png','/games/ruin-runners/explorer.png','/games/ruin-runners/logo.png','/games/ruin-runners/jungle.png','/games/ruin-runners/props.png','/api/vibe/native-events?after=0']:
  status,data=get(path);print(status,path,len(data),'bytes')
 status,data=get('/arcadium-live/ruin-runners/status');state=json.loads(data);assert state['protocol']==1;print('Shared live host:',state)
 if state.get('active'):
  for color in ['red','blue','green','yellow','pink','white']:
   _,data=get('/api/vibe/mode?color='+color);mode=json.loads(data);assert mode['game']=='ruin-runners' and mode['mode']=='web-game';print(color,'->',mode['page'])
 else:print('Open Ruin Runners from the Games catalogue, then rerun to check six-seat handoff.')
 print('HTTP routes passed. This does not verify physical Mini Vibe controls, Windows graphics, or antivirus acceptance.')
if __name__=='__main__':
 try:main()
 except Exception as e:print('VERIFICATION FAILED:',e)
 input('Press Enter to close...')
