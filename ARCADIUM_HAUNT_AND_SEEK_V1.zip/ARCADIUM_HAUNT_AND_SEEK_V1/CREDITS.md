# Credits

Haunt & Seek game code, castle geometry, capture and captain mechanics, UI, audio synthesis, shared-input adapter, live-game host and non-patching launcher were created for this request.

Original character/prop atlas, nine-room environment atlas, cover artwork and the concept mockup were generated for the game. The playable renderer uses the asset atlases with actual game geometry and simulation state; the concept mockup is not rendered as a gameplay screenshot. Castle art is 2.5D isometric sprite art, not a full 3D physics engine.

The existing Arcadium native-input.js reader is reused byte-for-byte. Python uses the standard library and the user's existing Arcadium installation. No third-party web runtime, network asset CDN, game-specific Android app or downloaded installer is required during play.
