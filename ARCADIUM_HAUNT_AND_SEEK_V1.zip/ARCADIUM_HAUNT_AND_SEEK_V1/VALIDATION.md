# Validation

Engine: node integrations/haunt-and-seek/tests/engine.test.mjs

Covers five distinct connected nine-room layouts, held movement/release, walls and doors, held/ranged captures, exactly one reward per ghost, rare values, decoys, all captain powers/energy/cooldowns, pause freezing, elimination, disclosed exact-tie handling and a natural five-round bot match ending with one hunter and five captains.

Python: python -m unittest discover -s integrations/haunt-and-seek/tests -p 'test_*.py'

Checks exact package checksums, registration/repeat/backups/corruption refusal, unchanged existing OS/bridge/native input/pairing/other games, shared host lease ownership, six private views, descriptor restrictions, scoped touch tokens, stale/replayed action rejection, stale images, unchanged-frame responses and handoff to previous games. The host only reads game descriptor data and does not execute server code from game folders.

Browser: tests/harness.py uses the exact inspected native receiver behind the existing route chain and the new generic host. tests/browser.cjs uses real Chromium, six synthetic color inputs, capture locks, held movement/release/expiry, Captain role/powers, local touch movement/capture, actual personal JPEG pages, pause, all five castle renders, final replay and offline assets. Tests use synthetic packets, not physical device evidence.

Windows: the exact ZIP and extracted files are checked by enabled cloud Defender and Internet attachment Save, including a positive-control detection in runner temp only. Every distributed script is checked individually. A clean run is not a manual Microsoft verdict or proof that a recipient alert is false. No exclusions or protection disabling are part of this software.

Limitations: real Mini Vibes, physical buttons, six-device Wi-Fi throughput, recipient Windows antivirus acceptance and the user's complete OS installation still require physical acceptance. Existing OS runs through the included launcher to load the additional broker in memory. Original startup shortcuts are not changed.
