import { HuntGame, COLORS, HEX } from "./engine.mjs";
import { Renderer, buttons } from "./render.mjs";
const game = new HuntGame(),
  canvas = document.querySelector("#world"),
  g = canvas.getContext("2d"),
  atlas = new Image();
atlas.src = "assets/atlas.png";
await atlas.decode();
const roomsAtlas = new Image();
roomsAtlas.src = "assets/rooms.png";
await roomsAtlas.decode();
const renderer = new Renderer(atlas, roomsAtlas),
  slug = "haunt-and-seek",
  base = "/arcadium-live/" + slug,
  owner = crypto.randomUUID?.() || Date.now().toString(36),
  readers = COLORS.map(() => ArcadiumInputState.create()),
  touch = Array(6).fill(0),
  touchAt = Array(6).fill(-Infinity),
  nativeAt = Array(6).fill(-Infinity),
  padMasks = Array(6).fill(0),
  padPrevious = Array(6).fill(0),
  surfaces = COLORS.map(() =>
    Object.assign(document.createElement("canvas"), {
      width: 720,
      height: 720,
    }),
  );
let running = true,
  active = false,
  native = null,
  legacyCursor = null,
  touchCursor = null,
  legacyBusy = false,
  touchBusy = false,
  publishBusy = false,
  nextSeat = 0,
  prevStage = "",
  last = 0,
  uiPhase = "",
  displaced = false,
  everActive = false,
  sound = true,
  audio = null,
  eventSeen = 0,
  eventSerial = 0;
const keys = {},
  timers = [],
  diag = {
    nativeSeq: 0,
    actionSeq: 0,
    touchSeq: 0,
    frames: 0,
    error: "",
    host: false,
  };
function stampedAt(e) {
  const n = Number(e.at);
  return Number.isFinite(n) && n > 1e8 ? (n < 1e11 ? n * 1000 : n) : Date.now();
}
function fresh(e, limit) {
  const age = Date.now() - stampedAt(e);
  return age >= -250 && age <= limit;
}
function stage() {
  return game.epoch + ":" + game.round + ":" + game.phase;
}
function clear() {
  readers.forEach((r) => r.clear());
  touch.fill(0);
  touchAt.fill(-Infinity);
  nativeAt.fill(-Infinity);
  padMasks.fill(0);
  for (const k in keys) keys[k] = false;
}
function mask(i) {
  return (
    (Date.now() - nativeAt[i] <= 650 ? readers[i].read() : 0) |
    (Date.now() - touchAt[i] <= 650 ? touch[i] : 0) |
    padMasks[i]
  );
}
function beep(f = 600, d = 0.08) {
  if (!sound) return;
  try {
    audio ||= new (window.AudioContext || window.webkitAudioContext)();
    if (audio.state === "suspended") audio.resume();
    const o = audio.createOscillator(),
      v = audio.createGain();
    o.type = "sine";
    o.frequency.setValueAtTime(f, audio.currentTime);
    o.frequency.exponentialRampToValueAtTime(f * 0.6, audio.currentTime + d);
    v.gain.setValueAtTime(0.035, audio.currentTime);
    v.gain.exponentialRampToValueAtTime(0.001, audio.currentTime + d);
    o.connect(v).connect(audio.destination);
    o.start();
    o.stop(audio.currentTime + d);
  } catch {}
}
function button(i, k) {
  if (i < 0 || i > 5 || document.hidden || displaced) return;
  const p = game.players[i];
  if (game.phase === "lobby") {
    if (k === "START" && p.human) {
      game.start();
      clear();
    } else if (k === "A" || k === "START") {
      game.ready(i);
      seats();
      beep(600 + i * 80);
    }
    return;
  }
  if (game.phase === "finished") {
    if (k === "START" || k === "A") {
      game.lobby();
      clear();
      seats();
    }
    return;
  }
  if (!p.human) return;
  if (k === "START") {
    if (game.phase === "results" && game.phaseTime >= 3) {
      game.phaseTime = 8;
      return;
    }
    game.togglePause();
    clear();
    return;
  }
  if (game.paused) return;
  if (p.role === "captain") {
    if (k === "A") game.cast(i);
    if (k === "L1") game.selectPower(i, -1);
    if (k === "R1") game.selectPower(i, 1);
    if (k === "B") game.cycleVictim(i);
  } else if (k === "B") game.pulse(i);
}
function controls() {
  return COLORS.map((_, i) => {
    let m = mask(i);
    if (i === 0) {
      if (keys.KeyW || keys.ArrowUp) m |= 1;
      if (keys.KeyS || keys.ArrowDown) m |= 2;
      if (keys.KeyA || keys.ArrowLeft) m |= 4;
      if (keys.KeyD || keys.ArrowRight) m |= 8;
      if (keys.Space) m |= 16;
    }
    const sx = (m & 8 ? 1 : 0) - (m & 4 ? 1 : 0),
      sy = (m & 2 ? 1 : 0) - (m & 1 ? 1 : 0);
    return {
      x: (sx + sy) / Math.SQRT2,
      y: (sy - sx) / Math.SQRT2,
      a: !!(m & 16),
    };
  });
}
function pads() {
  for (let i = 0; i < 6; i++) {
    const p = navigator.getGamepads?.()[i];
    if (!p) {
      padMasks[i] = padPrevious[i] = 0;
      continue;
    }
    padMasks[i] =
      (p.axes[0] < -0.3 || p.buttons[14]?.pressed ? 4 : 0) |
      (p.axes[0] > 0.3 || p.buttons[15]?.pressed ? 8 : 0) |
      (p.axes[1] < -0.3 || p.buttons[12]?.pressed ? 1 : 0) |
      (p.axes[1] > 0.3 || p.buttons[13]?.pressed ? 2 : 0) |
      (p.buttons[0]?.pressed ? 16 : 0);
    let bits = 0;
    for (const [n, k] of [
      [0, "A"],
      [1, "B"],
      [4, "L1"],
      [5, "R1"],
      [9, "START"],
    ])
      if (p.buttons[n]?.pressed) {
        bits |= 1 << n;
        if (!(padPrevious[i] & (1 << n))) button(i, k);
      }
    padPrevious[i] = bits;
  }
}
function seats() {
  const el = document.querySelector("#seats");
  el.innerHTML = game.players
    .map(
      (p) =>
        '<button style="--c:' +
        HEX[p.i] +
        '" data-seat="' +
        p.i +
        '"><canvas width="100" height="100"></canvas><div><b>P' +
        (p.i + 1) +
        " " +
        COLORS[p.i].toUpperCase() +
        "</b><span>" +
        (p.human ? "HUMAN / READY" : "CPU HUNTER") +
        "</span></div></button>",
    )
    .join("");
  for (const b of el.children) {
    const i = +b.dataset.seat;
    renderer.sprite(b.querySelector("canvas").getContext("2d"), i, 50, 96, 100);
    b.onclick = () => {
      if (game.phase === "lobby") {
        game.players[i].human = !game.players[i].human;
        seats();
      }
    };
  }
}
function ui() {
  const s = game.phase;
  document.querySelector("#lobby").hidden = s !== "lobby";
  document.querySelector("#results").hidden = !["results", "finished"].includes(
    s,
  );
  if (s !== uiPhase) {
    uiPhase = s;
    if (s === "lobby") seats();
    if (["results", "finished"].includes(s)) {
      const winner = game.players[game.winner],
        loser = game.players[game.roundResult.loser];
      document.querySelector("#resultLabel").textContent =
        s === "finished"
          ? "FIVE CASTLES / ONE LAST HUNTER"
          : "CASTLE " + (game.round + 1) + " COMPLETE";
      document.querySelector("#resultTitle").textContent =
        s === "finished"
          ? COLORS[winner.i].toUpperCase() + " IS THE CHAMPION"
          : COLORS[loser.i].toUpperCase() + " IS A GHOST CAPTAIN";
      document.querySelector("#resultTitle").style.color =
        s === "finished" ? HEX[winner.i] : HEX[loser.i];
      document.querySelector("#resultSub").textContent =
        s === "finished"
          ? "Every eliminated hunter stayed in the game as a captain."
          : game.roundResult.curseDraw
            ? "Exact score/capture tie: the Castle Curse draw chose this round’s captain."
            : "Lowest round score joins the haunting crew. Surviving hunters enter the next castle.";
      const list =
        s === "finished"
          ? [...game.players].sort(
              (a, b) =>
                (a.i === game.winner ? 1 : 6 - a.eliminatedRound) -
                (b.i === game.winner ? 1 : 6 - b.eliminatedRound),
            )
          : game.roundResult.standings.map((v) => game.players[v.i]);
      document.querySelector("#standings").innerHTML = list
        .map(
          (p) =>
            '<div class="standing" style="--c:' +
            HEX[p.i] +
            '"><b>P' +
            (p.i + 1) +
            " " +
            COLORS[p.i].toUpperCase() +
            "</b><span>" +
            p.score +
            " ROUND PTS / " +
            p.total +
            " TOTAL / " +
            (p.role === "captain" ? "GHOST CAPTAIN" : "HUNTER") +
            "</span></div>",
        )
        .join("");
    }
  }
  document.querySelector("#pause").textContent = game.paused
    ? "RESUME"
    : "PAUSE";
  document.querySelector("#next").hidden = s === "finished";
  document.querySelector("#next").disabled = game.phaseTime < 3;
  document.querySelector("#next").textContent =
    "NEXT CASTLE / " + Math.max(0, Math.ceil(8 - game.phaseTime)) + "s";
  document.querySelector("#link").textContent = diag.error
    ? "MINI VIBE: " + diag.error
    : diag.host
      ? "SHARED INPUT / SIX TRACKERS / " + diag.frames + " FRAMES"
      : "PC PLAY / SHARED HOST NOT CONNECTED";
}
function frame(t) {
  const dt = Math.min(0.05, (t - last) / 1000 || 0);
  last = t;
  if (
    document.hidden &&
    ["play", "countdown"].includes(game.phase) &&
    !game.paused
  ) {
    game.togglePause();
    clear();
  }
  pads();
  if (stage() !== prevStage) {
    prevStage = stage();
    clear();
  }
  game.update(dt, controls());
  renderer.main(g, game);
  ui();
  if (game.events.length && game.events[game.events.length - 1] !== eventSeen) {
    const e = game.events[game.events.length - 1];
    eventSeen = e;
    if (e.type === "capture") beep(e.value === 250 ? 1100 : 790, 0.12);
    if (e.type === "haunt") beep(240, 0.14);
    if (e.type === "elimination") beep(170, 0.25);
    if (e.type === "winner") beep(1318, 0.35);
  }
  if (running) requestAnimationFrame(frame);
}
async function req(path, options = {}, timeout = 1800) {
  const c = new AbortController(),
    timer = setTimeout(() => c.abort(), timeout);
  try {
    const r = await fetch(path, {
      cache: "no-store",
      ...options,
      signal: c.signal,
    });
    if (!r.ok) throw Error("HTTP " + r.status);
    return r;
  } finally {
    clearTimeout(timer);
  }
}
async function activate() {
  if (!running || document.hidden || displaced) return;
  try {
    await req("/arcadium-vibe/activate/" + slug, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ owner, renew: active }),
    });
    active = true;
    everActive = true;
    diag.host = true;
    diag.error = "";
  } catch (e) {
    active = false;
    diag.host = false;
    if (e.message === "HTTP 409" && everActive) {
      displaced = true;
      clear();
      if (["play", "countdown"].includes(game.phase) && !game.paused)
        game.togglePause();
    }
    diag.error = displaced
      ? "ANOTHER GAME IS ACTIVE / REOPEN HAUNT & SEEK"
      : e.message === "HTTP 404"
        ? "START USING THE INCLUDED SHARED-HOST LAUNCHER"
        : e.message;
  }
}
async function pollLegacy() {
  if (!running || legacyBusy || document.hidden) return;
  legacyBusy = true;
  try {
    const d = await (
      await req("/api/vibe/events?after=" + (legacyCursor ?? 0))
    ).json();
    if (!Number.isSafeInteger(d.latest) || !Array.isArray(d.events))
      throw Error("Input stream");
    if (legacyCursor === null || d.latest < legacyCursor)
      legacyCursor = d.latest;
    else {
      for (const e of d.events.slice().sort((a, b) => a.seq - b.seq))
        if (e.seq > legacyCursor) {
          if (
            fresh(e, 1500) &&
            ["A", "B", "START", "L1", "R1"].includes(e.button)
          )
            button(COLORS.indexOf(String(e.color).toLowerCase()), e.button);
          legacyCursor = e.seq;
        }
      legacyCursor = Math.max(legacyCursor, d.latest);
    }
    diag.actionSeq = legacyCursor;
  } catch (e) {
    diag.error = e.message;
  } finally {
    legacyBusy = false;
  }
}
async function pollTouch() {
  if (!running || touchBusy || !active || document.hidden) return;
  touchBusy = true;
  try {
    const d = await (
      await req(base + "/touch/events?after=" + (touchCursor ?? 0))
    ).json();
    if (!Number.isSafeInteger(d.latest) || !Array.isArray(d.events))
      throw Error("Touch stream");
    if (touchCursor === null || d.latest < touchCursor) touchCursor = d.latest;
    else {
      for (const e of d.events)
        if (e.seq > touchCursor) {
          const i = COLORS.indexOf(e.color);
          if (
            i >= 0 &&
            e.turnId === stage() &&
            fresh(e, e.key.startsWith("M") ? 650 : 1500)
          ) {
            if (/^M[0-9a-f]{3}$/i.test(e.key)) {
              touch[i] = parseInt(e.key.slice(1), 16);
              touchAt[i] = stampedAt(e);
            } else button(i, e.key);
          }
          touchCursor = e.seq;
        }
      touchCursor = Math.max(touchCursor, d.latest);
    }
    diag.touchSeq = touchCursor;
  } catch (e) {
    diag.error = e.message;
  } finally {
    touchBusy = false;
  }
}
async function publish() {
  if (!running || publishBusy || !active || document.hidden) return;
  publishBusy = true;
  try {
    const i = nextSeat++ % 6,
      c = surfaces[i];
    renderer.mini(c.getContext("2d"), game, i);
    await req(base + "/frame", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        owner,
        seat: i + 1,
        image: c.toDataURL("image/jpeg", 0.8).split(",")[1],
        state: {
          phase: game.phase,
          paused: game.paused,
          turnId: stage(),
          dashboards: COLORS.map((_, i) => game.dashboard(i)),
        },
      }),
    });
    diag.frames++;
  } catch (e) {
    diag.error = e.message;
  } finally {
    publishBusy = false;
  }
}
function exit() {
  if (!running) return;
  running = false;
  clear();
  native?.stop();
  timers.forEach(clearInterval);
  if (location.port === "8787")
    fetch("/arcadium-vibe/activate/" + slug, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ owner, active: false }),
      keepalive: true,
    }).catch(() => {});
}
document.querySelector("#launch").onclick = () => {
  beep(620, 0.2);
  game.start();
  clear();
};
document.querySelector("#allHuman").onclick = () => {
  game.players.forEach((p) => (p.human = true));
  seats();
};
document.querySelector("#next").onclick = () => {
  if (game.phase === "results" && game.phaseTime >= 3) game.phaseTime = 8;
};
document.querySelector("#replay").onclick = () => {
  game.lobby();
  clear();
};
document.querySelector("#pause").onclick = () => {
  game.togglePause();
  clear();
};
document.querySelector("#sound").onclick = (e) => {
  sound = !sound;
  e.target.textContent = sound ? "SOUND ON" : "SOUND OFF";
  if (sound) beep();
};
document.querySelector("#help").onclick = () => {
  if (["play", "countdown"].includes(game.phase) && !game.paused)
    game.togglePause();
  clear();
  document.querySelector("#helpPanel").hidden = false;
};
document.querySelector("#closeHelp").onclick = () =>
  (document.querySelector("#helpPanel").hidden = true);
document.querySelector("#exit").onclick = () => {
  exit();
  if (parent !== window) {
    parent.postMessage({ type: "ARCADIUM_GAME_EXIT", game: slug }, "*");
    parent.postMessage({ type: "arcadium:exit", game: slug }, "*");
  } else location.href = "/";
};
addEventListener("keydown", (e) => {
  if (
    [
      "Space",
      "ArrowUp",
      "ArrowDown",
      "ArrowLeft",
      "ArrowRight",
      "Enter",
    ].includes(e.code)
  )
    e.preventDefault();
  keys[e.code] = true;
  if (e.repeat) return;
  if (e.code === "Space") button(0, "A");
  if (e.code === "KeyE") button(0, "B");
  if (e.code === "KeyQ") button(0, "L1");
  if (e.code === "KeyR") button(0, "R1");
  if (e.code === "Enter") {
    if (game.phase === "lobby") game.start();
    else button(0, "START");
  }
  if (e.code === "Escape") {
    game.togglePause();
    clear();
  }
});
addEventListener("keyup", (e) => (keys[e.code] = false));
addEventListener("blur", () => {
  clear();
  if (["play", "countdown"].includes(game.phase) && !game.paused)
    game.togglePause();
});
document.addEventListener("visibilitychange", () => {
  clear();
  if (!document.hidden) {
    legacyCursor = touchCursor = null;
    activate();
  }
});
addEventListener("pagehide", exit);
window.HAUNT = {
  game,
  renderer,
  surfaces,
  diag,
  buttons,
  stage,
  mask,
  button,
  clear,
  exit,
  publish,
};
seats();
requestAnimationFrame(frame);
if (location.port === "8787") {
  native = ArcadiumInputState.connect({
    onEvent: (e) => {
      const i = COLORS.indexOf(String(e.color).toLowerCase());
      if (i >= 0 && !displaced && fresh(e, 650)) {
        readers[i].receive(e.button);
        nativeAt[i] = stampedAt(e);
      }
    },
    onReset: clear,
    onCursor: (n) => (diag.nativeSeq = n),
    onError: (e) => {
      if (e) diag.error = e;
    },
  });
  await activate();
  await pollLegacy();
  await pollTouch();
  timers.push(
    setInterval(activate, 2500),
    setInterval(pollLegacy, 35),
    setInterval(pollTouch, 35),
    setInterval(publish, 20),
  );
}
