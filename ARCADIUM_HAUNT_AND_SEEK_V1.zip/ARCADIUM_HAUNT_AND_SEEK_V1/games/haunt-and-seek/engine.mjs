export const COLORS = ["red", "blue", "green", "yellow", "pink", "white"];
export const HEX = [
  "#ff435f",
  "#35aaff",
  "#60ee87",
  "#ffdb60",
  "#f763cd",
  "#eaf5ff",
];
export const POWERS = [
  {
    id: "DECOY",
    cost: 15,
    cooldown: 3.5,
    help: "Plant a false ghost signal in your room.",
  },
  {
    id: "DOOR SLAM",
    cost: 25,
    cooldown: 7,
    help: "Seal a clear doorway for eight seconds.",
  },
  {
    id: "JAM TRACKER",
    cost: 30,
    cooldown: 8,
    help: "Scramble your selected hunter for six seconds.",
  },
];
export const CASTLES = [
  {
    name: "Moonveil Manor",
    sub: "The first haunting",
    floor: "#352d52",
    wall: "#51416d",
    accent: "#ae8cff",
    rooms: [
      "Library",
      "Moon Gallery",
      "Bell Tower",
      "West Stairs",
      "Great Hall",
      "Dining Room",
      "Crypt",
      "Conservatory",
      "Royal Vault",
    ],
    extra: [
      [0, 3],
      [1, 4],
      [2, 5],
      [3, 6],
      [4, 7],
      [5, 8],
    ],
  },
  {
    name: "Briarwatch Keep",
    sub: "Whispers in the ivy",
    floor: "#213d3c",
    wall: "#365b52",
    accent: "#7ee8ac",
    rooms: [
      "Herbarium",
      "Ivy Gallery",
      "Watchtower",
      "Root Cellar",
      "Thorn Hall",
      "Old Chapel",
      "Overgrown Crypt",
      "Greenhouse",
      "Raven Nest",
    ],
    extra: [
      [0, 3],
      [1, 4],
      [3, 6],
      [5, 8],
    ],
  },
  {
    name: "Frostglass Citadel",
    sub: "Cold rooms, bright spirits",
    floor: "#263950",
    wall: "#456681",
    accent: "#83e2ff",
    rooms: [
      "Ice Library",
      "Mirror Room",
      "North Tower",
      "Frost Chapel",
      "Crystal Hall",
      "Winter Dining",
      "Frozen Crypt",
      "Observatory",
      "Glacier Vault",
    ],
    extra: [
      [0, 3],
      [2, 5],
      [4, 7],
      [5, 8],
    ],
  },
  {
    name: "Embercrown Castle",
    sub: "A furnace full of phantoms",
    floor: "#49303d",
    wall: "#754552",
    accent: "#ffb468",
    rooms: [
      "Ash Archive",
      "Ember Gallery",
      "Firewatch",
      "Smelter Stairs",
      "Cinder Hall",
      "Royal Kitchen",
      "Coal Crypt",
      "Dragon Chapel",
      "Crown Vault",
    ],
    extra: [
      [1, 4],
      [2, 5],
      [3, 6],
      [4, 7],
    ],
  },
  {
    name: "Eclipse Palace",
    sub: "The final royal haunting",
    floor: "#342c51",
    wall: "#624377",
    accent: "#f0a5ff",
    rooms: [
      "Forbidden Library",
      "Star Gallery",
      "Eclipse Tower",
      "Secret Stairs",
      "Throne Hall",
      "Banquet Room",
      "Royal Tomb",
      "Moon Chapel",
      "Spirit Treasury",
    ],
    extra: [
      [0, 3],
      [1, 4],
      [2, 5],
      [3, 6],
      [5, 8],
    ],
  },
];
export const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
export const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
export function seeded(seed) {
  let s = seed >>> 0;
  return () => {
    s = (Math.imul(s, 1664525) + 1013904223) >>> 0;
    return s / 4294967296;
  };
}
function key(x, y) {
  return x + "," + y;
}
export function makeCastle(index) {
  const c = CASTLES[index],
    rooms = [],
    floor = new Set(),
    props = [],
    doors = [];
  const widths = [7, 8, 7],
    heights = index % 2 ? [6, 7, 6] : [7, 6, 7];
  let ys = 1;
  for (let row = 0; row < 3; row++) {
    let xs = 1;
    for (let col = 0; col < 3; col++) {
      const i = row * 3 + col,
        w = widths[(col + index) % 3],
        h = heights[row],
        r = {
          id: i,
          name: c.rooms[i],
          x: xs,
          y: ys,
          w,
          h,
          cx: xs + w / 2,
          cy: ys + h / 2,
        };
      rooms.push(r);
      for (let y = r.y; y < r.y + h; y++)
        for (let x = r.x; x < r.x + w; x++) floor.add(key(x, y));
      props.push({
        x: r.x + 1.5,
        y: r.y + 1.5,
        room: i,
        kind: 10 + ((i + index) % 6),
        r: 0.55,
      });
      xs += w + 3;
    }
    ys += heights[row] + 3;
  }
  const edges = [
    [0, 1],
    [1, 2],
    [2, 5],
    [5, 4],
    [4, 3],
    [3, 6],
    [6, 7],
    [7, 8],
    ...c.extra,
  ];
  const unique = [];
  for (const [a, b] of edges) {
    const id = [a, b].sort().join("-");
    if (unique.some((e) => e.id === id)) continue;
    unique.push({ id, a, b });
    const ra = rooms[a],
      rb = rooms[b],
      horizontal = Math.abs(ra.cx - rb.cx) > Math.abs(ra.cy - rb.cy);
    let x, y;
    if (horizontal) {
      y = Math.floor((ra.cy + rb.cy) / 2);
      for (
        x = Math.floor(Math.min(ra.cx, rb.cx));
        x <= Math.ceil(Math.max(ra.cx, rb.cx));
        x++
      ) {
        floor.add(key(x, y));
        floor.add(key(x, y - 1));
      }
      x = (ra.cx + rb.cx) / 2;
      doors.push({
        id: doors.length,
        a,
        b,
        x: Math.floor(x) + 0.5,
        y: y,
        horizontal: true,
        closed: 0,
      });
    } else {
      x = Math.floor((ra.cx + rb.cx) / 2);
      for (
        y = Math.floor(Math.min(ra.cy, rb.cy));
        y <= Math.ceil(Math.max(ra.cy, rb.cy));
        y++
      ) {
        floor.add(key(x, y));
        floor.add(key(x - 1, y));
      }
      y = (ra.cy + rb.cy) / 2;
      doors.push({
        id: doors.length,
        a,
        b,
        x: x,
        y: Math.floor(y) + 0.5,
        horizontal: false,
        closed: 0,
      });
    }
  }
  return {
    index,
    ...c,
    rooms,
    floor,
    props,
    doors,
    edges: unique,
    width: Math.max(...rooms.map((r) => r.x + r.w)) + 1,
    height: Math.max(...rooms.map((r) => r.y + r.h)) + 1,
  };
}
export class HuntGame {
  constructor(seed = 20261106) {
    this.random = seeded(seed);
    this.seed = seed;
    this.time = 0;
    this.phase = "lobby";
    this.paused = false;
    this.epoch = 0;
    this.round = 0;
    this.remaining = 90;
    this.phaseTime = 0;
    this.players = COLORS.map((color, i) => ({
      i,
      color,
      human: i === 0,
      role: "hunter",
      x: 0,
      y: 0,
      heading: 0,
      score: 0,
      total: 0,
      captures: 0,
      allCaptures: 0,
      progress: 0,
      target: null,
      pulse: 0,
      reveal: 0,
      energy: 40,
      power: 0,
      powerCd: [0, 0, 0],
      victim: 0,
      jam: 0,
      jamImmune: 0,
      room: 0,
      eliminatedRound: null,
      lastCapture: 0,
      casts: 0,
      move: 0,
      notice: "",
      noticeTime: 0,
      path: [],
      aiTime: 0,
      aiRest: 0,
    }));
    this.ghosts = [];
    this.fx = [];
    this.events = [];
    this.roundResult = null;
    this.winner = null;
    this.nextGhost = 1;
    this.castle = makeCastle(0);
    this.placePlayers();
    this.spawnGhosts(28);
  }
  emit(type, data = {}) {
    this.events.push({ type, time: this.time, ...data });
    if (this.events.length > 100) this.events.shift();
  }
  ready(i) {
    if (this.phase !== "lobby") return;
    this.players[i].human = true;
    this.emit("join", { i });
  }
  start() {
    if (this.phase !== "lobby" && this.phase !== "finished") return;
    for (const p of this.players)
      Object.assign(p, {
        role: "hunter",
        score: 0,
        total: 0,
        captures: 0,
        allCaptures: 0,
        eliminatedRound: null,
        casts: 0,
        energy: 40,
        power: 0,
        powerCd: [0, 0, 0],
        jam: 0,
        jamImmune: 0,
        notice: "",
        noticeTime: 0,
      });
    this.winner = null;
    this.round = 0;
    this.nextRound();
  }
  lobby() {
    this.phase = "lobby";
    this.paused = false;
    this.epoch++;
    this.winner = null;
    this.roundResult = null;
    for (const p of this.players) {
      p.role = "hunter";
      p.score = 0;
      p.total = 0;
      p.captures = 0;
      p.allCaptures = 0;
      p.progress = 0;
      p.target = null;
    }
    this.castle = makeCastle(0);
    this.placePlayers();
    this.spawnGhosts(28);
  }
  nextRound() {
    this.castle = makeCastle(this.round);
    this.remaining = 90;
    this.phaseTime = 0;
    this.phase = "countdown";
    this.paused = false;
    this.epoch++;
    this.roundResult = null;
    this.fx = [];
    for (const p of this.players) {
      p.score = 0;
      p.captures = 0;
      p.lastCapture = 0;
      p.progress = 0;
      p.target = null;
      p.pulse = 0;
      p.reveal = 0;
      p.jam = 0;
      p.jamImmune = 0;
      p.powerCd = [0, 0, 0];
      p.energy = Math.max(40, p.energy);
      p.path = [];
      p.aiTime = 0;
      p.aiRest = 0;
      p.notice = "";
      p.noticeTime = 0;
    }
    this.placePlayers();
    this.spawnGhosts(30 + this.round * 3);
    this.emit("castle", { round: this.round });
  }
  placePlayers() {
    const ids = [0, 2, 6, 8, 3, 5];
    for (const p of this.players) {
      const r = this.castle.rooms[p.role === "captain" ? 4 : ids[p.i]];
      p.x = r.cx + 0.3 * (p.i % 2);
      p.y = r.cy;
      p.room = r.id;
      p.move = 0;
    }
  }
  roomAt(x, y) {
    return (
      this.castle.rooms.find(
        (r) => x >= r.x && x < r.x + r.w && y >= r.y && y < r.y + r.h,
      )?.id ??
      this.castle.rooms.reduce((best, r) =>
        Math.hypot(r.cx - x, r.cy - y) < Math.hypot(best.cx - x, best.cy - y)
          ? r
          : best,
      ).id
    );
  }
  spawnGhost(room, kind) {
    const r = this.castle.rooms[room],
      rare = kind === "rare" || (kind === undefined && this.random() < 0.22);
    let g;
    for (let n = 0; n < 40; n++) {
      g = {
        id: this.nextGhost++,
        room,
        x: r.x + 1 + this.random() * (r.w - 2),
        y: r.y + 1 + this.random() * (r.h - 2),
        kind: kind || (rare ? "rare" : "common"),
        value: rare ? 250 : 100,
        phase: this.random() * Math.PI * 2,
        life: kind === "decoy" ? 18 : Infinity,
      };
      if (this.walkable(g.x, g.y, 0)) break;
    }
    this.ghosts.push(g);
    return g;
  }
  spawnGhosts(n) {
    this.ghosts = [];
    for (let i = 0; i < n; i++) this.spawnGhost(i % 9);
  }
  walkable(x, y, r = 0.22) {
    for (const [dx, dy] of [
      [-r, -r],
      [r, -r],
      [-r, r],
      [r, r],
    ])
      if (!this.castle.floor.has(key(Math.floor(x + dx), Math.floor(y + dy))))
        return false;
    for (const o of this.castle.props)
      if (Math.hypot(o.x - x, o.y - y) < o.r + r) return false;
    for (const d of this.castle.doors)
      if (
        d.closed > 0 &&
        (d.horizontal
          ? Math.abs(x - d.x) < 0.3 + r && Math.abs(y - d.y) < 1 + r
          : Math.abs(y - d.y) < 0.3 + r && Math.abs(x - d.x) < 1 + r)
      )
        return false;
    return true;
  }
  lineClear(a, b) {
    const n = Math.ceil(dist(a, b) / 0.18);
    for (let i = 1; i < n; i++) {
      const t = i / n;
      if (!this.walkable(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t, 0))
        return false;
    }
    return true;
  }
  movePlayer(p, dx, dy, dt) {
    const n = Math.hypot(dx, dy);
    p.move = n ? 1 : 0;
    if (!n) return;
    const speed = p.role === "captain" ? 4.3 : 3.65;
    dx = (dx / n) * speed * dt;
    dy = (dy / n) * speed * dt;
    p.heading = Math.atan2(dy, dx);
    if (p.role === "captain") {
      p.x = clamp(p.x + dx, 0.6, this.castle.width - 0.6);
      p.y = clamp(p.y + dy, 0.6, this.castle.height - 0.6);
    } else {
      if (this.walkable(p.x + dx, p.y)) p.x += dx;
      if (this.walkable(p.x, p.y + dy)) p.y += dy;
    }
    p.room = this.roomAt(p.x, p.y);
  }
  pulse(i) {
    const p = this.players[i];
    if (
      this.phase !== "play" ||
      this.paused ||
      p.role !== "hunter" ||
      p.pulse > 0
    )
      return false;
    p.pulse = 6;
    p.reveal = 3;
    this.fx.push({ type: "pulse", x: p.x, y: p.y, i, t: 0, life: 1.2 });
    this.emit("pulse", { i });
    return true;
  }
  selectPower(i, dir) {
    const p = this.players[i];
    if (p.role === "captain") p.power = (p.power + dir + 3) % 3;
  }
  cycleVictim(i) {
    const p = this.players[i],
      ids = this.players.filter((q) => q.role === "hunter").map((q) => q.i);
    p.victim = ids[(ids.indexOf(p.victim) + 1) % ids.length] ?? 0;
  }
  cast(i) {
    const p = this.players[i],
      power = POWERS[p.power];
    if (
      this.phase !== "play" ||
      this.paused ||
      p.role !== "captain" ||
      p.energy < power.cost ||
      p.powerCd[p.power] > 0
    )
      return false;
    let success = false;
    if (p.power === 0) {
      const g = this.spawnGhost(p.room, "decoy");
      g.owner = i;
      success = true;
    }
    if (p.power === 1) {
      const door = this.castle.doors
        .filter((d) => (d.a === p.room || d.b === p.room) && d.closed <= 0)
        .sort((a, b) => dist(p, a) - dist(p, b))
        .find(
          (d) =>
            !this.players.some(
              (q) =>
                q.role === "hunter" &&
                (d.horizontal
                  ? Math.abs(q.x - d.x) < 0.8 && Math.abs(q.y - d.y) < 1.4
                  : Math.abs(q.y - d.y) < 0.8 && Math.abs(q.x - d.x) < 1.4),
            ),
        );
      if (door) {
        door.closed = 8;
        door.owner = i;
        success = true;
      }
    }
    if (p.power === 2) {
      let q = this.players[p.victim];
      if (!q || q.role !== "hunter") {
        q = this.players.find((q) => q.role === "hunter");
        p.victim = q?.i ?? 0;
      }
      if (q && q.jam <= 0 && q.jamImmune <= 0) {
        q.jam = 6;
        q.jamImmune = 10;
        q.notice = "TRACKER JAMMED / B TO PULSE";
        q.noticeTime = 3;
        success = true;
      }
    }
    if (!success) {
      p.notice =
        p.power === 1
          ? "Door occupied / choose another room"
          : "Target protected / choose another hunter";
      p.noticeTime = 2;
      return false;
    }
    p.energy -= power.cost;
    p.powerCd[p.power] = power.cooldown;
    p.casts++;
    p.notice = power.id + " DEPLOYED";
    p.noticeTime = 2;
    this.emit("haunt", { i, power: p.power, room: p.room });
    this.fx.push({ type: "haunt", x: p.x, y: p.y, i, t: 0, life: 1 });
    return true;
  }
  targetFor(p) {
    return (
      this.ghosts
        .filter((g) => dist(p, g) < 2.25 && this.lineClear(p, g))
        .sort((a, b) => dist(p, a) - dist(p, b))[0] || null
    );
  }
  capture(p, g) {
    const at = this.ghosts.indexOf(g);
    if (at < 0) return false;
    this.ghosts.splice(at, 1);
    p.progress = 0;
    p.target = null;
    if (g.kind === "decoy") {
      p.notice = "FALSE SIGNAL / NO POINTS";
      p.noticeTime = 1.5;
      this.emit("decoy", { i: p.i });
      return true;
    }
    p.score += g.value;
    p.total += g.value;
    p.captures++;
    p.allCaptures++;
    p.lastCapture = 90 - this.remaining;
    if (!p.human) p.aiRest = 0.4 + this.random() * 0.6;
    p.notice =
      "+" +
      g.value +
      " / " +
      (g.kind === "rare" ? "ROYAL SPIRIT" : "GHOST COLLECTED");
    p.noticeTime = 1.4;
    this.fx.push({
      type: "capture",
      x: g.x,
      y: g.y,
      i: p.i,
      t: 0,
      life: 0.9,
      value: g.value,
    });
    this.emit("capture", { i: p.i, value: g.value });
    this.spawnGhost(Math.floor(this.random() * 9));
    return true;
  }
  path(a, b) {
    const start = [Math.floor(a.x), Math.floor(a.y)],
      goal = [Math.floor(b.x), Math.floor(b.y)],
      queue = [start],
      seen = new Map([[key(...start), null]]);
    let found = null;
    for (let h = 0; h < queue.length; h++) {
      const q = queue[h];
      if (Math.abs(q[0] - goal[0]) + Math.abs(q[1] - goal[1]) <= 1) {
        found = q;
        break;
      }
      for (const [dx, dy] of [
        [1, 0],
        [-1, 0],
        [0, 1],
        [0, -1],
      ]) {
        const n = [q[0] + dx, q[1] + dy],
          k = key(...n);
        if (!seen.has(k) && this.walkable(n[0] + 0.5, n[1] + 0.5, 0.18)) {
          seen.set(k, q);
          queue.push(n);
        }
      }
    }
    if (!found) return [];
    const out = [];
    for (let q = found; q; q = seen.get(key(...q)))
      out.push({ x: q[0] + 0.5, y: q[1] + 0.5 });
    return out.reverse().slice(1);
  }
  bot(p, dt) {
    if (p.role === "captain") {
      p.aiTime -= dt;
      if (p.aiTime <= 0) {
        p.aiTime = 2 + this.random() * 3;
        p.power = Math.floor(this.random() * 3);
        this.cycleVictim(p.i);
        this.cast(p.i);
        const r = this.castle.rooms[Math.floor(this.random() * 9)];
        p.aiGoal = { x: r.cx, y: r.cy };
      }
      const goal = p.aiGoal || { x: p.x, y: p.y };
      return { x: goal.x - p.x, y: goal.y - p.y, a: false };
    }
    if (p.aiRest > 0) {
      p.aiRest -= dt;
      return { x: 0, y: 0, a: false };
    }
    const close = this.targetFor(p);
    if (close && close.kind !== "decoy") return { x: 0, y: 0, a: true };
    p.aiTime -= dt;
    if (p.aiTime <= 0 || !p.path?.length) {
      p.aiTime = 0.6;
      const target = this.ghosts
        .filter((g) => g.kind !== "decoy")
        .sort((a, b) => dist(p, a) - dist(p, b))[0];
      p.path = target ? this.path(p, target) : [];
      if (p.pulse <= 0) this.pulse(p.i);
    }
    const n = p.path?.[0];
    if (n && dist(p, n) < 0.18) p.path.shift();
    return n
      ? { x: n.x - p.x, y: n.y - p.y, a: false }
      : { x: 0, y: 0, a: false };
  }
  finishRound() {
    const alive = this.players.filter((p) => p.role === "hunter");
    const order = [...alive].sort(
      (a, b) =>
        a.score - b.score ||
        a.captures - b.captures ||
        a.total - b.total ||
        b.lastCapture - a.lastCapture,
    );
    const first = order[0];
    const tied = order.filter(
      (p) =>
        p.score === first.score &&
        p.captures === first.captures &&
        p.total === first.total &&
        p.lastCapture === first.lastCapture,
    );
    const loser = tied[Math.floor(this.random() * tied.length)];
    loser.role = "captain";
    loser.eliminatedRound = this.round;
    loser.progress = 0;
    loser.target = null;
    loser.energy = 40;
    for (const p of this.players)
      if (p.role === "captain" && this.players[p.victim]?.role !== "hunter")
        p.victim = this.players.find((q) => q.role === "hunter")?.i ?? 0;
    this.roundResult = {
      loser: loser.i,
      curseDraw: tied.length > 1,
      standings: [...alive]
        .sort((a, b) => b.score - a.score || b.captures - a.captures)
        .map((p) => ({
          i: p.i,
          score: p.score,
          captures: p.captures,
          total: p.total,
        })),
    };
    this.emit("elimination", { i: loser.i });
    this.epoch++;
    this.phaseTime = 0;
    if (this.round === 4) {
      this.winner = this.players.find((p) => p.role === "hunter")?.i ?? null;
      this.phase = "finished";
      this.emit("winner", { i: this.winner });
    } else this.phase = "results";
  }
  update(dt, controls = []) {
    dt = clamp(dt, 0, 0.05);
    if (this.paused) return;
    if (this.phase === "play") dt = Math.min(dt, this.remaining);
    this.time += dt;
    this.phaseTime += dt;
    if (this.phase === "lobby") {
      return;
    }
    if (this.phase === "countdown") {
      if (this.phaseTime >= 3) {
        this.phase = "play";
        this.phaseTime = 0;
        this.epoch++;
        this.emit("go");
      }
      return;
    }
    if (this.phase === "results") {
      if (this.phaseTime >= 8) {
        this.round++;
        this.nextRound();
      }
      return;
    }
    if (this.phase !== "play") return;
    this.remaining = Math.max(0, this.remaining - dt);
    for (const d of this.castle.doors) d.closed = Math.max(0, d.closed - dt);
    for (const g of this.ghosts) {
      g.life -= dt;
      if (g.kind !== "decoy") {
        const r = this.castle.rooms[g.room],
          a = this.time * 0.7 + g.phase;
        const nx = g.x + Math.cos(a) * dt * 0.38,
          ny = g.y + Math.sin(a * 1.4) * dt * 0.38;
        if (
          nx > r.x + 0.7 &&
          nx < r.x + r.w - 0.7 &&
          ny > r.y + 0.7 &&
          ny < r.y + r.h - 0.7 &&
          this.walkable(nx, ny, 0)
        ) {
          g.x = nx;
          g.y = ny;
        }
      }
    }
    this.ghosts = this.ghosts.filter((g) => g.life > 0);
    const complete = [];
    for (const p of this.players) {
      p.pulse = Math.max(0, p.pulse - dt);
      p.reveal = Math.max(0, p.reveal - dt);
      p.jam = Math.max(0, p.jam - dt);
      p.jamImmune = Math.max(0, p.jamImmune - dt);
      p.noticeTime = Math.max(0, p.noticeTime - dt);
      p.powerCd = p.powerCd.map((t) => Math.max(0, t - dt));
      if (p.role === "captain") p.energy = Math.min(100, p.energy + dt * 6);
      const ctl = p.human ? controls[p.i] || {} : this.bot(p, dt);
      this.movePlayer(p, ctl.x || 0, ctl.y || 0, dt);
      if (p.role === "captain") {
        if (ctl.cast) this.cast(p.i);
        continue;
      }
      const g = ctl.a ? this.targetFor(p) : null;
      if (!g) {
        p.progress = 0;
        p.target = null;
        continue;
      }
      if (p.target !== g.id) {
        p.progress = 0;
        p.target = g.id;
      }
      p.progress +=
        dt / (g.kind === "rare" ? 1.3 : g.kind === "decoy" ? 0.55 : 0.9);
      if (p.progress >= 1) complete.push({ p, g, tie: this.random() });
    }
    complete
      .sort((a, b) => a.tie - b.tie)
      .forEach(({ p, g }) => this.capture(p, g));
    this.fx.forEach((f) => (f.t += dt));
    this.fx = this.fx.filter((f) => f.t < f.life);
    if (this.remaining <= 0) this.finishRound();
  }
  togglePause() {
    if (!["play", "countdown"].includes(this.phase)) return;
    this.paused = !this.paused;
    this.epoch++;
    for (const p of this.players) {
      p.progress = 0;
      p.target = null;
    }
  }
  dashboard(i) {
    const p = this.players[i],
      g = this.ghosts.find((g) => g.id === p.target),
      near = this.ghosts
        .filter((g) => g.kind !== "decoy" || p.reveal <= 0)
        .sort((a, b) => dist(p, a) - dist(p, b))[0];
    return {
      role: p.role,
      score: p.score,
      total: p.total,
      captures: p.captures,
      signal:
        p.jam > 0 && p.reveal <= 0
          ? 0
          : near
            ? clamp(1 - dist(p, near) / 9, 0, 1)
            : 0,
      lock: clamp(p.progress, 0, 1),
      targetRare: g?.kind === "rare",
      jammed: p.jam > 0,
      pulseReady: p.pulse <= 0,
      energy: p.energy,
      power: p.power,
      room: p.room,
      phase: this.phase,
      time: this.remaining,
    };
  }
}
