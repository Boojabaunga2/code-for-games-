"""Start your existing Arcadium OS with the shared live-game host enabled.

Only Haunt & Seek game files and its catalogue entry are installed. Existing OS
server, bridge, controller receiver, pairing and other games are never rewritten.
The additional routing is attached in memory for this normal server session.
"""
from pathlib import Path
import datetime
import hashlib
import importlib
import json
import os
import runpy
import shutil
import socket
import sys
import threading
import time
import urllib.error
import urllib.request
import webbrowser

SOURCE=Path(__file__).resolve().parent
SLUG='haunt-and-seek'

def digest(data):return hashlib.sha256(data).hexdigest()
def atomic(path,data):
    temp=path.with_name(path.name+'.haunt-seek.tmp')
    try:temp.write_bytes(data);os.replace(temp,path)
    finally:temp.unlink(missing_ok=True)

def verify_package():
    path=SOURCE/'CHECKSUMS.json'
    if not path.is_file():raise RuntimeError('Extract the entire ZIP first. CHECKSUMS.json is missing.')
    for name,expected in json.loads(path.read_text()).items():
        p=(SOURCE/name).resolve()
        if not p.is_relative_to(SOURCE.resolve()) or not p.is_file() or digest(p.read_bytes())!=expected:raise RuntimeError('Package file missing or changed: '+name)

def install_game(root):
    """Backed-up game/data installation. No interpreter searches or code patches."""
    root=Path(root).resolve();verify_package()
    for name in ('arcadium_server.py','arcadium_game_bridge.py','universal_input_routes.py','data/arcadium.json'):
        if not (root/name).is_file():raise RuntimeError('Choose the existing shared-controller Arcadium_OS_COMPACT folder. Missing '+name)
    catalog=json.loads((root/'data/arcadium.json').read_text(encoding='utf-8-sig'))
    if not isinstance(catalog.get('games'),list):raise RuntimeError('Unrecognized Arcadium catalogue; nothing changed.')
    matching=[g for g in catalog['games'] if g.get('id')==SLUG]
    if len(matching)>1:raise RuntimeError('Duplicate Haunt & Seek entries; nothing changed.')
    meta=json.loads((SOURCE/'games'/SLUG/'arcadium-game.json').read_text())
    if matching:matching[0].update(meta)
    else:catalog['games'].append(meta)
    writes={Path('data/arcadium.json'):(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n').encode()}
    for p in sorted((SOURCE/'games'/SLUG).rglob('*')):
        if p.is_file():writes[Path('games')/SLUG/p.relative_to(SOURCE/'games'/SLUG)]=p.read_bytes()
    for rel in writes:
        if not (root/rel).resolve().is_relative_to(root):raise RuntimeError('Game destination escapes selected OS folder.')
    changed={p:b for p,b in writes.items() if not (root/p).is_file() or (root/p).read_bytes()!=b}
    if not changed:return None
    backup=root/'arcadium_backups'/('haunt_seek_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f'));backup.mkdir(parents=True)
    manifest={}
    for rel,data in changed.items():
        dst=root/rel;exists=dst.exists();manifest[rel.as_posix()]={'existed':exists,'new_sha256':digest(data)}
        if exists:
            saved=backup/rel;saved.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(dst,saved)
    (backup/'manifest.json').write_text(json.dumps(manifest,indent=2))
    done=[]
    try:
        for rel,data in changed.items():
            dst=root/rel;dst.parent.mkdir(parents=True,exist_ok=True);atomic(dst,data);done.append(rel)
    except Exception:
        for rel in reversed(done):
            if manifest[rel.as_posix()]['existed']:atomic(root/rel,(backup/rel).read_bytes())
            else:(root/rel).unlink(missing_ok=True)
        raise
    return backup

def port_open():
    try:
        with socket.create_connection(('127.0.0.1',8787),timeout=.4):return True
    except OSError:return False

def shared_host_running():
    try:
        with urllib.request.urlopen('http://127.0.0.1:8787/arcadium-live/'+SLUG+'/status',timeout=1) as r:return json.load(r).get('protocol')==1
    except (OSError,ValueError,urllib.error.URLError):return False

def choose_root():
    from tkinter import filedialog
    cfg=SOURCE/'arcadium-location.json'
    if cfg.is_file():
        try:
            p=Path(json.loads(cfg.read_text())['root'])
            if (p/'arcadium_server.py').is_file():return p
        except (ValueError,KeyError,TypeError):pass
    folder=filedialog.askdirectory(title='Select your existing Arcadium_OS_COMPACT folder')
    return Path(folder) if folder else None

def main():
    import tkinter as tk
    from tkinter import messagebox
    ui=tk.Tk();ui.withdraw()
    try:
        verify_package();root=choose_root()
        if root is None:return
        while port_open():
            if shared_host_running():webbrowser.open('http://127.0.0.1:8787/games/'+SLUG+'/index.html');return
            if not messagebox.askretrycancel('Arcadium is already running','Close the existing Arcadium SERVER window (the black console), then click Retry. This launcher keeps all your existing games and pairing. It will not stop processes or change your server files.'):return
        backup=install_game(root)
        atomic(SOURCE/'arcadium-location.json',json.dumps({'root':str(root.resolve())}).encode())
    except Exception as e:
        messagebox.showerror('Haunt & Seek could not start',str(e));return
    finally:ui.destroy()
    if backup:print('Haunt & Seek game/data backup:',backup)
    run_existing_server(root)

def run_existing_server(root,open_browser=True):
    sys.path.insert(0,str(SOURCE))
    from arcadium_live_host import wrap_live_handler
    root=root.resolve();sys.path.insert(0,str(root));os.chdir(root)
    # Import the installed bridge normally, then add a standard wrapper in memory.
    bridge=importlib.import_module('arcadium_game_bridge')
    if not callable(getattr(bridge,'bridge',None)) or not hasattr(bridge,'ACTIVE_WEB_GAME') or not hasattr(bridge,'ACTIVE_LOCK'):raise RuntimeError('Existing Arcadium shared bridge is unavailable; server files were not modified.')
    existing=bridge.bridge
    def live_bridge(base):return wrap_live_handler(existing(base),root/'games')
    bridge.bridge=live_bridge
    print('Starting your existing Arcadium server with shared live-game support. No server source or controller app was replaced.')
    def open_when_ready():
        for _ in range(100):
            if shared_host_running():webbrowser.open('http://127.0.0.1:8787/games/'+SLUG+'/index.html');return
            time.sleep(.2)
    if open_browser:threading.Thread(target=open_when_ready,daemon=True).start()
    sys.argv=[str(root/'arcadium_server.py')]
    runpy.run_path(str(root/'arcadium_server.py'),run_name='__main__')

if __name__=='__main__':main()
